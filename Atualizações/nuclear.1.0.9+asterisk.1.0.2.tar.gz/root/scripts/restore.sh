#!/bin/bash
ARQUIVO=$1
cd /var/www/upload
/usr/bin/unzip -u -P pbxerix@@pbxerix /var/www/upload/$ARQUIVO
/bin/tar -zxvf pbxerix.tar.gz -C /
rm /var/www/upload/pbxerix.tar.gz
rm /var/www/upload/$ARQUIVO

user=$(cat /var/lib/asterisk/config.db.ini | grep dbuser |cut -d "=" -f 2 | tr -d '[:space:]')
pass=$(cat /var/lib/asterisk/config.db.ini | grep dbpass |cut -d "=" -f 2 | tr -d '[:space:]')

mysql -u $user -p$pass < /root/backup_db.sql 
rm /root/backup_db.sql

reboot
