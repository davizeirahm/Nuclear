#!/bin/bash
echo $1 > /etc/hostname
echo $1 > /proc/sys/kernel/hostname
/etc/init.d/hostname.sh
