#!/bin/bash
#dados do arquivos de backup
ARQUIVO="pbxerix.tar.gz"

user=$(cat /var/lib/asterisk/config.db.ini | grep dbuser |cut -d "=" -f 2 | tr -d '[:space:]')
pass=$(cat /var/lib/asterisk/config.db.ini | grep dbpass |cut -d "=" -f 2 | tr -d '[:space:]')

mysqldump -u $user -p$pass --databases asteriskcdrdb asterisk discador fop2 > /root/backup_db.sql

#Diretorios que serão backapeados
DIRETORIOS="/etc/asterisk /etc/resolv.conf /etc/sudoers /etc/hostname /etc/hosts /etc/rc.local
/etc/dahdi/modules /etc/dahdi/system.conf 
/etc/network/interfaces /etc/network/rout.sh /etc/fail2ban/jail.conf /etc/fail2ban/filter.d/asterisk.conf
/home/*.* /root/scripts
/usr/firewall.sh /usr/firewall.stop.sh /usr/RANGE_BRASIL /usr/crontab.sh
/root/backup_db.sql
/var/lib/asterisk/*.* /var/lib/asterisk/scripts /var/lib/asterisk/agi-bin
/var/lib/asterisk/sounds/ura/* /var/lib/asterisk/sounds/queue/* /var/lib/asterisk/mohmp3/* /var/lib/asterisk/sounds/custom
/var/spool/cron/crontabs/root  
/usr/local/fop2/user.cfg /usr/local/fop2/buttons.cfg /usr/local/fop2/fop2.cfg /var/www/fop2/config.php
/var/www/erixpabxip/config/*.ini /var/www/monitor*"

# Cria o arquivo .tar.gz no /root (Temporário)
tar zcf /root/$ARQUIVO $DIRETORIOS
zip -j -P pbxerix@@pbxerix /tmp/backup-pbxerix-$(date +%Y-%m-%d).erix /root/pbxerix.tar.gz > /dev/null

rm /root/backup_db.sql
rm /root/pbxerix.tar.gz

echo "OK"
