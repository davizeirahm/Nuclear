-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb2
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: 26/01/2019 às 13:33:45
-- Versão do Servidor: 5.5.33
-- Versão do PHP: 5.4.4-14+deb7u7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `asteriskcdrdb`
--

-- UPDATE mysql.user SET Grant_priv='Y', Super_priv='Y' WHERE User='root';
-- CREATE USER 'nuclear'@'%' IDENTIFIED VIA mysql_native_password USING '***';GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, FILE, INDEX, ALTER ON *.* TO 'nuclear'@'%' REQUIRE NONE WITH MAX_QUERIES_PER_HOUR 0 MAX_CONNECTIONS_PER_HOUR 0 MAX_UPDATES_PER_HOUR 0 MAX_USER_CONNECTIONS 0;

-- GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, INDEX, ALTER ON `asterisk`.* TO 'nuclear'@'%'; GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, INDEX, ALTER ON `asteriskcdrdb`.* TO 'nuclear'@'%'; GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, INDEX, ALTER ON `erimat`.* TO 'nuclear'@'%'; GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, INDEX, ALTER ON `erixagenda`.* TO 'nuclear'@'%'; GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, INDEX, ALTER ON `erixcallback`.* TO 'nuclear'@'%'; GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, INDEX, ALTER ON `fop2`.* TO 'nuclear'@'%'; GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, INDEX, ALTER ON `queuelog`.* TO 'nuclear'@'%';

REVOKE ALL PRIVILEGES ON *.* FROM 'nuclear'@'%'; REVOKE GRANT OPTION ON *.* FROM 'nuclear'@'%'; GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, FILE, INDEX, ALTER, LOCK TABLES ON *.* TO 'nuclear'@'%' REQUIRE NONE WITH MAX_QUERIES_PER_HOUR 0 MAX_CONNECTIONS_PER_HOUR 0 MAX_UPDATES_PER_HOUR 0 MAX_USER_CONNECTIONS 0;

ALTER TABLE `asterisk`.`agents` ADD `agendar` BOOLEAN NULL AFTER `ramal`;

DROP TABLE IF EXISTS `asteriskcdrdb`.`disc_agendamento`, `asteriskcdrdb`.`disc_agentestatus`, `asteriskcdrdb`.`disc_campanhas`, `asteriskcdrdb`.`disc_formulario`, `asteriskcdrdb`.`disc_numeros`, `asteriskcdrdb`.`disc_qualificacao`, `asteriskcdrdb`.`disc_status`;

-- --------------------------------------------------------

--
-- Estrutura para tabela `pbxerix_blacklist`
--

CREATE TABLE IF NOT EXISTS `asteriskcdrdb`.`pbxerix_blacklist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero` varchar(20) NOT NULL,
  `entrada` tinyint(1) DEFAULT NULL,
  `saida` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Estrutura para tabela `pbxerix_agendar`
--

CREATE TABLE IF NOT EXISTS `asteriskcdrdb`.`pbxerix_agendar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `calldate` datetime NOT NULL,
  `ramal` varchar(30) DEFAULT NULL,
  `numero` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Estrutura da tabela `pbxerix_modules`
--

CREATE TABLE IF NOT EXISTS `asteriskcdrdb`.`pbxerix_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `module` varchar(50) NOT NULL,
  `position` int(11) NOT NULL,
  `icon` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

TRUNCATE TABLE `asteriskcdrdb`.`pbxerix_modules`;

INSERT INTO `asteriskcdrdb`.`pbxerix_modules` (`id`, `name`, `module`, `position`, `icon`) VALUES
(1, 'Sistema', 'sistema', 1, 'settings'),
(2, 'Ramais e Troncos', 'ramais_troncos', 2, 'phone'),
(3, 'PBX Config', 'pbxconfig',  3, 'settings_applications'),
(4, 'Relatórios', 'relatorios', 4, 'poll'),
(5, 'Status', 'status', 5, 'reorder'),
(6, 'Painel', 'painel', 6, 'desktop_windows'),
(7, 'Aplicativos', 'aplicativos', 7, 'apps');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

--
-- Estrutura para tabela `pbxerix_pages`
--

CREATE TABLE IF NOT EXISTS `asteriskcdrdb`.`pbxerix_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_module` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `page` varchar(50) NOT NULL,
  `onlysuper` int(11) NOT NULL,
  `link` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=39;

TRUNCATE TABLE `asteriskcdrdb`.`pbxerix_pages`;

INSERT INTO `asteriskcdrdb`.`pbxerix_pages` (`id`, `id_module`, `position`, `name`, `page`, `onlysuper`, `link`) VALUES
(1, 1, 1, 'Informações', 'informacoes', 0, ''),
(2, 1, 2, 'Network', 'network', 0, ''),
(3, 1, 3, 'Firewall', 'firewall', 0, ''),
(4, 1, 4, 'Geral SIP', 'geral_sip', 0, ''),
(5, 1, 5, 'Usuários', 'usuarios', 0, ''),
(6, 1, 6, 'Backup', 'backup', 0, ''),
(7, 1, 7, 'Console', 'console', 0, ''),
(8, 1, 8, 'Anotações', 'anotacoes', 0, ''),

(9, 2, 1, 'Ramais SIP', 'ramais_sip', 0, ''),
(10, 2, 2, 'Ramais IAX2', 'ramais_iax2', 0, ''),
(11, 2, 3, 'Faixa de Discagem', 'faixa_discagem', 0, ''),
(12, 2, 4, 'Siga-me', 'sigame', 0, ''),
(13, 2, 5, 'Contábil', 'contabil', 0, ''),
(14, 2, 6, 'Tronco SIP', 'tronco_sip', 0, ''),
(15, 2, 7, 'Tronco IAX2', 'tronco_iax2', 0, ''),
(16, 2, 8, 'Config E1', 'config_e1', 0, ''),

(17, 3, 1, 'Rotas de Saída', 'rotas_saida', 0, ''),
(18, 3, 2, 'Categorias', 'categorias', 0, ''),
(19, 3, 3, 'Entrada', 'entrada', 0, ''),
(20, 3, 4, 'Calendário', 'calendario', 0, ''),
(21, 3, 5, 'URA', 'ura', 0, ''),
(22, 3, 6, 'Filas', 'filas', 0, ''),
(23, 3, 7, 'Agentes', 'agentes', 0, ''),
(24, 3, 8, 'Músicas', 'musicas', 0, ''),
(25, 3, 9, 'Abreviados', 'abreviados', 0, ''),
(26, 3, 10, 'Salas de Conferência', 'conferencias', 0, ''),
(27, 3, 11, 'Noturno', 'noturno', 0, ''),
-- (28, 3, 12, 'Telefonista', 'telefonista', 0, ''),
(29, 3, 13, 'Redirecionamento', 'redir', 0, ''),
(30, 3, 14, 'Blacklist', 'blacklist', 0, ''),
(31, 3, 15, 'Funcionalidades', 'funcionalidades', 0, ''),

(32, 4, 1, 'Sintético', 'sintetico', 0, ''),
(33, 4, 2, 'Analítico', 'analitico', 0, ''),

(34, 5, 1, 'SIP', 'sip', 0, ''),
(35, 5, 2, 'Grupos', 'grupos', 0, ''),

(36, 7, 1, 'Agendar', 'agendar', 0, ''),
(37, 7, 2, 'Nuclear Call Center', 'nuclear', 0, ''),
(38, 7, 3, 'Painel de ramais', 'mesa', 0, '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

--
-- Estrutura da tabela `pbxerix_permissions`
--

CREATE TABLE IF NOT EXISTS `asteriskcdrdb`.`pbxerix_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_page` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

--
-- Estrutura da tabela `pbxerix_cdr`
--

CREATE TABLE IF NOT EXISTS `asteriskcdrdb`.`pbxerix_cdr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniqueid` varchar(32) NOT NULL,
  `linkedid` varchar(32) NOT NULL,
  `sequence` varchar(32) NOT NULL,
  `calldate` datetime NOT NULL,
  `tipo` varchar(20) NOT NULL,
  `ddr` varchar(32) DEFAULT NULL,
  `ura` varchar(32) DEFAULT NULL,
  `menu` varchar(32) DEFAULT NULL,
  `queue` varchar(30) DEFAULT NULL,
  `origem` varchar(80) DEFAULT NULL,
  `destino` varchar(80) DEFAULT NULL,
  `trf` varchar(80) DEFAULT NULL,
  `cidade` varchar(40) DEFAULT NULL,
  `audio` varchar(155) DEFAULT NULL,
  `status` varchar(60) DEFAULT NULL,
  `holdtime` int(11) DEFAULT NULL,
  `callduration` int(11) DEFAULT NULL,
  `tronco` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=0;
	
-- ALTER TABLE asteriskcdrdb.pbxerix_cdr DISCARD TABLESPACE;
