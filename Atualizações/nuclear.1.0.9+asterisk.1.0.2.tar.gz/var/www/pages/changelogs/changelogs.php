    <div class="container-fluid">
		<!-- Changelogs -->
		<div class="block-header">
			<h2>CHANGELOGS</h2>
		</div>
		<div class="row clearfix">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="card">
					<div class="header">
						<h2>
							v1.0.9
							<small>13 de Fevereiro de 2020</small>
						</h2>
					</div>
					<div class="body">
						<p>- Update Interface Gráfica modo offline</p>
					</div>
				</div>
			</div>
		</div>
		<div class="row clearfix">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="card">
					<div class="header">
						<h2>
							v1.0.8
							<small>10 de Fevereiro de 2020</small>
						</h2>
					</div>
					<div class="body">
						<p>- Backup: Atualização de script de backup e restauração</p>
					</div>
				</div>
			</div>
		</div>
		<div class="row clearfix">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="card">
					<div class="header">
						<h2>
							v1.0.7
							<small>10 de Janeiro de 2020</small>
						</h2>
					</div>
					<div class="body">
						<p>- Filas: Adcionada opção announce-to-first-user</p>
						<p>- Update Nuclear Call Center página de login de agente</p>
					</div>
				</div>
			</div>
		</div>
		<div class="row clearfix">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="card">
					<div class="header">
						<h2>
							v1.0.6
							<small>09 de Janeiro de 2020</small>
						</h2>
					</div>
					<div class="body">
						<p>- Filas: Problema ao selecionar áudio em branco nos anúncios periódicos</p>
						<p>- URA: Menu não sendo mostrado na tela devido a faixa de discagem com mesmo digito inicial</p>
					</div>
				</div>
			</div>
		</div>
		<div class="row clearfix">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="card">
					<div class="header">
						<h2>
							v1.0.5
							<small>20 de Dezembro de 2019</small>
						</h2>
					</div>
					<div class="body">
						<p>- Calendário: Agora mostra no destino as URAs customizadas</p>
						<p>- URA: Menu vazio estava sendo salvo, ao editar prioridade estava vindo com valor vazio</p>
					</div>
				</div>
			</div>
		</div>
		<div class="row clearfix">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="card">
					<div class="header">
						<h2>
							v1.0.3
							<small>04 de Dezembro de 2019</small>
						</h2>
					</div>
					<div class="body">
						<p>- Adicionado ajuste para ramal CRM em Ramais Troncos -> Ramais SIP</p>
					</div>
				</div>
			</div>
		</div>
		<div class="row clearfix">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="card">
					<div class="header">
						<h2>
							v1.0.2
							<small>29 de Novembro de 2019</small>
						</h2>
					</div>
					<div class="body">
						<p>- Queue reload all ao editar filas estava deslogando os agentes</p>
						<p>- Outros ajustes</p>
					</div>
				</div>
			</div>
		</div>
		<div class="row clearfix">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="card">
					<div class="header">
						<h2>
							v1.0.1
							<small>26 de Novembro de 2019</small>
						</h2>
					</div>
					<div class="body">
						<p>- Primeira Release</p>
					</div>
				</div>
			</div>
		</div>
    </div>

<!--1.9.0-->
<!--1: Major revision (new UI, lots of new features, conceptual change, etc.)-->
<!--9: Minor revision (maybe a change to a search box, 1 feature added, collection of bug fixes)-->
<!--0: Bug fix release-->