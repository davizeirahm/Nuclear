<?php
?>

<script type='text/javascript'>
	document.location.assign('/nuclear');
</script>