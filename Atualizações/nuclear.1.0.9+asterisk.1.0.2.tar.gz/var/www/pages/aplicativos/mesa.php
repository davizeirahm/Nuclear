<?php
?>

<script type='text/javascript'>
	document.location.assign('/mesa');
</script>