<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.db.php");
	require_once(DIR_WWW."funcoes/funcoes.aplicativos.agendar.php");
	
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_sip.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_iax2.php");
	
	//COMANDOS ===========================================================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "agendar") {
		
		$erro = "";
		if ( $_POST['ramal'] == "" || !is_numeric($_POST['ramal']) ) {
			$erro = "Erro: Ramal inválido!";
		} 
		if ( $_POST['numero'] == "" || !is_numeric($_POST['numero']) ) {
			$erro = "Erro: Número inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		log_agendar($_POST['ramal'],$_POST['numero']);
		originateAsterisk($_POST['ramal'],$_POST['numero']);

	}
	
	//VARIAVEIS ==========================================================================================================
	
	$ramais_sip = get_ramais();
	$ramais_iax2 = get_ramais_iax();
	
	$relatorio = get_relatorio();
	
?>

	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- AGENDAR LIGAÇÃO -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
                                	<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
						</div>
                        <div class="body">

							<div class="demo-masked-input">
								<form id="formNovoUsuario" method="post">
									<?=$text_form;?>
									<input type="hidden" name="cmd" value="agendar" />
									
									<div class="row clearfix">
										<div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
											<label for="ramal_agendarChamada">Ramal</label>
										</div>
										<div class="col-lg-3 col-md-3 col-sm-8 col-xs-7">
											<div class="form-group form-float" style="margin-bottom: 0px;">
												<select name="ramal" id="ramal_agendarChamada" class="form-control show-tick" data-live-search="true">
													<option value=""> - </option>
													<?php
														foreach($ramais_sip as $key=>$value) {
															print "<option value=\"".$key."\">SIP/".$key."</option>";
														}
														foreach($ramais_iax2 as $key=>$value) {
															print "<option value=\"".$key."\">IAX2/".$key."</option>";
														}
													?>
												</select>
											</div>
										</div>
										<div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
											<label for="numero_agendarChamada">Número</label>
										</div>
										<div class="col-lg-3 col-md-3 col-sm-8 col-xs-7">
											<div class="form-group">
												<div class="form-line">
													<input type="text" name="numero" id="numero_agendarChamada" class="form-control numero" placeholder="Número">
												</div>
											</div>
										</div>
										<div class="col-lg-2 col-md-2 col-sm-4 col-xs-5">
											<button type="submit" class="btn btn-primary waves-effect">
												<i class="material-icons">play_arrow</i>
												<span>Agendar</span>
											</button>
										</div>
									</div>
									
								</form>
							</div>
							
							<div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
                                            <th>Data</th>
                                            <th>Ramal</th>
											<th>Número</th>
											<th>reagendar</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<?php
									foreach ($relatorio as $key=>$value){
									?>
										<tr>
											<td><?=date('d/m/Y H:i:s',strtotime($value['calldate']));?></td>
											<td><?=$value['ramal'];?></td> 
											<td><?=$value['numero'];?></td>
											<td>
												<a href="javascript:;" class="play" onclick="botaoReagendar(
													'<?=$value['ramal'];?>',
													'<?=$value['numero'];?>'
													)"><i class="material-icons" title="Reagendar">play_arrow</i></a>
											</td>
										</tr>
									<?php
									}
									?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- #END# TABELA USUÁRIOS -->
            </div>

        </div>
    <!--#END of PAGE CONTENT-->
	
		<!--MODAL EXCLUIR USUÁRIO-->
            <div class="modal fade" id="reagendarChamadaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Reagendar Chamada</h4>
                        </div>
                        <div class="modal-body">
							<form id="formReagendarChamada" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="agendar" />
							<input type="hidden" id="ramal_reagendarChamada" name="ramal" value="" />
							<input type="hidden" id="numero_reagendarChamada" name="numero" value="" />
							<p id="reagendarChamadaTexto"></p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
                            <button type="button" id="closeExcluirUsuarioModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
							</form>
                    </div>
                </div>
            </div>
		<!--#END of MODAL EXCLUIR USUÁRIO-->
	
<script>

function botaoReagendar(ramal, numero){
	$('#ramal_reagendarChamada').attr("value",ramal);
	$('#numero_reagendarChamada').attr("value",numero);
	document.getElementById('reagendarChamadaTexto').innerHTML = "Religar para: "+numero+", ramal: "+ramal;
	$("#reagendarChamadaModal").modal();
};

</script>