<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.network.debian7.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.status.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.config.ramal.php");
	//require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_sip.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.troncos_sip.php");
	
	if ( isset($_GET['tipo']) && $_GET['tipo'] == "criar") {
		$tipo = "criar";
	} else {
		$tipo = "troncos";
	}
	
	// DECLARAÇÃO DE VARIÁVEIS ==============================================================================================

	$troncos = get_troncos();
	//print_r($troncos);
	//echo json_encode($troncos, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
	
	$register = get_register();
	//print_r($register);
	//Array ( [0] => >00000117:11254kgo44x2vo00@;proxy.sonavoip.com.br )
	
	foreach ($troncos as $nome=>$tronco) {
		if (isset($tronco['fromuser']) && isset($tronco['secret']) && isset($tronco['host']) ) {
			foreach ($register as $value) {
				$aux = explode("@",$value);
				$host = $aux[1];
				$aux = explode(":",$aux[0]);
				$fromuser = $aux[0];
				$secret = $aux[1];
				if ( @$tronco['fromuser'] == $fromuser && @$tronco['secret'] == $secret && @$tronco['host'] == $host ) {
					$troncos[$nome]['register'] = "true";
				}
			}
		}
	}
	
	$codecs = get_ini_array("codecs", ARQ_CONFIG_RAMAL);
	//Array ( [1] => alaw [2] => ulaw [3] => g729 [4] => gsm )


	//TRONCO SIP ===============================================================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "novoTronco") {
	/*
	Array ( 
		[register] => register 
		[type] => friend 
		[troncoNome] => teste 
		[troncoInicial] => 
		[troncoFinal] => 
		[secret] => 123345 
		[context] => entrada1 
		[limit] => 1 
		[codec] => Array ( [0] => alaw [1] => ulaw [2] => g729 ) 
		[dtmf] => rfc2833 
		[insecure] => port,invite 
		[fromdomain] => 
		[fromuser] => 
		[host] => 
		[defaultuser] => 
		[proibeAddress] => 
		[proibeMask] => 
		[permiteAddress] => 
		[permiteMask] => 
		[transport] => udp 
		[port] => 5060 
		[nat] => force_rport,comedia 
		[qualify] => yes 
		[qualifyfreq] => 
		[keepalive] => 
		[rtptimeout] => 
		[rtpholdtimeout] => 
		[directmedia] => 
		[sendrpid] => 
		[ignoresdpversion] => 
		[prematuremedia] => 
		[progressinband] => 
	)
	*/
		//seta o tempo limite da aplicação para esperar mais tempo grandes loops demoram mais
		set_time_limit(600);
		
		$erro = "";
		$qtde = 0;
		
		if ( !isset($_POST['troncoNome']) || $_POST['troncoNome'] == "" ) {
			$inicio = $_POST['troncoInicial'];
			$fim = $_POST['troncoFinal'];
			
			if (!is_numeric($inicio)) {
				$erro = "Erro: Tronco inicial incorreto!";
			}
			if ($fim != "" && !is_numeric($fim)){
				$erro = "Erro: Tronco final incorreto!";
			}
			
			if ($fim > $inicio) {
				$qtde = ($fim - $inicio);
			} elseif ($fim == $inicio || ($inicio != "" && $fim == "") ) {
				$qtde = 0;
			} elseif ($inicio > $fim) {
				$qtde = ($inicio - $fim);
				$tmp = $fim;
				$fim = $inicio;
				$inicio = $tmp;
			}
			
		} else {
			$troncoNome = filter_var($_POST['troncoNome'], FILTER_SANITIZE_STRING);
			if ($troncoNome == "") {
				$erro = "Erro: Nome do Tronco inválido!";
			}
		}
		
		if ($_POST['proibeAddress'] != "" && !validate_ip($_POST['proibeAddress'])) {
			$erro .= "Erro: IP proíbe inválido!";
		}
		if ($_POST['proibeMask'] != "" && !validate_netmask($_POST['proibeMask'])) {
			$erro .= "Erro: Netmask proíbe inválido!";
		}
		if ($_POST['permiteAddress'] != "" && !validate_ip($_POST['permiteAddress'])) {
			$erro .= "Erro: IP permite inválido!";
		}
		if ($_POST['permiteMask'] != "" && !validate_netmask($_POST['permiteMask'])) {
			$erro .= "Erro: Netmask permite inválido!";
		}
		if (@$_POST['register'] == "register") {
			if ($_POST['fromuser'] == "")
				$erro .= "Erro: Para registro é necessário informar o fromuser!";
			if ($_POST['secret'] == "")
				$erro .= "Erro: Para registro é necessário informar o secret!";
			if ($_POST['host'] == "")
				$erro .= "Erro: Para registro é necessário informar o host!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !novos_troncos($_POST, $qtde, ARQ_TRONCO_SIP) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "editarTronco") {
		/*
		Array (
			[editarTronco] => SONAVOIP
			[register] => register
			[type] => friend 
			[secret] => 11254kgo44x2vo00 
			[context] => entrada1 
			[limit] => 
			[codec] => Array ( [0] => alaw [1] => g729 ) 
			[dtmf] => rfc2833 
			[insecure] => port,invite 
			[fromdomain] => ;proxy.sonavoip.com.br 
			[fromuser] => 00000117 
			[host] => ;proxy.sonavoip.com.br 
			[defaultuser] => 
			[proibeAddress] => 
			[proibeMask] => 
			[permiteAddress] => 
			[permiteMask] => 
			[port] => 5060 
			[qualify] => yes 
			[qualifyfreq] => 
			[keepalive] => 
			[rtptimeout] => 
			[rtpholdtimeout] => 
			[directmedia] => outgoing 
			[sendrpid] => rpid 
			[ignoresdpversion] => yes 
			[prematuremedia] => no 
			[progressinband] => yes
			[copiar] => Array ( [0] => type [1] => secret [2] => context [3] => limit [4] => codec [5] => dtmf [6] => insecure [7] => fromdomain [8] => fromuser [9] => host [10] => defaultuser [11] => proibe [12] => permite [13] => transport [14] => port [15] => nat [16] => qualify [17] => qualifyfreq [18] => keepalive [19] => rtptimeout [20] => rtpholdtimeout [21] => directmedia [22] => sendrpid [23] => ignoresdpversion [24] => prematuremedia [25] => progressinband )
			[copiarTroncos] => Array ( [0] => SONAVOIP [1] => algar [2] => 1000 [3] => 1050 ) )
		*/
		$erro="";
		if ($_POST['editarTronco'] == "") {
			$erro = "Erro: Tronco Incorreto!";
		}
		if ($_POST['proibeAddress'] != "" && !validate_ip($_POST['proibeAddress'])) {
			$erro = "Erro: IP proíbe inválido!";
		}
		if ($_POST['proibeMask'] != "" && !validate_netmask($_POST['proibeMask'])) {
			$erro = "Erro: Netmask proíbe inválido!";
		}
		if ($_POST['permiteAddress'] != "" && !validate_ip($_POST['permiteAddress'])) {
			$erro = "Erro: IP permite inválido!";
		}
		if ($_POST['permiteMask'] != "" && !validate_netmask($_POST['permiteMask'])) {
			$erro = "Erro: Netmask permite inválido!";
		}
		if (@$_POST['register'] == "register") {
			if ($_POST['fromuser'] == "")
				$erro .= "Erro: Para registro é necessário informar o fromuser!";
			if ($_POST['secret'] == "")
				$erro .= "Erro: Para registro é necessário informar o secret!";
			if ($_POST['host'] == "")
				$erro .= "Erro: Para registro é necessário informar o host!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !editar_troncos($_POST, ARQ_TRONCO_SIP) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirTronco") {
		//[tronco] => SONAVOIP 
		
		$erro="";
		if ($_POST['tronco'] == "") {
			$erro = "Erro: Tronco Incorreto!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !excluir_tronco($_POST['tronco'], ARQ_TRONCO_SIP) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "apagarFaixa") {
		set_time_limit(600);
		
		$erro = "";

		$inicio = $_POST['troncoInicial'];
		$fim = $_POST['troncoFinal'];
			
		if ( $inicio != "" && !is_numeric($inicio)) {
			$erro = "Erro: Tronco inicial incorreto!";
		}
		if ( $fim != "" && !is_numeric($fim)) {
			$erro = "Erro: Tronco final incorreto!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ($fim > $inicio) {
			$qtde = ($fim - $inicio);
		} elseif ($fim == $inicio || ($inicio != "" && $fim == "") ) {
			$qtde = 0;
		} elseif ($inicio > $fim) {
			$qtde = ($inicio - $fim);
			$tmp = $fim;
			$fim = $inicio;
			$inicio = $tmp;
		}
		for ($i = 0; $i <= $qtde; $i++) {
			excluir_tronco($inicio, ARQ_TRONCO_SIP);
			$inicio++;
		}
		print "<script>
			alert('Configurações salvas com sucesso!');
			document.getElementById('form_{$pagina}_{$menu}').submit();
		</script>";
	}

?>

	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- MENU TRONCOS -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
									<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
			</div>
                        <div class="body">
                            <ul class="nav nav-tabs tab-nav-right" role="tablist">
                                <li role="presentation" <?php echo ( $tipo == "troncos" ? "class=\"active\"" : "" ); ?> ><a href="#troncos" data-toggle="tab">TRONCOS</a></li>
                                <li role="presentation" <?php echo ( $tipo == "criar" ? "class=\"active\"" : "" ); ?> ><a href="#criar" data-toggle="tab">CRIAR TRONCOS</a></li>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
				<!-- TRONCOS #####################################################################################################################-->
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "troncos" ? "in active" : "" ); ?>" id="troncos">


			    <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
                                            <th>Número</th>
                                            <th>IP</th>
											<th>Status</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					    <?php
						foreach($troncos as $tronco=>$vetor) {
						    if (is_array($vetor)) {
								$statusRamal = infoRamalSIP($tronco);
					    ?>
							<tr>
								<td><?=$tronco;?></td>
								<td><?=@$statusRamal['Addr->IP'];?></td> 
								<td><?=@$statusRamal['Status'];?></td>
								<td>
									<a href="javascript:;" class="editar-tronco" data-tronco="<?=$tronco;?>" data-toggle="modal" data-target="#editarTroncoModal"><i class="material-icons" title="Editar">edit</i></a>&nbsp;
									<a href="javascript:;" class="play" onclick="botaoExcluirTronco('<?=$tronco;?>')"><i class="material-icons" title="Excluir">delete</i></a>
								</td>
							</tr>
					    <?php
						    }
						}
					    ?>
                                    </tbody>
                                </table>
                            </div>

						<button type="button" class="btn btn-danger waves-effect" data-toggle="modal" data-target="#apagarFaixaModal">
							<i class="material-icons">delete</i>
							<span>Apagar Faixa</span>
						</button>

				</div>
				<!--#FIM - TRONCOS ##############################################################################################################-->
				<!-- CRIAR TRONCO ###################################################################################################################-->
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "criar" ? "in active" : "" ); ?>" id="criar">

			</br>
			<h4>Novo Tronco SIP</h4>
			</br>
			    <div class="demo-masked-input">
			    <form id="formNovoTronco" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="novoTronco" />

				<div class="row clearfix">
					<div class="col-md-9 col-sm-12 col-xs-12">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<input type="checkbox" name="register" id="register_novoTronco" value="register" class="filled-in chk-col-light-blue"/>
							<label for="register_novoTronco">Inserir linha de Registro SIP?</label>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label title="type">Tipo</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="type" id="type_novoTronco" class="form-control show-tick">
            					<option value="friend">friend</option>
            					<option value="peer">peer</option>
								<option value="user">user</option>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label title="Cria um tronco por nome" for="troncoNome_novoTronco">Tronco Nome</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="troncoNome" id="troncoNome_novoTronco" class="form-control rota">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label title="Para criar somente um tronco deixe o campo Tronco Final vazio" for="troncoInicial_novoTronco">Tronco Inicial</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="troncoInicial" id="troncoInicial_novoTronco" class="form-control ramal">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label title="Cria toda a faixa, a partir do tronco inicial até o tronco final" for="troncoFinal_novoTronco">Tronco Final</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="troncoFinal" id="troncoFinal_novoTronco" class="form-control ramal">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="secret_novoTronco">Senha</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="secret" id="secret_novoTronco" class="form-control alphanumeric">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label>Contexto</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="context" id="context_novoTronco" class="form-control show-tick">
            					<option value=""> - </option>
            					<?php
									$tmpcat = get_ini_keys(ARQ_ENTRADASDDR_CONF);
            						foreach($tmpcat as $key=>$value) {
            							print "<option value=\"".$key."\">".$key."</option>";
            						}
									$tmpcat = get_ini_keys(ARQ_ENTRADASDDRCUSTOM_CONF);
            						foreach($tmpcat as $key=>$value) {
            							print "<option value=\"".$key."\">".$key."</option>";
            						}
									$tmpcat = meu_parse_ini_file(ARQ_CATEGORIAS_CONF);
									foreach($tmpcat as $key=>$value) {
										print "<option value=\"".$key."\">".$key."</option>";
									}
            					?>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="limit_novoTronco">Limite de ligações</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="limit" id="limit_novoTronco" class="form-control timeout">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="codec0_novoTronco">Codec 1</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="codec[]" id="codec0_novoTronco" class="form-control show-tick">
							<?php
								foreach ($codecs as $k=>$codec) {
							?>
								<option value="<?=$codec;?>"><?=$codec;?></option>
							<?php
								}
							?>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="codec1_novoTronco">Codec 2</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="codec[]" id="codec1_novoTronco" class="form-control show-tick">
							<?php
								foreach ($codecs as $k=>$codec) {
							?>
								<option value="<?=$codec;?>"><?=$codec;?></option>
							<?php
								}
							?>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="codec2_novoTronco">Codec 3</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="codec[]" id="codec2_novoTronco" class="form-control show-tick">
							<?php
								foreach ($codecs as $k=>$codec) {
							?>
								<option value="<?=$codec;?>"><?=$codec;?></option>
							<?php
								}
							?>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="codec3_novoTronco">Codec 4</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="codec[]" id="codec3_novoTronco" class="form-control show-tick">
							<?php
								foreach ($codecs as $k=>$codec) {
							?>
								<option value="<?=$codec;?>"><?=$codec;?></option>
							<?php
								}
							?>
							</select>
						</div>
					</div>
				</div>
				<!--DTMF-->
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label>DTMF</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="dtmf" id="dtmf_novoTronco" class="form-control show-tick">
								<option value=""> - </option>
								<option value="rfc2833">RFC2833</option>
								<option value="inband">Inband</option>
								<option value="info">Info</option>
								<option value="auto">Auto</option>
							</select>
						</div>
					</div>
				</div>
				<!--Insecure-->
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label>Insecure</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="insecure" id="insecure_novoTronco" class="form-control show-tick">
								<option value=""> - </option>
								<option value="port">port</option>
								<option value="invite">invite</option>
								<option value="port,invite">port,invite</option>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="fromdomain_novoTronco">Fromdomain</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="fromdomain" id="fromdomain_novoTronco" class="form-control">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="fromuser_novoTronco">Fromuser</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="fromuser" id="fromuser_novoTronco" class="form-control">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="host_novoTronco">Host</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="host" id="host_novoTronco" class="form-control">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="defaultuser_novoTronco" title="username">Default User</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="defaultuser" id="defaultuser_novoTronco" class="form-control">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label title="Endereço/Mascara (Ex.: 192.168.0.0/255.255.255.0)">Proíbe</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="proibeAddress" id="proibeAddress_novoTronco" class="form-control ip">
							</div>
						</div>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="proibeMask" id="proibeMask_novoTronco" class="form-control ip">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label title="Endereço/Mascara (Ex.: 192.168.0.0/255.255.255.0)">Permite</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="permiteAddress" id="permiteAddress_novoTronco" class="form-control ip">
							</div>
						</div>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="permiteMask" id="permiteMask_novoTronco" class="form-control ip">
								</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label>Transporte</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="transport" id="transport_novoTronco" class="form-control show-tick">
            					<option value="udp">UDP</option>
            					<option value="tcp">TCP</option>
            					<option value="tcp,udp">Ambos</option>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="port_novoTronco">Porta</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="port" id="port_novoTronco" class="form-control timeout">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label>Nat</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="nat" id="nat_novoTronco" class="form-control show-tick">
            					<option value=""> - </option>
            					<option value="auto_force_rport">auto_force_rport (default)</option>
								<option value="force_rport,comedia">force_rport,comedia</option>
            					<option value="force_rport">force_rport</option>
								<option value="comedia">comedia</option>
								<option value="auto_comedia">auto_comedia</option>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label>Qualify</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="qualify" id="qualify_novoTronco" class="form-control show-tick">
            					<option value=""> - </option>
            					<option value="yes">yes</option>
            					<option value="no">no</option>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="qualifyfreq_novoTronco" title="Tempo em segundos">Qualifyfreq</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="qualifyfreq" id="qualifyfreq_novoTronco" class="form-control timeout">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="keepalive_novoTronco" title="Tempo em segundos">Keepalive</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="keepalive" id="keepalive_novoTronco" class="form-control timeout">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="rtptimeout_novoTronco" title="Tempo em segundos">RTP Timeout</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="rtptimeout" id="rtptimeout_novoTronco" class="form-control timeout">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="rtpholdtimeout_novoTronco" title="Tempo em segundos">RTP Hold Timeout</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="rtpholdtimeout" id="rtpholdtimeout_novoTronco" class="form-control timeout">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label>Directmedia</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="directmedia" id="directmedia_novoTronco" class="form-control show-tick">
            					<option value=""> - </option>
            					<option value="yes">yes (default)</option>
            					<option value="no">no</option>
								<option value="nonat">nonat</option>
								<option value="update">update</option>
								<option value="outgoing">outgoing</option>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label>Sendrpid</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="sendrpid" id="sendrpid_novoTronco" class="form-control show-tick">
            					<option value=""> - </option>
            					<option value="no">no (default)</option>
            					<option value="yes">yes</option>
								<option value="rpid">rpid</option>
								<option value="pai">pai</option>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label>Ignore sdp version</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="ignoresdpversion" id="ignoresdpversion_novoTronco" class="form-control show-tick">
            					<option value=""> - </option>
            					<option value="yes">yes</option>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label>Premature Media</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="prematuremedia" id="prematuremedia_novoTronco" class="form-control show-tick">
            					<option value=""> - </option>
            					<option value="yes">yes (default)</option>
								<option value="no">no</option>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label>Progress Inband</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="progressinband" id="progressinband_novoTronco" class="form-control show-tick">
            					<option value=""> - </option>
            					<option value="no">no (default)</option>
								<option value="yes">yes</option>
							</select>
						</div>
					</div>
				</div>
				
				<button type="button" onclick="novoTronco()" class="btn btn-primary waves-effect">
					<i class="material-icons">save</i>
					<span>SALVAR</span>
			    	</button>
			    </form>
			    </div>


				</div>
				<!--#FIM - CRIAR TRONCO ##############################################################################################################-->
                            </div>


                        </div>
                    </div>
                </div>
                <!-- #END# MENU TRONCOS -->
            </div>
	</div>
	<!--END - PAGE CONTENT-->


	<!-- MODAL ================================================================================================================================== -->

		<!--MODAL EDITAR TRONCO-->
			<div class="modal fade" id="editarTroncoModal" tabindex="-1" role="dialog">
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h4 class="modal-title" id="editarTroncoLabel">Editar Tronco</h4>
						</div>
						<div class="modal-body">
							<div class="row clearfix demo-masked-input">
								<form id="formEditarTronco" method="post">
								<?=$text_form;?>
								<input type="hidden" name="cmd" value="editarTronco" />
								<input type="hidden" id="editarTronco" name="editarTronco" value="" />
								<!--Coluna esquerda - Editar Tronco-->
								<div class="col-md-8 col-sm-9 col-xs-12">
									<div class="col-xs-11">
										<p>Configurações</p>
										</br>
									</div>
									<div class="col-xs-1">
										<p>Copiar</p>
										</br>
									</div>
									<!--Register-->
									<div class="col-xs-12">
										<div class="form-group form-float">
											<input type="checkbox" name="register" id="register_editarTronco" value="register" class="filled-in chk-col-light-blue"/>
											<label for="register_editarTronco">Inserir linha de Registro SIP?</label>
										</div>
									</div>
									<!--Tipo-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label title="type">Tipo</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="type" id="type_editarTronco" class="form-control show-tick">
													<option value="friend">friend</option>
													<option value="peer">peer</option>
													<option value="user">user</option>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-type" value="type" class="filled-in chk-col-light-blue"/>
										<label for="copiar-type"></label>
									</div>
									<!--Senha-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Senha</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group">
												<div class="form-line">
													<input type="text" name="secret" id="secret_editarTronco" class="form-control alphanumeric">
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-secret" value="secret" class="filled-in chk-col-light-blue"/>
										<label for="copiar-secret"></label>
									</div>
									<!--Categoria-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Categoria</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="context" id="context_editarTronco" class="form-control show-tick">
													<option value=""> - </option>
													<?php
														$tmpcat = get_ini_keys(ARQ_ENTRADASDDR_CONF);
														foreach($tmpcat as $key=>$value) {
															print "<option value=\"".$key."\">".$key."</option>";
														}
														$tmpcat = get_ini_keys(ARQ_ENTRADASDDRCUSTOM_CONF);
														foreach($tmpcat as $key=>$value) {
															print "<option value=\"".$key."\">".$key."</option>";
														}
														$tmpcat = meu_parse_ini_file(ARQ_CATEGORIAS_CONF);
														foreach($tmpcat as $key=>$value) {
															print "<option value=\"".$key."\">".$key."</option>";
														}
													?>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-context" value="context" class="filled-in chk-col-light-blue"/>
										<label for="copiar-context"></label>
									</div>
									<!--Limit-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Limite de ligações</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group">
												<div class="form-line">
													<input type="text" name="limit" id="limit_editarTronco" class="form-control timeout">
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-limit" value="limit" class="filled-in chk-col-light-blue"/>
										<label for="copiar-limit"></label>
									</div>
									<!--Codec-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Codec 1</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="codec[]" id="codec0_editarTronco" class="form-control show-tick">
												<?php
													foreach ($codecs as $k=>$codec) {
												?>
												<option value="<?=$codec;?>"><?=$codec;?></option>
												<?php
													}
												?>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-codec" value="codec" class="filled-in chk-col-light-blue"/>
										<label for="copiar-codec"></label>
									</div>
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Codec 2</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="codec[]" id="codec1_editarTronco" class="form-control show-tick">
												<?php
													foreach ($codecs as $k=>$codec) {
												?>
												<option value="<?=$codec;?>"><?=$codec;?></option>
												<?php
													}
												?>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
									</div>
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Codec 3</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="codec[]" id="codec2_editarTronco" class="form-control show-tick">
												<?php
													foreach ($codecs as $k=>$codec) {
												?>
												<option value="<?=$codec;?>"><?=$codec;?></option>
												<?php
													}
												?>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
									</div>
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Codec 4</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="codec[]" id="codec3_editarTronco" class="form-control show-tick">
												<?php
													foreach ($codecs as $k=>$codec) {
												?>
												<option value="<?=$codec;?>"><?=$codec;?></option>
												<?php
													}
												?>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
									</div>
									<!--DTMF-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>DTMF</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="dtmf" id="dtmf_editarTronco" class="form-control show-tick">
													<option value=""> - </option>
													<option value="rfc2833">RFC2833</option>
													<option value="inband">Inband</option>
													<option value="info">Info</option>
													<option value="auto">Auto</option>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-dtmf" value="dtmf" class="filled-in chk-col-light-blue"/>
										<label for="copiar-dtmf"></label>
									</div>
									<!--Insecure-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Insecure</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="insecure" id="insecure_editarTronco" class="form-control show-tick">
													<option value=""> - </option>
													<option value="port">port</option>
													<option value="invite">invite</option>
													<option value="port,invite">port,invite</option>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-insecure" value="insecure" class="filled-in chk-col-light-blue"/>
										<label for="copiar-insecure"></label>
									</div>
									<!--Fromdomain-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label for="fromdomain_editarTronco">Fromdomain</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group">
												<div class="form-line">
													<input type="text" name="fromdomain" id="fromdomain_editarTronco" class="form-control">
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-fromdomain" value="fromdomain" class="filled-in chk-col-light-blue"/>
										<label for="copiar-fromdomain"></label>
									</div>
									<!--Fromuser-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label for="fromuser_editarTronco">Fromuser</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group">
												<div class="form-line">
													<input type="text" name="fromuser" id="fromuser_editarTronco" class="form-control">
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-fromuser" value="fromuser" class="filled-in chk-col-light-blue"/>
										<label for="copiar-fromuser"></label>
									</div>
									<!--Host-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label for="host_editarTronco">Host</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group">
												<div class="form-line">
													<input type="text" name="host" id="host_editarTronco" class="form-control">
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-host" value="host" class="filled-in chk-col-light-blue"/>
										<label for="copiar-host"></label>
									</div>
									<!--Default User-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label for="defaultuser_editarTronco" title="username">Default User</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group">
												<div class="form-line">
													<input type="text" name="defaultuser" id="defaultuser_editarTronco" class="form-control">
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-defaultuser" value="defaultuser" class="filled-in chk-col-light-blue"/>
										<label for="copiar-defaultuser"></label>
									</div>
									
									<!--Proíbe-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Proíbe</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="col-xs-6">
												<div class="form-group">
													<div class="form-line">
														<input type="text" name="proibeAddress" id="proibeAddress_editarTronco" class="form-control ip">
													</div>
												</div>
											</div>
											<div class="col-xs-6">
												<div class="form-group">
													<div class="form-line">
														<input type="text" name="proibeMask" id="proibeMask_editarTronco" class="form-control ip">
													</div>
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-proibe" value="proibe" class="filled-in chk-col-light-blue"/>
										<label for="copiar-proibe"></label>
									</div>
									<!--Permite-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Permite</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="col-xs-6">
												<div class="form-group">
													<div class="form-line">
														<input type="text" name="permiteAddress" id="permiteAddress_editarTronco" class="form-control ip">
													</div>
												</div>
											</div>
											<div class="col-xs-6">
												<div class="form-group">
													<div class="form-line">
														<input type="text" name="permiteMask" id="permiteMask_editarTronco" class="form-control ip">
													</div>
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-permite" value="permite" class="filled-in chk-col-light-blue"/>
										<label for="copiar-permite"></label>
									</div>
									<!--Transporte-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Transporte</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="transport" id="transport_editarTronco" class="form-control show-tick">
													<option value=""> - </option>
													<option value="udp">UDP</option>
													<option value="tcp">TCP</option>
													<option value="tcp,udp">Ambos</option>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-transport" value="transport" class="filled-in chk-col-light-blue"/>
										<label for="copiar-transport"></label>
									</div>
									<!--Porta-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Porta SIP</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group">
												<div class="form-line">
													<input type="text" name="port" id="port_editarTronco" class="form-control timeout">
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-port" value="port" class="filled-in chk-col-light-blue"/>
										<label for="copiar-port"></label>
									</div>
									<!--Nat-->
									<div class="col-xs-11">
										<div class="row clearfix">
											<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
												<label>Nat</label>
											</div>
											<div class="col-md-9 col-sm-8 col-xs-7">
												<div class="form-group form-float">
													<select name="nat" id="nat_editarTronco" class="form-control show-tick">
            											<option value=""> - </option>
            											<option value="auto_force_rport">auto_force_rport (default)</option>
														<option value="force_rport,comedia">force_rport,comedia</option>
            											<option value="force_rport">force_rport</option>
														<option value="comedia">comedia</option>
														<option value="auto_comedia">auto_comedia</option>
													</select>
												</div>
											</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-nat" value="nat" class="filled-in chk-col-light-blue"/>
										<label for="copiar-nat"></label>
									</div>
									<!--Qualify-->
									<div class="col-xs-11">
										<div class="row clearfix">
											<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
												<label>Qualify</label>
											</div>
											<div class="col-md-9 col-sm-8 col-xs-7">
												<div class="form-group form-float">
													<select name="qualify" id="qualify_editarTronco" class="form-control show-tick">
            											<option value=""> - </option>
            											<option value="yes">yes</option>
            											<option value="no">no</option>
													</select>
												</div>
											</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-qualify" value="qualify" class="filled-in chk-col-light-blue"/>
										<label for="copiar-qualify"></label>
									</div>
									<!--Qualifyfreq-->
									<div class="col-xs-11">
										<div class="row clearfix">
											<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
												<label for="qualifyfreq_editarTronco" title="Tempo em segundos">Qualifyfreq</label>
											</div>
											<div class="col-md-9 col-sm-8 col-xs-7">
												<div class="form-group">
													<div class="form-line">
														<input type="text" name="qualifyfreq" id="qualifyfreq_editarTronco" class="form-control timeout">
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-qualifyfreq" value="qualifyfreq" class="filled-in chk-col-light-blue"/>
										<label for="copiar-qualifyfreq"></label>
									</div>
									<!--Keepalive-->
									<div class="col-xs-11">
										<div class="row clearfix">
											<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
												<label for="keepalive_editarTronco" title="Tempo em segundos">Keepalive</label>
											</div>
											<div class="col-md-9 col-sm-8 col-xs-7">
												<div class="form-group">
													<div class="form-line">
														<input type="text" name="keepalive" id="keepalive_editarTronco" class="form-control timeout">
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-keepalive" value="keepalive" class="filled-in chk-col-light-blue"/>
										<label for="copiar-keepalive"></label>
									</div>
									<!--RTP Timeout-->
									<div class="col-xs-11">
										<div class="row clearfix">
											<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
												<label for="rtptimeout_editarTronco" title="Tempo em segundos">RTP Timeout</label>
											</div>
											<div class="col-md-9 col-sm-8 col-xs-7">
												<div class="form-group">
													<div class="form-line">
														<input type="text" name="rtptimeout" id="rtptimeout_editarTronco" class="form-control timeout">
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-rtptimeout" value="rtptimeout" class="filled-in chk-col-light-blue"/>
										<label for="copiar-rtptimeout"></label>
									</div>
									<!--RTP Hold Timeout-->
									<div class="col-xs-11">
										<div class="row clearfix">
											<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
												<label for="rtpholdtimeout_editarTronco" title="Tempo em segundos">RTP Hold Timeout</label>
											</div>
											<div class="col-md-9 col-sm-8 col-xs-7">
												<div class="form-group">
													<div class="form-line">
														<input type="text" name="rtpholdtimeout" id="rtpholdtimeout_editarTronco" class="form-control timeout">
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-rtpholdtimeout" value="rtpholdtimeout" class="filled-in chk-col-light-blue"/>
										<label for="copiar-rtpholdtimeout"></label>
									</div>
									<!--Directmedia-->
									<div class="col-xs-11">
										<div class="row clearfix">
											<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
												<label>Directmedia</label>
											</div>
											<div class="col-md-9 col-sm-8 col-xs-7">
												<div class="form-group form-float">
													<select name="directmedia" id="directmedia_editarTronco" class="form-control show-tick">
            											<option value=""> - </option>
            											<option value="yes">yes (default)</option>
            											<option value="no">no</option>
														<option value="nonat">nonat</option>
														<option value="update">update</option>
														<option value="outgoing">outgoing</option>
													</select>
												</div>
											</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-directmedia" value="directmedia" class="filled-in chk-col-light-blue"/>
										<label for="copiar-directmedia"></label>
									</div>
									<!--Sendrpid-->
									<div class="col-xs-11">
										<div class="row clearfix">
											<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
												<label>Sendrpid</label>
											</div>
											<div class="col-md-9 col-sm-8 col-xs-7">
												<div class="form-group form-float">
													<select name="sendrpid" id="sendrpid_editarTronco" class="form-control show-tick">
            											<option value=""> - </option>
            											<option value="no">no (default)</option>
            											<option value="yes">yes</option>
														<option value="rpid">rpid</option>
														<option value="pai">pai</option>
													</select>
												</div>
											</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-sendrpid" value="sendrpid" class="filled-in chk-col-light-blue"/>
										<label for="copiar-sendrpid"></label>
									</div>
									<!--Ignore sdp version-->
									<div class="col-xs-11">
										<div class="row clearfix">
											<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
												<label>Ignore sdp version</label>
											</div>
											<div class="col-md-9 col-sm-8 col-xs-7">
												<div class="form-group form-float">
													<select name="ignoresdpversion" id="ignoresdpversion_editarTronco" class="form-control show-tick">
            											<option value=""> - </option>
            											<option value="yes">yes</option>
													</select>
												</div>
											</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-ignoresdpversion" value="ignoresdpversion" class="filled-in chk-col-light-blue"/>
										<label for="copiar-ignoresdpversion"></label>
									</div>
									<!--Premature Media-->
									<div class="col-xs-11">
										<div class="row clearfix">
											<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
												<label>Premature Media</label>
											</div>
											<div class="col-md-9 col-sm-8 col-xs-7">
												<div class="form-group form-float" style="margin-bottom: 0px;">
													<select name="prematuremedia" id="prematuremedia_editarTronco" class="form-control show-tick">
            											<option value=""> - </option>
            											<option value="yes">yes (default)</option>
														<option value="no">no</option>
													</select>
												</div>
											</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-prematuremedia" value="prematuremedia" class="filled-in chk-col-light-blue"/>
										<label for="copiar-prematuremedia"></label>
									</div>
									<!--Progress Inband-->
									<div class="col-xs-11">
										<div class="row clearfix">
											<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
												<label>Progress Inband</label>
											</div>
											<div class="col-md-9 col-sm-8 col-xs-7">
												<div class="form-group form-float">
													<select name="progressinband" id="progressinband_editarTronco" class="form-control show-tick">
            											<option value=""> - </option>
            											<option value="no">no (default)</option>
														<option value="yes">yes</option>
													</select>
												</div>
											</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-progressinband" value="progressinband" class="filled-in chk-col-light-blue"/>
										<label for="copiar-progressinband"></label>
									</div>

								</div>
								<!--Coluna direira - Copiar-->
								<div class="col-md-4 col-sm-3 col-xs-12">
									<p title="Copia as configurações selecionadas para os troncos selecionados abaixo.">Copiar para troncos:</p>
									<br>
									<div class="dd">
										<ul class="list-modal" style="overflow: hidden; height: 1000px; touch-action: manipulation;">
											<li class="dd-item">
												<div class="dd-handle">
												<input type="checkbox" name="paraTodos" onclick="marcarTodosTroncos()" id="paraTodos" class="filled-in chk-col-light-blue"/>
												<label for="paraTodos">Marcar Todos</label>
												</div>
											</li>
										<?php
											foreach ($troncos as $tronco=>$vetor) {
										?>
											<li class="dd-item">
												<div class="dd-handle">
												<input type="checkbox" name="copiarTroncos[]" id="copiarTronco-<?=$tronco;?>" value="<?=$tronco;?>" class="filled-in chk-col-light-blue"/>
												<label for="copiarTronco-<?=$tronco;?>"><?=$tronco;?></label>
												</div>
											</li>
										<?php
											}
										?>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
							<button type="button" id="closeEditarTroncoModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
						</div>
							</form>
					</div>
				</div>
			</div>
	    <!--#END of MODAL EDITAR TRONCO-->


	    <!--MODAL EXCLUIR TRONCO-->
            <div class="modal fade" id="excluirTroncoModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirTroncoLabel">Excluir Tronco</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirTronco" method="post">
				<?=$text_form;?>
				<input type="hidden" name="tipo" value="tronco" />
				<input type="hidden" name="cmd" value="excluirTronco" />
				<input type="hidden" id="excluirTronco" name="tronco" value="" />
			    <p>Tem certeza que deseja excluir o Tronco?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
							<button type="button" id="closeExcluirTroncoModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR TRONCO-->


		<!--MODAL APAGAR FAIXA-->
            <div class="modal fade" id="apagarFaixaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Apagar Faixa</h4>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
								<form id="formEditarUsuario" method="post">
									<?=$text_form;?>
									<input type="hidden" name="cmd" value="apagarFaixa" />

								<div class="row clearfix">
									<div class="col-lg-4 col-md-4 col-sm-4 col-xs-5 form-control-label">
										<label for="troncoInicial_apagarFaixa">Tronco Inicial</label>
									</div>
									<div class="col-lg-8 col-md-8 col-sm-8 col-xs-7">
										<div class="form-group">
											<div class="form-line">
												<input type="text" name="troncoInicial" id="troncoInicial_apagarFaixa" class="form-control ramal">
											</div>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-lg-4 col-md-4 col-sm-4 col-xs-5 form-control-label">
										<label for="troncoFinal_apagarFaixa">Tronco Final</label>
									</div>
									<div class="col-lg-8 col-md-8 col-sm-8 col-xs-7">
										<div class="form-group">
											<div class="form-line">
												<input type="text" name="troncoFinal" id="troncoFinal_apagarFaixa" class="form-control ramal">
											</div>
										</div>
									</div>
								</div>
							</div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Apagar</span>
							</button>
                            <button type="button" id="closeApagarFaixaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL APAGAR FAIXA-->


	<!--#END - MODAL ============================================================================================================================== -->

<script>


function novoTronco()
{
	
	document.getElementById("formNovoTronco").submit();
} 

function botaoExcluirTronco(excluirTronco) {
	$('#excluirTronco').val(excluirTronco);

	$('#excluirTroncoLabel').text("Excluir Tronco "+excluirTronco);
	$("#excluirTroncoModal").modal();
};

function marcarTodosTroncos() {
	if ( $('#paraTodos').is(":checked") == true) {
		$("input[name='copiarTroncos[]']").each(function(){
			//alert($(this).val());
			document.getElementById($(this).attr("id")).checked = true;
			//$(this).checked = true;
		});
	} else {
		$("input[name='copiarTroncos[]']").each(function(){
			document.getElementById($(this).attr("id")).checked = false;
			//$(this).checked = false;
		});
	}
};

$(document).ready(function(){

	var troncos = <?php echo json_encode($troncos, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
	/*
	"3954":{
		"type":"friend",
		"secret":"102030",
		"qualify":"1",
		"port":"5060",
		"nat":"force_rport,comedia",
		"mailbox":"3954@device",
		"host":"dynamic",
		"dtmfmode":"rfc2833",
		"disallow":"all",
		"dial":"SIP/3954",
		"context":"1",
		"canreinvite":"1",
		"limit":"",
		"codec":["alaw"," ulaw"," gsm"],
		"calleridname":"Kenko ",
		"proibeAddress":"",
		"proibeMask":"",
		"permiteAddress":"",
		"permiteMask":"",
	}
	*/

	$(".editar-tronco").on('click', function(event) {
		event.preventDefault();

		var tronco = $(this).data('tronco');

		document.getElementById('editarTroncoLabel').innerHTML = "EditarTronco: "+tronco;

		$('#editarTronco').val(tronco);

		$('#secret_editarTronco').val(troncos[tronco].secret);
		$('#port_editarTronco').val(troncos[tronco].port);
		$('#limit_editarTronco').val(troncos[tronco].limit);
		$('#proibeAddress_editarTronco').val(troncos[tronco].proibeAddress);
		$('#proibeMask_editarTronco').val(troncos[tronco].proibeMask);
		$('#permiteAddress_editarTronco').val(troncos[tronco].permiteAddress);
		$('#permiteMask_editarTronco').val(troncos[tronco].permiteMask);
		$('#fromdomain_editarTronco').val(troncos[tronco].fromdomain);
		$('#fromuser_editarTronco').val(troncos[tronco].fromuser);
		$('#host_editarTronco').val(troncos[tronco].host);
		$('#defaultuser_editarTronco').val(troncos[tronco].defaultuser);
		$('#qualifyfreq').val(troncos[tronco].qualifyfreq);
		$('#keepalive').val(troncos[tronco].keepalive);
		$('#rtptimeout').val(troncos[tronco].rtptimeout);
		$('#rtpholdtimeout').val(troncos[tronco].rtpholdtimeout);
		
		$('#register_editarTronco').prop('checked',false);
		if ( troncos[tronco].register == "true" ) {
			$('#register_editarTronco').prop('checked',true);
		}
		
		var aux = 0;
		$('#type_editarTronco option').each(function(){
			if ($(this).val() == troncos[tronco].type) {
				$('#type_editarTronco').selectpicker('val', troncos[tronco].type);
				aux = 1;
			} else if (aux != 1) {
				$('#tipoTronco_editarTronco').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#context_editarTronco option').each(function(){
			if ($(this).val() == troncos[tronco].context) {
				$('#context_editarTronco').selectpicker('val', troncos[tronco].context);
				aux = 1;
			} else if (aux != 1) {
				$('#context_editarTronco').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#dtmf_editarTronco option').each(function(){
			if ($(this).val() == troncos[tronco].dtmfmode) {
				$('#dtmf_editarTronco').selectpicker('val', troncos[tronco].dtmfmode);
				aux = 1;
			} else if (aux != 1) {
				$('#dtmf_editarTronco').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#insecure_editarTronco option').each(function(){
			if ($(this).val() == troncos[tronco].insecure) {
				$('#insecure_editarTronco').selectpicker('val', troncos[tronco].insecure);
				aux = 1;
			} else if (aux != 1) {
				$('#insecure_editarTronco').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#transport_editarTronco option').each(function(){
			if ($(this).val() == troncos[tronco].transport) {
				$('#transport_editarTronco').selectpicker('val', troncos[tronco].transport);
				aux = 1;
			} else if (aux != 1) {
				$('#transport_editarTronco').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#nat_editarTronco option').each(function(){
			if ($(this).val() == troncos[tronco].nat) {
				$('#nat_editarTronco').selectpicker('val', troncos[tronco].nat);
				aux = 1;
			} else if (aux != 1) {
				$('#nat_editarTronco').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#qualify_editarTronco option').each(function(){
			if ($(this).val() == troncos[tronco].qualify) {
				$('#qualify_editarTronco').selectpicker('val', troncos[tronco].qualify);
				aux = 1;
			} else if (aux != 1) {
				$('#qualify_editarTronco').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#directmedia_editarTronco option').each(function(){
			if ($(this).val() == troncos[tronco].directmedia) {
				$('#directmedia_editarTronco').selectpicker('val', troncos[tronco].directmedia);
				aux = 1;
			} else if (aux != 1) {
				$('#directmedia_editarTronco').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#sendrpid_editarTronco option').each(function(){
			if ($(this).val() == troncos[tronco].sendrpid) {
				$('#sendrpid_editarTronco').selectpicker('val', troncos[tronco].sendrpid);
				aux = 1;
			} else if (aux != 1) {
				$('#sendrpid_editarTronco').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#ignoresdpversion_editarTronco option').each(function(){
			if ($(this).val() == troncos[tronco].ignoresdpversion) {
				$('#ignoresdpversion_editarTronco').selectpicker('val', troncos[tronco].ignoresdpversion);
				aux = 1;
			} else if (aux != 1) {
				$('#ignoresdpversion_editarTronco').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#prematuremedia_editarTronco option').each(function(){
			if ($(this).val() == troncos[tronco].prematuremedia) {
				$('#prematuremedia_editarTronco').selectpicker('val', troncos[tronco].prematuremedia);
				aux = 1;
			} else if (aux != 1) {
				$('#prematuremedia_editarTronco').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#progressinband_editarTronco option').each(function(){
			if ($(this).val() == troncos[tronco].progressinband) {
				$('#progressinband_editarTronco').selectpicker('val', troncos[tronco].progressinband);
				aux = 1;
			} else if (aux != 1) {
				$('#progressinband_editarTronco').selectpicker('val', 'null');
			}
		});

		for(var i = 0; i < 4; i++) {
			$('#codec'+i+'_editarTronco').selectpicker('deselectAll');
			$('#codec'+i+'_editarTronco').selectpicker('val', troncos[tronco].codec[i]);
		}
		
	});
	
	function slimscrollReboot(){
		$('#editarTroncoModal .list-modal')
			.slimscroll({ destroy: true })
			.slimscroll({ height: '1000px' });
		//window.addEventListener("wheel", function(event){ event.preventDefault(); }, {passive: false} );
	};
	slimscrollReboot();
	
	$("#editarTroncoModal").on('show.bs.modal', function() {
		slimscrollReboot();
	});
	
	$('#troncoNome_novoTronco').on('input', function() {
		if($(this).val().length) {
			$('#troncoInicial_novoTronco').prop('disabled', true);
			$('#troncoFinal_novoTronco').prop('disabled', true);
		} else {
			$('#troncoInicial_novoTronco').prop('disabled', false);
			$('#troncoFinal_novoTronco').prop('disabled', false);
		}
	});
	
	$('#troncoInicial_novoTronco').on('input', function() {
		if($(this).val().length) {
			$('#troncoNome_novoTronco').prop('disabled', true);
			$('#troncoFinal_novoTronco').prop('disabled', false);
		} else {
			$('#troncoNome_novoTronco').prop('disabled', false);
			$('#troncoFinal_novoTronco').prop('disabled', false);
		}
	});

});

</script>