<?php
/*

		[register] => register 
		[type] => friend 
		[troncoNome] => teste 
		[troncoInicial] => 
		[troncoFinal] => 
		[secret] => 123345 
		[context] => entrada1 
		[codec] => Array ( [0] => alaw [1] => ulaw [2] => g729 ) 
		[host] => 
		[username] => 
		[proibeAddress] => 
		[proibeMask] => 
		[permiteAddress] => 
		[permiteMask] => 
		[qualify] => yes 
		[qualifyfreqok] => 
		trunk=yes|no
		requirecalltoken=yes|no
*/
	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.network.debian7.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.status.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.config.ramal.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.troncos_iax2.php");
	
	if ( isset($_REQUEST['tipo']) && $_REQUEST['tipo'] == "criar") {
		$tipo = "criar";
	} else {
		$tipo = "troncos";
	}
	
	// DECLARAÇÃO DE VARIÁVEIS ==============================================================================================

	$troncos = get_troncos();
	//print_r($troncos);
	//echo json_encode($troncos, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
	
	$register = get_register();
	//print_r($register);
	//Array ( [0] => >00000117:11254kgo44x2vo00@;proxy.sonavoip.com.br )
	
	foreach ($troncos as $nome=>$tronco) {
		if (isset($tronco['username']) && isset($tronco['secret']) && isset($tronco['host']) ) {
			foreach ($register as $value) {
				$aux = explode("@",$value);
				$host = $aux[1];
				$aux = explode(":",$aux[0]);
				$username = $aux[0];
				$secret = $aux[1];
				if ( @$tronco['username'] == $username && @$tronco['secret'] == $secret && @$tronco['host'] == $host ) {
					$troncos[$nome]['register'] = "true";
				}
			}
		}
	}
	
	$codecs = get_ini_array("codecs", ARQ_CONFIG_RAMAL);
	//Array ( [1] => alaw [2] => ulaw [3] => g729 [4] => gsm )


	//TRONCO IAX2 ===============================================================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "novoTronco") {
	/*
	Array ( 
		[register] => register 
		[type] => friend 
		[troncoNome] => teste 
		[troncoInicial] => 
		[troncoFinal] => 
		[secret] => 123345 
		[context] => entrada1 
		[codec] => Array ( [0] => alaw [1] => ulaw [2] => g729 ) 
		[host] => 
		[username] => 
		[proibeAddress] => 
		[proibeMask] => 
		[permiteAddress] => 
		[permiteMask] => 
		[qualify] => yes 
		[qualifyfreqok] => 
		[trunk] =>
		[requirecalltoken] =>
	)
	*/
		//seta o tempo limite da aplicação para esperar mais tempo grandes loops demoram mais
		set_time_limit(600);
		
		$erro = "";
		$qtde = 0;
		
		if ( !isset($_POST['troncoNome']) || $_POST['troncoNome'] == "" ) {
			$inicio = $_POST['troncoInicial'];
			$fim = $_POST['troncoFinal'];
			
			if (!is_numeric($inicio)) {
				$erro = "Erro: Tronco inicial incorreto!";
			}
			if ($fim != "" && !is_numeric($fim)){
				$erro = "Erro: Tronco final incorreto!";
			}
			
			if ($fim > $inicio) {
				$qtde = ($fim - $inicio);
			} elseif ($fim == $inicio || ($inicio != "" && $fim == "") ) {
				$qtde = 0;
			} elseif ($inicio > $fim) {
				$qtde = ($inicio - $fim);
				$tmp = $fim;
				$fim = $inicio;
				$inicio = $tmp;
			}
			
		} else {
			$troncoNome = filter_var($_POST['troncoNome'], FILTER_SANITIZE_STRING);
			if ($troncoNome == "") {
				$erro = "Erro: Nome do Tronco inválido!";
			}
		}
		
		if ($_POST['proibeAddress'] != "" && !validate_ip($_POST['proibeAddress'])) {
			$erro .= "Erro: IP proíbe inválido!";
		}
		if ($_POST['proibeMask'] != "" && !validate_netmask($_POST['proibeMask'])) {
			$erro .= "Erro: Netmask proíbe inválido!";
		}
		if ($_POST['permiteAddress'] != "" && !validate_ip($_POST['permiteAddress'])) {
			$erro .= "Erro: IP permite inválido!";
		}
		if ($_POST['permiteMask'] != "" && !validate_netmask($_POST['permiteMask'])) {
			$erro .= "Erro: Netmask permite inválido!";
		}
		if (@$_POST['register'] == "register") {
			if ($_POST['username'] == "")
				$erro .= "Erro: Para registro é necessário informar o username!";
			if ($_POST['secret'] == "")
				$erro .= "Erro: Para registro é necessário informar o secret!";
			if ($_POST['host'] == "")
				$erro .= "Erro: Para registro é necessário informar o host!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !novos_troncos($_POST, $qtde, ARQ_TRONCO_IAX2) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "editarTronco") {
		/*
		Array (
			[editarTronco] => SONAVOIP
			[register] => register
			[type] => friend 
			[secret] => 11254kgo44x2vo00 
			[context] => entrada1 
			[codec] => Array ( [0] => alaw [1] => g729 ) 
			[host] => ;proxy.sonavoip.com.br 
			[username] => 
			[proibeAddress] => 
			[proibeMask] => 
			[permiteAddress] => 
			[permiteMask] => 
			[qualify] => yes 
			[qualifyfreqok] => 
			[trunk] => no 
			[requirecalltoken] => yes
			[copiar] => Array ( [0] => type [1] => secret [2] => context [4] => codec [9] => host [10] => username [11] => proibe [12] => permite [16] => qualify [17] => qualifyfreqok [24] => trunk [25] => requirecalltoken )
			[copiarTroncos] => Array ( [0] => SONAVOIP [1] => algar [2] => 1000 [3] => 1050 ) )
		*/
		$erro="";
		if ($_POST['editarTronco'] == "") {
			$erro = "Erro: Tronco Incorreto!";
		}
		if ($_POST['proibeAddress'] != "" && !validate_ip($_POST['proibeAddress'])) {
			$erro = "Erro: IP proíbe inválido!";
		}
		if ($_POST['proibeMask'] != "" && !validate_netmask($_POST['proibeMask'])) {
			$erro = "Erro: Netmask proíbe inválido!";
		}
		if ($_POST['permiteAddress'] != "" && !validate_ip($_POST['permiteAddress'])) {
			$erro = "Erro: IP permite inválido!";
		}
		if ($_POST['permiteMask'] != "" && !validate_netmask($_POST['permiteMask'])) {
			$erro = "Erro: Netmask permite inválido!";
		}
		if (@$_POST['register'] == "register") {
			if ($_POST['username'] == "")
				$erro .= "Erro: Para registro é necessário informar o username!";
			if ($_POST['secret'] == "")
				$erro .= "Erro: Para registro é necessário informar o secret!";
			if ($_POST['host'] == "")
				$erro .= "Erro: Para registro é necessário informar o host!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !editar_troncos($_POST, ARQ_TRONCO_IAX2) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirTronco") {
		
		$erro="";
		if ($_POST['tronco'] == "") {
			$erro = "Erro: Tronco Incorreto!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !excluir_tronco($_POST['tronco'], ARQ_TRONCO_IAX2) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "apagarFaixa") {
		set_time_limit(600);
		
		$erro = "";

		$inicio = $_POST['troncoInicial'];
		$fim = $_POST['troncoFinal'];
			
		if ( $inicio != "" && !is_numeric($inicio)) {
			$erro = "Erro: Tronco inicial incorreto!";
		}
		if ( $fim != "" && !is_numeric($fim)) {
			$erro = "Erro: Tronco final incorreto!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ($fim > $inicio) {
			$qtde = ($fim - $inicio);
		} elseif ($fim == $inicio || ($inicio != "" && $fim == "") ) {
			$qtde = 0;
		} elseif ($inicio > $fim) {
			$qtde = ($inicio - $fim);
			$tmp = $fim;
			$fim = $inicio;
			$inicio = $tmp;
		}
		for ($i = 0; $i <= $qtde; $i++) {
			excluir_tronco($inicio, ARQ_TRONCO_IAX2);
			$inicio++;
		}
		print "<script>
			alert('Configurações salvas com sucesso!');
			document.getElementById('form_{$pagina}_{$menu}').submit();
		</script>";
	}

?>

	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- MENU TRONCOS -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
									<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
									<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
			</div>
                        <div class="body">
                            <ul class="nav nav-tabs tab-nav-right" role="tablist">
                                <li role="presentation" <?php echo ( $tipo == "troncos" ? "class=\"active\"" : "" ); ?> ><a href="#troncos" data-toggle="tab">TRONCOS</a></li>
                                <li role="presentation" <?php echo ( $tipo == "criar" ? "class=\"active\"" : "" ); ?> ><a href="#criar" data-toggle="tab">CRIAR TRONCOS</a></li>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
				<!-- TRONCOS #####################################################################################################################-->
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "troncos" ? "in active" : "" ); ?>" id="troncos">


			    <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
                                            <th>Número</th>
                                            <th>IP</th>
											<th>Status</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					    <?php
						foreach($troncos as $tronco=>$vetor) {
						    if (is_array($vetor)) {
								$statusRamal = infoRamalIAX2($tronco);
					    ?>
							<tr>
								<td><?=$tronco;?></td>
								<td><?=@$statusRamal['Addr->IP'];?></td> 
								<td><?=@$statusRamal['Status'];?></td>
								<td>
									<a href="javascript:;" class="editar-tronco" data-tronco="<?=$tronco;?>" data-toggle="modal" data-target="#editarTroncoModal"><i class="material-icons" title="Editar">edit</i></a>&nbsp;
									<a href="javascript:;" class="play" onclick="botaoExcluirTronco('<?=$tronco;?>')"><i class="material-icons" title="Excluir">delete</i></a>
								</td>
							</tr>
					    <?php
						    }
						}
					    ?>
                                    </tbody>
                                </table>
                            </div>

						<button type="button" class="btn btn-danger waves-effect" data-toggle="modal" data-target="#apagarFaixaModal">
							<i class="material-icons">delete</i>
							<span>Apagar Faixa</span>
						</button>

				</div>
				<!--#FIM - TRONCOS ##############################################################################################################-->
				<!-- CRIAR TRONCO ###################################################################################################################-->
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "criar" ? "in active" : "" ); ?>" id="criar">

			</br>
			<h4>Novo Tronco IAX2</h4>
			</br>
			    <div class="demo-masked-input">
			    <form id="formNovoTronco" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="novoTronco" />

				<div class="row clearfix">
					<div class="col-md-9 col-sm-12 col-xs-12">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<input type="checkbox" name="register" id="register_novoTronco" value="register" class="filled-in chk-col-light-blue"/>
							<label for="register_novoTronco">Inserir linha de Registro IAX2?</label>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label title="type">Tipo</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="type" id="type_novoTronco" class="form-control show-tick">
            					<option value="friend">friend</option>
            					<option value="peer">peer</option>
								<option value="user">user</option>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label title="Cria um tronco por nome" for="troncoNome_novoTronco">Tronco Nome</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="troncoNome" id="troncoNome_novoTronco" class="form-control rota">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label title="Para criar somente um tronco deixe o campo Tronco Final vazio" for="troncoInicial_novoTronco">Tronco Inicial</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="troncoInicial" id="troncoInicial_novoTronco" class="form-control ramal">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label title="Cria toda a faixa, a partir do tronco inicial até o tronco final" for="troncoFinal_novoTronco">Tronco Final</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="troncoFinal" id="troncoFinal_novoTronco" class="form-control ramal">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="secret_novoTronco">Senha</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="secret" id="secret_novoTronco" class="form-control alphanumeric">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label>Contexto</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="context" id="context_novoTronco" class="form-control show-tick">
            					<option value=""> - </option>
            					<?php
									$tmpcat = get_ini_keys(ARQ_ENTRADASDDR_CONF);
            						foreach($tmpcat as $key=>$value) {
            							print "<option value=\"".$key."\">".$key."</option>";
            						}
									$tmpcat = get_ini_keys(ARQ_ENTRADASDDRCUSTOM_CONF);
            						foreach($tmpcat as $key=>$value) {
            							print "<option value=\"".$key."\">".$key."</option>";
            						}
									$tmpcat = meu_parse_ini_file(ARQ_CATEGORIAS_CONF);
									foreach($tmpcat as $key=>$value) {
										print "<option value=\"".$key."\">".$key."</option>";
									}
            					?>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="codec0_novoTronco">Codec 1</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="codec[]" id="codec0_novoTronco" class="form-control show-tick">
							<?php
								foreach ($codecs as $k=>$codec) {
							?>
								<option value="<?=$codec;?>"><?=$codec;?></option>
							<?php
								}
							?>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="codec1_novoTronco">Codec 2</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="codec[]" id="codec1_novoTronco" class="form-control show-tick">
							<?php
								foreach ($codecs as $k=>$codec) {
							?>
								<option value="<?=$codec;?>"><?=$codec;?></option>
							<?php
								}
							?>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="codec2_novoTronco">Codec 3</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="codec[]" id="codec2_novoTronco" class="form-control show-tick">
							<?php
								foreach ($codecs as $k=>$codec) {
							?>
								<option value="<?=$codec;?>"><?=$codec;?></option>
							<?php
								}
							?>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="codec3_novoTronco">Codec 4</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="codec[]" id="codec3_novoTronco" class="form-control show-tick">
							<?php
								foreach ($codecs as $k=>$codec) {
							?>
								<option value="<?=$codec;?>"><?=$codec;?></option>
							<?php
								}
							?>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="host_novoTronco">Host</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="host" id="host_novoTronco" class="form-control">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="username_novoTronco" title="username">Username</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="username" id="username_novoTronco" class="form-control">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label title="Endereço/Mascara (Ex.: 192.168.0.0/255.255.255.0)">Proíbe</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="proibeAddress" id="proibeAddress_novoTronco" class="form-control ip">
							</div>
						</div>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="proibeMask" id="proibeMask_novoTronco" class="form-control ip">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label title="Endereço/Mascara (Ex.: 192.168.0.0/255.255.255.0)">Permite</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="permiteAddress" id="permiteAddress_novoTronco" class="form-control ip">
							</div>
						</div>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="permiteMask" id="permiteMask_novoTronco" class="form-control ip">
								</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label>Qualify</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="qualify" id="qualify_novoTronco" class="form-control show-tick">
            					<option value=""> - </option>
            					<option value="yes">yes</option>
            					<option value="no">no</option>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="qualifyfreqok_novoTronco" title="Tempo em segundos">Qualifyfreq</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="qualifyfreqok" id="qualifyfreqok_novoTronco" class="form-control timeout">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label>Trunk</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="trunk" id="trunk_novoTronco" class="form-control show-tick">
            					<option value=""> - </option>
            					<option value="yes">yes</option>
								<option value="no">no</option>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label>Require Call Token</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="requirecalltoken" id="requirecalltoken_novoTronco" class="form-control show-tick">
            					<option value=""> - </option>
            					<option value="yes">yes</option>
								<option value="no">no</option>
							</select>
						</div>
					</div>
				</div>
				
				<button type="button" onclick="novoTronco()" class="btn btn-primary waves-effect">
					<i class="material-icons">save</i>
					<span>SALVAR</span>
			    	</button>
			    </form>
			    </div>


				</div>
				<!--#FIM - CRIAR TRONCO ##############################################################################################################-->
                            </div>


                        </div>
                    </div>
                </div>
                <!-- #END# MENU TRONCOS -->
            </div>
	</div>
	<!--END - PAGE CONTENT-->


	<!-- MODAL ================================================================================================================================== -->

		<!--MODAL EDITAR TRONCO-->
			<div class="modal fade" id="editarTroncoModal" tabindex="-1" role="dialog">
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h4 class="modal-title" id="editarTroncoLabel">Editar Tronco</h4>
						</div>
						<div class="modal-body">
							<div class="row clearfix demo-masked-input">
								<form id="formEditarTronco" method="post">
								<?=$text_form;?>
								<input type="hidden" name="cmd" value="editarTronco" />
								<input type="hidden" id="editarTronco" name="editarTronco" value="" />
								<!--Coluna esquerda - Editar Tronco-->
								<div class="col-md-8 col-sm-9 col-xs-12">
									<div class="col-xs-11">
										<p>Configurações</p>
										</br>
									</div>
									<div class="col-xs-1">
										<p>Copiar</p>
										</br>
									</div>
									<!--Register-->
									<div class="col-xs-12">
										<div class="form-group form-float">
											<input type="checkbox" name="register" id="register_editarTronco" value="register" class="filled-in chk-col-light-blue"/>
											<label for="register_editarTronco">Inserir linha de Registro IAX2?</label>
										</div>
									</div>
									<!--Tipo-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label title="type">Tipo</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="type" id="type_editarTronco" class="form-control show-tick">
													<option value="friend">friend</option>
													<option value="peer">peer</option>
													<option value="user">user</option>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-type" value="type" class="filled-in chk-col-light-blue"/>
										<label for="copiar-type"></label>
									</div>
									<!--Senha-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Senha</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group">
												<div class="form-line">
													<input type="text" name="secret" id="secret_editarTronco" class="form-control alphanumeric">
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-secret" value="secret" class="filled-in chk-col-light-blue"/>
										<label for="copiar-secret"></label>
									</div>
									<!--Categoria-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Categoria</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="context" id="context_editarTronco" class="form-control show-tick">
													<option value=""> - </option>
													<?php
														$tmpcat = get_ini_keys(ARQ_ENTRADASDDR_CONF);
														foreach($tmpcat as $key=>$value) {
															print "<option value=\"".$key."\">".$key."</option>";
														}
														$tmpcat = get_ini_keys(ARQ_ENTRADASDDRCUSTOM_CONF);
														foreach($tmpcat as $key=>$value) {
															print "<option value=\"".$key."\">".$key."</option>";
														}
														$tmpcat = meu_parse_ini_file(ARQ_CATEGORIAS_CONF);
														foreach($tmpcat as $key=>$value) {
															print "<option value=\"".$key."\">".$key."</option>";
														}
													?>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-context" value="context" class="filled-in chk-col-light-blue"/>
										<label for="copiar-context"></label>
									</div>
									<!--Codec-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Codec 1</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="codec[]" id="codec0_editarTronco" class="form-control show-tick">
												<?php
													foreach ($codecs as $k=>$codec) {
												?>
												<option value="<?=$codec;?>"><?=$codec;?></option>
												<?php
													}
												?>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-codec" value="codec" class="filled-in chk-col-light-blue"/>
										<label for="copiar-codec"></label>
									</div>
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Codec 2</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="codec[]" id="codec1_editarTronco" class="form-control show-tick">
												<?php
													foreach ($codecs as $k=>$codec) {
												?>
												<option value="<?=$codec;?>"><?=$codec;?></option>
												<?php
													}
												?>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
									</div>
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Codec 3</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="codec[]" id="codec2_editarTronco" class="form-control show-tick">
												<?php
													foreach ($codecs as $k=>$codec) {
												?>
												<option value="<?=$codec;?>"><?=$codec;?></option>
												<?php
													}
												?>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
									</div>
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Codec 4</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="codec[]" id="codec3_editarTronco" class="form-control show-tick">
												<?php
													foreach ($codecs as $k=>$codec) {
												?>
												<option value="<?=$codec;?>"><?=$codec;?></option>
												<?php
													}
												?>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
									</div>
									<!--Host-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label for="host_editarTronco">Host</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group">
												<div class="form-line">
													<input type="text" name="host" id="host_editarTronco" class="form-control">
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-host" value="host" class="filled-in chk-col-light-blue"/>
										<label for="copiar-host"></label>
									</div>
									<!--Username-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label for="username_editarTronco" title="username">Username</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group">
												<div class="form-line">
													<input type="text" name="username" id="username_editarTronco" class="form-control">
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-username" value="username" class="filled-in chk-col-light-blue"/>
										<label for="copiar-username"></label>
									</div>
									
									<!--Proíbe-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Proíbe</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="col-xs-6">
												<div class="form-group">
													<div class="form-line">
														<input type="text" name="proibeAddress" id="proibeAddress_editarTronco" class="form-control ip">
													</div>
												</div>
											</div>
											<div class="col-xs-6">
												<div class="form-group">
													<div class="form-line">
														<input type="text" name="proibeMask" id="proibeMask_editarTronco" class="form-control ip">
													</div>
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-proibe" value="proibe" class="filled-in chk-col-light-blue"/>
										<label for="copiar-proibe"></label>
									</div>
									<!--Permite-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Permite</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="col-xs-6">
												<div class="form-group">
													<div class="form-line">
														<input type="text" name="permiteAddress" id="permiteAddress_editarTronco" class="form-control ip">
													</div>
												</div>
											</div>
											<div class="col-xs-6">
												<div class="form-group">
													<div class="form-line">
														<input type="text" name="permiteMask" id="permiteMask_editarTronco" class="form-control ip">
													</div>
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-permite" value="permite" class="filled-in chk-col-light-blue"/>
										<label for="copiar-permite"></label>
									</div>
									<!--Qualify-->
									<div class="col-xs-11">
										<div class="row clearfix">
											<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
												<label>Qualify</label>
											</div>
											<div class="col-md-9 col-sm-8 col-xs-7">
												<div class="form-group form-float">
													<select name="qualify" id="qualify_editarTronco" class="form-control show-tick">
            											<option value=""> - </option>
            											<option value="yes">yes</option>
            											<option value="no">no</option>
													</select>
												</div>
											</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-qualify" value="qualify" class="filled-in chk-col-light-blue"/>
										<label for="copiar-qualify"></label>
									</div>
									<!--Qualifyfreq-->
									<div class="col-xs-11">
										<div class="row clearfix">
											<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
												<label for="qualifyfreqok_editarTronco" title="Tempo em segundos">Qualifyfreq</label>
											</div>
											<div class="col-md-9 col-sm-8 col-xs-7">
												<div class="form-group">
													<div class="form-line">
														<input type="text" name="qualifyfreqok" id="qualifyfreqok_editarTronco" class="form-control timeout">
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-qualifyfreqok" value="qualifyfreqok" class="filled-in chk-col-light-blue"/>
										<label for="copiar-qualifyfreqok"></label>
									</div>
									<!--Trunk-->
									<div class="col-xs-11">
										<div class="row clearfix">
											<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
												<label>Trunk</label>
											</div>
											<div class="col-md-9 col-sm-8 col-xs-7">
												<div class="form-group form-float" style="margin-bottom: 0px;">
													<select name="trunk" id="trunk_editarTronco" class="form-control show-tick">
            											<option value=""> - </option>
            											<option value="yes">yes</option>
														<option value="no">no</option>
													</select>
												</div>
											</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-trunk" value="trunk" class="filled-in chk-col-light-blue"/>
										<label for="copiar-trunk"></label>
									</div>
									<!--Requirecalltoken-->
									<div class="col-xs-11">
										<div class="row clearfix">
											<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
												<label>Require Call Token</label>
											</div>
											<div class="col-md-9 col-sm-8 col-xs-7">
												<div class="form-group form-float">
													<select name="requirecalltoken" id="requirecalltoken_editarTronco" class="form-control show-tick">
            											<option value=""> - </option>
            											<option value="no">no (default)</option>
														<option value="yes">yes</option>
													</select>
												</div>
											</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-requirecalltoken" value="requirecalltoken" class="filled-in chk-col-light-blue"/>
										<label for="copiar-requirecalltoken"></label>
									</div>

								</div>
								<!--Coluna direira - Copiar-->
								<div class="col-md-4 col-sm-3 col-xs-12">
									<p title="Copia as configurações selecionadas para os troncos selecionados abaixo.">Copiar para troncos:</p>
									<br>
									<div class="dd">
										<ul class="list-modal" style="overflow: hidden; height: 1000px; touch-action: manipulation;">
											<li class="dd-item">
												<div class="dd-handle">
												<input type="checkbox" name="paraTodos" onclick="marcarTodosTroncos()" id="paraTodos" class="filled-in chk-col-light-blue"/>
												<label for="paraTodos">Marcar Todos</label>
												</div>
											</li>
										<?php
											foreach ($troncos as $tronco=>$vetor) {
										?>
											<li class="dd-item">
												<div class="dd-handle">
												<input type="checkbox" name="copiarTroncos[]" id="copiarTronco-<?=$tronco;?>" value="<?=$tronco;?>" class="filled-in chk-col-light-blue"/>
												<label for="copiarTronco-<?=$tronco;?>"><?=$tronco;?></label>
												</div>
											</li>
										<?php
											}
										?>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
							<button type="button" id="closeEditarTroncoModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
						</div>
							</form>
					</div>
				</div>
			</div>
	    <!--#END of MODAL EDITAR TRONCO-->


	    <!--MODAL EXCLUIR TRONCO-->
            <div class="modal fade" id="excluirTroncoModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirTroncoLabel">Excluir Tronco</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirTronco" method="post">
				<?=$text_form;?>
				<input type="hidden" name="tipo" value="tronco" />
				<input type="hidden" name="cmd" value="excluirTronco" />
				<input type="hidden" id="excluirTronco" name="tronco" value="" />
			    <p>Tem certeza que deseja excluir o Tronco?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
							<button type="button" id="closeExcluirTroncoModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR TRONCO-->


		<!--MODAL APAGAR FAIXA-->
            <div class="modal fade" id="apagarFaixaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Apagar Faixa</h4>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
								<form id="formEditarUsuario" method="post">
									<?=$text_form;?>
									<input type="hidden" name="cmd" value="apagarFaixa" />

								<div class="row clearfix">
									<div class="col-lg-4 col-md-4 col-sm-4 col-xs-5 form-control-label">
										<label for="troncoInicial_apagarFaixa">Tronco Inicial</label>
									</div>
									<div class="col-lg-8 col-md-8 col-sm-8 col-xs-7">
										<div class="form-group">
											<div class="form-line">
												<input type="text" name="troncoInicial" id="troncoInicial_apagarFaixa" class="form-control ramal">
											</div>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-lg-4 col-md-4 col-sm-4 col-xs-5 form-control-label">
										<label for="troncoFinal_apagarFaixa">Tronco Final</label>
									</div>
									<div class="col-lg-8 col-md-8 col-sm-8 col-xs-7">
										<div class="form-group">
											<div class="form-line">
												<input type="text" name="troncoFinal" id="troncoFinal_apagarFaixa" class="form-control ramal">
											</div>
										</div>
									</div>
								</div>
							</div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Apagar</span>
							</button>
                            <button type="button" id="closeApagarFaixaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL APAGAR FAIXA-->


	<!--#END - MODAL ============================================================================================================================== -->

<script>


function novoTronco()
{
	
	document.getElementById("formNovoTronco").submit();
} 

function botaoExcluirTronco(excluirTronco) {
	$('#excluirTronco').val(excluirTronco);

	$('#excluirTroncoLabel').text("Excluir Tronco "+excluirTronco);
	$("#excluirTroncoModal").modal();
};

function marcarTodosTroncos() {
	if ( $('#paraTodos').is(":checked") == true) {
		$("input[name='copiarTroncos[]']").each(function(){
			//alert($(this).val());
			document.getElementById($(this).attr("id")).checked = true;
			//$(this).checked = true;
		});
	} else {
		$("input[name='copiarTroncos[]']").each(function(){
			document.getElementById($(this).attr("id")).checked = false;
			//$(this).checked = false;
		});
	}
};

$(document).ready(function(){

	var troncos = <?php echo json_encode($troncos, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;

	$(".editar-tronco").on('click', function(event) {
		event.preventDefault();

		var tronco = $(this).data('tronco');

		document.getElementById('editarTroncoLabel').innerHTML = "EditarTronco: "+tronco;

		$('#editarTronco').val(tronco);

		$('#secret_editarTronco').val(troncos[tronco].secret);
		$('#proibeAddress_editarTronco').val(troncos[tronco].proibeAddress);
		$('#proibeMask_editarTronco').val(troncos[tronco].proibeMask);
		$('#permiteAddress_editarTronco').val(troncos[tronco].permiteAddress);
		$('#permiteMask_editarTronco').val(troncos[tronco].permiteMask);
		$('#host_editarTronco').val(troncos[tronco].host);
		$('#username_editarTronco').val(troncos[tronco].username);
		$('#qualifyfreqok').val(troncos[tronco].qualifyfreqok);
		
		$('#register_editarTronco').prop('checked',false);
		if ( troncos[tronco].register == "true" ) {
			$('#register_editarTronco').prop('checked',true);
		}
		
		var aux = 0;
		$('#type_editarTronco option').each(function(){
			if ($(this).val() == troncos[tronco].type) {
				$('#type_editarTronco').selectpicker('val', troncos[tronco].type);
				aux = 1;
			} else if (aux != 1) {
				$('#tipoTronco_editarTronco').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#context_editarTronco option').each(function(){
			if ($(this).val() == troncos[tronco].context) {
				$('#context_editarTronco').selectpicker('val', troncos[tronco].context);
				aux = 1;
			} else if (aux != 1) {
				$('#context_editarTronco').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#qualify_editarTronco option').each(function(){
			if ($(this).val() == troncos[tronco].qualify) {
				$('#qualify_editarTronco').selectpicker('val', troncos[tronco].qualify);
				aux = 1;
			} else if (aux != 1) {
				$('#qualify_editarTronco').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#trunk_editarTronco option').each(function(){
			if ($(this).val() == troncos[tronco].trunk) {
				$('#trunk_editarTronco').selectpicker('val', troncos[tronco].trunk);
				aux = 1;
			} else if (aux != 1) {
				$('#trunk_editarTronco').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#requirecalltoken_editarTronco option').each(function(){
			if ($(this).val() == troncos[tronco].requirecalltoken) {
				$('#requirecalltoken_editarTronco').selectpicker('val', troncos[tronco].requirecalltoken);
				aux = 1;
			} else if (aux != 1) {
				$('#requirecalltoken_editarTronco').selectpicker('val', 'null');
			}
		});

		for(var i = 0; i < 4; i++) {
			$('#codec'+i+'_editarTronco').selectpicker('deselectAll');
			$('#codec'+i+'_editarTronco').selectpicker('val', troncos[tronco].codec[i]);
		}
		
	});
	
	function slimscrollReboot(){
		$('#editarTroncoModal .list-modal')
			.slimscroll({ destroy: true })
			.slimscroll({ height: '1000px' });
		//window.addEventListener("wheel", function(event){ event.preventDefault(); }, {passive: false} );
	};
	slimscrollReboot();
	
	$("#editarTroncoModal").on('show.bs.modal', function() {
		slimscrollReboot();
	});
	
	$('#troncoNome_novoTronco').on('input', function() {
		if($(this).val().length) {
			$('#troncoInicial_novoTronco').prop('disabled', true);
			$('#troncoFinal_novoTronco').prop('disabled', true);
		} else {
			$('#troncoInicial_novoTronco').prop('disabled', false);
			$('#troncoFinal_novoTronco').prop('disabled', false);
		}
	});
	
	$('#troncoInicial_novoTronco').on('input', function() {
		if($(this).val().length) {
			$('#troncoNome_novoTronco').prop('disabled', true);
			$('#troncoFinal_novoTronco').prop('disabled', false);
		} else {
			$('#troncoNome_novoTronco').prop('disabled', false);
			$('#troncoFinal_novoTronco').prop('disabled', false);
		}
	});

});

</script>