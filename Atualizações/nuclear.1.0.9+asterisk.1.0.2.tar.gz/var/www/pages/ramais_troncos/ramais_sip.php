<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.status.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.config.ramal.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_sip.php");
	require_once(DIR_WWW."funcoes/funcoes.network.debian7.php");

	//require_once(DIR_WWW."funcoes/funcoes.db.php");
	//require_once(DIR_WWW."funcoes/funcoes.config.usuarios.php");

	if ( isset($_REQUEST['tipo']) && $_REQUEST['tipo'] == "grupos") {
		$tipo = "grupos";
	} elseif ( isset($_REQUEST['tipo']) && $_REQUEST['tipo'] == "criar") {
		$tipo = "criar";
	} else {
		$tipo = "ramais";
	}

	// DECLARAÇÃO DE VARIÁVEIS ==============================================================================================

	//$ramaissip = meu_parse_ini_file(ARQ_RAMAIS_SIP);
	$ramaissip = get_ramais(); //Função nova para leitura de ramais e astdb ao mesmo tempo - Davi Almeida
	//print_r($ramaissip);
	//echo json_encode($ramaissip, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
	
	$gruposCaptura = get_ini_array("grupos-captura", ARQ_CONFIG_RAMAL);
	//Array ( [1] => vendas [2] => comercial [3] => suporte [4] => desenvolvimento )
	$codecs = get_ini_array("codecs", ARQ_CONFIG_RAMAL);
	//Array ( [1] => alaw [2] => ulaw [3] => g729 [4] => gsm )

	//RAMAL SIP ===============================================================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "novoRamal") {
	/*
		Array ( 
			[tipoRamal] => no
			[ramalInicial] => 1000 
			[ramalFinal] => 1009 
			[secret] => 123456 
			[context] => 1 
			[abreviado] => 1 
			[limit] => 1 
			[callgroup] => Array ( [0] => suporte ) 
			[pickupgroup] => Array ( [0] => vendas [1] => comercial [2] => develop [3] => suporte ) 
			[codec] => Array ( [0] => alaw [1] => ulaw [2] => g729 ) 
			[proibeAddress] => 0.0.0.0 
			[proibeMask] => 0.0.0.0 
			[permiteAddress] => 192.168.0.0 
			[permiteMask] => 255.255.0.0
			[transport] => udp
			[gravaIn] => yes 
			[gravaOut] => yes 
			[gravaInterno] => no 
		)
	*/
		//seta o tempo limite da aplicação para esperar mais tempo grandes loops demoram mais
		set_time_limit(600);
		
		//primeiro vamos checar a quantidade de ramais a serem criadas
		$inicio = $_POST['ramalInicial'];
		$fim = $_POST['ramalFinal'];
		
		$erro = "";
		if (!is_numeric($inicio)) {
			$erro = "Erro: Ramal inicial incorreto!";
		}
		if ($fim != "" && !is_numeric($fim)){
			$erro = "Erro: Ramal final incorreto!";
		}
		if ($_POST['proibeAddress'] != "" && !validate_ip($_POST['proibeAddress'])) {
			$erro = "Erro: IP proíbe inválido!";
		}
		if ($_POST['proibeMask'] != "" && !validate_netmask($_POST['proibeMask'])) {
			$erro = "Erro: Netmask proíbe inválido!";
		}
		if ($_POST['permiteAddress'] != "" && !validate_ip($_POST['permiteAddress'])) {
			$erro = "Erro: IP permite inválido!";
		}
		if ($_POST['permiteMask'] != "" && !validate_netmask($_POST['permiteMask'])) {
			$erro = "Erro: Netmask permite inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";

		}
		
		if ($fim > $inicio) {
			$qtde = ($fim - $inicio);
		} elseif ($fim == $inicio || ($inicio != "" && $fim == "") ) {
			$qtde = 0;
		} elseif ($inicio > $fim) {
			$qtde = ($inicio - $fim);
			$tmp = $fim;
			$fim = $inicio;
			$inicio = $tmp;
		}
		
		if ( !novos_ramais($_POST, $qtde, ARQ_RAMAIS_SIP) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";

		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";

		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "editarRamal") {
		/*
		Array ( 
		[editarRamal] => 5000
		[tipoRamal] => yes 
		[secret] => 102030 
		[context] => 2 
		[abreviado] => 2 
		[limit] => 5 
		[callgroup] => Array ( [0] => develop [1] => suporte ) 
		[pickupgroup] => Array ( [0] => develop [1] => suporte ) 
		[codec] => Array ( [0] => alaw [1] => ulaw [2] => g729 ) 
		[calleridname] => davi 
		[dtmf] => rfc2833 
		[mailbox] => 5000@device 
		[proibeAddress] => 0.0.0.0 
		[proibeMask] => 0.0.0.0 
		[permiteAddress] => 192.168.0.0 
		[permiteMask] => 255.255.0.0 
		[port] => 5060 
		[transport] => tcp,udp 
		[gravaIn] => yes 
		[gravaOut] => yes 
		[gravaInterno] => no 
		[copiar] => Array ( [0] => tipoRamal [1] => secret [2] => context [3] => abreviado [4] => limit [5] => callgroup [6] => pickupgroup [7] => codec [8] => calleridname [9] => dtmf [10] => mailbox [11] => proibe [12] => permite [13] => port [14] => transport [15] => gravaIn [16] => gravaOut [17] => gravaInterno )
		[copiarRamais] => Array ( [0] => 4000 [1] => 4001 [2] => 4002 )
		)
		*/
		$erro="";
		if (!is_numeric($_POST['editarRamal']) || $_POST['editarRamal'] == "") {
			$erro = "Erro: Ramal Incorreto!";
		}
		if ($_POST['proibeAddress'] != "" && !validate_ip($_POST['proibeAddress'])) {
			$erro = "Erro: IP proíbe inválido!";
		}
		if ($_POST['proibeMask'] != "" && !validate_netmask($_POST['proibeMask'])) {
			$erro = "Erro: Netmask proíbe inválido!";
		}
		if ($_POST['permiteAddress'] != "" && !validate_ip($_POST['permiteAddress'])) {
			$erro = "Erro: IP permite inválido!";
		}
		if ($_POST['permiteMask'] != "" && !validate_netmask($_POST['permiteMask'])) {
			$erro = "Erro: Netmask permite inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";

		}
		
		if ( !editar_ramais($_POST, ARQ_RAMAIS_SIP) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";

		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";

		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirRamal") {
		
		$erro="";
		if (!is_numeric($_POST['ramal']) || $_POST['ramal'] == "") {
			$erro = "Erro: Ramal Incorreto!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";

		}
		
		if ( !excluir_ramal($_POST['ramal'], ARQ_RAMAIS_SIP) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";

		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";

		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "apagarFaixa") {
		set_time_limit(600);
		
		$erro = "";

		$inicio = $_POST['ramalInicial'];
		$fim = $_POST['ramalFinal'];
			
		if ( $inicio != "" && !is_numeric($inicio)) {
			$erro = "Erro: Ramal inicial incorreto!";
		}
		if ( $fim != "" && !is_numeric($fim)) {
			$erro = "Erro: Ramal final incorreto!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";

		}
		
		if ($fim > $inicio) {
			$qtde = ($fim - $inicio);
		} elseif ($fim == $inicio || ($inicio != "" && $fim == "") ) {
			$qtde = 0;
		} elseif ($inicio > $fim) {
			$qtde = ($inicio - $fim);
			$tmp = $fim;
			$fim = $inicio;
			$inicio = $tmp;
		}
		for ($i = 0; $i <= $qtde; $i++) {
			excluir_ramal($inicio, ARQ_RAMAIS_SIP);
			$inicio++;
		}
		print "<script>
			alert('Configurações salvas com sucesso!');
			document.getElementById('form_{$pagina}_{$menu}').submit();
		</script>";
	}

	//GRUPOS DE CAPTURA =======================================================================================================

	if (isset($_POST['cmd']) && $_POST['cmd'] == "novoGrupo") {
		//[nome] => teste

		$erro = "";
		$nomeGrupo = filter_var($_POST['nome'], FILTER_SANITIZE_STRING);
		if ($nomeGrupo == "") {
			$erro = "Erro: Nome de Grupo inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";

		}

		if ( !insert_ini_array($nomeGrupo, "grupos-captura", ARQ_CONFIG_RAMAL) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";

		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";

		}
	}

	if (isset($_POST['cmd']) && $_POST['cmd'] == "editarGrupo") {
		//[nome] => teste

		$erro = "";
		$nomeGrupo = filter_var($_POST['nome'], FILTER_SANITIZE_STRING);
		if ($nomeGrupo == "") {
			$erro = "Erro: Nome de Grupo inválido!";
		}
		if ($_POST['id'] == "") {
			$erro = "Erro: Id inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";

		}

		if ( !edit_grupo($_POST['id'], $nomeGrupo) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";

		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";

		}
	}

	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirGrupo") {
		//[id] => 0 [nome] => vendas
		$erro = "";
		$nomeGrupo = filter_var($_POST['nome'], FILTER_SANITIZE_STRING);
		if ($nomeGrupo == "") {
			$erro = "Erro: Nome de Grupo inválido!";
		}
		if (!is_numeric($_POST['id']) && $_POST['id'] == "") {
			$erro = "Erro: Id inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";

		}

		if ( !excluir_grupo($_POST['id'], $nomeGrupo) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";

		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";

		}
	}
?>

	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- MENU RAMAIS SIP -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
						<div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
                                	<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
						</div>
                        <div class="body">
                            <ul class="nav nav-tabs tab-nav-right" role="tablist">
                                <li role="presentation" <?php echo ( $tipo == "ramais" ? "class=\"active\"" : "" ); ?> ><a href="#ramais" data-toggle="tab">RAMAIS</a></li>
                                <li role="presentation" <?php echo ( $tipo == "criar" ? "class=\"active\"" : "" ); ?> ><a href="#criar" data-toggle="tab">CRIAR RAMAIS</a></li>
								<li role="presentation" <?php echo ( $tipo == "grupos" ? "class=\"active\"" : "" ); ?> ><a href="#grupos" data-toggle="tab">GRUPOS DE CAPTURA</a></li>
							</ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
				<!-- RAMAIS SIP #####################################################################################################################-->
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "ramais" ? "in active" : "" ); ?>" id="ramais">


			    <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
                                            <th>Número</th>
											<th>Tipo</th>
											<th>Categoria</th>
                                            <th>IP</th>
											<th>Status</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					    <?php
						foreach($ramaissip as $ramal=>$vetor) {
						    if (is_array($vetor)) {
								$statusRamal = infoRamalSIP($ramal);
								if ($vetor['tipoRamal'] == "yes") {
									$tipo = "Call Center";
								} else {
									$tipo = "Pabx";
								}
					    ?>
							<tr>
								<td><?=$ramal;?></td>
								<td><?=$tipo;?></td>
								<td><?=$vetor['context'];?></td>
								<td><?=$statusRamal['Addr->IP'];?></td> 
								<td><?=$statusRamal['Status'];?></td>
								<td>
									<a href="javascript:;" class="editar-ramal" data-ramal="<?=$ramal;?>" data-toggle="modal" data-target="#editarRamalModal"><i class="material-icons" title="Editar">edit</i></a>&nbsp;
									<a href="javascript:;" class="play" onclick="botaoExcluirRamal('<?=$ramal;?>')"><i class="material-icons" title="Excluir">delete</i></a>
								</td>
						        </tr>
					    <?php
						    }
						}
					    ?>
                                    </tbody>
                                </table>
                            </div>

						<button type="button" class="btn btn-danger waves-effect" data-toggle="modal" data-target="#apagarFaixaModal">
							<i class="material-icons">delete</i>
							<span>Apagar Faixa</span>
						</button>

				</div>
				<!--#FIM - RAMAIS SIP ##############################################################################################################-->
				<!-- CRIAR RAMAL ###################################################################################################################-->
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "criar" ? "in active" : "" ); ?>" id="criar">

			</br>
			<h4>Novo Ramal SIP</h4>
			</br>
			    <div class="demo-masked-input">
			    <form id="formNovoRamal" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="novoRamal" />

					<div class="row clearfix">
						<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
							<label>Tipo de Ramal</label>
						</div>
						<div class="col-md-3 col-sm-3 col-xs-7">
							<div class="form-group form-float" style="margin-bottom: 0px;">
								<select name="tipoRamal" id="tipoRamal_novoRamal" class="form-control show-tick">
									<option value="no">Simples</option>
									<option value="yes">Call Center</option>
								</select>
							</div>
						</div>
					</div>
					<div class="row clearfix">
						<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
							<label title="Ramal Call Center disca sem estar logado?">Disca não logado</label>
						</div>
						<div class="demo-radio-button">
							<input name="discaNaoLogado" type="radio" id="discaNaoLogado_1_novoRamal" value="yes"/>
							<label for="discaNaoLogado_1_novoRamal">SIM</label>
							<input name="discaNaoLogado" type="radio" id="discaNaoLogado_2_novoRamal" value="no" checked/>
							<label for="discaNaoLogado_2_novoRamal">NÃO</label>
						</div>
					</div>
					<div class="row clearfix">
						<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
							<label title="Para criar somente um ramal deixe o campo Ramal Final vazio" for="ramalInicial_novoRamal">Ramal Inicial</label>
						</div>
						<div class="col-md-2 col-sm-3 col-xs-7">
							<div class="form-group" style="margin-bottom: 0px;">
								<div class="form-line">
									<input type="text" name="ramalInicial" id="ramalInicial_novoRamal" class="form-control ramal">
								</div>
							</div>
						</div>
					</div>
					<div class="row clearfix">
						<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
							<label title="Cria toda a faixa, a partir do ramal inicial até o ramal final" for="ramalFinal_novoRamal">Ramal Final</label>
						</div>
						<div class="col-md-2 col-sm-3 col-xs-7">
							<div class="form-group" style="margin-bottom: 0px;">
								<div class="form-line">
									<input type="text" name="ramalFinal" id="ramalFinal_novoRamal" class="form-control ramal">
								</div>
							</div>
						</div>
					</div>
					<div class="row clearfix">
						<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
							<label for="secret_novoRamal">Senha</label>
						</div>
						<div class="col-md-2 col-sm-3 col-xs-7">
							<div class="form-group" style="margin-bottom: 0px;">
								<div class="form-line">
									<input type="password" name="secret" id="secret_novoRamal" class="form-control">
								</div>
							</div>
						</div>
					</div>
					<div class="row clearfix">
						<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
							<label>Categoria</label>
						</div>
						<div class="col-md-3 col-sm-3 col-xs-7">
							<div class="form-group form-float" style="margin-bottom: 0px;">
								<select name="context" id="context_novoRamal" class="form-control show-tick">
									<option value=""> - </option>
									<?php
										$tmpcat = meu_parse_ini_file(ARQ_CATEGORIAS_CONF);
										foreach($tmpcat as $key=>$value) {
											print "<option value=\"".$key."\">".$key."</option>";
										}
									?>
								</select>
							</div>
						</div>
					</div>
					<div class="row clearfix">
						<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
							<label>Abreviado</label>
						</div>
						<div class="col-md-3 col-sm-3 col-xs-7">
							<div class="form-group form-float" style="margin-bottom: 0px;">
								<select name="abreviado" id="abreviado_novoRamal" class="form-control show-tick">
									<option value=""> - </option>
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
									<option value="6">6</option>
									<option value="7">7</option>
									<option value="8">8</option>
									<option value="9">9</option>
									<option value="10">10</option>
								</select>
							</div>
						</div>
					</div>
					<div class="row clearfix">
						<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
							<label for="limit_novoRamal">Limite de ligações</label>
						</div>
						<div class="col-md-2 col-sm-3 col-xs-7">
							<div class="form-group" style="margin-bottom: 0px;">
								<div class="form-line">
									<input type="text" name="limit" id="limit_novoRamal" class="form-control ramal">
								</div>
							</div>
						</div>
					</div>
					<div class="row clearfix">
						<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
							<label for="callgroup_novoRamal">Callgroup</label>
						</div>
						<div class="col-md-3 col-sm-3 col-xs-7">
							<div class="form-group" style="margin-bottom: 0px;">
								<select name="callgroup[]" id="callgroup_novoRamal" class="form-control show-tick" multiple>
						<?php
							foreach ($gruposCaptura as $id=>$grupo) {
						?>
									<option value="<?=$grupo;?>"><?=$grupo;?></option>
						<?php
							}
						?>
								</select>
							</div>
						</div>
					</div>
					<div class="row clearfix">
						<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
							<label for="pickupgroup_novoRamal">Pickupgroup</label>
						</div>
						<div class="col-md-3 col-sm-3 col-xs-7">
							<div class="form-group form-float" style="margin-bottom: 0px;">
								<select name="pickupgroup[]" id="pickupgroup_novoRamal" class="form-control show-tick" multiple>
						<?php
							foreach ($gruposCaptura as $id=>$grupo) {
						?>
									<option value="<?=$grupo;?>"><?=$grupo;?></option>
						<?php
							}
						?>
								</select>
							</div>
						</div>
					</div>
					<div class="row clearfix">
						<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
							<label for="codec0_novoRamal">Codec 1</label>
						</div>
						<div class="col-md-3 col-sm-3 col-xs-7">
							<div class="form-group form-float" style="margin-bottom: 0px;">
								<select class="select2" name="codec[]" id="codec0_novoRamal" class="form-control show-tick">
								<?php
									foreach ($codecs as $k=>$codec) {
								?>
									<option value="<?=$codec;?>"><?=$codec;?></option>
								<?php
									}
								?>
								</select>
							</div>
						</div>
					</div>
					<div class="row clearfix">
						<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
							<label for="codec1_novoRamal">Codec 2</label>
						</div>
						<div class="col-md-3 col-sm-3 col-xs-7">
							<div class="form-group form-float" style="margin-bottom: 0px;">
								<select class="select2" name="codec[]" id="codec1_novoRamal" class="form-control show-tick">
								<?php
									foreach ($codecs as $k=>$codec) {
								?>
									<option value="<?=$codec;?>"><?=$codec;?></option>
								<?php
									}
								?>
								</select>
							</div>
						</div>
					</div>
					<div class="row clearfix">
						<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
							<label for="codec2_novoRamal">Codec 3</label>
						</div>
						<div class="col-md-3 col-sm-3 col-xs-7">
							<div class="form-group form-float" style="margin-bottom: 0px;">
								<select class="select2" name="codec[]" id="codec2_novoRamal" class="form-control show-tick">
								<?php
									foreach ($codecs as $k=>$codec) {
								?>
									<option value="<?=$codec;?>"><?=$codec;?></option>
								<?php
									}
								?>
								</select>
							</div>
						</div>
					</div>
					<div class="row clearfix">
						<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
							<label for="codec3_novoRamal">Codec 4</label>
						</div>
						<div class="col-md-3 col-sm-3 col-xs-7">
							<div class="form-group form-float" style="margin-bottom: 0px;">
								<select class="select2" name="codec[]" id="codec3_novoRamal" class="form-control show-tick">
								<?php
									foreach ($codecs as $k=>$codec) {
								?>
									<option value="<?=$codec;?>"><?=$codec;?></option>
								<?php
									}
								?>
								</select>
							</div>
						</div>
					</div>
					<div class="row clearfix">
						<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
							<label title="Endereço/Mascara (Ex.: 192.168.0.0/255.255.255.0)">Proíbe</label>
						</div>
						<div class="col-md-2 col-sm-3 col-xs-7">
							<div class="form-group" style="margin-bottom: 0px;">
								<div class="form-line">
									<input type="text" name="proibeAddress" id="proibeAddress_novoRamal" class="form-control ip">
								</div>
							</div>
						</div>
						<div class="col-md-2 col-sm-3 col-xs-7">
							<div class="form-group" style="margin-bottom: 0px;">
								<div class="form-line">
									<input type="text" name="proibeMask" id="proibeMask_novoRamal" class="form-control ip">
								</div>
							</div>
						</div>
					</div>
					<div class="row clearfix">
						<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
							<label title="Endereço/Mascara (Ex.: 192.168.0.0/255.255.255.0)">Permite</label>
						</div>
						<div class="col-md-2 col-sm-3 col-xs-7">
							<div class="form-group" style="margin-bottom: 0px;">
								<div class="form-line">
									<input type="text" name="permiteAddress" id="permiteAddress_novoRamal" class="form-control ip">
								</div>
							</div>
						</div>
						<div class="col-md-2 col-sm-3 col-xs-7">
							<div class="form-group" style="margin-bottom: 0px;">
								<div class="form-line">
									<input type="text" name="permiteMask" id="permiteMask_novoRamal" class="form-control ip">
									</div>
							</div>
						</div>
					</div>
					<div class="row clearfix">
						<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
							<label>Transporte</label>
						</div>
						<div class="col-md-3 col-sm-3 col-xs-7">
							<div class="form-group form-float" style="margin-bottom: 0px;">
								<select name="transport" id="transport_novoRamal" class="form-control show-tick">
									<option value="udp">UDP</option>
									<option value="tcp">TCP</option>
									<option value="tcp,udp">Ambos</option>
								</select>
							</div>
						</div>
					</div>
					<div class="row clearfix">
						<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
							<label>Sendrpid</label>
						</div>
						<div class="col-md-3 col-sm-3 col-xs-7">
							<div class="form-group form-float" style="margin-bottom: 0px;">
								<select name="sendrpid" id="sendrpid_novoRamal" class="form-control show-tick">
									<option value=""> - </option>
									<option value="yes">yes</option>
									<option value="rpid">rpid</option>
									<option value="pai">pai</option>
									<option value="no">no</option>
								</select>
							</div>
						</div>
					</div>
					<div class="row clearfix">
						<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
							<label>Trustrpid</label>
						</div>
						<div class="col-md-3 col-sm-3 col-xs-7">
							<div class="form-group form-float" style="margin-bottom: 0px;">
								<select name="trustrpid" id="trustrpid_novoRamal" class="form-control show-tick">
									<option value=""> - </option>
									<option value="yes">yes</option>
									<option value="no">no</option>
								</select>
							</div>
						</div>
					</div>
					<div class="row clearfix">
						<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
							<label title="Gravar ligações recebidas">Gravar Entrada</label>
						</div>
						<div class="demo-radio-button">
							<input name="gravaIn" type="radio" id="gravaIn_1_novoRamal" value="yes"/>
							<label for="gravaIn_1_novoRamal">SIM</label>
							<input name="gravaIn" type="radio" id="gravaIn_2_novoRamal" value="no" checked/>
							<label for="gravaIn_2_novoRamal">NÃO</label>
						</div>
					</div>
					<div class="row clearfix">
						<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
							<label title="Gravar ligações realizadas">Gravar Saída</label>
						</div>
						<div class="demo-radio-button">
							<input name="gravaOut" type="radio" id="gravaOut_1_novoRamal" value="yes"/>
							<label for="gravaOut_1_novoRamal">SIM</label>
							<input name="gravaOut" type="radio" id="gravaOut_2_novoRamal" value="no" checked/>
							<label for="gravaOut_2_novoRamal">NÃO</label>
						</div>
					</div>
					<div class="row clearfix">
						<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
							<label title="Gravar ligações entre ramais">Gravar Interno</label>
						</div>
						<div class="demo-radio-button">
							<input name="gravaInterno" type="radio" id="gravaInterno_1_novoRamal" value="yes"/>
							<label for="gravaInterno_1_novoRamal">SIM</label>
							<input name="gravaInterno" type="radio" id="gravaInterno_2_novoRamal" value="no" checked/>
							<label for="gravaInterno_2_novoRamal">NÃO</label>
						</div>
					</div>
					<div class="row clearfix">
						<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
							<label title="Ramal CRM">CRM</label>
						</div>
						<div class="demo-radio-button">
							<input name="crm" type="radio" id="crm_1_novoRamal" value="yes"/>
							<label for="crm_1_novoRamal">SIM</label>
							<input name="crm" type="radio" id="crm_2_novoRamal" value="no" checked/>
							<label for="crm_2_novoRamal">NÃO</label>
						</div>
					</div>
					<button type="button" onclick="novoRamal()" class="btn btn-primary waves-effect">
						<i class="material-icons">save</i>
						<span>SALVAR</span>
			    	</button>
			    </form>
			    </div>


				</div>
				<!--#FIM - CRIAR RAMAL ##############################################################################################################-->
				<!-- GRUPOS DE CAPTURA ##############################################################################################################-->
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "grupos" ? "in active" : "" ); ?>" id="grupos">


			    <button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novoGrupoModal">
				<i class="material-icons">add_circle</i>
				<span>NOVO GRUPO</span>
			    </button>
			    <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
					    <th>Id</th>
					    <th>Descrição</th>
					    <th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					    <?php
						foreach ($gruposCaptura as $id=>$grupo){
					    ?>
							<tr>
								<td><?=$id;?></td>
								<td><?=$grupo;?></td> 
								<td>
									<a href="javascript:;" class="play" onclick="botaoEditarGrupo('<?=$id;?>','<?=$grupo;?>')"><i class="material-icons" title="Editar">edit</i></a>&nbsp;
									<a href="javascript:;" class="play" onclick="botaoExcluirGrupo('<?=$id;?>','<?=$grupo;?>')"><i class="material-icons" title="Excluir">delete</i></a>
								</td>
						        </tr>
					    <?php
						}
					    ?>
                                    </tbody>
                                </table>
                            </div>


                                </div>
				<!--#FIM - GRUPOS DE CAPTURA ########################################################################################################-->
                            </div>


                        </div>
                    </div>
                </div>
                <!-- #END# MENU RAMAIS SIP -->
            </div>
	</div>
	<!--END - PAGE CONTENT-->


	<!-- MODAL ================================================================================================================================== -->

		<!--MODAL EDITAR RAMAL-->
			<div class="modal fade" id="editarRamalModal" tabindex="-1" role="dialog">
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h4 class="modal-title" id="editarRamalLabel">Editar Ramal</h4>
						</div>
						<div class="modal-body">
							<div class="row clearfix demo-masked-input">
								<form id="formEditarRamal" method="post">
								<?=$text_form;?>
								<input type="hidden" name="cmd" value="editarRamal" />
								<input type="hidden" id="editarRamal" name="editarRamal" value="" />
								<!--Coluna esquerda - Editar Ramal-->
								<div class="col-md-8 col-sm-9 col-xs-12">
									<div class="col-xs-11">
										<p>Configurações</p>
										</br>
									</div>
									<div class="col-xs-1">
										<p>Copiar</p>
										</br>
									</div>
									<!--Tipo-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Tipo de Ramal</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float" >
												<select name="tipoRamal" id="tipoRamal_editarRamal" class="form-control show-tick">
													<option value="no">Simples</option>
													<option value="yes">Call Center</option>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-tipoRamal" value="tipoRamal" class="filled-in chk-col-light-blue"/>
										<label for="copiar-tipoRamal"></label>
									</div>
									<!--Disca não logado-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Disca Não Logado</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="demo-radio-button">
												<input name="discaNaoLogado" type="radio" id="discaNaoLogado_1_editarRamal" value="yes"/>
												<label for="discaNaoLogado_1_editarRamal">SIM</label>
												<input name="discaNaoLogado" type="radio" id="discaNaoLogado_2_editarRamal" value="no" checked/>
												<label for="discaNaoLogado_2_editarRamal">NÃO</label>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-discaNaoLogado" value="discaNaoLogado" class="filled-in chk-col-light-blue"/>
										<label for="copiar-discaNaoLogado"></label>
									</div>
									<!--Senha-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Senha</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group">
												<div class="form-line">
													<input type="text" name="secret" id="secret_editarRamal" class="form-control">
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-secret" value="secret" class="filled-in chk-col-light-blue"/>
										<label for="copiar-secret"></label>
									</div>
									<!--Categoria-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Categoria</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="context" id="context_editarRamal" class="form-control show-tick">
													<option value=""> - </option>
													<?php
														$tmpcat = meu_parse_ini_file(ARQ_CATEGORIAS_CONF);
														foreach($tmpcat as $key=>$value) {
															print "<option value=\"".$key."\">".$key."</option>";
														}
													?>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-context" value="context" class="filled-in chk-col-light-blue"/>
										<label for="copiar-context"></label>
									</div>
									<!--Abreviado-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Abreviado</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="abreviado" id="abreviado_editarRamal" class="form-control show-tick">
													<option value=""> - </option>
													<option value="1">1</option>
													<option value="2">2</option>
													<option value="3">3</option>
													<option value="4">4</option>
													<option value="5">5</option>
													<option value="6">6</option>
													<option value="7">7</option>
													<option value="8">8</option>
													<option value="9">9</option>
													<option value="10">10</option>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-abreviado" value="abreviado" class="filled-in chk-col-light-blue"/>
										<label for="copiar-abreviado"></label>
									</div>
									<!--Limit-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Limite de ligações</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group">
												<div class="form-line">
													<input type="text" name="limit" id="limit_editarRamal" class="form-control ramal">
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-limit" value="limit" class="filled-in chk-col-light-blue"/>
										<label for="copiar-limit"></label>
									</div>
									<!--Callgroup-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Callgroup</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group">
												<select name="callgroup[]" id="callgroup_editarRamal" class="form-control show-tick" multiple>
											<?php
													foreach ($gruposCaptura as $id=>$grupo) {
											?>
														<option value="<?=$grupo;?>"><?=$grupo;?></option>
											<?php
												}
											?>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-callgroup" value="callgroup" class="filled-in chk-col-light-blue"/>
										<label for="copiar-callgroup"></label>
									</div>
									<!--Pickupgroup-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Pickupgroup</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group">
												<select name="pickupgroup[]" id="pickupgroup_editarRamal" class="form-control show-tick" multiple>
											<?php
													foreach ($gruposCaptura as $id=>$grupo) {
											?>
														<option value="<?=$grupo;?>"><?=$grupo;?></option>
											<?php
												}
											?>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-pickupgroup" value="pickupgroup" class="filled-in chk-col-light-blue"/>
										<label for="copiar-pickupgroup"></label>
									</div>
									<!--Codec-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Codec 1</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="codec[]" id="codec0_editarRamal" class="form-control show-tick">
												<?php
													foreach ($codecs as $k=>$codec) {
												?>
												<option value="<?=$codec;?>"><?=$codec;?></option>
												<?php
													}
												?>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-codec" value="codec" class="filled-in chk-col-light-blue"/>
										<label for="copiar-codec"></label>
									</div>
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Codec 2</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="codec[]" id="codec1_editarRamal" class="form-control show-tick">
												<?php
													foreach ($codecs as $k=>$codec) {
												?>
												<option value="<?=$codec;?>"><?=$codec;?></option>
												<?php
													}
												?>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
									</div>
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Codec 3</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="codec[]" id="codec2_editarRamal" class="form-control show-tick">
												<?php
													foreach ($codecs as $k=>$codec) {
												?>
												<option value="<?=$codec;?>"><?=$codec;?></option>
												<?php
													}
												?>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
									</div>
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Codec 4</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="codec[]" id="codec3_editarRamal" class="form-control show-tick">
												<?php
													foreach ($codecs as $k=>$codec) {
												?>
												<option value="<?=$codec;?>"><?=$codec;?></option>
												<?php
													}
												?>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
									</div>
									<!--calleridname-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Nome</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group">
												<div class="form-line">
													<input type="text" name="calleridname" id="calleridname_editarRamal" class="form-control">
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-calleridname" value="calleridname" class="filled-in chk-col-light-blue"/>
										<label for="copiar-calleridname"></label>
									</div>
									<!--DTMF-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>DTMF</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="dtmf" id="dtmf_editarRamal" class="form-control show-tick">
													<option value="rfc2833">RFC2833</option>
													<option value="inband">Inband</option>
													<option value="auto">Auto</option>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-dtmf" value="dtmf" class="filled-in chk-col-light-blue"/>
										<label for="copiar-dtmf"></label>
									</div>
									<!--MailBox-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Caixa Postal</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group">
												<div class="form-line">
													<input type="text" name="mailbox" id="mailbox_editarRamal" class="form-control">
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-mailbox" value="mailbox" class="filled-in chk-col-light-blue"/>
										<label for="copiar-mailbox"></label>
									</div>
									<!--Proíbe-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Proíbe</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="col-xs-6">
												<div class="form-group">
													<div class="form-line">
														<input type="text" name="proibeAddress" id="proibeAddress_editarRamal" class="form-control ip">
													</div>
												</div>
											</div>
											<div class="col-xs-6">
												<div class="form-group">
													<div class="form-line">
														<input type="text" name="proibeMask" id="proibeMask_editarRamal" class="form-control ip">
													</div>
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-proibe" value="proibe" class="filled-in chk-col-light-blue"/>
										<label for="copiar-proibe"></label>
									</div>
									<!--Permite-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Permite</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="col-xs-6">
												<div class="form-group">
													<div class="form-line">
														<input type="text" name="permiteAddress" id="permiteAddress_editarRamal" class="form-control ip">
													</div>
												</div>
											</div>
											<div class="col-xs-6">
												<div class="form-group">
													<div class="form-line">
														<input type="text" name="permiteMask" id="permiteMask_editarRamal" class="form-control ip">
													</div>
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-permite" value="permite" class="filled-in chk-col-light-blue"/>
										<label for="copiar-permite"></label>
									</div>
									<!--Porta-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Porta SIP</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group">
												<div class="form-line">
													<input type="text" name="port" id="port_editarRamal" class="form-control ramal">
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-port" value="port" class="filled-in chk-col-light-blue"/>
										<label for="copiar-port"></label>
									</div>
									<!--Transporte-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Transporte</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="transport" id="transport_editarRamal" class="form-control show-tick">
													<option value="udp">UDP</option>
													<option value="tcp">TCP</option>
													<option value="tcp,udp">Ambos</option>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-transport" value="transport" class="filled-in chk-col-light-blue"/>
										<label for="copiar-transport"></label>
									</div>
									<!--Sendrpid-->
									<div class="col-xs-11">
										<div class="row clearfix">
											<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
												<label>Sendrpid</label>
											</div>
											<div class="col-md-9 col-sm-8 col-xs-7">
												<div class="form-group form-float">
													<select name="sendrpid" id="sendrpid_editarRamal" class="form-control show-tick">
														<option value=""> - </option>
														<option value="yes">yes</option>
														<option value="rpid">rpid</option>
														<option value="pai">pai</option>
														<option value="no">no</option>
													</select>
												</div>
											</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-sendrpid" value="sendrpid" class="filled-in chk-col-light-blue"/>
										<label for="copiar-sendrpid"></label>
									</div>
									<!--Trustrpid-->
									<div class="col-xs-11">
										<div class="row clearfix">
											<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
												<label>Trustrpid</label>
											</div>
											<div class="col-md-9 col-sm-8 col-xs-7">
												<div class="form-group form-float">
													<select name="trustrpid" id="trustrpid_editarRamal" class="form-control show-tick">
														<option value=""> - </option>
														<option value="yes">yes</option>
														<option value="no">no</option>
													</select>
												</div>
											</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-trustrpid" value="trustrpid" class="filled-in chk-col-light-blue"/>
										<label for="copiar-trustrpid"></label>
									</div>
									<!--GravaIn-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Gravar Entrada</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="demo-radio-button">
												<input name="gravaIn" type="radio" id="gravaIn_1_editarRamal" value="yes"/>
												<label for="gravaIn_1_editarRamal">SIM</label>
												<input name="gravaIn" type="radio" id="gravaIn_2_editarRamal" value="no" checked/>
												<label for="gravaIn_2_editarRamal">NÃO</label>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-gravaIn" value="gravaIn" class="filled-in chk-col-light-blue"/>
										<label for="copiar-gravaIn"></label>
									</div>
									<!--gravaOut-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Gravar Saída</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="demo-radio-button">
												<input name="gravaOut" type="radio" id="gravaOut_1_editarRamal" value="yes"/>
												<label for="gravaOut_1_editarRamal">SIM</label>
												<input name="gravaOut" type="radio" id="gravaOut_2_editarRamal" value="no" checked/>
												<label for="gravaOut_2_editarRamal">NÃO</label>
											</div>
										</div>
										</div>
									</div>
									<!--GravaInterno-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Gravar Interno</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="demo-radio-button">
												<input name="gravaInterno" type="radio" id="gravaInterno_1_editarRamal" value="yes"/>
												<label for="gravaInterno_1_editarRamal">SIM</label>
												<input name="gravaInterno" type="radio" id="gravaInterno_2_editarRamal" value="no" checked/>
												<label for="gravaInterno_2_editarRamal">NÃO</label>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-gravaInterno" value="gravaInterno" class="filled-in chk-col-light-blue"/>
										<label for="copiar-gravaInterno"></label>
									</div>
									<!--CRM-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>CRM</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="demo-radio-button">
												<input name="crm" type="radio" id="crm_1_editarRamal" value="yes"/>
												<label for="crm_1_editarRamal">SIM</label>
												<input name="crm" type="radio" id="crm_2_editarRamal" value="no" checked/>
												<label for="crm_2_editarRamal">NÃO</label>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-crm" value="crm" class="filled-in chk-col-light-blue"/>
										<label for="copiar-crm"></label>
									</div>
								</div>
								<!--Coluna direira - Copiar-->
								<div class="col-md-4 col-sm-3 col-xs-12">
									<p title="Copia as configurações selecionadas para os ramais selecionados abaixo.">Copiar para ramais:</p>
									<br>
									<div class="dd">
										<ul class="list-modal" style="overflow: hidden; height: 1000px; touch-action: manipulation;">
											<li class="dd-item">
												<div class="dd-handle">
												<input type="checkbox" name="paraTodos" onclick="marcarTodosRamais()" id="paraTodos" class="filled-in chk-col-light-blue"/>
												<label for="paraTodos">Marcar Todos</label>
												</div>
											</li>
										<?php
											foreach ($ramaissip as $ramal=>$vetor) {
										?>
											<li class="dd-item">
												<div class="dd-handle">
												<input type="checkbox" name="copiarRamais[]" id="copiarRamal-<?=$ramal;?>" value="<?=$ramal;?>" class="filled-in chk-col-light-blue"/>
												<label for="copiarRamal-<?=$ramal;?>"><?=$ramal;?></label>
												</div>
											</li>
										<?php
											}
										?>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
							<button type="button" id="closeEditarRamalModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
						</div>
							</form>
					</div>
				</div>
			</div>
	    <!--#END of MODAL EDITAR RAMAL-->


	    <!--MODAL EXCLUIR RAMAL-->
            <div class="modal fade" id="excluirRamalModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirRamalLabel">Excluir Ramal</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirRamal" method="post">
				<?=$text_form;?>
				<input type="hidden" name="tipo" value="ramal" />
				<input type="hidden" name="cmd" value="excluirRamal" />
				<input type="hidden" id="excluirRamal" name="ramal" value="" />
			    <p>Tem certeza que deseja excluir o Ramal?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
							<button type="button" id="closeExcluirRamalModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR RAMAL-->


	    <!--MODAL NOVO GRUPO DE CAPTURA-->
            <div class="modal fade" id="novoGrupoModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="novoGrupoLabel">Novo Grupo de Captura</h4>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
							<form id="formNovoGrupo" method="post">
							<?=$text_form;?>
							<input type="hidden" name="tipo" value="grupos" />
							<input type="hidden" name="cmd" value="novoGrupo" />

								<div class="row clearfix">
                                    <div class="col-sm-3 col-xs-5 form-control-label">
                                        <label for="novoGrupo_nome">Nome</label>
                                    </div>
                                    <div class="col-sm-9 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="nome" id="novoGrupo_nome" class="form-control">
                                            </div>
                                        </div>
                                    </div>
								</div>

							</div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
                            <button type="button" id="closeNovoGrupoModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
							</form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL NOVO GRUPO DE CAPTURA-->

	    <!--MODAL EDITAR GRUPO DE CAPTURA-->
            <div class="modal fade" id="editarGrupoModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="editarGrupoLabel">Editar Grupo de Captura</h4>
                        </div>
                        <div class="modal-body">
			    <div class="demo-masked-input">
			    <form id="formEditarGrupo" method="post">
				<?=$text_form;?>
				<input type="hidden" name="tipo" value="grupos" />
				<input type="hidden" name="cmd" value="editarGrupo" />
				<input type="hidden" id="id_editarGrupo" name="id" value="" />

				<div class="row clearfix">
                                    <div class="col-sm-3 col-xs-5 form-control-label">
                                        <label for="editarGrupo_nome">Nome</label>
                                    </div>
                                    <div class="col-sm-9 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="nome" id="nome_editarGrupo" class="form-control">
                                            </div>
                                        </div>
                                    </div>
				</div>

			    </div>
                        </div>
                        <div class="modal-footer">
			    <button type="submit" class="btn btn-primary waves-effect">
				<i class="material-icons">save</i>
				<span>Salvar</span>
			    </button>
                            <button type="button" id="closeEditarGrupoModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EDITAR GRUPO DE CAPTURA-->

	    <!--MODAL EXCLUIR GRUPO DE CAPTURA-->
            <div class="modal fade" id="excluirGrupoModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirGrupoLabel">Excluir Rota</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirGrupo" method="post">
				<?=$text_form;?>
				<input type="hidden" name="tipo" value="grupos" />
				<input type="hidden" name="cmd" value="excluirGrupo" />
				<input type="hidden" id="id_excluirGrupo" name="id" value="" />
				<input type="hidden" id="nome_excluirGrupo" name="nome" value="" />
			    <p>Tem certeza que deseja excluir o Grupo de Captura?</p>
			    <small>Todas as configurações do grupo serão desfeitas</small>
                        </div>
                        <div class="modal-footer">
			    <button type="submit" class="btn btn-danger waves-effect">
				<i class="material-icons">delete</i>
				<span>Sim</span>
			    </button>
                            <button type="button" id="closeExcluirGrupoModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR GRUPO DE CAPTURA-->

		<!--MODAL APAGAR FAIXA-->
            <div class="modal fade" id="apagarFaixaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Apagar Faixa</h4>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
								<form id="formEditarUsuario" method="post">
									<?=$text_form;?>
									<input type="hidden" name="cmd" value="apagarFaixa" />

								<div class="row clearfix">
									<div class="col-lg-4 col-md-4 col-sm-4 col-xs-5 form-control-label">
										<label for="ramalInicial_apagarFaixa">Ramal Inicial</label>
									</div>
									<div class="col-lg-8 col-md-8 col-sm-8 col-xs-7">
										<div class="form-group">
											<div class="form-line">
												<input type="text" name="ramalInicial" id="ramalInicial_apagarFaixa" class="form-control ramal">
											</div>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-lg-4 col-md-4 col-sm-4 col-xs-5 form-control-label">
										<label for="ramalFinal_apagarFaixa">Ramal Final</label>
									</div>
									<div class="col-lg-8 col-md-8 col-sm-8 col-xs-7">
										<div class="form-group">
											<div class="form-line">
												<input type="text" name="ramalFinal" id="ramalFinal_apagarFaixa" class="form-control ramal">
											</div>
										</div>
									</div>
								</div>
							</div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Apagar</span>
							</button>
                            <button type="button" id="closeApagarFaixaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL APAGAR FAIXA-->

	<!--#END - MODAL ============================================================================================================================== -->

<script>

function novoRamal() {
	document.getElementById("formNovoRamal").submit();
} 

function botaoExcluirRamal(excluirRamal) {
	$('#excluirRamal').val(excluirRamal);

	$('#excluirRamalLabel').text("Excluir Ramal "+excluirRamal);
	$("#excluirRamalModal").modal();
};

function marcarTodosRamais() {
	if ( $('#paraTodos').is(":checked") == true) {
		$("input[name='copiarRamais[]']").each(function(){
			//alert($(this).val());
			document.getElementById($(this).attr("id")).checked = true;
			//$(this).checked = true;
		});
	} else {
		$("input[name='copiarRamais[]']").each(function(){
			document.getElementById($(this).attr("id")).checked = false;
			//$(this).checked = false;
		});
	}
};

$(document).ready(function(){

	var ramais = <?php echo json_encode($ramaissip, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
	/*
	"3954":{
		"type":"friend",
		"secret":"102030",
		"qualify":"1",
		"port":"5060",
		"nat":"force_rport,comedia",
		"mailbox":"3954@device",
		"host":"dynamic",
		"dtmfmode":"rfc2833",
		"disallow":"all",
		"dial":"SIP/3954",
		"context":"1",
		"canreinvite":"1",
		"limit":"",
		"accountcode":"",
		"cc_agent_policy":"generic",
		"cc_monitor_policy":"generic",
		"pickupgroup":["vendas"],
		"callgroup":["vendas"],
		"codec":["alaw"," ulaw"," gsm"],
		"calleridname":"Kenko ",
		"proibeAddress":"",
		"proibeMask":"",
		"permiteAddress":"",
		"permiteMask":"",
		"abreviado":"1",
		"tipoRamal":"no",
		"gravaIn":"yes",
		"gravaOut":"yes",
		"gravaInterno":"yes"
	}
	*/

	$(".editar-ramal").on('click', function(event) {
		event.preventDefault();

		var ramal = $(this).data('ramal');

		document.getElementById('editarRamalLabel').innerHTML = "EditarRamal: "+ramal;

		$('#editarRamal').val(ramal);

		$('#secret_editarRamal').val(ramais[ramal].secret);
		$('#port_editarRamal').val(ramais[ramal].port);
		$('#limit_editarRamal').val(ramais[ramal].limit);
		$('#calleridname_editarRamal').val(ramais[ramal].calleridname);
		$('#mailbox_editarRamal').val(ramais[ramal].mailbox);
		$('#proibeAddress_editarRamal').val(ramais[ramal].proibeAddress);
		$('#proibeMask_editarRamal').val(ramais[ramal].proibeMask);
		$('#permiteAddress_editarRamal').val(ramais[ramal].permiteAddress);
		$('#permiteMask_editarRamal').val(ramais[ramal].permiteMask);
		
		var aux = 0;
		$('#tipoRamal_editarRamal option').each(function(){
			if ($(this).val() == ramais[ramal].tipoRamal) {
				$('#tipoRamal_editarRamal').selectpicker('val', ramais[ramal].tipoRamal);
				aux = 1;
			} else if (aux != 1) {
				$('#tipoRamal_editarRamal').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#context_editarRamal option').each(function(){
			if ($(this).val() == ramais[ramal].context) {
				$('#context_editarRamal').selectpicker('val', ramais[ramal].context);
				aux = 1;
			} else if (aux != 1) {
				$('#context_editarRamal').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#abreviado_editarRamal option').each(function(){
			if ($(this).val() == ramais[ramal].abreviado) {
				$('#abreviado_editarRamal').selectpicker('val', ramais[ramal].abreviado);
				aux = 1;
			} else if (aux != 1) {
				$('#abreviado_editarRamal').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#dtmf_editarRamal option').each(function(){
			if ($(this).val() == ramais[ramal].dtmfmode) {
				$('#dtmf_editarRamal').selectpicker('val', ramais[ramal].dtmfmode);
				aux = 1;
			} else if (aux != 1) {
				$('#dtmf_editarRamal').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#transport_editarRamal option').each(function(){
			if ($(this).val() == ramais[ramal].transport) {
				$('#transport_editarRamal').selectpicker('val', ramais[ramal].transport);
				aux = 1;
			} else if (aux != 1) {
				$('#transport_editarRamal').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#sendrpid_editarRamal option').each(function(){
			if ($(this).val() == ramais[ramal].sendrpid) {
				$('#sendrpid_editarRamal').selectpicker('val', ramais[ramal].sendrpid);
				aux = 1;
			} else if (aux != 1) {
				$('#sendrpid_editarRamal').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#trustrpid_editarRamal option').each(function(){
			if ($(this).val() == ramais[ramal].trustrpid) {
				$('#trustrpid_editarRamal').selectpicker('val', ramais[ramal].trustrpid);
				aux = 1;
			} else if (aux != 1) {
				$('#trustrpid_editarRamal').selectpicker('val', 'null');
			}
		});
		
		$('#pickupgroup_editarRamal').selectpicker('deselectAll');
		$('#pickupgroup_editarRamal').selectpicker('val', ramais[ramal].pickupgroup);

		$('#callgroup_editarRamal').selectpicker('deselectAll');
		$('#callgroup_editarRamal').selectpicker('val', ramais[ramal].callgroup);
		
		for(var i = 0; i < 4; i++) {
			$('#codec'+i+'_editarRamal').selectpicker('deselectAll');
			$('#codec'+i+'_editarRamal').selectpicker('val', ramais[ramal].codec[i]);
		}
		
		var radios = document.getElementsByName("discaNaoLogado");
		for (var i = 0; i < radios.length; i++) {
			if (radios[i].value == ramais[ramal].discaNaoLogado) {
				radios[i].checked = true;
			}
		}
		var radios = document.getElementsByName("gravaIn");
		for (var i = 0; i < radios.length; i++) {
			if (radios[i].value == ramais[ramal].gravaIn) {
				radios[i].checked = true;
			}
		}
		var radios = document.getElementsByName("gravaOut");
		for (var i = 0; i < radios.length; i++) {
			if (radios[i].value == ramais[ramal].gravaOut) {
				radios[i].checked = true;
			}
		}
		var radios = document.getElementsByName("gravaInterno");
		for (var i = 0; i < radios.length; i++) {
			if (radios[i].value == ramais[ramal].gravaInterno) {
				radios[i].checked = true;
			}
		}
		var radios = document.getElementsByName("crm");
		for (var i = 0; i < radios.length; i++) {
			if (radios[i].value == ramais[ramal].crm) {
				radios[i].checked = true;
			}
		}

	});
	
	function slimscrollReboot(){
		$('#editarRamalModal .list-modal')
			.slimscroll({ destroy: true })
			.slimscroll({ height: '1000px' });
		//window.addEventListener("wheel", function(event){ event.preventDefault(); }, {passive: false} );
	};
	slimscrollReboot();
	
	$("#editarRamalModal").on('show.bs.modal', function() {
		slimscrollReboot();
	});

});

//FUNÇÕES GRUPOS
	function botaoEditarGrupo(editarGrupo_id, editarGrupo_nome) {
		$('#id_editarGrupo').val(editarGrupo_id);
		$('#nome_editarGrupo').val(editarGrupo_nome);

		$("#editarGrupoModal").modal();
	};

	function botaoExcluirGrupo(excluirGrupo_id, excluirGrupo_nome) {
		$('#id_excluirGrupo').val(excluirGrupo_id);
		$('#nome_excluirGrupo').val(excluirGrupo_nome);

		$('#excluirGrupoLabel').text("Excluir Grupo "+excluirGrupo_nome);
		$("#excluirGrupoModal").modal();
	};

</script>