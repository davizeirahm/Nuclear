<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.config.ramal.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.faixa_discagem.php");
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "novaFaixa") {
		//print_r($_POST);
		
		$faixa = filter_var($_POST['faixa_dialplan'], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
		$erro = "";
		if ( !isset($faixa) ) {
			$erro = "00000010";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}

		if ( !nova_faixa($faixa) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
			die();
		} else {
			print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
			die();
		}

	} elseif (isset($_POST['cmd']) && $_POST['cmd'] == "editarFaixa") {

		$faixa = filter_var($_POST['faixa_dialplan'], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
		$faixa_old = filter_var($_POST['faixa_old'], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
		$erro = "";
		if (!isset($_POST['faixa_id']) or !isset($faixa) ) {
			$erro = "00000011";
		} elseif ( !isInteger($_POST['faixa_id']) ) {
			$erro = "Erro: ID Inválida!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}

		if ( !editar_faixa($_POST['faixa_id'], $faixa_old, $faixa ) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
			die();
		} else {
			print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
			die();
		}

	} elseif (isset($_POST['cmd']) && $_POST['cmd'] == "excluirFaixa") {

		$faixa = filter_var($_POST['faixa_dialplan'], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
		$erro = "";
		if (!isset($_POST['faixa_id']) or !isset($faixa) ) {
			$erro = "00000100";
		} elseif ( !isInteger($_POST['faixa_id']) ) {
			$erro = "Erro: ID Inválida!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}

		if ( !excluir_faixa($_POST['faixa_id'], $faixa) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
			die();
		} else {
			print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
			die();
		}
	}
	
	$faixas = get_faixas();
	//Array ( [12] => 40XX [13] => 39XX [18] => 59XX )

	
?>

		<!--PAGE CONTENT-->
        <div class="container-fluid">

            <div class="row clearfix">
                <!-- Bloco Pesquisa -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
									<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
						</div>
                        <div class="body" style="padding-bottom: 5px;">

							<div class="row clearfix">
								<div class="col-xs-12 col-sm-6 col-md-3 col-lg-2" style="margin-bottom: 0px;">
									<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novaFaixaModal">
										<i class="material-icons">add_circle</i>
										<span>NOVA FAIXA</span>
									</button>
								</div>
							</div>
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination3">
                                    <thead>
                                        <tr>
											<th>Faixa</th>
											<th>Dialplan</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
			if (isset($faixas)) {
				$id=1;
				foreach ($faixas as $key=>$value) {
?>
					<tr>
						<td>Faixa <?=$id;?></td>
						<td><?=$value;?></td>
						<td>
							<a href="javascript:;" class="play" onclick="botaoEditarFaixa('<?=$key;?>', '<?=$value;?>')"><i class="material-icons" title="Editar">edit</i></a>
							<a href="javascript:;" class="play" onclick="botaoExcluirFaixa('<?=$key;?>', '<?=$value;?>')"><i class="material-icons" title="Apagar">delete</i></a>
						</td>
					</tr>
<?php
					$id++;
				}
			}
?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- #END# Bloco Pesquisa -->
            </div>



	    <!-- Modal Dialogs ====================================================================================================================== -->

            <!--MODAL NOVA FAIXA-->
            <div class="modal fade" id="novaFaixaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Nova Faixa</h4>
                        </div>
                        <div class="modal-body">
			    <div class="demo-masked-input">
			    <form id="formNovaFaixa" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="novaFaixa" />

				</br></br>

					<div class="row clearfix">

						<div class="col-sm-12">
						<div class="form-group form-float">
							<div class="form-line">
								<input name="faixa_dialplan" id="faixa_dialplan" type="text" class="form-control" />
								<label class="form-label">Dialplan</label>
							</div>
						</div>
						</div>

					</div>
			    </div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
                            <button type="button" id="closeNovaFaixaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL NOVA FAIXA-->




	    <!--MODAL EDITAR FAIXA-->
            <div class="modal fade" id="editarFaixaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Editar Faixa</h4>
                        </div>
                        <div class="modal-body">
			    <div class="demo-masked-input">
			    <form id="formEditarFaixa" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="editarFaixa" />
				<input type="hidden" name="faixa_id" id="editarFaixa_id">
				<input type="hidden" name="faixa_old" id="editarFaixa_old">
				</br></br>

				<div class="row clearfix">

                                    <div class="col-sm-3 col-xs-5 form-control-label">
                                        <label for="editarFaixa_address">Dialplan</label>
                                    </div>
                                    <div class="col-sm-9 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="faixa_dialplan" id="editarFaixa_dialplan" class="form-control">
                                            </div>
                                        </div>
                                    </div>

                                </div>
			    </div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
                            <button type="button" id="closeEditarFaixaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EDITAR FAIXA-->



	    <!--MODAL EXCLUIR FAIXA-->
            <div class="modal fade" id="excluirFaixaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Excluir Faixa</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirFaixa" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="excluirFaixa" />
				<input type="hidden" name="faixa_id" id="excluirFaixa_id">
				<input type="hidden" name="faixa_dialplan" id="excluirFaixa_dialplan">
			    <p>Tem certeza que deseja excluir a Faixa de discagem?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
                            <button type="button" id="closeExcluirFaixaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR FAIXA-->



<script>

function botaoEditarFaixa(editarFaixa_id, editarFaixa_dialplan) {
	$('#editarFaixa_id').val(editarFaixa_id);
	$('#editarFaixa_old').val(editarFaixa_dialplan);

	$('#editarFaixa_dialplan').val(editarFaixa_dialplan);

	$("#editarFaixaModal").modal();
};

function botaoExcluirFaixa(excluirFaixa_id, editarFaixa_dialplan) {
	$('#excluirFaixa_id').val(excluirFaixa_id);
	$('#excluirFaixa_dialplan').val(editarFaixa_dialplan);
	
	$("#excluirFaixaModal").modal();
}

</script>