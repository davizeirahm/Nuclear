<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.config.ramal.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.config_e1.php");
	
	if ( isset($_REQUEST['tipo']) && $_REQUEST['tipo'] == "system") {
		$tipo = "system";
	} else {
		$tipo = "chan";
	}
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "salvarChanDahdi") {

		$erro = "";
		if ( !is_numeric($_POST['mfcr2_max_ani']) ) {
			$erro = "Erro: mfcr2_max_ani inválido!";
		}
		if ( !is_numeric($_POST['mfcr2_max_dnis']) ) {
			$erro = "Erro: mfcr2_max_dnis inválido!";
		}
		if ( !is_numeric($_POST['mfcr2_metering_pulse_timeout']) ) {
			$erro = "Erro: mfcr2_metering_pulse_timeout inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		unset($_POST['pagina']);
		unset($_POST['menu']);
		unset($_POST['cmd']);
		if ( !salvar_dahdi_conf($_POST) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		} else {
			print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		}
	} elseif (isset($_POST['cmd']) && $_POST['cmd'] == "salvarSystemConf") {

		$erro = "";
		if ( !isset($_POST['loadzone']) ) {
			$erro = "Erro: loadzone inválido!";
		}
		if ( !isset($_POST['defaultzone']) ) {
			$erro = "Erro: defaultzone inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		unset($_POST['pagina']);
		unset($_POST['menu']);
		unset($_POST['cmd']);
		if ( !salvar_system_conf($_POST) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		} else {
			print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		}
	} elseif (isset($_POST['cmd']) && ($_POST['cmd'] == "novoGrupo" || $_POST['cmd'] == "editarGrupo") ) {
		
		$erro = "";
		if ( !is_numeric($_POST['grupo']) ) {
			$erro .= "Erro: Grupo inválido! ";
		}
		if ( !isset($_POST['context']) || $_POST['context'] == "" ) {
			$erro .= "Erro: Contexto inválido! ";
		}
		if ( !isset($_POST['signalling']) || $_POST['signalling'] == "" ) {
			$erro .= "Erro: Sinalização inválida! ";
		}
		if ( !isset($_POST['channel']) || $_POST['channel'] == "" ) {
			$erro .= "Erro: Canais inválidos! ";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		unset($_POST['pagina']);
		unset($_POST['menu']);
		unset($_POST['cmd']);
		if ( !novo_group_dahdi($_POST) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		} else {
			print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		}
	} elseif (isset($_POST['cmd']) && $_POST['cmd'] == "excluirGrupo") {
		
		$erro = "";
		if ( !is_numeric($_POST['grupo']) ) {
			$erro .= "Erro: Grupo inválido! ";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		if ( !excluir_group_dahdi($_POST['grupo']) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		} else {
			print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		}
	} elseif (isset($_POST['cmd']) && $_POST['cmd'] == "novoDynamic" ) {
		
		$erro = "";
		if ( !is_numeric($_POST['vspan']) ) {
			$erro .= "Erro: Virtual Span inválido! ";
		}
		if ( !is_numeric($_POST['qtd']) ) {
			$erro .= "Erro: Número de canais inválido! ";
		}
		if ( !is_numeric($_POST['timing']) ) {
			$erro .= "Erro: Timing inválido! ";
		}
		if ( !isset($_POST['mac']) || $_POST['mac'] == "" ) {
			$erro .= "Erro: MAC inválido! ";
		}
		if ( !isset($_POST['canais']) || $_POST['canais'] == "" ) {
			$erro .= "Erro: Canais inválido! ";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		unset($_POST['pagina']);
		unset($_POST['menu']);
		unset($_POST['cmd']);
		if ( !novo_dynamic_span($_POST) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		} else {
			print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		}
	} elseif (isset($_POST['cmd']) && $_POST['cmd'] == "editarDynamic" ) {
		
		$erro = "";
		if ( !isset($_POST['key']) ) {
			$erro .= "Erro: Chave inválida! ";
		}
		if ( !is_numeric($_POST['vspan']) ) {
			$erro .= "Erro: Virtual Span inválido! ";
		}
		if ( !is_numeric($_POST['qtd']) ) {
			$erro .= "Erro: Número de canais inválido! ";
		}
		if ( !is_numeric($_POST['timing']) ) {
			$erro .= "Erro: Timing inválido! ";
		}
		if ( !isset($_POST['mac']) || $_POST['mac'] == "" ) {
			$erro .= "Erro: MAC inválido! ";
		}
		if ( !isset($_POST['canais']) || $_POST['canais'] == "" ) {
			$erro .= "Erro: Canais inválido! ";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		unset($_POST['pagina']);
		unset($_POST['menu']);
		unset($_POST['cmd']);
		if ( !editar_dynamic_span($_POST) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		} else {
			print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		}
	} elseif (isset($_POST['cmd']) && $_POST['cmd'] == "excluirDynamic") {
		
		$erro = "";
		if ( !isset($_POST['key']) ) {
			$erro .= "Erro: Chave inválida! ";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		if ( !excluir_span_dynamic($_POST['key']) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		} else {
			print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		}
	} elseif (isset($_POST['cmd']) && $_POST['cmd'] == "novoSpan" ) {
		
		$erro = "";
		if ( !is_numeric($_POST['span']) ) {
			$erro .= "Erro: Span inválido! ";
		}
		if ( !is_numeric($_POST['timing']) ) {
			$erro .= "Erro: Timing inválido! ";
		}
		if ( !is_numeric($_POST['lbo']) ) {
			$erro .= "Erro: LBO inválido! ";
		}
		if ( !isset($_POST['framing']) || $_POST['framing'] == "" ) {
			$erro .= "Erro: Framing inválido! ";
		}
		if ( !isset($_POST['coding']) || $_POST['coding'] == "" ) {
			$erro .= "Erro: Coding inválido! ";
		}
		if ( !isset($_POST['canais']) || $_POST['canais'] == "" ) {
			$erro .= "Erro: Canais inválido! ";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		unset($_POST['pagina']);
		unset($_POST['menu']);
		unset($_POST['cmd']);
		if ( !novo_span($_POST) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		} else {
			print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		}
	} elseif (isset($_POST['cmd']) && $_POST['cmd'] == "editarSpan" ) {
		
		$erro = "";
		if ( !is_numeric($_POST['span']) ) {
			$erro .= "Erro: Span inválido! ";
		}
		if ( !is_numeric($_POST['timing']) ) {
			$erro .= "Erro: Timing inválido! ";
		}
		if ( !is_numeric($_POST['lbo']) ) {
			$erro .= "Erro: LBO inválido! ";
		}
		if ( !isset($_POST['framing']) || $_POST['framing'] == "" ) {
			$erro .= "Erro: Framing inválido! ";
		}
		if ( !isset($_POST['coding']) || $_POST['coding'] == "" ) {
			$erro .= "Erro: Coding inválido! ";
		}
		if ( !isset($_POST['canais']) || $_POST['canais'] == "" ) {
			$erro .= "Erro: Canais inválido! ";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		unset($_POST['pagina']);
		unset($_POST['menu']);
		unset($_POST['cmd']);
		if ( !editar_span($_POST) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		} else {
			print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		}
	} elseif (isset($_POST['cmd']) && $_POST['cmd'] == "excluirSpan") {
		
		$erro = "";
		if ( !isset($_POST['key']) ) {
			$erro .= "Erro: Chave inválida! ";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		if ( !excluir_span($_POST['key']) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		} else {
			print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		}
	}
	
	//DEFINIÇAO DE VARIAVEIS ============================================
	$config = get_dahdi_config();
	//print_r($config);
	$groups = get_dahdi_groups();
	
	$configSystem = get_system_config();
	
	$dynamicSpans = get_dynamic_spans();
	
	$spans = get_spans();
?>

		<!--PAGE CONTENT-->
        <div class="container-fluid">

            <div class="row clearfix">
                <!-- Bloco Pesquisa -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
									<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
						</div>
                        <div class="body" style="padding-bottom: 5px;">
                            <ul class="nav nav-tabs tab-nav-right" role="tablist">
                                <li role="presentation" <?php echo ( @$tipo == "chan" ? "class=\"active\"" : "" ); ?> ><a href="#chan" data-toggle="tab">CHAN DAHDI</a></li>
                                <li role="presentation" <?php echo ( @$tipo == "system" ? "class=\"active\"" : "" ); ?> ><a href="#system" data-toggle="tab">SYSTEM</a></li>
							</ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
								<div role="tabpanel" class="tab-pane fade <?php echo ( @$tipo == "chan" ? "in active" : "" ); ?>" id="chan">
						
						
						
					<!--Formulário-->
					<div class="demo-masked-input">
						<form id="filtro-user" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="salvarChanDahdi" />
							
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>Language</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="language" id="language" class="form-control show-tick">
											<option value="us" <?=(@$config['language'] == "us"?'selected="selected"':"");?> >us</option>
											<option value="uk" <?=(@$config['language'] == "uk"?'selected="selected"':"");?> >uk</option>
											<option value="fr" <?=(@$config['language'] == "fr"?'selected="selected"':"");?> >fr</option>
											<option value="de" <?=(@$config['language'] == "de"?'selected="selected"':"");?> >de</option>
											<option value="pt" <?=(@$config['language'] == "pt"?'selected="selected"':"");?> >pt</option>
											<option value="br" <?=(@$config['language'] == "br"?'selected="selected"':"");?> >br</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>Use callerid</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="usecallerid" id="usecallerid" class="form-control show-tick">
											<option value="" <?=(!isset($config['usecallerid']) || @$config['usecallerid'] == ""?'selected="selected"':"");?> > - </option>
											<option value="yes" <?=(@$config['usecallerid'] == "yes"?'selected="selected"':"");?> >yes</option>
											<option value="no" <?=(@$config['usecallerid'] == "no"?'selected="selected"':"");?> >no</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>Call waiting</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="callwaiting" id="callwaiting" class="form-control show-tick">
											<option value="" <?=(!isset($config['callwaiting']) || @$config['callwaiting'] == ""?'selected="selected"':"");?> > - </option>
											<option value="yes" <?=(@$config['callwaiting'] == "yes"?'selected="selected"':"");?> >yes</option>
											<option value="no" <?=(@$config['callwaiting'] == "no"?'selected="selected"':"");?> >no</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>Use calling pres</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="usecallingpres" id="usecallingpres" class="form-control show-tick">
											<option value="" <?=(!isset($config['usecallingpres']) || @$config['usecallingpres'] == ""?'selected="selected"':"");?> > - </option>
											<option value="yes" <?=(@$config['usecallingpres'] == "yes"?'selected="selected"':"");?> >yes</option>
											<option value="no" <?=(@$config['usecallingpres'] == "no"?'selected="selected"':"");?> >no</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>Call waiting callerid</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="callwaitingcallerid" id="callwaitingcallerid" class="form-control show-tick">
											<option value="" <?=(!isset($config['callwaitingcallerid']) || @$config['callwaitingcallerid'] == ""?'selected="selected"':"");?> > - </option>
											<option value="yes" <?=(@$config['callwaitingcallerid'] == "yes"?'selected="selected"':"");?> >yes</option>
											<option value="no" <?=(@$config['callwaitingcallerid'] == "no"?'selected="selected"':"");?> >no</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>Three way calling</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="threewaycalling" id="threewaycalling" class="form-control show-tick">
											<option value="" <?=(!isset($config['threewaycalling']) || @$config['threewaycalling'] == ""?'selected="selected"':"");?> > - </option>
											<option value="yes" <?=(@$config['threewaycalling'] == "yes"?'selected="selected"':"");?> >yes</option>
											<option value="no" <?=(@$config['threewaycalling'] == "no"?'selected="selected"':"");?> >no</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>Transfer</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="transfer" id="transfer" class="form-control show-tick">
											<option value="" <?=(!isset($config['transfer']) || @$config['transfer'] == ""?'selected="selected"':"");?> > - </option>
											<option value="yes" <?=(@$config['transfer'] == "yes"?'selected="selected"':"");?> >yes</option>
											<option value="no" <?=(@$config['transfer'] == "no"?'selected="selected"':"");?> >no</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>Canpark</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="canpark" id="canpark" class="form-control show-tick">
											<option value="" <?=(!isset($config['canpark']) || @$config['canpark'] == ""?'selected="selected"':"");?> > - </option>
											<option value="yes" <?=(@$config['canpark'] == "yes"?'selected="selected"':"");?> >yes</option>
											<option value="no" <?=(@$config['canpark'] == "no"?'selected="selected"':"");?> >no</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>Can callforward</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="cancallforward" id="cancallforward" class="form-control show-tick">
											<option value="" <?=(!isset($config['cancallforward']) || @$config['cancallforward'] == ""?'selected="selected"':"");?> > - </option>
											<option value="yes" <?=(@$config['cancallforward'] == "yes"?'selected="selected"':"");?> >yes</option>
											<option value="no" <?=(@$config['cancallforward'] == "no"?'selected="selected"':"");?> >no</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>Call return</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="callreturn" id="callreturn" class="form-control show-tick">
											<option value="" <?=(!isset($config['callreturn']) || @$config['callreturn'] == ""?'selected="selected"':"");?> > - </option>
											<option value="yes" <?=(@$config['callreturn'] == "yes"?'selected="selected"':"");?> >yes</option>
											<option value="no" <?=(@$config['callreturn'] == "no"?'selected="selected"':"");?> >no</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>Echo cancel</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="echocancel" id="echocancel" class="form-control show-tick">
											<option value="" <?=(!isset($config['echocancel']) || @$config['echocancel'] == ""?'selected="selected"':"");?> > - </option>
											<option value="yes" <?=(@$config['echocancel'] == "yes"?'selected="selected"':"");?> >yes</option>
											<option value="no" <?=(@$config['echocancel'] == "no"?'selected="selected"':"");?> >no</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>Echo cancel when bridged</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="echocancelwhenbridged" id="echocancelwhenbridged" class="form-control show-tick">
											<option value="" <?=(!isset($config['echocancelwhenbridged']) || @$config['echocancelwhenbridged'] == ""?'selected="selected"':"");?> > - </option>
											<option value="yes" <?=(@$config['echocancelwhenbridged'] == "yes"?'selected="selected"':"");?> >yes</option>
											<option value="no" <?=(@$config['echocancelwhenbridged'] == "no"?'selected="selected"':"");?> >no</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>RX gain</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="rxgain" id="rxgain" class="form-control show-tick">
											<option value="" <?=(!isset($config['rxgain']) || @$config['rxgain'] == ""?'selected="selected"':"");?> > - </option>
											<option value="12.0" <?=(@$config['rxgain'] == "12.0"?'selected="selected"':"");?> >12.0</option>
											<option value="9.0" <?=(@$config['rxgain'] == "9.0"?'selected="selected"':"");?> >9.0</option>
											<option value="6.0" <?=(@$config['rxgain'] == "6.0"?'selected="selected"':"");?> >6.0</option>
											<option value="3.0" <?=(@$config['rxgain'] == "3.0"?'selected="selected"':"");?> >3.0</option>
											<option value="0.0" <?=(@$config['rxgain'] == "0.0"?'selected="selected"':"");?> >0.0</option>
											<option value="-3.0" <?=(@$config['rxgain'] == "-3.0"?'selected="selected"':"");?> >-3.0</option>
											<option value="-6.0" <?=(@$config['rxgain'] == "-6.0"?'selected="selected"':"");?> >-6.0</option>
											<option value="-9.0" <?=(@$config['rxgain'] == "-9.0"?'selected="selected"':"");?> >-9.0</option>
											<option value="-12.0" <?=(@$config['rxgain'] == "-12.0"?'selected="selected"':"");?> >-12.0</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>TX gain</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="txgain" id="txgain" class="form-control show-tick">
											<option value="" <?=(!isset($config['txgain']) || @$config['txgain'] == ""?'selected="selected"':"");?> > - </option>
											<option value="12.0" <?=(@$config['txgain'] == "12.0"?'selected="selected"':"");?> >12.0</option>
											<option value="9.0" <?=(@$config['txgain'] == "9.0"?'selected="selected"':"");?> >9.0</option>
											<option value="6.0" <?=(@$config['txgain'] == "6.0"?'selected="selected"':"");?> >6.0</option>
											<option value="3.0" <?=(@$config['txgain'] == "3.0"?'selected="selected"':"");?> >3.0</option>
											<option value="0.0" <?=(@$config['txgain'] == "0.0"?'selected="selected"':"");?> >0.0</option>
											<option value="-3.0" <?=(@$config['txgain'] == "-3.0"?'selected="selected"':"");?> >-3.0</option>
											<option value="-6.0" <?=(@$config['txgain'] == "-6.0"?'selected="selected"':"");?> >-6.0</option>
											<option value="-9.0" <?=(@$config['txgain'] == "-9.0"?'selected="selected"':"");?> >-9.0</option>
											<option value="-12.0" <?=(@$config['txgain'] == "-12.0"?'selected="selected"':"");?> >-12.0</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-sm-6 col-xs-12">
									<h4 style="text-align: center;">MFCR2</h4>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>mfcr2 variant</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="mfcr2_variant" id="mfcr2_variant" class="form-control show-tick">
											<option value="" <?=(!isset($config['mfcr2_variant']) || @$config['mfcr2_variant'] == ""?'selected="selected"':"");?> > - </option>
											<option value="us" <?=(@$config['mfcr2_variant'] == "us"?'selected="selected"':"");?> >us</option>
											<option value="uk" <?=(@$config['mfcr2_variant'] == "uk"?'selected="selected"':"");?> >uk</option>
											<option value="fr" <?=(@$config['mfcr2_variant'] == "fr"?'selected="selected"':"");?> >fr</option>
											<option value="de" <?=(@$config['mfcr2_variant'] == "de"?'selected="selected"':"");?> >de</option>
											<option value="pt" <?=(@$config['mfcr2_variant'] == "pt"?'selected="selected"':"");?> >pt</option>
											<option value="br" <?=(@$config['mfcr2_variant'] == "br"?'selected="selected"':"");?> >br</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>mfcr2 get ani first</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="mfcr2_get_ani_first" id="mfcr2_get_ani_first" class="form-control show-tick">
											<option value="" <?=(!isset($config['mfcr2_get_ani_first']) || @$config['mfcr2_get_ani_first'] == ""?'selected="selected"':"");?> > - </option>
											<option value="yes" <?=(@$config['mfcr2_get_ani_first'] == "yes"?'selected="selected"':"");?> >yes</option>
											<option value="no" <?=(@$config['mfcr2_get_ani_first'] == "no"?'selected="selected"':"");?> >no</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label for="mfcr2_max_ani">mfcr2 max ani</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group" style="margin-bottom: 0px;">
										<div class="form-line">
											<input type="text" name="mfcr2_max_ani" id="mfcr2_max_ani" class="form-control ramal" <?=(@$config['mfcr2_max_ani']?'value="'.$config['mfcr2_max_ani'].'"':"");?> >
										</div>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label for="mfcr2_max_dnis">mfcr2 max dnis</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group" style="margin-bottom: 0px;">
										<div class="form-line">
											<input type="text" name="mfcr2_max_dnis" id="mfcr2_max_dnis" class="form-control ramal" <?=(@$config['mfcr2_max_dnis']?'value="'.$config['mfcr2_max_dnis'].'"':"");?> >
										</div>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>mfcr2 category</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="mfcr2_category" id="mfcr2_category" class="form-control show-tick">
											<option value="" <?=(!isset($config['mfcr2_category']) || @$config['mfcr2_category'] == ""?'selected="selected"':"");?> > - </option>
											<option value="national_subscriber" <?=(@$config['mfcr2_category'] == "national_subscriber"?'selected="selected"':"");?> >national_subscriber</option>
											<option value="national_priority_subscriber" <?=(@$config['mfcr2_category'] == "national_priority_subscriber"?'selected="selected"':"");?> >national_priority_subscriber</option>
											<option value="international_subscriber" <?=(@$config['mfcr2_category'] == "international_subscriber"?'selected="selected"':"");?> >international_subscriber</option>
											<option value="international_priority_subscriber" <?=(@$config['mfcr2_category'] == "international_priority_subscriber"?'selected="selected"':"");?> >international_priority_subscriber</option>
											<option value="collect_call" <?=(@$config['mfcr2_category'] == "collect_call"?'selected="selected"':"");?> >collect_call</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label for="mfcr2_metering_pulse_timeout">mfcr2 metering pulse timeout</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group" style="margin-bottom: 0px;">
										<div class="form-line">
											<input type="text" name="mfcr2_metering_pulse_timeout" id="mfcr2_metering_pulse_timeout" class="form-control ramal" <?=(@$config['mfcr2_metering_pulse_timeout']?'value="'.$config['mfcr2_metering_pulse_timeout'].'"':"");?> >
										</div>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>mfcr2 allow collect calls</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="mfcr2_allow_collect_calls" id="mfcr2_allow_collect_calls" class="form-control show-tick">
											<option value="" <?=(!isset($config['mfcr2_allow_collect_calls']) || @$config['mfcr2_allow_collect_calls'] == ""?'selected="selected"':"");?> > - </option>
											<option value="yes" <?=(@$config['mfcr2_allow_collect_calls'] == "yes"?'selected="selected"':"");?> >yes</option>
											<option value="no" <?=(@$config['mfcr2_allow_collect_calls'] == "no"?'selected="selected"':"");?> >no</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>mfcr2 double answer</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="mfcr2_double_answer" id="mfcr2_double_answer" class="form-control show-tick">
											<option value="" <?=(!isset($config['mfcr2_double_answer']) || @$config['mfcr2_double_answer'] == ""?'selected="selected"':"");?> > - </option>
											<option value="yes" <?=(@$config['mfcr2_double_answer'] == "yes"?'selected="selected"':"");?> >yes</option>
											<option value="no" <?=(@$config['mfcr2_double_answer'] == "no"?'selected="selected"':"");?> >no</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>mfcr2 charge calls</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="mfcr2_charge_calls" id="mfcr2_charge_calls" class="form-control show-tick">
											<option value="" <?=(!isset($config['mfcr2_charge_calls']) || @$config['mfcr2_charge_calls'] == ""?'selected="selected"':"");?> > - </option>
											<option value="yes" <?=(@$config['mfcr2_charge_calls'] == "yes"?'selected="selected"':"");?> >yes</option>
											<option value="no" <?=(@$config['mfcr2_charge_calls'] == "no"?'selected="selected"':"");?> >no</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>mfcr2 forced release</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="mfcr2_forced_release" id="mfcr2_forced_release" class="form-control show-tick">
											<option value="" <?=(!isset($config['mfcr2_forced_release']) || @$config['mfcr2_forced_release'] == ""?'selected="selected"':"");?> > - </option>
											<option value="yes" <?=(@$config['mfcr2_forced_release'] == "yes"?'selected="selected"':"");?> >yes</option>
											<option value="no" <?=(@$config['mfcr2_forced_release'] == "no"?'selected="selected"':"");?> >no</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-sm-6 col-xs-12">
									<h4 style="text-align: center;">ISDN</h4>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>Overlap dial</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="overlapdial" id="overlapdial" class="form-control show-tick">
											<option value="" <?=(!isset($config['overlapdial']) || @$config['overlapdial'] == ""?'selected="selected"':"");?> > - </option>
											<option value="yes" <?=(@$config['overlapdial'] == "yes"?'selected="selected"':"");?> >yes</option>
											<option value="no" <?=(@$config['overlapdial'] == "no"?'selected="selected"':"");?> >no</option>
											<option value="outgoing" <?=(@$config['overlapdial'] == "outgoing"?'selected="selected"':"");?> >outgoing</option>
											<option value="incoming" <?=(@$config['overlapdial'] == "incoming"?'selected="selected"':"");?> >incoming</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>Pridialplan</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="pridialplan" id="pridialplan" class="form-control show-tick">
											<option value="" <?=(!isset($config['pridialplan']) || @$config['pridialplan'] == ""?'selected="selected"':"");?> > - </option>
											<option value="local" <?=(@$config['pridialplan'] == "local"?'selected="selected"':"");?> >local</option>
											<option value="unknown" <?=(@$config['pridialplan'] == "unknown"?'selected="selected"':"");?> >unknown</option>
											<option value="international" <?=(@$config['pridialplan'] == "international"?'selected="selected"':"");?> >international</option>
											<option value="national" <?=(@$config['pridialplan'] == "national"?'selected="selected"':"");?> >national</option>
											<option value="subscriber" <?=(@$config['pridialplan'] == "subscriber"?'selected="selected"':"");?> >subscriber</option>
											<option value="abbreviated" <?=(@$config['pridialplan'] == "abbreviated"?'selected="selected"':"");?> >abbreviated</option>
											<option value="reserved" <?=(@$config['pridialplan'] == "reserved"?'selected="selected"':"");?> >reserved</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>Switchtype</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="switchtype" id="switchtype" class="form-control show-tick">
											<option value="" <?=(!isset($config['switchtype']) || @$config['switchtype'] == ""?'selected="selected"':"");?> > - </option>
											<option value="euroisdn" <?=(@$config['switchtype'] == "euroisdn"?'selected="selected"':"");?> >euroisdn</option>
											<option value="national" <?=(@$config['switchtype'] == "national"?'selected="selected"':"");?> >national</option>
											<option value="dms100" <?=(@$config['switchtype'] == "dms100"?'selected="selected"':"");?> >dms100</option>
											<option value="4ess" <?=(@$config['switchtype'] == "4ess"?'selected="selected"':"");?> >4ess</option>
											<option value="5ess" <?=(@$config['switchtype'] == "5ess"?'selected="selected"':"");?> >5ess</option>
											<option value="ni1" <?=(@$config['switchtype'] == "ni1"?'selected="selected"':"");?> >ni1</option>
											<option value="qsig" <?=(@$config['switchtype'] == "qsig"?'selected="selected"':"");?> >qsig</option>
										</select>
									</div>
								</div>
							</div>

							<div class="row clearfix">
								<div class="col-xs-12">
									<button id="btnSubmit" type="submit" class="btn btn-primary waves-effect">
										<i class="material-icons">save</i>
										<span>SALVAR</span>
									</button>
								</div>
							</div>
						</form>
					</div>
					<!--FIM FORMULÁRIO-->
								</div>
								<div role="tabpanel" class="tab-pane fade <?php echo ( @$tipo == "system" ? "in active" : "" ); ?>" id="system">

					<!--System-->
					<div class="demo-masked-input">
						<form id="filtro-user" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="salvarSystemConf" />
							
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>Loadzone</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="loadzone" id="loadzone" class="form-control show-tick">
											<option value="us" <?=(@$configSystem['loadzone'] == "us"?'selected="selected"':"");?> >us</option>
											<option value="br" <?=(@$configSystem['loadzone'] == "br"?'selected="selected"':"");?> >br</option>
											<option value="es" <?=(@$configSystem['loadzone'] == "es"?'selected="selected"':"");?> >es</option>
											<option value="gr" <?=(@$configSystem['loadzone'] == "gr"?'selected="selected"':"");?> >gr</option>
											<option value="it" <?=(@$configSystem['loadzone'] == "it"?'selected="selected"':"");?> >it</option>
											<option value="fr" <?=(@$configSystem['loadzone'] == "fr"?'selected="selected"':"");?> >fr</option>
											<option value="de" <?=(@$configSystem['loadzone'] == "de"?'selected="selected"':"");?> >de</option>
											<option value="pt" <?=(@$configSystem['loadzone'] == "pt"?'selected="selected"':"");?> >pt</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label>Defaultzone</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="defaultzone" id="defaultzone" class="form-control show-tick">
											<option value="us" <?=(@$configSystem['defaultzone'] == "us"?'selected="selected"':"");?> >us</option>
											<option value="br" <?=(@$configSystem['defaultzone'] == "br"?'selected="selected"':"");?> >br</option>
											<option value="es" <?=(@$configSystem['defaultzone'] == "es"?'selected="selected"':"");?> >es</option>
											<option value="gr" <?=(@$configSystem['defaultzone'] == "gr"?'selected="selected"':"");?> >gr</option>
											<option value="it" <?=(@$configSystem['defaultzone'] == "it"?'selected="selected"':"");?> >it</option>
											<option value="fr" <?=(@$configSystem['defaultzone'] == "fr"?'selected="selected"':"");?> >fr</option>
											<option value="de" <?=(@$configSystem['defaultzone'] == "de"?'selected="selected"':"");?> >de</option>
											<option value="pt" <?=(@$configSystem['defaultzone'] == "pt"?'selected="selected"':"");?> >pt</option>
										</select>
									</div>
								</div>
							</div>
							
							<div class="row clearfix">
								<div class="col-xs-12">
									<button id="btnSubmit" type="submit" class="btn btn-primary waves-effect">
										<i class="material-icons">save</i>
										<span>SALVAR</span>
									</button>
								</div>
							</div>
						</form>
					</div>
					<!--System-->
					
								</div>
							</div>
                        </div>
                    </div>
                </div>
                <!-- #END# Bloco Pesquisa -->
            </div>



	    <!--GROUPS - Table-->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="card">
						<div class="header">
                            <h2>GRUPOS DAHDI</h2>
                        </div>
                        <div class="body">

							<div class="row clearfix">
								<div class="col-xs-12 col-sm-6 col-md-3 col-lg-2" style="margin-bottom: 0px;">
									<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novoGrupoModal">
										<i class="material-icons">add_circle</i>
										<span>NOVO GRUPO</span>
									</button>
								</div>
							</div>

                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination3">
                                    <thead>
                                        <tr>
											<th>Grupo</th>
											<th>Contexto</th>
											<th>Sinalização</th>
											<th>Canais</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
			if (isset($groups)) {
				foreach ($groups as $value) {
?>
									<tr>
										<td><?=$value['group'];?></td>
										<td><?=$value['context'];?></td>
										<td><?=$value['signalling'];?></td>
										<td><?=$value['channel'];?></td>
										<td>
											<a href="javascript:;" class="play" onclick="botaoEditarGrupo('<?=$value['group'];?>', '<?=$value['context'];?>', '<?=$value['signalling'];?>', '<?=$value['channel'];?>')"><i class="material-icons" title="Editar">edit</i></a>
											<a href="javascript:;" class="play" onclick="botaoExcluirGrupo('<?=$value['group'];?>')"><i class="material-icons" title="Apagar">delete</i></a>
										</td>
									</tr>
<?php
				}
			}
?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <!-- #END# GROUPS - Table -->

		<!--Dynamic Spans - Table-->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="card">
						<div class="header">
                            <h2>Dynamic Spans - Configuração do Hardware</h2>
                        </div>
                        <div class="body">

							<div class="row clearfix">
								<div class="col-xs-12 col-sm-6 col-md-3 col-lg-2" style="margin-bottom: 0px;">
									<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novoDynamicModal">
										<i class="material-icons">add_circle</i>
										<span>NOVO SPAN</span>
									</button>
								</div>
							</div>

                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination3">
                                    <thead>
                                        <tr>
											<th>MAC</th>
											<th>Ethernet</th>
											<th>Span Virtual</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
			if (isset($dynamicSpans)) {
				foreach ($dynamicSpans as $key=>$value) {
?>
									<tr>
										<td><?=$value['mac'];?></td>
										<td><?=$value['ethernet'];?></td>
										<td><?=$value['vspan'];?></td>
										<td>
											<a href="javascript:;" class="play" onclick="botaoEditarDynamic(
																							'<?=$key;?>',
																							'<?=$value['drive'];?>',
																							'<?=$value['ethernet'];?>',
																							'<?=$value['mac'];?>',
																							'<?=$value['vspan'];?>',
																							'<?=$value['qtd'];?>',
																							'<?=$value['timing'];?>',
																							'<?=$value['canais'];?>',
																							'<?=$value['dchan'];?>'
																						)"><i class="material-icons" title="Editar">edit</i></a>
											<a href="javascript:;" class="play" onclick="botaoExcluirDynamic('<?=$key;?>')"><i class="material-icons" title="Apagar">delete</i></a>
										</td>
									</tr>
<?php
				}
			}
?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <!-- #END# DYNAMIC SPANS - Table -->

		<!--CARD SPANS - Table-->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="card">
						<div class="header">
                            <h2>Card Spans - Configuração do Hardware</h2>
                        </div>
                        <div class="body">

							<div class="row clearfix">
								<div class="col-xs-12 col-sm-6 col-md-3 col-lg-2" style="margin-bottom: 0px;">
									<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novoSpanModal">
										<i class="material-icons">add_circle</i>
										<span>NOVO SPAN</span>
									</button>
								</div>
							</div>

                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination3">
                                    <thead>
                                        <tr>
											<th>Span</th>
											<th>Framing</th>
											<th>Coding</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
			if (isset($spans)) {
				foreach ($spans as $key=>$value) {
?>
									<tr>
										<td><?=$value['span'];?></td>
										<td><?=$value['framing'];?></td>
										<td><?=$value['coding'];?></td>
										<td>
											<a href="javascript:;" class="play" onclick="botaoEditarSpan(
																							'<?=$key;?>',
																							'<?=$value['span'];?>',
																							'<?=$value['timing'];?>',
																							'<?=$value['lbo'];?>',
																							'<?=$value['framing'];?>',
																							'<?=$value['coding'];?>',
																							'<?=$value['canais'];?>',
																							'<?=$value['dchan'];?>'
																						)"><i class="material-icons" title="Editar">edit</i></a>
											<a href="javascript:;" class="play" onclick="botaoExcluirSpan('<?=$key;?>')"><i class="material-icons" title="Apagar">delete</i></a>
										</td>
									</tr>
<?php
				}
			}
?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <!-- #END# CARD SPANS - Table -->


		</div>
		<!--#END of PAGE CONTENT-->
	
	
	    <!-- Modal Dialogs ====================================================================================================================== -->

        <!--MODAL NOVO GRUPO-->
		<div class="modal fade" id="novoGrupoModal" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="defaultModalLabel">Novo Grupo</h4>
					</div>
					<div class="modal-body">
						<div class="demo-masked-input">
						<form id="formNovoGrupo" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="novoGrupo" />

						</br></br>

							<div class="row clearfix">
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label>Grupo</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group form-float">
										<select name="grupo" id="grupo" class="form-control show-tick">
										<?php
											for ($i = 1; $i < 64; $i++) {
												if (!isset($groups[$i]) ) {
										?>
											<option value="<?=$i;?>"><?=$i;?></option>
										<?php
												}
											}
										?>
										</select>
									</div>
								</div>
								<div class="col-xs-12">
									<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Contexto</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="context" id="context_novoGrupo" class="form-control show-tick">
													<option value=""> - </option>
													<?php
														$tmpcat = get_ini_keys(ARQ_ENTRADASDDR_CONF);
														foreach($tmpcat as $key=>$value) {
															print "<option value=\"".$key."\">".$key."</option>";
														}
														$tmpcat = get_ini_keys(ARQ_ENTRADASDDRCUSTOM_CONF);
														foreach($tmpcat as $key=>$value) {
															print "<option value=\"".$key."\">".$key."</option>";
														}
														$tmpcat = meu_parse_ini_file(ARQ_CATEGORIAS_CONF);
														foreach($tmpcat as $key=>$value) {
															print "<option value=\"".$key."\">".$key."</option>";
														}
													?>
												</select>
											</div>
										</div>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label>Signalling</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group form-float">
										<select name="signalling" id="signalling_novoGrupo" class="form-control show-tick">
											<option value="mfcr2">mfcr2</option>
											<option value="pri_net">pri_net</option>
											<option value="pri_cpe">pri_cpe</option>
										</select>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label for="channel_novoGrupo">Canais</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group" style="margin-bottom: 0px;">
										<div class="form-line">
											<input type="text" name="channel" id="channel_novoGrupo" class="form-control" placeholder="1-15,17-31">
										</div>
									</div>
								</div>
							</div>
						</div>
                    </div>
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary waves-effect">
							<i class="material-icons">save</i>
							<span>Salvar</span>
						</button>
						<button type="button" id="closeNovoLocalnetModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
					</div>
						</form>
                </div>
            </div>
        </div>
	    <!--#END of MODAL NOVO GRUPO-->


	    <!--MODAL EDITAR GRUPO-->
        <div class="modal fade" id="editarGrupoModal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="defaultModalLabel">Editar GRUPO</h4>
                    </div>
                    <div class="modal-body">
						<div class="demo-masked-input">
							<form id="formEditarGrupo" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="editarGrupo" />
							<input type="hidden" name="grupo" id="editarGrupo_id">
							</br></br>

							<div class="row clearfix">
								<div class="col-xs-12">
									<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Contexto</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="context" id="context_editarGrupo" class="form-control show-tick">
													<option value=""> - </option>
													<?php
														$tmpcat = get_ini_keys(ARQ_ENTRADASDDR_CONF);
														foreach($tmpcat as $key=>$value) {
															print "<option value=\"".$key."\">".$key."</option>";
														}
														$tmpcat = get_ini_keys(ARQ_ENTRADASDDRCUSTOM_CONF);
														foreach($tmpcat as $key=>$value) {
															print "<option value=\"".$key."\">".$key."</option>";
														}
														$tmpcat = meu_parse_ini_file(ARQ_CATEGORIAS_CONF);
														foreach($tmpcat as $key=>$value) {
															print "<option value=\"".$key."\">".$key."</option>";
														}
													?>
												</select>
											</div>
										</div>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label>Signalling</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group form-float">
										<select name="signalling" id="signalling_editarGrupo" class="form-control show-tick">
											<option value="mfcr2">mfcr2</option>
											<option value="pri_net">pri_net</option>
											<option value="pri_cpe">pri_cpe</option>
										</select>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label for="channel_editarGrupo">Canais</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group" style="margin-bottom: 0px;">
										<div class="form-line">
											<input type="text" name="channel" id="channel_editarGrupo" class="form-control" placeholder="1-15,17-31">
										</div>
									</div>
								</div>
                            </div>
						</div>
                    </div>
                    <div class="modal-footer">
						<button type="submit" class="btn btn-primary waves-effect">
							<i class="material-icons">save</i>
							<span>Salvar</span>
						</button>
                        <button type="button" id="closeEditarGrupoModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                    </div>
						</form>
				</div>
			</div>
		</div>
	    <!--#END of MODAL EDITAR GRUPO-->


		<!--MODAL EXCLUIR GRUPO-->
        <div class="modal fade" id="excluirGrupoModal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="defaultModalLabel">Excluir Grupo</h4>
                    </div>
                    <div class="modal-body">
						<form id="formExcluirUsuario" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="excluirGrupo" />
							<input type="hidden" name="grupo" id="excluirGrupo_id">
							<p>Tem certeza que deseja excluir o grupo?</p>
                    </div>
                    <div class="modal-footer">
						<button type="submit" class="btn btn-danger waves-effect">
							<i class="material-icons">delete</i>
							<span>Sim</span>
						</button>
                        <button type="button" id="closeExcluirGrupoModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                    </div>
						</form>
                </div>
            </div>
        </div>
	    <!--#END of MODAL EXCLUIR GRUPO-->

		<!--Dynamic Spans ======================================================================================================================== -->

		<!--MODAL NOVO DYNAMIC-->
		<div class="modal fade" id="novoDynamicModal" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="defaultModalLabel">Novo Span Dynamic</h4>
					</div>
					<div class="modal-body">
						<div class="demo-masked-input">
						<form id="formNovoGrupo" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="novoDynamic" />

						</br></br>

							<div class="row clearfix">
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label>Drive</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group form-float">
										<select name="drive" id="drive_novoDynamic" class="form-control show-tick">
											<option value="eth">eth</option>
											<option value="ethmf">ethmf</option>
										</select>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label>Ethernet</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group form-float">
										<select name="ethernet" id="ethernet_novoDynamic" class="form-control show-tick">
											<option value="eth0">eth0</option>
											<option value="eth1">eth1</option>
											<option value="eth2">eth2</option>
											<option value="eth3">eth3</option>
											<option value="eth4">eth4</option>
											<option value="eth5">eth5</option>
											<option value="eth6">eth6</option>
											<option value="eth7">eth7</option>
											<option value="eth8">eth8</option>
											<option value="eth9">eth9</option>
										</select>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label for="mac">MAC</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group">
										<div class="form-line">
											<input type="text" name="mac" id="mac_novoDynamic" class="form-control mac" >
										</div>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label>Virtual Span</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group form-float">
										<select name="vspan" id="vspan_novoDynamic" class="form-control show-tick">
											<option value="0">0</option>
											<option value="1">1</option>
											<option value="2">2</option>
											<option value="3">3</option>
										</select>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label for="qtd_novoDynamic">Número de canais</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group">
										<div class="form-line">
											<input type="text" name="qtd" id="qtd_novoDynamic" class="form-control ramal" >
										</div>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label>Timing</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group form-float">
										<select name="timing" id="timing_novoDynamic" class="form-control show-tick">
											<?php
											for ($i = 0; $i < 10; $i++) {
										?>
											<option value="<?=$i;?>"><?=$i;?></option>
										<?php
											}
										?>
										</select>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label for="canais_novoDynamic">Canais</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group">
										<div class="form-line">
											<input type="text" name="canais" id="canais_novoDynamic" class="form-control" placeholder="1-15,17-31">
										</div>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label for="canais_novoDynamic">Canal de sinalização (dchan)</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group">
										<div class="form-line">
											<input type="text" name="dchan" id="dchan_novoDynamic" class="form-control" placeholder="16" disabled="disabled">
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
										<label>Sinalização</label>
									</div>
									<div class="demo-radio-button">
										<input name="signalling" type="radio" onclick="mfcr2_click()" id="signalling_1_novoDynamic" value="mfcr2" checked/>
										<label for="signalling_1_novoDynamic">MFCR2</label>
										<input name="signalling" type="radio" onclick="isdn_click()" id="signalling_2_novoDynamic" value="isdn"/>
										<label for="signalling_2_novoDynamic">ISDN</label>
									</div>
								</div>
							</div>
						</div>
                    </div>
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary waves-effect">
							<i class="material-icons">save</i>
							<span>Salvar</span>
						</button>
						<button type="button" id="closeNovoDynamicModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
					</div>
						</form>
                </div>
            </div>
        </div>
	    <!--#END of MODAL NOVO DYNAMIC-->
		
		
		<!--MODAL EDITAR DYNAMIC-->
		<div class="modal fade" id="editarDynamicModal" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="defaultModalLabel">Editar Span Dynamic</h4>
					</div>
					<div class="modal-body">
						<div class="demo-masked-input">
						<form id="formEditarDynamic" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="editarDynamic" />
							<input type="hidden" name="key" id="key_editarDynamic" value="" />

						</br></br>

							<div class="row clearfix">
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label>Drive</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group form-float">
										<select name="drive" id="drive_editarDynamic" class="form-control show-tick">
											<option value="eth">eth</option>
											<option value="ethmf">ethmf</option>
										</select>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label>Ethernet</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group form-float">
										<select name="ethernet" id="ethernet_editarDynamic" class="form-control show-tick">
											<option value="eth0">eth0</option>
											<option value="eth1">eth1</option>
											<option value="eth2">eth2</option>
											<option value="eth3">eth3</option>
											<option value="eth4">eth4</option>
											<option value="eth5">eth5</option>
											<option value="eth6">eth6</option>
											<option value="eth7">eth7</option>
											<option value="eth8">eth8</option>
											<option value="eth9">eth9</option>
										</select>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label for="mac">MAC</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group">
										<div class="form-line">
											<input type="text" name="mac" id="mac_editarDynamic" class="form-control mac" >
										</div>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label>Virtual Span</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group form-float">
										<select name="vspan" id="vspan_editarDynamic" class="form-control show-tick">
											<option value="0">0</option>
											<option value="1">1</option>
											<option value="2">2</option>
											<option value="3">3</option>
										</select>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label for="qtd_editarDynamic">Número de canais</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group">
										<div class="form-line">
											<input type="text" name="qtd" id="qtd_editarDynamic" class="form-control ramal" >
										</div>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label>Timing</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group form-float">
										<select name="timing" id="timing_editarDynamic" class="form-control show-tick">
											<?php
											for ($i = 0; $i < 10; $i++) {
										?>
											<option value="<?=$i;?>"><?=$i;?></option>
										<?php
											}
										?>
										</select>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label for="canais_editarDynamic">Canais</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group">
										<div class="form-line">
											<input type="text" name="canais" id="canais_editarDynamic" class="form-control" placeholder="1-15,17-31">
										</div>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label for="canais_editarDynamic">Canal de sinalização (dchan)</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group">
										<div class="form-line">
											<input type="text" name="dchan" id="dchan_editarDynamic" class="form-control" placeholder="16" disabled="disabled">
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
										<label>Sinalização</label>
									</div>
									<div class="demo-radio-button">
										<input name="signalling" type="radio" onclick="mfcr2_click()" id="signalling_1_editarDynamic" value="mfcr2" checked/>
										<label for="signalling_1_editarDynamic">MFCR2</label>
										<input name="signalling" type="radio" onclick="isdn_click()" id="signalling_2_editarDynamic" value="isdn"/>
										<label for="signalling_2_editarDynamic">ISDN</label>
									</div>
								</div>
							</div>
						</div>
                    </div>
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary waves-effect">
							<i class="material-icons">save</i>
							<span>Salvar</span>
						</button>
						<button type="button" id="closeEditarDynamicModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
					</div>
						</form>
                </div>
            </div>
        </div>
	    <!--#END of MODAL EDITAR DYNAMIC-->
		
		
		<!--MODAL EXCLUIR DYNAMIC-->
        <div class="modal fade" id="excluirDynamicModal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="defaultModalLabel">Excluir Span Dynamic</h4>
                    </div>
                    <div class="modal-body">
						<form id="formExcluirDynamic" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="excluirDynamic" />
							<input type="hidden" name="key" id="key_excluirDynamic" value="" />
							<p>Tem certeza que deseja excluir o Span?</p>
                    </div>
                    <div class="modal-footer">
						<button type="submit" class="btn btn-danger waves-effect">
							<i class="material-icons">delete</i>
							<span>Sim</span>
						</button>
                        <button type="button" id="closeExcluirDynamicModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                    </div>
						</form>
                </div>
            </div>
        </div>
	    <!--#END of MODAL EXCLUIR DYNAMIC-->
		
		<!-- Card Spans ======================================================================================================================== -->

		<!--MODAL NOVO CARD SPAN-->
		<div class="modal fade" id="novoSpanModal" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="defaultModalLabel">Novo Span</h4>
					</div>
					<div class="modal-body">
						<div class="demo-masked-input">
						<form id="formNovoGrupo" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="novoSpan" />

						</br></br>

							<div class="row clearfix">
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label>Span</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group form-float">
										<select name="span" id="span_novoSpan" class="form-control show-tick">
											<option value="1">1</option>
											<option value="2">2</option>
											<option value="3">3</option>
											<option value="4">4</option>
											<option value="5">5</option>
											<option value="6">6</option>
											<option value="7">7</option>
											<option value="8">8</option>
										</select>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label>Timing</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group form-float">
										<select name="timing" id="timing_novoSpan" class="form-control show-tick">
											<?php
											for ($i = 0; $i < 10; $i++) {
										?>
											<option value="<?=$i;?>"><?=$i;?></option>
										<?php
											}
										?>
										</select>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label>LBO</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group form-float">
										<select name="lbo" id="lbo_novoSpan" class="form-control show-tick">
											<?php
											for ($i = 0; $i < 8; $i++) {
										?>
											<option value="<?=$i;?>"><?=$i;?></option>
										<?php
											}
										?>
										</select>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label>Framing</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group form-float">
										<select name="framing" id="framing_novoSpan" class="form-control show-tick">
											<option value="cas">cas</option>
											<option value="ccs">ccs</option>
										</select>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label>Coding</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group form-float">
										<select name="coding" id="coding_novoSpan" class="form-control show-tick">
											<option value="hdb3">hdb3</option>
											<option value="ami">ami</option>
										</select>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label for="canais_novoSpan">Canais</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group">
										<div class="form-line">
											<input type="text" name="canais" id="canais_novoSpan" class="form-control" placeholder="1-15,17-31">
										</div>
									</div>
								</div>
								<div class="col-md-6 col-sm-6 col-xs-5 form-control-label">
									<label for="canais_novoSpan">Canal de sinalização (dchan - somente ccs)</label>
								</div>
								<div class="col-md-6 col-sm-6 col-xs-7">
									<div class="form-group">
										<div class="form-line">
											<input type="text" name="dchan" id="dchan_novoSpan" class="form-control" placeholder="16">
										</div>
									</div>
								</div>
							</div>
						</div>
                    </div>
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary waves-effect">
							<i class="material-icons">save</i>
							<span>Salvar</span>
						</button>
						<button type="button" id="closeNovoSpanModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
					</div>
						</form>
                </div>
            </div>
        </div>
	    <!--#END of MODAL NOVO CARD SPAN-->
		
		<!--MODAL EDITAR CARD SPAN-->
		<div class="modal fade" id="editarSpanModal" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="defaultModalLabel">Editar Span</h4>
					</div>
					<div class="modal-body">
						<div class="demo-masked-input">
						<form id="formEditarSpan" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="editarSpan" />
							<input type="hidden" name="key" id="key_editarSpan" value="" />

						</br></br>

							<div class="row clearfix">
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label>Span</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group form-float">
										<select name="span" id="span_editarSpan" class="form-control show-tick">
											<option value="0">0</option>
											<option value="1">1</option>
											<option value="2">2</option>
											<option value="3">3</option>
										</select>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label>Timing</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group form-float">
										<select name="timing" id="timing_editarSpan" class="form-control show-tick">
											<?php
											for ($i = 0; $i < 10; $i++) {
										?>
											<option value="<?=$i;?>"><?=$i;?></option>
										<?php
											}
										?>
										</select>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label>LBO</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group form-float">
										<select name="lbo" id="lbo_editarSpan" class="form-control show-tick">
											<?php
											for ($i = 0; $i < 8; $i++) {
										?>
											<option value="<?=$i;?>"><?=$i;?></option>
										<?php
											}
										?>
										</select>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label>Framing</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group form-float">
										<select name="framing" id="framing_editarSpan" class="form-control show-tick">
											<option value="cas">cas</option>
											<option value="ccs">ccs</option>
										</select>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label>Coding</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group form-float">
										<select name="coding" id="coding_editarSpan" class="form-control show-tick">
											<option value="hdb3">hdb3</option>
											<option value="ami">ami</option>
										</select>
									</div>
								</div>
								<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
									<label for="canais_editarSpan">Canais</label>
								</div>
								<div class="col-md-9 col-sm-8 col-xs-7">
									<div class="form-group">
										<div class="form-line">
											<input type="text" name="canais" id="canais_editarSpan" class="form-control" placeholder="1-15,17-31">
										</div>
									</div>
								</div>
								<div class="col-md-6 col-sm-6 col-xs-5 form-control-label">
									<label for="dchan_editarSpan">Canal de sinalização (dchan - somente ccs)</label>
								</div>
								<div class="col-md-6 col-sm-6 col-xs-7">
									<div class="form-group">
										<div class="form-line">
											<input type="text" name="dchan" id="dchan_editarSpan" class="form-control" placeholder="16">
										</div>
									</div>
								</div>
							</div>
						</div>
                    </div>
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary waves-effect">
							<i class="material-icons">save</i>
							<span>Salvar</span>
						</button>
						<button type="button" id="closeEditarSpanModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
					</div>
						</form>
                </div>
            </div>
        </div>
	    <!--#END of MODAL NOVO CARD SPAN-->

		<!--MODAL EXCLUIR CARD SPAN-->
        <div class="modal fade" id="excluirSpanModal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="defaultModalLabel">Excluir Span</h4>
                    </div>
                    <div class="modal-body">
						<form id="formExcluirSpan" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="excluirSpan" />
							<input type="hidden" name="key" id="key_excluirSpan" value="" />
							<p>Tem certeza que deseja excluir o Span?</p>
                    </div>
                    <div class="modal-footer">
						<button type="submit" class="btn btn-danger waves-effect">
							<i class="material-icons">delete</i>
							<span>Sim</span>
						</button>
                        <button type="button" id="closeExcluirSpanModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                    </div>
						</form>
                </div>
            </div>
        </div>
	    <!--#END of MODAL EXCLUIR CARD SPAN-->
		
<script>

	function mfcr2_click() {
		$('#dchan_novoDynamic').val('');
		$('#dchan_novoDynamic').prop('disabled', 'disabled');
		$('#dchan_editarDynamic').val('');
		$('#dchan_editarDynamic').prop('disabled', 'disabled');
	}
	function isdn_click() {
		$('#dchan_novoDynamic').prop('disabled', false);
		$('#dchan_editarDynamic').prop('disabled', false);
	}

	function botaoEditarGrupo(grupo, context, signalling, channel) {

		$('#editarGrupo_id').val(grupo);

		var aux = 0;
		$('#context_editarGrupo option').each(function(){
			if ($(this).val() == context) {
				$('#context_editarGrupo').selectpicker('val', context);
				aux = 1;
			} else if (aux != 1) {
				$('#context_editarGrupo').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#signalling_editarGrupo option').each(function(){
			if ($(this).val() == signalling) {
				$('#signalling_editarGrupo').selectpicker('val', signalling);
				aux = 1;
			} else if (aux != 1) {
				$('#signalling_editarGrupo').selectpicker('val', 'null');
			}
		});

		$('#channel_editarGrupo').val(channel);

		$("#editarGrupoModal").modal();
	};
	
	function botaoExcluirGrupo(excluirGrupo_id) {

		$('#excluirGrupo_id').val(excluirGrupo_id);
		$("#excluirGrupoModal").modal();
	}

	function botaoEditarDynamic(key, drive, ethernet, mac, vspan, qtd, timing, canais, dchan) {
		
		$('#key_editarDynamic').val(key);
		
		var aux = 0;
		$('#drive_editarDynamic option').each(function(){
			if ($(this).val() == drive) {
				$('#drive_editarDynamic').selectpicker('val', drive);
				aux = 1;
			} else if (aux != 1) {
				$('#drive_editarDynamic').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#ethernet_editarDynamic option').each(function(){
			if ($(this).val() == ethernet) {
				$('#ethernet_editarDynamic').selectpicker('val', ethernet);
				aux = 1;
			} else if (aux != 1) {
				$('#ethernet_editarDynamic').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#vspan_editarDynamic option').each(function(){
			if ($(this).val() == vspan) {
				$('#vspan_editarDynamic').selectpicker('val', vspan);
				aux = 1;
			} else if (aux != 1) {
				$('#vspan_editarDynamic').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#timing_editarDynamic option').each(function(){
			if ($(this).val() == timing) {
				$('#timing_editarDynamic').selectpicker('val', timing);
				aux = 1;
			} else if (aux != 1) {
				$('#timing_editarDynamic').selectpicker('val', 'null');
			}
		});
		
		$('#mac_editarDynamic').val(mac);
		$('#canais_editarDynamic').val(canais);
		$('#qtd_editarDynamic').val(qtd);
		
		if (dchan == "0"){
			var radio="mfcr2";
			$('#dchan_editarDynamic').val('');
			$('#dchan_editarDynamic').prop('disabled', 'disabled');
		} else {
			var radio="isdn";
			$('#dchan_editarDynamic').val(dchan);
			$('#dchan_editarDynamic').prop('disabled', false);
		}
		var radios = document.getElementsByName("signalling");
		for (var i = 0; i < radios.length; i++) {
			if (radios[i].value == radio) {
				radios[i].checked = true;
			}
		}
		
		$("#editarDynamicModal").modal();
	}

	function botaoExcluirDynamic(key) {

		$('#key_excluirDynamic').val(key);
		$("#excluirDynamicModal").modal();
	}
	
	/*
'<?=$key;?>',
'<?=$value['span'];?>',
'<?=$value['timing'];?>',
'<?=$value['lbo'];?>',
'<?=$value['framing'];?>',
'<?=$value['coding'];?>',
'<?=$value['canais'];?>',
<?=$value['dchan'];?>'
	*/
	
	function botaoEditarSpan(key, span, timing, lbo, framing, coding, canais, dchan) {
		
		$('#key_editarSpan').val(key);
		
		var aux = 0;
		$('#span_editarSpan option').each(function(){
			if ($(this).val() == span) {
				$('#span_editarSpan').selectpicker('val', span);
				aux = 1;
			} else if (aux != 1) {
				$('#span_editarSpan').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#timing_editarSpan option').each(function(){
			if ($(this).val() == timing) {
				$('#timing_editarSpan').selectpicker('val', timing);
				aux = 1;
			} else if (aux != 1) {
				$('#timing_editarSpan').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#lbo_editarSpan option').each(function(){
			if ($(this).val() == lbo) {
				$('#lbo_editarSpan').selectpicker('val', lbo);
				aux = 1;
			} else if (aux != 1) {
				$('#lbo_editarSpan').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#framing_editarSpan option').each(function(){
			if ($(this).val() == framing) {
				$('#framing_editarSpan').selectpicker('val', framing);
				aux = 1;
			} else if (aux != 1) {
				$('#framing_editarSpan').selectpicker('val', 'null');
			}
		});
		
		aux = 0;
		$('#coding_editarSpan option').each(function(){
			if ($(this).val() == coding) {
				$('#coding_editarSpan').selectpicker('val', coding);
				aux = 1;
			} else if (aux != 1) {
				$('#coding_editarSpan').selectpicker('val', 'null');
			}
		});
		
		$('#canais_editarSpan').val(canais);
		$('#dchan_editarSpan').val(dchan);
		
		$("#editarSpanModal").modal();
	}
	
	function botaoExcluirSpan(key) {

		$('#key_excluirSpan').val(key);
		$("#excluirSpanModal").modal();
	}
</script>