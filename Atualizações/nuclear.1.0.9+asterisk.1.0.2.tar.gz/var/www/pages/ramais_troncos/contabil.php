<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.contabil.php");
	
	// DECLARAÇÃO DE VARIÁVEIS ==============================================================================================

	$codigos = get_codigos();
	//Array ( [6000] => Array ( [senha] => 1234 [grava] => yes [cat] => 1 ) )
	//echo json_encode($ramaissip, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
	
	//CÓDIGOS ===============================================================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "novoCodigo") {
	/*
		Array ( 
			[codigoInicial] => 1000 
			[codigoFinal] => 1009 
			[secret] => 123456 
			[context] => 1 
			[gravaOut] => yes 
		)
	*/
		//seta o tempo limite da aplicação para esperar mais tempo grandes loops demoram mais
		set_time_limit(600);
		
		//primeiro vamos checar a quantidade de ramais a serem criadas
		$inicio = $_POST['codigoInicial'];
		$fim = $_POST['codigoFinal'];
		
		$erro = "";
		if (!is_numeric($inicio)) {
			$erro = "Erro: Código inicial incorreto!";
		}
		if ($fim != "" && !is_numeric($fim)){
			$erro = "Erro: Código final incorreto!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ($fim > $inicio) {
			$qtde = ($fim - $inicio);
		} elseif ($fim == $inicio || ($inicio != "" && $fim == "") ) {
			$qtde = 0;
		} elseif ($inicio > $fim) {
			$qtde = ($inicio - $fim);
			$tmp = $fim;
			$fim = $inicio;
			$inicio = $tmp;
		}
		
		if ( !novos_codigos($_POST, $qtde) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "editarCodigo") {
		/*
		Array ( 
		[editarCodigo] => 5000
		[secret] => 102030 
		[context] => 2 
		[gravaOut] => yes 
		)
		*/
		$erro="";
		if (!is_numeric($_POST['editarCodigo']) || $_POST['editarCodigo'] == "") {
			$erro = "Erro: Código Incorreto!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !editar_codigo($_POST) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirCodigo") {
		
		$erro="";
		if (!is_numeric($_POST['codigo']) || $_POST['codigo'] == "") {
			$erro = "Erro: Código Incorreto!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !excluir_codigo($_POST['codigo']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	
?>

		<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- MENU CÓDIGOS -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="row clearfix">
			    <div class="col-xs-12 col-sm-6">
				<ol class="breadcrumb">
                                	<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
				</ol>
			    </div>
			</div>
                        <div class="body">
                            <ul class="nav nav-tabs tab-nav-right" role="tablist">
                                <li role="presentation" class="active" ><a href="#ramais" data-toggle="tab">CÓDIGOS</a></li>
                                <li role="presentation" ><a href="#criar" data-toggle="tab">CRIAR CÓDIGOS</a></li>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
				<!-- RAMAIS IAX2 #####################################################################################################################-->
				<div role="tabpanel" class="tab-pane fade in active" id="ramais">


							<div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
											<th>Código</th>
											<th>Categoria</th>
											<th>Grava</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					    <?php
						foreach($codigos as $codigo=>$vetor) {
						    if (is_array($vetor)) {
					    ?>
							<tr>
								<td><?=$codigo;?></td>
								<td><?=$vetor['cat'];?></td> 
								<td><?=$vetor['grava'];?></td>
								<td>
									<a href="javascript:;" class="play" onclick="botaoEditarCodigo('<?=$codigo;?>','<?=$vetor['cat'];?>','<?=$vetor['grava'];?>','<?=$vetor['senha'];?>')"><i class="material-icons" title="Editar">edit</i></a>&nbsp;
									<a href="javascript:;" class="play" onclick="botaoExcluirCodigo('<?=$codigo;?>')"><i class="material-icons" title="Excluir">delete</i></a>
								</td>
						        </tr>
					    <?php
						    }
						}
					    ?>
                                    </tbody>
                                </table>
                            </div>


				</div>
				<!--#FIM - RAMAIS IAX2 ##############################################################################################################-->
				<!-- CRIAR CODIGO ###################################################################################################################-->
				<div role="tabpanel" class="tab-pane fade" id="criar">

			</br>
			<h4>Novo Código</h4>
			</br>
			    <div class="demo-masked-input">
			    <form id="formNovoCodigo" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="novoCodigo" />

				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label title="Para criar somente um codigo deixe o campo Codigo Final vazio" for="codigoInicial_novoCodigo">Código Inicial</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="codigoInicial" id="codigoInicial_novoCodigo" class="form-control ramal">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label title="Cria toda a faixa, a partir do código inicial até o código final" for="codigoFinal_novoCodigo">Código Final</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="codigoFinal" id="codigoFinal_novoCodigo" class="form-control ramal">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="secret_novoCodigo">Senha</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="secret" id="secret_novoCodigo" class="form-control ramal">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label>Categoria</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="context" id="context_novoCodigo" class="form-control show-tick">
            					<?php
            						$tmpcat = meu_parse_ini_file(ARQ_CATEGORIAS_CONF);
            						foreach($tmpcat as $key=>$value) {
            							print "<option value=\"".$key."\">".$key."</option>";
            						}
            					?>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label title="Gravar ligações realizadas">Gravar Saída</label>
					</div>
					<div class="demo-radio-button">
						<input name="gravaOut" type="radio" id="gravaOut_1_novoCodigo" value="yes"/>
						<label for="gravaOut_1_novoCodigo">SIM</label>
						<input name="gravaOut" type="radio" id="gravaOut_2_novoCodigo" value="no" checked/>
						<label for="gravaOut_2_novoCodigo">NÃO</label>
					</div>
				</div>
				<button type="button" onclick="novoCodigo()" class="btn btn-primary waves-effect">
					<i class="material-icons">save</i>
					<span>SALVAR</span>
			    </button>
			    </form>
			    </div>


				</div>
				<!--#FIM - CRIAR CODIGO ##############################################################################################################-->
                            </div>


                        </div>
                    </div>
                </div>
                <!-- #END# MENU CÓDIGOS -->
            </div>
	</div>
	<!--END - PAGE CONTENT-->
	
	
	<!-- MODAL ================================================================================================================================== -->

		<!--MODAL EDITAR CODIGO-->
			<div class="modal fade" id="editarCodigoModal" tabindex="-1" role="dialog">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h4 class="modal-title" id="editarCodigoLabel">Editar Código</h4>
						</div>
						<div class="modal-body">
							<div class="row clearfix demo-masked-input">
								<form id="formEditarCodigo" method="post">
								<?=$text_form;?>
								<input type="hidden" name="cmd" value="editarCodigo" />
								<input type="hidden" id="editarCodigo" name="editarCodigo" value="" />
									<div class="col-xs-12">
										<p>Configurações</p>
										</br>
									</div>
									<!--Senha-->
									<div class="col-xs-12">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Senha</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group">
												<div class="form-line">
													<input type="text" name="secret" id="secret_editarCodigo" class="form-control ramal">
												</div>
											</div>
										</div>
										</div>
									</div>
									<!--Categoria-->
									<div class="col-xs-12">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Categoria</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="context" id="context_editarCodigo" class="form-control show-tick">
													<option value=""> - </option>
													<?php
														$tmpcat = meu_parse_ini_file(ARQ_CATEGORIAS_CONF);
														foreach($tmpcat as $key=>$value) {
															print "<option value=\"".$key."\">".$key."</option>";
														}
													?>
												</select>
											</div>
										</div>
										</div>
									</div>
									<!--gravaOut-->
									<div class="col-xs-12">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Gravar Saída</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="demo-radio-button">
												<input name="gravaOut" type="radio" id="gravaOut_1_editarCodigo" value="yes"/>
												<label for="gravaOut_1_editarCodigo">SIM</label>
												<input name="gravaOut" type="radio" id="gravaOut_2_editarCodigo" value="no" checked/>
												<label for="gravaOut_2_editarCodigo">NÃO</label>
											</div>
										</div>
										</div>
									</div>
							</div>
						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
							<button type="button" id="closeEditarCodigoModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
						</div>
							</form>
					</div>
				</div>
			</div>
	    <!--#END of MODAL EDITAR CODIGO-->


	    <!--MODAL EXCLUIR CODIGO-->
            <div class="modal fade" id="excluirCodigoModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirCodigoLabel">Excluir Código</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirCodigo" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="excluirCodigo" />
				<input type="hidden" id="excluirCodigo" name="codigo" value="" />
			    <p>Tem certeza que deseja excluir o Código?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
							<button type="button" id="closeExcluirCodigoModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR CODIGO-->


	<!--#END - MODAL ============================================================================================================================== -->

<script>


function novoCodigo()
{
	
	document.getElementById("formNovoCodigo").submit();
} 

function botaoEditarCodigo(editarCodigo, cat, grava, senha) {
	$('#editarCodigo').val(editarCodigo);
	$('#secret_editarCodigo').val(senha);
	
	var aux = 0;
	$('#context_editarCodigo option').each(function(){
		if ($(this).val() == cat) {
			$('#context_editarCodigo').selectpicker('val', cat);
			aux = 1;
		} else if (aux != 1) {
			$('#context_editarCodigo').selectpicker('val', 'null');
		}
	});
	
	var radios = document.getElementsByName("gravaOut");
	for (var i = 0; i < radios.length; i++) {
		if (radios[i].value == grava) {
			radios[i].checked = true;
		}
	}
	
	$("#editarCodigoModal").modal();
};

function botaoExcluirCodigo(excluirCodigo) {
	$('#excluirCodigo').val(excluirCodigo);

	$('#excluirCodigoLabel').text("Excluir Código "+excluirCodigo);
	$("#excluirCodigoModal").modal();
};

</script>