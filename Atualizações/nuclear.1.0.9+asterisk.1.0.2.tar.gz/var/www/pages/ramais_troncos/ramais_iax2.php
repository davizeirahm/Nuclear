<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.status.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.config.ramal.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_iax2.php");
	require_once(DIR_WWW."funcoes/funcoes.network.debian7.php");

	if ( isset($_GET['tipo']) && $_GET['tipo'] == "criar") {
		$tipo = "criar";
	} else {
		$tipo = "ramais";
	}

	// DECLARAÇÃO DE VARIÁVEIS ==============================================================================================

	//$ramaissip = meu_parse_ini_file(ARQ_RAMAIS_SIP);
	$ramaisiax = get_ramais_iax(); //Função nova para leitura de ramais e astdb ao mesmo tempo - Davi Almeida
	//print_r($ramaissip);
	//echo json_encode($ramaissip, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
	
	$codecs = get_ini_array("codecs", ARQ_CONFIG_RAMAL);
	//Array ( [1] => alaw [2] => ulaw [3] => g729 [4] => gsm )

	//RAMAL IAX ===============================================================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "novoRamal") {
	/*
		Array ( 
			[ramalInicial] => 1000 
			[ramalFinal] => 1009 
			[secret] => 123456 
			[context] => 1 
			[abreviado] => 1 
			[codec] => Array ( [0] => alaw [1] => ulaw [2] => g729 ) 
			[proibeAddress] => 0.0.0.0 
			[proibeMask] => 0.0.0.0 
			[permiteAddress] => 192.168.0.0 
			[permiteMask] => 255.255.0.0
			[gravaIn] => yes 
			[gravaOut] => yes 
			[gravaInterno] => no 
		)
	*/
		//seta o tempo limite da aplicação para esperar mais tempo grandes loops demoram mais
		set_time_limit(600);
		
		//primeiro vamos checar a quantidade de ramais a serem criadas
		$inicio = $_POST['ramalInicial'];
		$fim = $_POST['ramalFinal'];
		
		$erro = "";
		if (!is_numeric($inicio)) {
			$erro = "Erro: Ramal inicial incorreto!";
		}
		if ($fim != "" && !is_numeric($fim)){
			$erro = "Erro: Ramal final incorreto!";
		}
		if ($_POST['proibeAddress'] != "" && !validate_ip($_POST['proibeAddress'])) {
			$erro = "Erro: IP proíbe inválido!";
		}
		if ($_POST['proibeMask'] != "" && !validate_netmask($_POST['proibeMask'])) {
			$erro = "Erro: Netmask proíbe inválido!";
		}
		if ($_POST['permiteAddress'] != "" && !validate_ip($_POST['permiteAddress'])) {
			$erro = "Erro: IP permite inválido!";
		}
		if ($_POST['permiteMask'] != "" && !validate_netmask($_POST['permiteMask'])) {
			$erro = "Erro: Netmask permite inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ($fim > $inicio) {
			$qtde = ($fim - $inicio);
		} elseif ($fim == $inicio || ($inicio != "" && $fim == "") ) {
			$qtde = 0;
		} elseif ($inicio > $fim) {
			$qtde = ($inicio - $fim);
			$tmp = $fim;
			$fim = $inicio;
			$inicio = $tmp;
		}
		
		if ( !novos_ramais_iax($_POST, $qtde, ARQ_RAMAIS_IAX2) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "editarRamal") {
		/*
		Array ( 
		[editarRamal] => 5000
		[secret] => 102030 
		[context] => 2 
		[abreviado] => 2 
		[codec] => Array ( [0] => alaw [1] => ulaw [2] => g729 ) 
		[calleridname] => davi 
		[proibeAddress] => 0.0.0.0 
		[proibeMask] => 0.0.0.0 
		[permiteAddress] => 192.168.0.0 
		[permiteMask] => 255.255.0.0 
		[gravaIn] => yes 
		[gravaOut] => yes 
		[gravaInterno] => no 
		[copiar] => Array ( [0] => secret [1] => context [2] => abreviado [3] => codec [4] => calleridname [5] => proibe [6] => permite [7] => gravaIn [8] => gravaOut [9] => gravaInterno )
		[copiarRamais] => Array ( [0] => 4000 [1] => 4001 [2] => 4002 )
		)
		*/
		$erro="";
		if (!is_numeric($_POST['editarRamal']) || $_POST['editarRamal'] == "") {
			$erro = "Erro: Ramal Incorreto!";
		}
		if ($_POST['proibeAddress'] != "" && !validate_ip($_POST['proibeAddress'])) {
			$erro = "Erro: IP proíbe inválido!";
		}
		if ($_POST['proibeMask'] != "" && !validate_netmask($_POST['proibeMask'])) {
			$erro = "Erro: Netmask proíbe inválido!";
		}
		if ($_POST['permiteAddress'] != "" && !validate_ip($_POST['permiteAddress'])) {
			$erro = "Erro: IP permite inválido!";
		}
		if ($_POST['permiteMask'] != "" && !validate_netmask($_POST['permiteMask'])) {
			$erro = "Erro: Netmask permite inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !editar_ramais_iax($_POST, ARQ_RAMAIS_IAX2) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirRamal") {
		
		$erro="";
		if (!is_numeric($_POST['ramal']) || $_POST['ramal'] == "") {
			$erro = "Erro: Ramal Incorreto!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !excluir_ramal_iax($_POST['ramal'], ARQ_RAMAIS_IAX2) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	
?>

	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- MENU RAMAIS IAX2 -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="row clearfix">
			    <div class="col-xs-12 col-sm-6">
				<ol class="breadcrumb">
                                	<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
				</ol>
			    </div>
			</div>
                        <div class="body">
                            <ul class="nav nav-tabs tab-nav-right" role="tablist">
                                <li role="presentation" <?php echo ( $tipo == "ramais" ? "class=\"active\"" : "" ); ?> ><a href="#ramais" data-toggle="tab">RAMAIS</a></li>
                                <li role="presentation" <?php echo ( $tipo == "criar" ? "class=\"active\"" : "" ); ?> ><a href="#criar" data-toggle="tab">CRIAR RAMAIS</a></li>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
				<!-- RAMAIS IAX2 #####################################################################################################################-->
				<div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "ramais" ? "in active" : "" ); ?>" id="ramais">


							<div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
											<th>Número</th>
											<th>IP</th>
											<th>Status</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					    <?php
						foreach($ramaisiax as $ramal=>$vetor) {
						    if (is_array($vetor)) {
								$statusRamal = infoRamalIAX2($ramal);
					    ?>
							<tr>
								<td><?=$ramal;?></td>
								<td><?=$statusRamal['Addr->IP'];?></td> 
								<td><?=$statusRamal['Status'];?></td>
								<td>
									<a href="javascript:;" class="editar-ramal" data-ramal="<?=$ramal;?>" data-toggle="modal" data-target="#editarRamalModal"><i class="material-icons" title="Editar">edit</i></a>&nbsp;
									<a href="javascript:;" class="play" onclick="botaoExcluirRamal('<?=$ramal;?>')"><i class="material-icons" title="Excluir">delete</i></a>
								</td>
						        </tr>
					    <?php
						    }
						}
					    ?>
                                    </tbody>
                                </table>
                            </div>


				</div>
				<!--#FIM - RAMAIS IAX2 ##############################################################################################################-->
				<!-- CRIAR RAMAL ###################################################################################################################-->
				<div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "criar" ? "in active" : "" ); ?>" id="criar">

			</br>
			<h4>Novo Ramal IAX2</h4>
			</br>
			    <div class="demo-masked-input">
			    <form id="formNovoRamal" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="novoRamal" />

				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label title="Para criar somente um ramal deixe o campo Ramal Final vazio" for="ramalInicial_novoRamal">Ramal Inicial</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="ramalInicial" id="ramalInicial_novoRamal" class="form-control ramal">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label title="Cria toda a faixa, a partir do ramal inicial até o ramal final" for="ramalFinal_novoRamal">Ramal Final</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="ramalFinal" id="ramalFinal_novoRamal" class="form-control ramal">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="secret_novoRamal">Senha</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="secret" id="secret_novoRamal" class="form-control">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label>Categoria</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="context" id="context_novoRamal" class="form-control show-tick">
            					<option value=""> - </option>
            					<?php
            						$tmpcat = meu_parse_ini_file(ARQ_CATEGORIAS_CONF);
            						foreach($tmpcat as $key=>$value) {
            							print "<option value=\"".$key."\">".$key."</option>";
            						}
            					?>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label>Abreviado</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="abreviado" id="abreviado_novoRamal" class="form-control show-tick">
            					<option value=""> - </option>
            					<option value="1">1</option>
            					<option value="2">2</option>
            					<option value="3">3</option>
            					<option value="4">4</option>
            					<option value="5">5</option>
            					<option value="6">6</option>
            					<option value="7">7</option>
            					<option value="8">8</option>
            					<option value="9">9</option>
            					<option value="10">10</option>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="codec0_novoRamal">Codec 1</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select class="select2" name="codec[]" id="codec0_novoRamal" class="form-control show-tick">
							<?php
								foreach ($codecs as $k=>$codec) {
							?>
								<option value="<?=$codec;?>"><?=$codec;?></option>
							<?php
								}
							?>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="codec1_novoRamal">Codec 2</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select class="select2" name="codec[]" id="codec1_novoRamal" class="form-control show-tick">
							<?php
								foreach ($codecs as $k=>$codec) {
							?>
								<option value="<?=$codec;?>"><?=$codec;?></option>
							<?php
								}
							?>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="codec2_novoRamal">Codec 3</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select class="select2" name="codec[]" id="codec2_novoRamal" class="form-control show-tick">
							<?php
								foreach ($codecs as $k=>$codec) {
							?>
								<option value="<?=$codec;?>"><?=$codec;?></option>
							<?php
								}
							?>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="codec3_novoRamal">Codec 4</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select class="select2" name="codec[]" id="codec3_novoRamal" class="form-control show-tick">
							<?php
								foreach ($codecs as $k=>$codec) {
							?>
								<option value="<?=$codec;?>"><?=$codec;?></option>
							<?php
								}
							?>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label title="Endereço/Mascara (Ex.: 192.168.0.0/255.255.255.0)">Proíbe</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="proibeAddress" id="proibeAddress_novoRamal" class="form-control ip">
							</div>
						</div>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="proibeMask" id="proibeMask_novoRamal" class="form-control ip">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label title="Endereço/Mascara (Ex.: 192.168.0.0/255.255.255.0)">Permite</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="permiteAddress" id="permiteAddress_novoRamal" class="form-control ip">
							</div>
						</div>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="permiteMask" id="permiteMask_novoRamal" class="form-control ip">
								</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label title="Gravar ligações recebidas">Gravar Entrada</label>
					</div>
					<div class="demo-radio-button">
						<input name="gravaIn" type="radio" id="gravaIn_1_novoRamal" value="yes"/>
						<label for="gravaIn_1_novoRamal">SIM</label>
						<input name="gravaIn" type="radio" id="gravaIn_2_novoRamal" value="no" checked/>
						<label for="gravaIn_2_novoRamal">NÃO</label>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label title="Gravar ligações realizadas">Gravar Saída</label>
					</div>
					<div class="demo-radio-button">
						<input name="gravaOut" type="radio" id="gravaOut_1_novoRamal" value="yes"/>
						<label for="gravaOut_1_novoRamal">SIM</label>
						<input name="gravaOut" type="radio" id="gravaOut_2_novoRamal" value="no" checked/>
						<label for="gravaOut_2_novoRamal">NÃO</label>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label title="Gravar ligações entre ramais">Gravar Interno</label>
					</div>
					<div class="demo-radio-button">
						<input name="gravaInterno" type="radio" id="gravaInterno_1_novoRamal" value="yes"/>
						<label for="gravaInterno_1_novoRamal">SIM</label>
						<input name="gravaInterno" type="radio" id="gravaInterno_2_novoRamal" value="no" checked/>
						<label for="gravaInterno_2_novoRamal">NÃO</label>
					</div>
				</div>
				<button type="button" onclick="novoRamal()" class="btn btn-primary waves-effect">
					<i class="material-icons">save</i>
					<span>SALVAR</span>
			    	</button>
			    </form>
			    </div>


				</div>
				<!--#FIM - CRIAR RAMAL ##############################################################################################################-->
                            </div>


                        </div>
                    </div>
                </div>
                <!-- #END# MENU RAMAIS IAX2 -->
            </div>
	</div>
	<!--END - PAGE CONTENT-->


	<!-- MODAL ================================================================================================================================== -->

		<!--MODAL EDITAR RAMAL-->
			<div class="modal fade" id="editarRamalModal" tabindex="-1" role="dialog">
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h4 class="modal-title" id="editarRamalLabel">Editar Ramal</h4>
						</div>
						<div class="modal-body">
							<div class="row clearfix demo-masked-input">
								<form id="formEditarRamal" method="post">
								<?=$text_form;?>
								<input type="hidden" name="cmd" value="editarRamal" />
								<input type="hidden" id="editarRamal" name="editarRamal" value="" />
								<!--Coluna esquerda - Editar Ramal-->
								<div class="col-md-8 col-sm-9 col-xs-12">
									<div class="col-xs-11">
										<p>Configurações</p>
										</br>
									</div>
									<div class="col-xs-1">
										<p>Copiar</p>
										</br>
									</div>
									<!--Senha-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Senha</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group">
												<div class="form-line">
													<input type="text" name="secret" id="secret_editarRamal" class="form-control">
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-secret" value="secret" class="filled-in chk-col-light-blue"/>
										<label for="copiar-secret"></label>
									</div>
									<!--Categoria-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Categoria</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="context" id="context_editarRamal" class="form-control show-tick">
													<option value=""> - </option>
													<?php
														$tmpcat = meu_parse_ini_file(ARQ_CATEGORIAS_CONF);
														foreach($tmpcat as $key=>$value) {
															print "<option value=\"".$key."\">".$key."</option>";
														}
													?>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-context" value="context" class="filled-in chk-col-light-blue"/>
										<label for="copiar-context"></label>
									</div>
									<!--Abreviado-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Abreviado</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="abreviado" id="abreviado_editarRamal" class="form-control show-tick">
													<option value=""> - </option>
													<option value="1">1</option>
													<option value="2">2</option>
													<option value="3">3</option>
													<option value="4">4</option>
													<option value="5">5</option>
													<option value="6">6</option>
													<option value="7">7</option>
													<option value="8">8</option>
													<option value="9">9</option>
													<option value="10">10</option>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-abreviado" value="abreviado" class="filled-in chk-col-light-blue"/>
										<label for="copiar-abreviado"></label>
									</div>
									<!--Codec-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Codec 1</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="codec[]" id="codec0_editarRamal" class="form-control show-tick">
												<?php
													foreach ($codecs as $k=>$codec) {
												?>
												<option value="<?=$codec;?>"><?=$codec;?></option>
												<?php
													}
												?>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-codec" value="codec" class="filled-in chk-col-light-blue"/>
										<label for="copiar-codec"></label>
									</div>
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Codec 2</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="codec[]" id="codec1_editarRamal" class="form-control show-tick">
												<?php
													foreach ($codecs as $k=>$codec) {
												?>
												<option value="<?=$codec;?>"><?=$codec;?></option>
												<?php
													}
												?>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
									</div>
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Codec 3</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="codec[]" id="codec2_editarRamal" class="form-control show-tick">
												<?php
													foreach ($codecs as $k=>$codec) {
												?>
												<option value="<?=$codec;?>"><?=$codec;?></option>
												<?php
													}
												?>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
									</div>
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Codec 4</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group form-float">
												<select name="codec[]" id="codec3_editarRamal" class="form-control show-tick">
												<?php
													foreach ($codecs as $k=>$codec) {
												?>
												<option value="<?=$codec;?>"><?=$codec;?></option>
												<?php
													}
												?>
												</select>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
									</div>
									<!--calleridname-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Nome</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="form-group">
												<div class="form-line">
													<input type="text" name="calleridname" id="calleridname_editarRamal" class="form-control">
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-calleridname" value="calleridname" class="filled-in chk-col-light-blue"/>
										<label for="copiar-calleridname"></label>
									</div>
									<!--Proíbe-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Proíbe</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="col-xs-6">
												<div class="form-group">
													<div class="form-line">
														<input type="text" name="proibeAddress" id="proibeAddress_editarRamal" class="form-control ip">
													</div>
												</div>
											</div>
											<div class="col-xs-6">
												<div class="form-group">
													<div class="form-line">
														<input type="text" name="proibeMask" id="proibeMask_editarRamal" class="form-control ip">
													</div>
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-proibe" value="proibe" class="filled-in chk-col-light-blue"/>
										<label for="copiar-proibe"></label>
									</div>
									<!--Permite-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Permite</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="col-xs-6">
												<div class="form-group">
													<div class="form-line">
														<input type="text" name="permiteAddress" id="permiteAddress_editarRamal" class="form-control ip">
													</div>
												</div>
											</div>
											<div class="col-xs-6">
												<div class="form-group">
													<div class="form-line">
														<input type="text" name="permiteMask" id="permiteMask_editarRamal" class="form-control ip">
													</div>
												</div>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-permite" value="permite" class="filled-in chk-col-light-blue"/>
										<label for="copiar-permite"></label>
									</div>
									<!--GravaIn-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Gravar Entrada</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="demo-radio-button">
												<input name="gravaIn" type="radio" id="gravaIn_1_editarRamal" value="yes"/>
												<label for="gravaIn_1_editarRamal">SIM</label>
												<input name="gravaIn" type="radio" id="gravaIn_2_editarRamal" value="no" checked/>
												<label for="gravaIn_2_editarRamal">NÃO</label>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-gravaIn" value="gravaIn" class="filled-in chk-col-light-blue"/>
										<label for="copiar-gravaIn"></label>
									</div>
									<!--gravaOut-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Gravar Saída</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="demo-radio-button">
												<input name="gravaOut" type="radio" id="gravaOut_1_editarRamal" value="yes"/>
												<label for="gravaOut_1_editarRamal">SIM</label>
												<input name="gravaOut" type="radio" id="gravaOut_2_editarRamal" value="no" checked/>
												<label for="gravaOut_2_editarRamal">NÃO</label>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-gravaOut" value="gravaOut" class="filled-in chk-col-light-blue"/>
										<label for="copiar-gravaOut"></label>
									</div>
									<!--GravaInterno-->
									<div class="col-xs-11">
										<div class="row clearfix">
										<div class="col-md-3 col-sm-4 col-xs-5 form-control-label">
											<label>Gravar Interno</label>
										</div>
										<div class="col-md-9 col-sm-8 col-xs-7">
											<div class="demo-radio-button">
												<input name="gravaInterno" type="radio" id="gravaInterno_1_editarRamal" value="yes"/>
												<label for="gravaInterno_1_editarRamal">SIM</label>
												<input name="gravaInterno" type="radio" id="gravaInterno_2_editarRamal" value="no" checked/>
												<label for="gravaInterno_2_editarRamal">NÃO</label>
											</div>
										</div>
										</div>
									</div>
									<div class="col-xs-1">
										<input type="checkbox" name="copiar[]" id="copiar-gravaInterno" value="gravaInterno" class="filled-in chk-col-light-blue"/>
										<label for="copiar-gravaInterno"></label>
									</div>
								</div>
								<!--Coluna direira - Copiar-->
								<div class="col-md-4 col-sm-3 col-xs-12">
									<p title="Copia as configurações selecionadas para os ramais selecionados abaixo.">Copiar para ramais:</p>
									<br>
									<div class="dd">
										<ul class="list-modal" style="overflow: hidden; height: 500px; touch-action: manipulation;">
											<li class="dd-item">
												<div class="dd-handle">
												<input type="checkbox" name="paraTodos" onclick="marcarTodosRamais()" id="paraTodos" class="filled-in chk-col-light-blue"/>
												<label for="paraTodos">Marcar Todos</label>
												</div>
											</li>
										<?php
											foreach ($ramaisiax as $ramal=>$vetor) {
										?>
											<li class="dd-item">
												<div class="dd-handle">
												<input type="checkbox" name="copiarRamais[]" id="copiarRamal-<?=$ramal;?>" value="<?=$ramal;?>" class="filled-in chk-col-light-blue"/>
												<label for="copiarRamal-<?=$ramal;?>"><?=$ramal;?></label>
												</div>
											</li>
										<?php
											}
										?>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
							<button type="button" id="closeEditarRamalModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
						</div>
							</form>
					</div>
				</div>
			</div>
	    <!--#END of MODAL EDITAR RAMAL-->


	    <!--MODAL EXCLUIR RAMAL-->
            <div class="modal fade" id="excluirRamalModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirRamalLabel">Excluir Ramal</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirRamal" method="post">
				<?=$text_form;?>
				<input type="hidden" name="tipo" value="ramal" />
				<input type="hidden" name="cmd" value="excluirRamal" />
				<input type="hidden" id="excluirRamal" name="ramal" value="" />
			    <p>Tem certeza que deseja excluir o Ramal?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
							<button type="button" id="closeExcluirRamalModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR RAMAL-->


	<!--#END - MODAL ============================================================================================================================== -->

<script>


function novoRamal()
{
	
	document.getElementById("formNovoRamal").submit();
} 

function botaoExcluirRamal(excluirRamal) {
	$('#excluirRamal').val(excluirRamal);

	$('#excluirRamalLabel').text("Excluir Ramal "+excluirRamal);
	$("#excluirRamalModal").modal();
};

function marcarTodosRamais() {
	if ( $('#paraTodos').is(":checked") == true) {
		$("input[name='copiarRamais[]']").each(function(){
			//alert($(this).val());
			document.getElementById($(this).attr("id")).checked = true;
			//$(this).checked = true;
		});
	} else {
		$("input[name='copiarRamais[]']").each(function(){
			document.getElementById($(this).attr("id")).checked = false;
			//$(this).checked = false;
		});
	}
};

$(document).ready(function(){

	var ramais = <?php echo json_encode($ramaisiax, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
	/*
	"3954":{
		"type":"friend",
		"secret":"102030",
		"qualify":"1",
		"host":"dynamic",
		"disallow":"all",
		"dial":"SIP/3954",
		"context":"1",
		"codec":["alaw"," ulaw"," gsm"],
		"calleridname":"Kenko ",
		"proibeAddress":"",
		"proibeMask":"",
		"permiteAddress":"",
		"permiteMask":"",
		"abreviado":"1",
		"gravaIn":"yes",
		"gravaOut":"yes",
		"gravaInterno":"yes"
	}
	*/

	$(".editar-ramal").on('click', function(event) {
		event.preventDefault();

		var ramal = $(this).data('ramal');

		document.getElementById('editarRamalLabel').innerHTML = "EditarRamal: "+ramal;

		$('#editarRamal').val(ramal);

		$('#secret_editarRamal').val(ramais[ramal].secret);
		$('#port_editarRamal').val(ramais[ramal].port);
		$('#calleridname_editarRamal').val(ramais[ramal].calleridname);
		$('#proibeAddress_editarRamal').val(ramais[ramal].proibeAddress);
		$('#proibeMask_editarRamal').val(ramais[ramal].proibeMask);
		$('#permiteAddress_editarRamal').val(ramais[ramal].permiteAddress);
		$('#permiteMask_editarRamal').val(ramais[ramal].permiteMask);
		
		var aux = 0;
		$('#context_editarRamal option').each(function(){
			if ($(this).val() == ramais[ramal].context) {
				$('#context_editarRamal').selectpicker('val', ramais[ramal].context);
				aux = 1;
			} else if (aux != 1) {
				$('#context_editarRamal').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#abreviado_editarRamal option').each(function(){
			if ($(this).val() == ramais[ramal].abreviado) {
				$('#abreviado_editarRamal').selectpicker('val', ramais[ramal].abreviado);
				aux = 1;
			} else if (aux != 1) {
				$('#abreviado_editarRamal').selectpicker('val', 'null');
			}
		});
		aux = 0;

		for(var i = 0; i < 4; i++) {
			$('#codec'+i+'_editarRamal').selectpicker('deselectAll');
			$('#codec'+i+'_editarRamal').selectpicker('val', ramais[ramal].codec[i]);
		}
		
		var radios = document.getElementsByName("gravaIn");
		for (var i = 0; i < radios.length; i++) {
			if (radios[i].value == ramais[ramal].gravaIn) {
				radios[i].checked = true;
			}
		}
		var radios = document.getElementsByName("gravaOut");
		for (var i = 0; i < radios.length; i++) {
			if (radios[i].value == ramais[ramal].gravaOut) {
				radios[i].checked = true;
			}
		}
		var radios = document.getElementsByName("gravaInterno");
		for (var i = 0; i < radios.length; i++) {
			if (radios[i].value == ramais[ramal].gravaInterno) {
				radios[i].checked = true;
			}
		}

	});
	
	function slimscrollReboot(){
		$('#editarRamalModal .list-modal')
			.slimscroll({ destroy: true })
			.slimscroll({ height: '500px' });
		//window.addEventListener("wheel", function(event){ event.preventDefault(); }, {passive: false} );
	};
	slimscrollReboot();
	
	$("#editarRamalModal").on('show.bs.modal', function() {
		slimscrollReboot();
	});

});

</script>