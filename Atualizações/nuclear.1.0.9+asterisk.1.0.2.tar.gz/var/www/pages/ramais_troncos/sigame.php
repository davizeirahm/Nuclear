<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.config.ramal.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.sigame.php");
	
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_sip.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_iax2.php");

	// DECLARAÇÃO DE VARIÁVEIS ==============================================================================================
	
	$ramais_sip = get_ramais();
	$ramais_iax2 = get_ramais_iax();
	
	$sigames = get_sigames();
	//echo json_encode($sigames, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

	//SIGAMES ===============================================================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "novoSigame") {
		//print_r($_POST);
		//die();
		//[origem] => 4000 [destino] => 4001

		$erro = "";
		if (!isset($_POST['origem']) || @$_POST['origem'] == "") {
			$erro = "Erro: Origem inválida!";
		}
		if ( !isset($_POST['destino']) || @$_POST['destino'] == "") {
			$erro = "Erro: Destino inválido!";
		}
		if ( @$_POST['origem'] ==  @$_POST['destino']) {
			$erro = "Erro: Não é possivel fazer siga-me para o mesmo ramal da origem!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !novo_sigame($_POST['origem'], $_POST['destino']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirSigame") {
		
		$erro="";
		if ( !isset($_POST['origem']) || @$_POST['origem'] == "") {
			$erro = "Erro: 0x00000011!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !excluir_sigame($_POST['origem']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}

?>


	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- MENU SIGA-ME -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
						<div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
                                	<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
						</div>
                        <div class="body">

							<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novaSigameModal">
								<i class="material-icons">add_circle</i>
								<span>NOVO SIGA-ME</span>
							</button>
							<div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
                                            <th>Origem</th>
											<th>Destino</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<?php
									foreach ($sigames as $key=>$value) {
									?>
										<tr>
											<td><?=$value['origem'];?></td>
											<td><?=$value['destino'];?></td>
											<td>
												<a href="javascript:;" class="play" onclick="botaoExcluirSigame('<?=$value['origem'];?>')"><i class="material-icons" title="Excluir">delete</i></a>
											</td>
										</tr>
									<?php
									}
									?>
                                    </tbody>
                                </table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	<!--END - PAGE CONTENT-->


	<!-- MODAL ================================================================================================================================== -->

		<!--MODAL NOVO SIGAME-->
            <div class="modal fade" id="novaSigameModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="modal-title" id="novoSigameLabel">Novo Siga-me</h2>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
							<form id="formNovoSigame" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="novoSigame" />
								<div class="row clearfix">
									<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
										<label>Origem</label>
									</div>
									<div class="col-md-9 col-sm-9 col-xs-7">
										<div class="form-group form-float">
											<select name="origem" id="origem_novoSigame" class="form-control show-tick" data-live-search="true">
												<?php
													foreach($ramais_sip as $key=>$value) {
														print "<option value=\"".$key."\">SIP/".$key."</option>";
													}
													foreach($ramais_iax2 as $key=>$value) {
														print "<option value=\"".$key."\">IAX2/".$key."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
										<label>Destino</label>
									</div>
									<div class="col-md-9 col-sm-9 col-xs-7">
										<div class="form-group form-float">
											<select name="destino" id="destino_novoSigame" class="form-control show-tick" data-live-search="true">
												<?php
													foreach($ramais_sip as $key=>$value) {
														print "<option value=\"".$key."\">SIP/".$key."</option>";
													}
													foreach($ramais_iax2 as $key=>$value) {
														print "<option value=\"".$key."\">IAX2/".$key."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>

								<div class="modal-footer">
									<button type="submit" class="btn btn-primary waves-effect">
										<i class="material-icons">save</i>
										<span>Salvar</span>
									</button>
									<button type="button" id="closenovoSigameModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
								</div>
							</form>
							</div>
						</div>
					</div>
				</div>
			</div>
	    <!--#END of MODAL NOVA SIGAME-->


	    <!--MODAL EXCLUIR SIGAME-->
            <div class="modal fade" id="excluirSigameModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirSigameLabel">Excluir Siga-me</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirSigame" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="excluirSigame" />
				<input type="hidden" id="origem_excluirSigame" name="origem" value="" />
			    <p>Tem certeza que deseja excluir o Siga-me?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
							<button type="button" id="closeExcluirSigameModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR SIGAME-->


	<!--#END - MODAL ============================================================================================================================== -->

<script>

function botaoExcluirSigame(origem) {
	$('#origem_excluirSigame').val(origem);

	$('#excluirSigameLabel').text("Excluir Siga-me do Ramal "+origem);
	$('#excluirSigameModal').modal();
};

</script>