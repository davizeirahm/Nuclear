<?php
	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.db.php");
	require_once(DIR_WWW."funcoes/funcoes.config.usuarios.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.agentes.php");

	if ( isset($_REQUEST['tipo']) && $_REQUEST['tipo'] == "perfil") {
		$tipo = "perfil";
	} else {
		$tipo = "usuario";
	}
	
	//USUARIOS ================================================================================================

	$users = get_users();
	//print_r($users);
	//[0] => Array ( [id] => 4 [nome] => operador [email] => [perfil] => Operador )

	$perfis = get_perfis();
	//print_r($perfis);
	//[0] => Array ( [id] => 2 [nome] => Administrador ) [1] => Array ( [id] => 3 [nome] => Operador )
	
	$agentes = get_agentes();

	//PERMISSOES ==============================================================================================

	$pages = get_pages();
	//print_r($pages);
	//echo json_encode($pages, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

	$modules = get_modules();
	//print_r($modules);
	//Array ( [1] => Sistema [2] => Ramais e Troncos [3] => PBX Config [4] => Relatórios [5] => Painel [6] => Aplicativos )

	//CONTROLE DE USUÁRIOS ====================================================================================

	if (isset($_POST['cmd']) && $_POST['cmd'] == "novoUsuario") {
		//print_r($_POST);
		//[nome] => davi [senha] => assuncion@@ [email] => davi@erimatoeste.com.br [perfil] => Operador

		$erro = "";
		if ( $_POST['nome'] == "" || $_POST['nome'] == "admin") {
			$erro = "Erro: Nome inválido!";
		}
		if ( array_search(@$_POST['nome'], array_column($users, 'nome')) !== FALSE ) {
			$erro = "Erro: Nome já utilizado como usuário!";
		}
		if ( array_key_exists($_POST['nome'], $agentes) ) {
			$erro = "Erro: Nome já utilizado como agente!";
		}
		if ( $_POST['senha'] == "" ) {
			$erro = "Erro: Senha inválida!";
		}
		if ( $_POST['perfil'] == "") {
			$erro = "Erro: Perfil inválido!";
		}
		if ( $_POST['email'] != "" && !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) ) {
			$erro = "Erro: E-mail inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}

		if ( !new_user($_POST['nome'],$_POST['senha'],$_POST['email'],$_POST['perfil']) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				   </script>";
			die();
		} else {
			print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				   </script>";
			die();
		}
	}

	if (isset($_POST['cmd']) && $_POST['cmd'] == "novoPerfil") {
		//print_r($_POST);
		//[nome] => davi

		$erro = "";
		if ( $_POST['nome'] == "" ) {
			$erro = "Erro: Nome inválido!";
		} 
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}

		if ( !new_perfil($_POST['nome']) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				   </script>";
			die();
		} else {
			print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				   </script>";
			die();
		}
	}

	if (isset($_POST['cmd']) && $_POST['cmd'] == "editarUsuario") {
		//print_r($_POST);
		//[id_editarUsuario] => 4 [nome] => operador [email] => [perfil] => Operador

		$erro = "";
		if ( $_POST['id_editarUsuario'] == "" ) {
			$erro = "Erro: Erro de ID!";
		} 
		if ( $_POST['nome'] == "" || $_POST['nome'] == "admin") {
			$erro = "Erro: Nome inválido!";
		}
		if ( array_search(@$_POST['nome'], array_column($users, 'nome')) !== FALSE ) {
			$erro = "Erro: Nome já utilizado como usuário!";
		}
		if ( array_key_exists($_POST['nome'], $agentes) ) {
			$erro = "Erro: Nome já utilizado como agente!";
		} 
		if ( $_POST['perfil'] == "") {
			$erro = "Erro: Perfil inválido!";
		}
		if ( $_POST['email'] != "" && !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) ) {
			$erro = "Erro: E-mail inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}

		if ( !edit_user($_POST['id_editarUsuario'], $_POST['nome'], $_POST['email'], $_POST['perfil']) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				   </script>";
			die();
		} else {
			print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				   </script>";
			die();
		}
	}

	if (isset($_POST['cmd']) && $_POST['cmd'] == "editarPerfil") {
		//print_r($_POST);
		//[id_editarPerfil] => 4 [nome] => Operador

		$erro = "";
		if ( $_POST['id_editarPerfil'] == "" ) {
			$erro = "Erro: Erro de ID!";
		} 
		if ( $_POST['nome'] == "" ) {
			$erro = "Erro: Nome inválido!";
		} 
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}

		if ( !edit_perfil($_POST['id_editarPerfil'], $_POST['nome']) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				   </script>";
			die();
		} else {
			print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				   </script>";
			die();
		}
	}

	if (isset($_POST['cmd']) && $_POST['cmd'] == "alterarSenha") {
		//print_r($_POST);
		//[id_alterarSenha] => 5 [nome_alterarSenha] => operador [senha] => 123 [confSenha] => 123

		$erro = "";
		if ( $_POST['id_alterarSenha'] == "" && $_POST['nome_alterarSenha'] == "" ) {
			$erro = "Erro: Usuário Inválido!";
		}
		if ( $_POST['senha'] == "" || $_POST['confSenha'] == "" ) {
			$erro = "Erro: Senha Inválida!";
		}
		if ( $_POST['senha'] != $_POST['confSenha'] ) {
			$erro = "Erro: Senhas não conferem!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}

		if ( !alter_secret_user($_POST['id_alterarSenha'],$_POST['nome_alterarSenha'],$_POST['senha']) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
			die();
		} else {
			print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
			die();
		}
	}

	if (isset($_POST['cmd']) && $_POST['cmd'] == "alterarPermissoes") {
		//print_r($_POST);
		//[id_alterarPermissoes] => 5 [pages] => Array ( [0] => 1 [1] => 5 [2] => 28 ) )

		if ( $_POST['id_alterarPermissoes'] != "" ) {
			save_permissions($_POST['id_alterarPermissoes'],@$_POST['pages']);
		} else {
			echo "<script>alert('Dados inválidos, verifique por favor!');</script>";
		}

	}

	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirUsuario") {
		//print_r($_POST);
		//[id_excluirUsuario] => 6 [nome_excluirUsuario] => davi

		if ( $_POST['id_excluirUsuario'] != "" && $_POST['nome_excluirUsuario'] != "" ) {
			remove_user($_POST['id_excluirUsuario'],$_POST['nome_excluirUsuario']);
		} else {
			echo "<script>alert('Dados inválidos, verifique por favor!');</script>";
		}
	}

	//NOVO METODO
	foreach ($users as $key=>$value) {
		$perm = get_permissions($value['id']);
		$users[$key]['permissoes'] = $perm;
	}
	//print_r($users);
	//echo json_encode($users, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
	foreach ($perfis as $key=>$value) {
		$perm = get_permissions($value['id']);
		$perfis[$key]['permissoes'] = $perm;
	}

?>

	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- TABELA USUÁRIOS -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
                                	<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
						</div>
                        <div class="body">
                            <ul class="nav nav-tabs tab-nav-right" role="tablist">
                                <li role="presentation" <?php echo ( $tipo == "usuario" ? "class=\"active\"" : "" ); ?> ><a href="#usuarios" data-toggle="tab">USUÁRIOS</a></li>
                                <li role="presentation" <?php echo ( $tipo == "perfil" ? "class=\"active\"" : "" ); ?> ><a href="#perfis" data-toggle="tab">PERFIS</a></li>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "usuario" ? "in active" : "" ); ?>" id="usuarios">




							<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novoUsuarioModal">
								<i class="material-icons">person_add</i>
								<span>Novo Usuário</span>
							</button>
							<div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
                                            <th>Usuário</th>
                                            <th>E-mail</th>
											<th>Perfil</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					    <?php
						foreach ($users as $key=>$value){
					    ?>
							<tr>
								<td><?=$value['nome'];?></td> 
								<td><?=$value['email'];?></td> 
								<td><?=$value['perfil'];?></td>
								<td>
									<a href="javascript:;" class="play" onclick="botaoEditar(
										'<?=$value['id'];?>',
										'<?=$value['nome'];?>',
										'<?=$value['email'];?>',
										'<?=$value['perfil'];?>'
										)"><i class="material-icons" title="Editar">edit</i></a>&nbsp;
									<a href="javascript:;" class="play" onclick="botaoAlterarSenha('<?=$value['id'];?>','<?=$value['nome'];?>')"><i class="material-icons" title="Alterar Senha">account_circle</i></a>&nbsp;
									<?php
										if ($value['super'] == 0) {
									?>
									<a href="javascript:;" class="open-modal" data-id="<?=$value['id'];?>" data-toggle="modal" data-target="#alterarPermissoesModal"><i class="material-icons" title="Permissões">settings</i></a>&nbsp;
									<?php
										}
									?>
									<a href="javascript:;" class="play" onclick="botaoExcluir('<?=$value['id'];?>','<?=$value['nome'];?>')"><i class="material-icons" title="Excluir">delete</i></a>
								</td>
						        </tr>
					    <?php
						}
					    ?>
                                    </tbody>
                                </table>
                            </div>



								</div>
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "perfil" ? "in active" : "" ); ?>" id="perfis">



							<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novoPerfilModal">
								<i class="material-icons">add_circle</i>
								<span>Novo Perfil</span>
							</button>
							<div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
											<th>Perfil</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					    <?php
						foreach ($perfis as $key=>$value){
					    ?>
							<tr>
								<td><?=$value['nome'];?></td> 
								<td>
									<a href="javascript:;" class="play" onclick="botaoEditarPerfil(
										'<?=$value['id'];?>',
										'<?=$value['nome'];?>',
										)"><i class="material-icons" title="Editar">edit</i></a>&nbsp;
									<a href="javascript:;" class="open-modal" data-id="<?=$value['id'];?>" data-tipo="perfil" data-toggle="modal" data-target="#alterarPermissoesModal"><i class="material-icons" title="Permissões">settings</i></a>&nbsp;
									<a href="javascript:;" class="play" onclick="botaoExcluir('<?=$value['id'];?>','<?=$value['nome'];?>')"><i class="material-icons" title="Excluir">delete</i></a>
								</td>
						        </tr>
					    <?php
						}
					    ?>
                                    </tbody>
                                </table>
                            </div>



                                </div>
                            </div>


                        </div>
                    </div>
                </div>
                <!-- #END# TABELA USUÁRIOS -->
            </div>

        </div>
    	<!--#END of PAGE CONTENT-->


	    <!-- Modal Dialogs ====================================================================================================================== -->

            <!--MODAL NOVO USUÁRIO-->
            <div class="modal fade" id="novoUsuarioModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Novo Usuário</h4>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
							<form id="formNovoUsuario" method="post">
								<?=$text_form;?>
								<input type="hidden" name="cmd" value="novoUsuario" />

								<div class="row clearfix">
                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                        <label for="nome_novoUsuario">Nome</label>
                                    </div>
                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="nome" id="nome_novoUsuario" class="form-control" placeholder="Nome">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row clearfix">
                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                        <label for="senha_novoUsuario">Senha</label>
                                    </div>
                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="password" name="senha" id="senha_novoUsuario" class="form-control" placeholder="Senha">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row clearfix">
                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                        <label for="email_novoUsuario">E-mail</label>
                                    </div>
                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="email" id="email_novoUsuario" class="form-control email" placeholder="E-mail">
                                            </div>
                                        </div>
                                    </div>
                                </div>
								<div class="row clearfix">
                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                        <label for="perfil_novoUsuario">Perfil</label>
                                    </div>
                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
										<div class="form-group form-float">
											<select name="perfil" id="perfil_novoUsuario" class="form-control show-tick">
											<option value="null">-- Nenhum --</option>
									<?php
										foreach ($perfis as $value) {
									?>
											<option value="<?=$value['nome'];?>"><?=$value['nome'];?></option>
									<?php
										}
									?>
											</select>
										</div>
									</div>
                                </div>
							</div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
                            <button type="button" id="closeNovoUsuarioModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
							</form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL NOVO USUÁRIO-->


            <!--MODAL EDITAR USUÁRIO-->
            <div class="modal fade" id="editarUsuarioModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Editar Usuário</h4>
                        </div>
                        <div class="modal-body">
			    <div class="demo-masked-input">
			    <form id="formEditarUsuario" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="editarUsuario" />
				<input type="hidden" id="id_editarUsuario" name="id_editarUsuario" value="" />

				<div class="row clearfix">
                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                        <label for="nome_editarUsuario">Nome</label>
                                    </div>
                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="nome" id="nome_editarUsuario" class="form-control" placeholder="Nome">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row clearfix">
                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                        <label for="email_editarUsuario">E-mail</label>
                                    </div>
                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="email" id="email_editarUsuario" class="form-control email" placeholder="E-mail">
                                            </div>
                                        </div>
                                    </div>
                                </div>
				<div class="row clearfix">
                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                        <label for="perfil_editarUsuario">Perfil</label>
                                    </div>
                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
					<div class="form-group form-float">
					    <select name="perfil" id="perfil_editarUsuario" class="form-control show-tick">
						<option value="null">-- Nenhum --</option>
<?php
						foreach ($perfis as $value) {
?>
                                        	<option value="<?=$value['nome'];?>"><?=$value['nome'];?></option>
<?php
						}
?>
                                    	    </select>
					</div>
				    </div>
                                </div>
			    </div>
                        </div>
                        <div class="modal-footer">
			    <button type="submit" class="btn btn-primary waves-effect">
				<i class="material-icons">save</i>
				<span>Salvar</span>
			    </button>
                            <button type="button" id="closeEditarUsuarioModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EDITAR USUÁRIO-->


            <!--MODAL ALTERAR SENHA-->
            <div class="modal fade" id="alterarSenhaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Alterar Senha</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formAlterarSenha" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="alterarSenha" />
				<input type="hidden" id="id_alterarSenha" name="id_alterarSenha" value="" />
				<input type="hidden" id="nome_alterarSenha" name="nome_alterarSenha" value="" />

				<div class="row clearfix">
                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                        <label for="senha_alterarSenha">Senha</label>
                                    </div>
                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="password" name="senha" id="senha_alterarSenha" class="form-control" placeholder="senha">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row clearfix">
                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                        <label for="confSenha_alterarSenha">Comfirma Senha</label>
                                    </div>
                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="password" name="confSenha" id="confSenha_alterarSenha" class="form-control" placeholder="confirma">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        </div>
                        <div class="modal-footer">
			    <button type="submit" class="btn btn-primary waves-effect">
				<i class="material-icons">save</i>
				<span>Salvar</span>
			    </button>
                            <button type="button" id="closeAlterarSenhaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL ALTERAR SENHA-->


	    <!--MODAL ALTERAR PERMISSOES-->
            <div class="modal fade" id="alterarPermissoesModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Alterar Permissões</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formAlterarPermissoes" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="alterarPermissoes" />
				<input type="hidden" id="id_alterarPermissoes" name="id_alterarPermissoes" value="" />

			    <div class="clearfix">
				<div class="dd">
                                    <ol class="dd-list">
<?php
				foreach ($modules as $key=>$m) {
?>
                                        <li class="dd-item" data-id="<?=$m;?>">
                                            <div class="dd-handle"><?=$m;?></div>
                                            <ol class="dd-list">
<?php
					foreach ($pages as $k=>$p) {
						if($key == $p['module_id']) {
?>
                                                <li class="dd-item" data-id="dd-<?=$p['name'];?>">
                                                    <div class="dd-handle">
							<input type="checkbox" name="pages[]" id="page-<?=$p['id'];?>" value="<?=$p['id'];?>" class="filled-in chk-col-light-blue"/>
							<label for="page-<?=$p['id'];?>"><?=$p['name'];?></label>
						    </div>
                                                </li>
<?php
						}
					}
?>
                                            </ol>
                                        </li>
<?php
				}
?>
                                    </ol>
				</div>
			    </div>

                        </div>
                        <div class="modal-footer">
			    <button type="submit" class="btn btn-primary waves-effect">
				<i class="material-icons">save</i>
				<span>Salvar</span>
			    </button>
                            <button type="button" id="closeAlterarPermissoesModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL ALTERAR PERMISSOES-->



        <!--MODAL EXCLUIR USUÁRIO-->
            <div class="modal fade" id="excluirUsuarioModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Excluir Usuário</h4>
                        </div>
                        <div class="modal-body">
							<form id="formExcluirUsuario" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="excluirUsuario" />
							<input type="hidden" id="id_excluirUsuario" name="id_excluirUsuario" value="" />
							<input type="hidden" id="nome_excluirUsuario" name="nome_excluirUsuario" value="" />
							<p id="excluirUsuarioTexto"></p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
                            <button type="button" id="closeExcluirUsuarioModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
							</form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR USUÁRIO-->



            <!--MODAL NOVO PERFIL-->
            <div class="modal fade" id="novoPerfilModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Novo Perfil</h4>
                        </div>
                        <div class="modal-body">
			    <div class="demo-masked-input">
			    <form id="formNovoPerfil" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="novoPerfil" />

				<div class="row clearfix">
                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                        <label for="nome_novoPerfil">Nome</label>
                                    </div>
                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="nome" id="nome_novoPerfil" class="form-control" placeholder="Nome">
                                            </div>
                                        </div>
                                    </div>
                                </div>
			    </div>
                        </div>
                        <div class="modal-footer">
			    <button type="submit" class="btn btn-primary waves-effect">
				<i class="material-icons">save</i>
				<span>Salvar</span>
			    </button>
                            <button type="button" id="closeNovoPerfilModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL NOVO PERFIL-->

            <!--MODAL EDITAR PERFIL-->
            <div class="modal fade" id="editarPerfilModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Editar Perfil</h4>
                        </div>
                        <div class="modal-body">
			    <div class="demo-masked-input">
			    <form id="formEditarPerfil" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="editarPerfil" />
				<input type="hidden" id="id_editarPerfil" name="id_editarPerfil" value="" />

				<div class="row clearfix">
                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                        <label for="nome_editarPerfil">Nome</label>
                                    </div>
                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="nome" id="nome_editarPerfil" class="form-control" placeholder="Nome">
                                            </div>
                                        </div>
                                    </div>
                                </div>
			    </div>
                        </div>
                        <div class="modal-footer">
			    <button type="submit" class="btn btn-primary waves-effect">
				<i class="material-icons">save</i>
				<span>Salvar</span>
			    </button>
                            <button type="button" id="closeEditarPerfilModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EDITAR PERFIL-->


<script>

function botaoAlterarSenha(senha_id, senha_nome){
	$('#id_alterarSenha').attr("value",senha_id);
	$('#nome_alterarSenha').attr("value",senha_nome);
	$("#alterarSenhaModal").modal();
};

function botaoEditar(editar_id, editar_nome, editar_email, editar_perfil){
	$('#id_editarUsuario').attr("value",editar_id);
	$('#nome_editarUsuario').attr("value",editar_nome);
	$('#email_editarUsuario').val(editar_email);

	var aux = 0;

	$('#perfil_editarUsuario option').each(function(){
		if ($(this).text() == editar_perfil) {
			$('#perfil_editarUsuario').selectpicker('val', editar_perfil);
			aux = 1;
		} else if (aux != 1) {
			$('#perfil_editarUsuario').selectpicker('val', 'null');
		}
	});

	$("#editarUsuarioModal").modal();
};

function botaoEditarPerfil(editar_id, editar_nome){
	$('#id_editarPerfil').attr("value",editar_id);
	$('#nome_editarPerfil').attr("value",editar_nome);

	$("#editarPerfilModal").modal();
};

function botaoExcluir(excluir_id, excluir_nome){
	$('#id_excluirUsuario').attr("value",excluir_id);
	$('#nome_excluirUsuario').attr("value",excluir_nome);
	document.getElementById('excluirUsuarioTexto').innerHTML = "Deseja excluir o usuário: "+excluir_nome;
	$("#excluirUsuarioModal").modal();
};

function botaoAlterarPermissoes(id) {
	$("#alterarPermissoesModal").modal();
};

$(document).ready(function(){

	var users = <?php echo json_encode($users, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
	var perfis = <?php echo json_encode($perfis, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;

	var pages = <?php echo json_encode($pages, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;

	$(".open-modal").on('click', function(event) {
		event.preventDefault();

		var userId = $(this).data('id');

		for (var z in pages) {
			$('#page-'+pages[z].id).prop('checked',false);
		}

		for (var i in users) {
			if (users[i].id == userId) {
				$('#id_alterarPermissoes').attr("value",users[i].id);
				for (var y in users[i].permissoes) {
					$('#page-'+users[i].permissoes[y]).prop('checked',true);
				}
			}
		}

		var perfilval = $(this).data('tipo');

		if (perfilval == "perfil") {
			for (var i in perfis) {
				if (perfis[i].id == userId) {
					$('#id_alterarPermissoes').attr("value",perfis[i].id);
					for (var y in perfis[i].permissoes) {
						$('#page-'+perfis[i].permissoes[y]).prop('checked',true);
					}
				}
			}
		}
	});

	$('#alterarPermissoesModal').on('show.bs.modal', function (e) {
		$('.dd').nestable({
		    maxDepth: 0,
            noDragClass:'dd-nodrag',
		    handleClass:'123'
		});
	});
});

</script>