<?php

	$cmd = (isset($_REQUEST['cmd']))?$_REQUEST['cmd']:"";
	
	switch($cmd) {
		
		case "restore" :

			if (!isset($_FILES['arquivo']['name'])) {
				print "<script type='text/javascript'>
						alert(\"Nenhum arquivo de backup selecionado\");
					</script>"; 
			} else {

				$target = "/var/www/upload/".basename($_FILES['arquivo']['name']);
			
				if( move_uploaded_file($_FILES['arquivo']['tmp_name'], $target) ) {
				
					$retorno = shell_exec("sudo /root/scripts/restore.sh '".basename($target)."'");
					
					print "<br><div id=\"conteudo\"><br><br>";
					print "<center><h1>Reiniciando o Sistema. Aguarde 1 minuto. </h1></center><br><br><br>";
					print "<center><img src=\"images/loading.gif\" border=\"0\" /></center>";
					print "</div>";
		
						//preciso de um shellscript para reiniciar as interfaces e tacar o novo endereço na url
					print "<script type='text/javascript'>
							setInterval(function() {
								document.getElementById('form_{$pagina}_{$menu}').submit();
							}, 60000); 
						</script>"; 
				} else {
					print "<script> alert('Erro: Não foi possível fazer upload do Backup! ".$_FILES['arquivo']['error']." '); history.back(1); </script>";
				}
			}
		break;
	}

?>

	<form style="margin-block-end: 0em" id="form_<?=$pagina;?>_<?=$menu;?>" method="POST" action="./">
		<input type="hidden" name="pagina" value="<?=$pagina;?>">
		<input type="hidden" name="pagina_nome" value="<?=$pagina_nome;?>">
		<input type="hidden" name="menu" value="<?=$menu;?>">
		<input type="hidden" name="menu_nome" value="<?=$menu_nome;?>">
	</form>

	<!--PAGE CONTENT-->
	<div class="container-fluid">
		<div class="row clearfix">
			<!-- Bloco Pesquisa -->
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<div class="card">
					<div class="row clearfix">
						<div class="col-xs-12 col-sm-6">
							<ol class="breadcrumb">
								<li>NUCLEAR PABX IP</li>
								<li><?=$pagina_nome;?></li>
								<li class="active"><?=$menu_nome;?></li>
							</ol>
						</div>
					</div>
					<div class="body" style="padding-bottom: 5px;">
						<div class="row clearfix">
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<button id="btnBackup" type="button" class="btn btn-primary waves-effect">
									<i class="material-icons">get_app</i>
									<span>DOWNLOAD BACKUP</span>
								</button>
							</div>
						</div>
						<hr>
						<!--Formulário-->
						<form action="./" method="post" name="upload_backup" enctype="multipart/form-data">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="restore" />
							<div class="row clearfix">
								<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
									<h4>Selecione o arquivo de backup do Sistema PBXERIX</h4>
								</div>
								<div class="col-sm-12 col-md-6">
									<div class="form-group form-float" style="margin-bottom:0px">
										<div class="form-line">
											<input name="arquivo" type="file" class="form-control" />
										</div>
									</div>
								</div>
								<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
									<Button id="btnSubmit" type="submit" class="btn btn-primary waves-effect">
										<i class="material-icons">restore</i>
										<span>RESTAURAR BACKUP</span>
									</Button>
								</div>
							</div>
						</form>
						<!--FIM FORMULÁRIO-->

					</div>
				</div>
			</div>
			<!-- #END# Bloco Pesquisa -->
		</div>
	</div>
	<!--FIM - PAGE CONTENT-->

<script>

	$(document).ready(function() {
		$("#btnBackup").click(function() {
			//document.location.assign("?pagina=sistema&menu=backup&cmd=backup&tipo=download");
			document.location.assign("/backup.download.php");
			//window.open("url", "_blank");
		});
	});

</script>