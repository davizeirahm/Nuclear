<?php

?>

<style>

	.console { 
		position: relative;
		height: calc(100vh - 140px);
		background-color: #000000;
		color : #FFFFFF;
		font: 12px/18px "Lucida Console";
		overflow: auto;
		text-align:left; /* "rem dio" para o hack do IE */ 
	}
	
	.ipt-console {
		width: 87%;
		border : 0px;
		-moz-border-radius:0px;
		-webkit-border-radius:0px;
		border-radius:0px;
		background-color: #000000;
		color : #FFFFFF;
		font: 12px/18px "Lucida Console";
	}
		
	.ipt-console:focus{
		outline: 0;
	}

</style>

	<!--PAGE CONTENT-->
	<div class="container-fluid">
		<div class="row clearfix">
			<!-- Bloco Pesquisa -->
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<div class="card">
					<div class="row clearfix">
						<div class="col-xs-12 col-sm-6">
							<ol class="breadcrumb">
								<li>NUCLEAR PABX IP</li>
								<li><?=$pagina_nome;?></li>
								<li class="active"><?=$menu_nome;?></li>				
							</ol>
						</div>
					</div>
					<div class="body" style="padding-bottom: 5px;">
						<div class="row clearfix console" id="console1">
							<div class="col-sm-12" style="margin: 0px;">
								<div id="console-text">
						
								</div>
								<div class="row clearfix">
								<form name="form-command" id="form-command"  autocomplete="off">
									<div class="col-md-2 col-sm-3 col-xs-5" style="margin: 0px;">
										<label for="command">PBXERIX@<?=$_SESSION["nome"];?>:#></label>
									</div>
									<div class="col-md-10 col-sm-9 col-xs-7" style="margin: 0px;">
										<input type="text" name="command" id="command" class="ipt-console">
									</div>
								</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- #END# Bloco Pesquisa -->
		</div>
	</div>
	<!--FIM - PAGE CONTENT-->

<script>

	$(function() {
	
		$("#command").focus();
		
		$("#console1").click(function() {
			$("#command").focus();
		});
		
		$("#form-command").submit(function(event) {
			event.preventDefault();
			
			var rsult = $("#command").val();
			
			if ($("#command").val() !== "") {
				
				if(rsult === "cls") {
					$("#console-text").html("");
					$("#command").val("");
					return;
				}
				
				$.ajax({
				
					url: '/pages/sistema/console.source.php',
					type: 'post',
					data : {
						cmd : $("#command").val()
					},
					success: function(msg) {
						$("#console-text").append("<p>"+msg+"</p>");	
						var scltop = $( "#console-text" ).height();
				
						$( "#console1" ).scrollTop( scltop ); 
					},
					error : function(error) {
					
					}
				});
				
				
				$("#console-text").append("<p>PBXERIX@<?=$_SESSION["nome"];?>:#> "+$("#command").val()+"</p>");
				
			} else { 
				$("#console-text").append("<p>PBXERIX@<?=$_SESSION["nome"];?>:#></p>");
			}

			$("#command").val("");
			var scltop = $( "#console-text" ).height();
				
			$( "#console1" ).scrollTop( scltop ); 
			
		});
	
	});
</script>