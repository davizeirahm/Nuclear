<?php
	
	require_once("../../config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.network.debian7.php");
	
	$ids = $_REQUEST['listids'];

	$expIds = explode(";",$ids);
	
	$tmp = parse_interface("/etc/network/interfaces");
	
	foreach ($expIds as $key=>$value) {
		unset($tmp[$value]);
		shell_exec("sudo /sbin/ifconfig ".$value." down");	
	}
	
	$success = salvar_interface($tmp, "/etc/network/interfaces");

	if (!$success) {
		print "Erro! Não foi possível remover os aliases selecionados.";

	} else {
		print "Configurações de redes salvas com sucesso!";
	}
	
?>