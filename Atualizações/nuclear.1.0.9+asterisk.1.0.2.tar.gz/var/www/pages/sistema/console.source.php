<?php
 
	include("../../funcoes/funcoes.console.php");

	$cmd = (isset($_REQUEST['cmd']))?$_REQUEST['cmd']:"";
	
	$ast = new AstMan();
	
	$result = $ast->login();
			
	if(!$result) {
		print "Erro de conexão com PBXErix";
	} else {
		$sends = $ast->Query("Action: command\r\ncommand: ".$cmd."\r\n\r\n");
		if (!$sends) {
			print "Erro de conexão com PBXErix";
		} else {
			print str_replace(PHP_EOL, "<BR>", $sends);
		}
	}
	
?>