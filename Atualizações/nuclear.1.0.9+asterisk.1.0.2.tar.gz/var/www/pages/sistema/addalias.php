<?php

	require_once("../../config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.network.debian7.php");

	$aliasinterface = $_REQUEST['aliasinterface'];
	$aliasip	= $_REQUEST['aliasip'];
	$aliasmask	= $_REQUEST['aliasmask'];

	if ( !validate_ip($aliasip) ) {
		print "Erro: IP Inválido!";
		die();
	}
	if ( !validate_netmask($aliasmask) ) {
		print "Erro: Mascara de rede Inválida!";
		die();
	}
	
	
	$tmp = parse_interface("/etc/network/interfaces");
	
	
	$tmp[$aliasinterface] = array(
				"TIPO" 	 => "static",
				"address" => $aliasip,
				"netmask" => $aliasmask,
				"gateway" => ""
			);
	
	
	$sucess = salvar_interface($tmp, "/etc/network/interfaces");	
	
	if (!$sucess) {
		print "Erro ao tentar salvar as alterações!";
	} else {
		shell_exec("sudo /sbin/ifconfig ".$aliasinterface." ".$aliasip." netmask ".$aliasmask);
		print "Configurações de redes salvas com sucesso!";
	}

?>