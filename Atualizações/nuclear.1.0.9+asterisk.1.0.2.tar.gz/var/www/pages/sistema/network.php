<?php
	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.sistema.network.php");
	require_once(DIR_WWW."funcoes/funcoes.network.php");
	require_once(DIR_WWW."funcoes/funcoes.network.debian7.php");
	require_once(DIR_WWW."funcoes/funcoes.network.rotas.php");


	if (isset($_POST['cmd']) && $_POST['cmd'] == "novarota") {
		//[rota_address] => 192.168.200.20 [rota_mask] => 255.255.255.255 [rota_gw] => 192.168.70.10

		$erro = "";
		if ( !validate_ip($_POST['rota_address']) ) {
			$erro = "Erro: Endereço Inválido!";
		}
		if ( !validate_netmask($_POST['rota_mask']) ) {
			$erro = "Erro: Mascara Inválida!";
		}
		if ( !validate_gateway($_POST['rota_gw']) ) {
			$erro = "Erro: Gateway Inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}

		if ( !nova_rota($_POST['rota_address'], $_POST['rota_mask'], $_POST['rota_gw']) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				   </script>";
			die();
		} else {
			print "<script>
					alert('Configurações de rotas salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				   </script>";
			die();
		}

	} elseif (isset($_POST['cmd']) && $_POST['cmd'] == "editarrota") {
		//[rota_id] => 1 [rota_ativo] => on [rota_address] => 60.60.50.50 [rota_mask] => 255.255.255.255 [rota_gw] => 192.168.70.250
		//[rota_id] => 0 [rota_address] => 50.50.50.50 [rota_mask] => 255.255.255.255 [rota_gw] => 192.168.70.250

		$erro = "";
		if ( !validate_ip($_POST['rota_address']) ) {
			$erro = "Erro: Endereço Inválido!";
		}
		if ( !validate_netmask($_POST['rota_mask']) ) {
			$erro = "Erro: Mascara Inválida!";
		}
		if ( !validate_gateway($_POST['rota_gw']) ) {
			$erro = "Erro: Gateway Inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}

		if ( isset($_POST['rota_ativo']) ) {
			$ativo = 1;
		} else {
			$ativo = 0;
		}
		$rota_id = $_POST['rota_id'];

		if ( !editar_rota($rota_id, $ativo, $_POST['rota_address'], $_POST['rota_mask'], $_POST['rota_gw']) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				   </script>";
			die();
		} else {
			print "<script>
					alert('Configurações de rotas salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				   </script>";
			die();
		}
	} elseif (isset($_POST['cmd']) && $_POST['cmd'] == "excluirrota") {

		if (isset($_POST['rota_id'])) {
			$rota_id = $_POST['rota_id'];

			if ( !excluir_rota($rota_id) ) {
				print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
					</script>";
				die();
			} else {
				print "<script>
					alert('Configurações de rotas salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
					</script>";
				die();
			}
		}
	}
	
	//instancia a classe erixNetwork
	$erixNet = new erixNetwork();
	$arrEths = $erixNet->obter_interfaces_red();
	//print_r($arrEths);
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "salvarnetwork") {
		
		//salva dns e hostname
		
		$exec1 = shell_exec("sudo /bin/hostname ".$_POST['rede_hostname']);
		$exec2 = shell_exec("echo 'nameserver ".$_POST['rede_dns1'].PHP_EOL."nameserver ".$_POST['rede_dns2']."' > /etc/resolv.conf");
		
		$exec4 = shell_exec("sudo /root/scripts/hostname.sh ".$_POST['rede_hostname']);
		
		alterar_hostname($_POST['rede_hostname']);
		
		print "<script type='text/javascript'>
			alert('Configurações de Redes do sistema foram salvas com sucesso!');
			document.getElementById('form_{$pagina}_{$menu}').submit();
		</script>"; 
		
	} elseif (isset($_POST['cmd']) && $_POST['cmd'] == "salvarinterface") {
		//salva as interfaces
		$id   = $_POST["id_interface"];
		//$type = @$_POST["radio"];
		$ip   = @$_POST["endereco_ip"];
		$mask = @$_POST["mask_ip"];
		$gateway = @$_POST["gateway_ip"];


		$erro = "";
		if ( !validate_ip($ip) ) {
			$erro = "Erro: IP Inválido!";
		}
		if ( !validate_netmask($mask) ) {
			$erro = "Erro: Mascara de rede Inválida!";
		}
		if ( !validate_gateway($gateway) and $gateway != "") {
			$erro = "Erro: Gateway Inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}


		$tmp = parse_interface("/etc/network/interfaces");
		
		if (!isset($_POST["radio"])) {
			$type = "static";
		} 
		
		$tmp[$id] = array(
			"TIPO" 	 => $type,
			"address" => $ip,
			"netmask" => $mask,
			"gateway" => $gateway
		);
		
		
		$sucess = salvar_interface($tmp, "/etc/network/interfaces");
		if (!$sucess) {
			print "<br><b>ERRO:</b> Não foi possível configurar a Interface de rede ".$_GET['id']."<br>";
			
			exit () ; //morre por aqui
		} else {

			shell_exec("sudo /sbin/ifconfig ".$id." down");
			shell_exec("sudo /sbin/ifconfig ".$id." ".$ip." netmask ".$mask);

			if (strlen($gateway) > 0) {
				shell_exec("sudo /sbin/route add default gw ".$gateway);
			}

			print "<center><img src=\"images/loading.gif\" border=\"0\" /></center>";

			print "<script>
				setInterval(function() {
					document.getElementById('form_{$pagina}_{$menu}').submit();
				}, 2000);
			</script>";
			
			die();
		}
	} 
	
	//CAPTURANDO AS INFORMAÇÕES DE REDE =====================================================================================================
	$arrNetwork = $erixNet->obter_configuracoes_red();
	
	$dns1 		= isset($arrNetwork['dns'][0])?$arrNetwork['dns'][0]:'';
	$dns2 		= isset($arrNetwork['dns'][1])?$arrNetwork['dns'][1]:'';
	
	$hostname 	= isset($arrNetwork['host'])?$arrNetwork['host']:'';
	$gateway 	= isset($arrNetwork['gateway'])?$arrNetwork['gateway']:'';
	


	//CAPTURANDO AS INFORMAÇÕES DE INTERFACES 
	$count = count($arrEths);

	$tmp = parse_interface("/etc/network/interfaces");

	foreach ($tmp as $iface=>$value1) {
		foreach ($arrEths as $ifconf=>$value2) {
			if ($iface == $ifconf) {
				$arrEths[$ifconf]['gateway'] = $value1['gateway'];
			}
		}
	}

	//ROTAS =================================================================================================================================
	$rotas = get_rotas();
	//Array ( [0] => Array ( [ativo] => 0 [rota] => 50.50.50.50 [mask] => 255.255.255.255 [gw] => 192.168.70.250 ) )

	

?>

	<form style="margin-block-end: 0em" id="form_<?=$pagina;?>_<?=$menu;?>" method="POST" action="./">
		<input type="hidden" name="pagina" value="<?=$pagina;?>">
		<input type="hidden" name="pagina_nome" value="<?=$pagina_nome;?>">
		<input type="hidden" name="menu" value="<?=$menu;?>">
		<input type="hidden" name="menu_nome" value="<?=$menu_nome;?>">
	</form>

	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- Bloco Pesquisa -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
                                	<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
						</div>
                        <div class="body" style="padding-bottom: 5px;">
                            <!--Formulário-->
			    <form id="filtro-user" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="salvarnetwork" />
			    <div class="row clearfix">
				<div class="col-sm-6">
				    <div class="form-group form-float" style="margin-bottom:0px">
					<div class="form-line">
					    <input name="rede_hostname" id="rede_hostname" type="text" class="form-control" <?=(@$hostname?'value="'.$hostname.'"':"");?> />
					    <label class="form-label">Hostname</label>
					</div>
				    </div>
				</div>
			    </div>
			    <div class="row clearfix demo-masked-input">
				<div class="col-sm-6">
				    <div class="form-group form-float" style="margin-bottom:0px">
					<div class="form-line">
					    <input name="rede_dns1" id="rede_dns1" type="text" class="form-control ip" <?=(@$dns1?'value="'.$dns1.'"':"");?> />
					    <label class="form-label">DNS Primário</label>
					</div>
				    </div>
				</div>
				<div class="col-sm-6">
				    <div class="form-group form-float" style="margin-bottom:0px">
					<div class="form-line">
					    <input name="rede_dns2" id="rede_dns2" type="text" class="form-control ip" <?=(@$dns2?'value="'.$dns2.'"':"");?> />
					    <label class="form-label">DNS Secundário</label>
					</div>
				    </div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="margin-bottom: 0px;">
				    <button id="btnSubmit" type="submit" class="btn btn-primary waves-effect pull-right">
                                    	<i class="material-icons">save</i>
                                    	<span>SALVAR</span>
                                    </button>
				</div>
			    </div>
			    </form>
			    <!--FIM FORMULÁRIO-->

                        </div>
                    </div>
                </div>
                <!-- #END# Bloco Pesquisa -->
            </div>


	    <!--INTERFACES DE REDE - Table-->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
			<div class="header">
                            <h2>Interfaces de Rede</h2>
                        </div>
                        <div class="body">

			    <div class="row clearfix">
				<div class="col-xs-12 col-sm-6 col-md-3 col-lg-2" style="margin-bottom: 0px;">
					<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novoAliasModal">
						<i class="material-icons">add_circle</i>
						<span>NOVO ALIAS</span>
					</button>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-3 col-lg-2" style="margin-bottom: 0px;">
					<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#removerAliasModal">
						<i class="material-icons">delete_forever</i>
						<span>REMOVER ALIAS</span>
					</button>
				</div>
			    </div>

                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination3">
                                    <thead>
                                        <tr>
                                            <th>Device/Alias</th>
					    <th>IP</th>
					    <th>Mask</th>
					    <th>Status</th>
					    <th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
			if ($count > 0) {
				foreach ($arrEths as $idEth=>$value) {
					$rodando = ($value['Running']=="Yes" ? "<font color=green>Connectado</font>" : "<font color=red>Desconectado</font>");
?>
					<tr>
						<td><?=$value['Name'];?></td>
						<td><?=$value['Inet Addr'];?></td>
						<td><?=$value['Mask'];?></td>
						<td><?=$rodando;?></td>
						<td>
						<?php
							if ($value['Name'] != "Loopback") {
						?>
							<a href="javascript:;" class="play" onclick="botaoEditar('<?=$idEth;?>', '<?=$value['Inet Addr'];?>', '<?=$value['Mask'];?>', '<?=$value['gateway'];?>')"><i class="material-icons" title="Editar">edit</i></a>
						<?php
							}
						?>
						</td>
					</tr>
<?php
				}
			}
?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# INTERFACES DE REDE - Table -->





	    <!--ROTAS - Table-->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
			<div class="header">
                            <h2>Rotas Estáticas</h2>
                        </div>
                        <div class="body">

			    <div class="row clearfix">
				<div class="col-xs-12 col-sm-6 col-md-3 col-lg-2" style="margin-bottom: 0px;">
					<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novoRotaModal">
						<i class="material-icons">add_circle</i>
						<span>NOVA ROTA</span>
					</button>
				</div>
			    </div>

                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination3">
                                    <thead>
                                        <tr>
                                            <th>Status</th>
					    <th>Endereço</th>
					    <th>Mask</th>
					    <th>Gateway</th>
					    <th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
			if (isset($rotas[0]['ativo'])) {
				foreach ($rotas as $key=>$value) {
					$status = ($value['ativo']==1 ? "<font color=green>Ativo</font>" : "<font color=red>Inativo</font>");
?>
					<tr>
						<td><?=$status;?></td>
						<td><?=$value['address'];?></td>
						<td><?=$value['mask'];?></td>
						<td><?=$value['gw'];?></td>
						<td>
							<a href="javascript:;" class="play" onclick="botaoEditarRota('<?=$key;?>', '<?=$value['ativo'];?>', '<?=$value['address'];?>', '<?=$value['mask'];?>', '<?=$value['gw'];?>')"><i class="material-icons" title="Editar">edit</i></a>
							<a href="javascript:;" class="play" onclick="botaoExcluirRota('<?=$key;?>')"><i class="material-icons" title="Apagar">delete</i></a>
						</td>
					</tr>
<?php
				}
			}
?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# ROTAS - Table -->



	</div>
	<!--#END of PAGE CONTENT-->


	    <!-- Modal Dialogs ====================================================================================================================== -->

            <!--MODAL NOVO ALIAS-->
            <div class="modal fade" id="novoAliasModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Novo Alias</h4>
                        </div>
                        <div class="modal-body">
			    <div class="demo-masked-input">
				<input type="hidden" name="alias_id" id="alias_id">
				</br></br>

				<div class="row clearfix">
				    <div class="col-sm-3">
					<p><b>Nome do Alias</b></p>
				    </div>
				    <div class="col-sm-9">
					<div class="form-group form-float">
					    <select name="alias_interface" id="alias_interface" class="form-control show-tick">
                                        	<option>eth0:0</option>
                                        	<option>eth0:1</option>
                                        	<option>eth0:2</option>
						<option>eth0:3</option>
						<option>eth0:4</option>
						
						<option>eth1:0</option>
						<option>eth1:1</option>
						<option>eth1:2</option>
						<option>eth1:3</option>
						<option>eth1:4</option>

						<option>eth2:0</option>
						<option>eth2:1</option>
						<option>eth2:2</option>
						<option>eth2:3</option>
						<option>eth2:4</option>

						<option>eth3:0</option>
						<option>eth3:1</option>
						<option>eth3:2</option>
						<option>eth3:3</option>
						<option>eth3:4</option>
                                    	    </select>
					</div>
				    </div>

                                    <div class="col-sm-12">
					<div class="form-group form-float">
						<div class="form-line">
							<input name="alias_ip" id="alias_ip" type="text" class="form-control ip" />
							<label class="form-label">Endereço de IP</label>
						</div>
					</div>
				    </div>

				    <div class="col-sm-12">
					<div class="form-group form-float" style="margin-bottom:0px">
						<div class="form-line">
							<input name="alias_mask" id="alias_mask" type="text" class="form-control ip" />
							<label class="form-label">Mascara</label>
						</div>
					</div>
				    </div>
                                </div>
			    </div>
                        </div>
                        <div class="modal-footer">
			    <button type="button" onclick="novoAlias()" class="btn btn-primary waves-effect">
				<i class="material-icons">save</i>
				<span>Salvar</span>
			    </button>
                            <button type="button" id="closeNovoAliasModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>

                    </div>
                </div>
            </div>
	    <!--#END of MODAL NOVO ALIAS-->




            <!--MODAL EDITAR ALIAS-->
            <div class="modal fade" id="editarAliasModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="editarAliasLabel">Editar Interface - </h4>
                        </div>
                        <div class="modal-body">
			    <div class="demo-masked-input">
			    <form id="formEditarAlias" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="salvarinterface" />
				<input type="hidden" id="interface_editarIface" name="id_interface" value="" />

				<div class="row clearfix">
                                    <div class="col-sm-3 col-xs-5 form-control-label">
                                        <label for="ip_editarIface">Endereço de IP</label>
                                    </div>
                                    <div class="col-sm-9 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="endereco_ip" id="ip_editarIface" class="form-control ip">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row clearfix">
                                    <div class="col-sm-3 col-xs-5 form-control-label">
                                        <label for="mask_editarIface">Máscara</label>
                                    </div>
                                    <div class="col-sm-9 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="mask_ip" id="mask_editarIface" class="form-control ip">
                                            </div>
                                        </div>
                                    </div>
                                </div>
				<div class="row clearfix">
                                    <div class="col-sm-3 col-xs-5 form-control-label">
                                        <label for="gateway_editarIface">Gateway</label>
                                    </div>
                                    <div class="col-sm-9 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="gateway_ip" id="gateway_editarIface" class="form-control ip">
                                            </div>
                                        </div>
                                    </div>
                                </div>
			     </div>
                        </div>
                        <div class="modal-footer">
			    <button type="submit" class="btn btn-primary waves-effect">
				<i class="material-icons">save</i>
				<span>SALVAR</span>
			    </button>
                            <button type="button" id="closeEditarAliasModal" class="btn btn-link waves-effect" data-dismiss="modal">CANCELAR</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EDITAR ALIAS-->




	    <!--MODAL REMOVER ALIAS-->
            <div class="modal fade" id="removerAliasModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Remover Alias</h4>
                        </div>
                        <div class="modal-body">

				<input type="hidden" name="alias_id" id="alias_id">
				</br></br>

				<p><b>Marque os Alias que você deseja remover</b></p>

				<div class="row clearfix">
					<div class="demo-checkbox">
				    
				<?php
					foreach($arrEths as $idEth=>$value) {
						if (isAlias($idEth)) {
				?>
							<input type="checkbox" name="<?=$idEth;?>" id="<?=$idEth;?>" value="<?=$idEth;?>" class="filled-in marcar" />
							<label for="<?=$idEth;?>"><?=$idEth;?></label>
							<br>
				<?php
						}
					}
				?>
					</div>
                                </div>
                        </div>
                        <div class="modal-footer">
			    <button type="button" onclick="removerAlias()" class="btn btn-primary waves-effect">
				<i class="material-icons">save</i>
				<span>Salvar</span>
			    </button>
                            <button type="button" id="closeRemoverAliasModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>

                    </div>
                </div>
            </div>
	    <!--#END of MODAL REMOVER ALIAS-->

	    <!-- MODAL ROTAS ====================================================================================================================== -->

            <!--MODAL NOVA ROTA-->
            <div class="modal fade" id="novoRotaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Nova Rota</h4>
                        </div>
                        <div class="modal-body">
			    <div class="demo-masked-input">
			    <form id="formNovoRota" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="novarota" />

				</br></br>

				<div class="row clearfix">

                                    <div class="col-sm-12">
					<div class="form-group form-float">
						<div class="form-line">
							<input name="rota_address" id="rota_address" type="text" class="form-control ip" />
							<label class="form-label">Endereço</label>
						</div>
					</div>
				    </div>

				    <div class="col-sm-12">
					<div class="form-group form-float">
						<div class="form-line">
							<input name="rota_mask" id="rota_mask" type="text" class="form-control ip" />
							<label class="form-label">Mascara</label>
						</div>
					</div>
				    </div>

				    <div class="col-sm-12">
					<div class="form-group form-float" style="margin-bottom:0px">
						<div class="form-line">
							<input name="rota_gw" id="rota_gw" type="text" class="form-control ip" />
							<label class="form-label">Gateway</label>
						</div>
					</div>
				    </div>
                                </div>
			    </div>
                        </div>
                        <div class="modal-footer">
			    <button type="submit" class="btn btn-primary waves-effect">
				<i class="material-icons">save</i>
				<span>Salvar</span>
			    </button>
                            <button type="button" id="closeNovoRotaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL NOVA ROTA-->



	    <!--MODAL EDITAR ROTA-->
            <div class="modal fade" id="editarRotaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Editar Rota</h4>
                        </div>
                        <div class="modal-body">
			    <div class="demo-masked-input">
			    <form id="formEditarRota" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="editarrota" />
				<input type="hidden" name="rota_id" id="editarRota_id">
				</br></br>

				<div class="row clearfix">

				    <div class="col-sm-12">
					<div class="demo-checkbox">
					    <input type="checkbox" name="rota_ativo" id="editarRota_ativo" />
					    <label for="editarRota_ativo">Ativo</label>
					</div>
				    </div>

                                    <div class="col-sm-3 col-xs-5 form-control-label">
                                        <label for="editarRota_address">Endereço</label>
                                    </div>
                                    <div class="col-sm-9 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="rota_address" id="editarRota_address" class="form-control ip">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-3 col-xs-5 form-control-label">
                                        <label for="editarRota_mask">Mascara</label>
                                    </div>
                                    <div class="col-sm-9 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="rota_mask" id="editarRota_mask" class="form-control ip">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-3 col-xs-5 form-control-label">
                                        <label for="editarRota_gw">Gateway</label>
                                    </div>
                                    <div class="col-sm-9 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="rota_gw" id="editarRota_gw" class="form-control ip">
                                            </div>
                                        </div>
                                    </div>

                                </div>
			    </div>
                        </div>
                        <div class="modal-footer">
			    <button type="submit" class="btn btn-primary waves-effect">
				<i class="material-icons">save</i>
				<span>Salvar</span>
			    </button>
                            <button type="button" id="closeEditarRotaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EDITAR ROTA-->



	    <!--MODAL EXCLUIR ROTA-->
            <div class="modal fade" id="excluirRotaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Excluir Rota</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirUsuario" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="excluirrota" />
				<input type="hidden" name="rota_id" id="excluirRota_id">
			    <p>Tem certeza que deseja excluir a rota?</p>
                        </div>
                        <div class="modal-footer">
			    <button type="submit" class="btn btn-danger waves-effect">
				<i class="material-icons">delete</i>
				<span>Sim</span>
			    </button>
                            <button type="button" id="closeExcluirRotaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR ROTA-->


<script>

	function novoAlias() {
		$.ajax({
			url: '/pages/sistema/addalias.php',
			type: 'POST',
			data: {
				aliasinterface:	$("#alias_interface").val(),
				aliasip:	$("#alias_ip").val(),
				aliasmask:	$("#alias_mask").val(),
				aliasgateway:	$("#alias_gateway").val()	
			},			
			success: function (resposta) {
				alert(resposta);
				document.getElementById('form_<?=$pagina;?>_<?=$menu;?>').submit();
			},
			error: function (errormsg) {
				$("#novoAliasModal" ).modal('hide');
			}
		});
	}

	function botaoEditar(editar_interface, editar_ip, editar_mask, editar_gateway){

		$('#interface_editarIface').val(editar_interface);
		$('#ip_editarIface').val(editar_ip);
		$('#mask_editarIface').val(editar_mask);
		if (editar_gateway == "") {
			$('#gateway_editarIface').prop('disabled', 'disabled');
		} else {
			$('#gateway_editarIface').prop('disabled', false);
		}
		$('#gateway_editarIface').val(editar_gateway);

		$('#editarAliasLabel').text("Editar Interface "+editar_interface);
		$("#editarAliasModal").modal();
	};

	function removerAlias() {

		var bValid = true;
				
		var varlistids = "";

		$(".marcar").each(function(index) {
			if ($(this).is(':checked')) {
				if (varlistids != "") {
					varlistids = varlistids+";";
				}
				varlistids = varlistids + $(this).attr('id');
			}
		});
		
		bValid = (varlistids != "" && bValid); 
				
		if ( bValid ) {
			$.ajax ({
				url: '/pages/sistema/delalias.php',
				type: "POST",
				data: {
					listids : varlistids
				},			
				success: function (resposta) {
					alert(resposta);
					document.getElementById('form_<?=$pagina;?>_<?=$menu;?>').submit();
				},
				error: function (errormsg) {
					$("#removerAliasModal" ).modal('hide');
				}
			});	
			$("#removerAliasModal" ).modal('hide');
		} else {
			alert("teste");
		}
	
	}

	//FUNÇÕES ROTAS

	function botaoEditarRota(editarRota_id, editarRota_ativo, editarRota_address, editarRota_mask, editarRota_gw) {

		$('#editarRota_id').val(editarRota_id);

		if (editarRota_ativo == '1') {
			$('#editarRota_ativo').prop('checked',true);
		} else {
			$('#editarRota_ativo').prop('checked',false);
		}

		$('#editarRota_address').val(editarRota_address);
		$('#editarRota_mask').val(editarRota_mask);
		$('#editarRota_gw').val(editarRota_gw);

		$("#editarRotaModal").modal();
	};

	function botaoExcluirRota(excluirRota_id) {

		$('#excluirRota_id').val(excluirRota_id);
		$("#excluirRotaModal").modal();
	}

</script>
