<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.network.debian7.php");

?>

	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- Bloco Pesquisa -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
                                	<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
						</div>
                        <div class="body" style="padding-bottom: 5px;">

							<div class="row clearfix">
								<div class="col-xs-12 col-sm-6 col-md-3 col-lg-2" style="margin-bottom: 0px;">
									<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novaRegraModal">
										<i class="material-icons">add_circle</i>
										<span>NOVA REGRA</span>
									</button>
								</div>
							</div>

                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination3">
                                    <thead>
                                        <tr>
                                            <th>Rede</th>
											<th>Permissões</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
			if ( isset($linhas[0]) ) {
				foreach ($linhas as $key=>$value) {
?>
					<tr>
						<td><?=$value[''];?></td>
						<td><?=$value[''];?></td>
						<td>
							<a href="javascript:;" class="play" onclick="botaoEditar('<?=$key;?>', '<?=$value[''];?>', '<?=$value[''];?>', '<?=$value[''];?>')"><i class="material-icons" title="Editar">edit</i></a>
							<a href="javascript:;" class="play" onclick="botaoExcluir('<?=$key;?>')"><i class="material-icons" title="Apagar">delete</i></a>
						</td>
					</tr>
<?php
				}
			}
?>
                                    </tbody>
                                </table>
                            </div>


                        </div>
                    </div>
                </div>
                <!-- #END# Bloco Pesquisa -->
            </div>
