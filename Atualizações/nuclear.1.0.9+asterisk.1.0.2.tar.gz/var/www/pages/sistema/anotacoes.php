<?php

	require_once("config/inc_fileconf.php");

	$file = file(ARQ_ANOTACOES_CONF);
	
	$txt = "";
	
	foreach ($file as $key=>$value) {
		$txt .= $value.PHP_EOL;
	}
	
	$cmd = (isset($_REQUEST["cmd"]))?$_REQUEST["cmd"]:"";
	
	if ($cmd == "salvar") {
		$txt = $_POST["txt"];
		
		if (!file_put_contents(ARQ_ANOTACOES_CONF, $txt)) {
			print "<script> 
				alert('Não foi possível salvar as alterações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();					
			</script>";
			die();
		}
		
		print "<script> 
				alert('Anotações Salvas com Sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";	
		die();
	}

?>

	<!--PAGE CONTENT-->
	<div class="container-fluid">
		<div class="row clearfix">
			<!-- Bloco Pesquisa -->
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<div class="card">
					<div class="row clearfix">
						<div class="col-xs-12 col-sm-6">
							<ol class="breadcrumb">
								<li>NUCLEAR PABX IP</li>
								<li><?=$pagina_nome;?></li>
								<li class="active"><?=$menu_nome;?></li>
							</ol>
						</div>
					</div>
					<div class="body" style="padding-bottom: 5px;">
						<div class="row clearfix">
						<form name="form_txt" id="form_txt" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="salvar"/>
							<textarea name="txt" id="txt" title=""><?=$txt;?></textarea>
						</form>
						</div>
					</div>
				</div>
			</div>
			<!-- #END# Bloco Pesquisa -->
		</div>
	</div>
	<!--FIM - PAGE CONTENT-->


    <!-- TinyMCE -->
    <script src="plugins/tinymce/tinymce.js"></script>

<script>

$(function () {
	//TinyMCE
	tinymce.init({
		language : 'pt_BR',
		selector: 'textarea',
		theme: 'modern',
		height: 340,
		plugins: 'save',
		toolbar1: 'save undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link',
		toolbar2: 'forecolor backcolor emoticons',
		save_enablewhendirty: true,
		save_onsavecallback: function() {
			$("#form_txt").submit();
			console.log("Save");
		}

	});
	tinymce.suffix = ".min";
	tinyMCE.baseURL = '/plugins/tinymce';
});

</script>