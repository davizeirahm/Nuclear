<?php
	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.sistema.informacoes.php");
	require_once(DIR_WWW."funcoes/funcoes.config.usuarios.php");

	//VERSAO ASTERISK
	$version_asterisk = printini(ARQ_VERSION_ASTERISK, "version", "asterisk");

	//FUNCOES
	$arrMem = InfoMemoria();
	$arrDisco = InfoDisco();

	include_once(DIR_WWW."funcoes/funcoes.network.php");
	
	//instancia a classe erixNetwork
	$erixNet = new erixNetwork();
	$eths = $erixNet->obter_interfaces_red();
	$ip = $eths['eth0']['Inet Addr'];

	$statusServicos = statusServicos();

	$hardware = hardware();
	
	
	//REDEFINIR SENHA ===================================================
	if (isset($_POST['cmd']) && $_POST['cmd'] == "redefinirSenha") {
		//print_r($_POST);
		//die();
		$erro = "";
		if (!isset($_SESSION['idusuario']) || @$_SESSION['idusuario'] == "") {
			$erro = "Erro: Usuário inválido!";
		}
		if (!isset($_POST['senha']) || @$_POST['senha'] == "") {
			$erro = "Erro: Senha inválida!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.location.assign('?pagina=inicial');
			</script>";
			die();
		}
		
		if ( !alter_secret_user($_SESSION["idusuario"],$_SESSION["nome"],$_POST['senha']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.location.assign('?pagina=sistema&menu=informacoes');
			</script>";
			die();
		} else {
			$_SESSION["senha_padrao"] = "";
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.location.assign('?pagina=sistema&menu=informacoes');
			</script>";
			die();
		}
	}
	
?>

    <!--PAGE CONTENT-->
        <div class="container-fluid">

	    <!-- INFORMAÇÕES DO SISTEMA -->
            <div class="row clearfix">
                <!-- Bloco Padrão -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2>Informações do Sistema</h2>
                        </div>
                        <div class="body">
                            <table class="table">
                                <tbody>
                                    <tr>
                                        <td>Interface versão</td>
										<td><?=$version;?></td>
                                    </tr>
									<tr>
										<td>Pbxerix versão</td>
										<td><?=$version_asterisk;?></td>
									</tr>
                                    <tr>
                                        <td>Nome do Host</td>
										<td><?=GetHostName();?></td>
                                    </tr>
                                    <tr>
                                        <td>Endereço de IP</td>
										<td><?=$ip;?></td>
                                    </tr>
                                    <tr>
                                        <td>Versão do Kernel</td>
										<td><?=VersaoKernel();?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- #END# Bloco Padrão -->
            </div>
	    <!-- #END - INFORMAÇÕES DO SISTEMA -->

	    <!-- HD E MEMÓRIA -->
            <div class="row clearfix">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                    <div class="card">
                        <div class="header">
                            <h2>Uso de Memória</h2>
                        </div>
                        <div class="body">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th width="10%">TIPO</th>
                                        <th>PERCENTUAL</th>
                                        <th>LIVRE</th>
										<th>EM USO</th>
										<th>TOTAL</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th scope="row">Memória</th>
                                        <td>
					    <div class="progress">
						<div class="progress-bar" role="progressbar" aria-valuenow="<?=$arrMem['mem']['perc'];?>" aria-valuemin="0" aria-valuemax="100" style="width: <?=$arrMem['mem']['perc'];?>%;">
						    <?=$arrMem['mem']['perc'];?>%
						</div>
					    </div>
					</td>
					<td width="10%"><?=round($arrMem['mem']['livre'] / 1024, 2)." GiB";?></td>
					<td width="10%"><?=round($arrMem['mem']['emuso'] / 1024, 2)." GiB";?></td>
					<td width="10%"><?=round($arrMem['mem']['total'] / 1024, 2)." GiB"; ?> 
                                    </tr>
                                    <tr>
                                        <th scope="row">Swap</th>
                                        <td>
					    <div class="progress">
						<div class="progress-bar" role="progressbar" aria-valuenow="<?=$arrMem['swap']['perc'];?>" aria-valuemin="0" aria-valuemax="100" style="width: <?=$arrMem['swap']['perc'];?>%;">
						    <?=$arrMem['swap']['perc'];?>%
						</div>
					    </div>
					</td>
					<td width="10%"><?=round($arrMem['swap']['livre'] / 1024, 2)." GiB";?></td>
					<td width="10%"><?=round($arrMem['swap']['emuso'] / 1024, 2)." GiB";?></td>
					<td width="10%"><?=round($arrMem['swap']['total'] / 1024, 2)." GiB"; ?> 
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                    <div class="card">
                        <div class="header">
                            <h2>Uso de Disco</h2>
                        </div>
                        <div class="body">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th width="10%">MONTAGEM</th>
                                        <th>PERCENTUAL</th>
                                        <th>LIVRE</th>
                                        <th>EM USO</th>
                                        <th>TOTAL</th>
                                    </tr>
                                </thead>
                                <tbody>
<?php
				foreach ($arrDisco as $value) {
					if ($value['perc'] > 80) {
						$danger = "progress-bar-danger";
					} else {
						$danger = "";
					}
?>
                                    <tr>
                                        <td scope="row"><?=$value['ponto'];?></td>
										<td>
											<div class="progress">
											<div class="progress-bar <?=$danger;?>" role="progressbar" aria-valuenow="<?=$value['perc'];?>" aria-valuemin="0" aria-valuemax="100" style="width: <?=$value['perc'];?>;">
												<?=$value['perc'];?>
											</div>
											</div>
										</td>
                                        <td><?=$value['livre'];?> GiB</td>
                                        <td><?=$value['emuso'];?> GiB</td>
                                        <td><?=$value['total'];?> GiB</td>
                                    </tr>
<?php
				}
?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- #END# Bloco Padrão -->
            </div>
	    <!-- #END - HD E MEMÓRIA -->

	    <!-- OUTROS SISTEMAS -->
            <div class="row clearfix">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2>Status</h2>
                        </div>
                        <div class="body">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>SERVIÇO</th>
                                        <th>STATUS</th>
                                    </tr>
                                </thead>
                                <tbody>
<?php
									foreach ($statusServicos as $key=>$value) {
										if ($value == 0) {
											$text = 'WARNING!';
											$label = "label-danger";
										} else {
											$text = 'OK';
											$label = "label-success";
										}
?>
                                    <tr>
                                        <td><?=$key;?></th>
										<td>
											<span class="label <?=$label;?>"><?=$text;?></span>
										</td>
                                    </tr>
<?php
									}
?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
	    <!-- #END - OUTROS SISTEMAS -->

	    <!-- HARDWARE -->
            <div class="row clearfix">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2>Hardware</h2>
                        </div>
                        <div class="body">
                            <table class="table">
                                <tbody>
<?php
				foreach ($hardware as $key=>$value) {
?>
                                    <tr>
                                        <td><?=$key;?></th>
										<td><?=$value;?></td>
                                    </tr>
<?php
				}
?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
	    <!-- #END - HARDWARE -->

        </div>
    <!--#END of PAGE CONTENT-->
	
	
		<!--MODAL REDEFINIR SENHA-->
		<div class="modal fade" id="redefinirSenhaModal" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h2 class="modal-title" id="redefinirSenhaLabel">Redefinir Senha</h2>
						<small>Troque a senha padrão por uma mais segura, a senha deve ter pelo menos de 6 caracteres.</small>
					</div>
					<div class="modal-body">
						<div class="demo-masked-input">
						<form id="formRedefinirSenha" method="post">
						<!-- <input type="hidden" name="pagina" value="pbxconfig" /> -->
						<!-- <input type="hidden" name="menu" value="agentes" /> -->
						<input type="hidden" name="cmd" value="redefinirSenha" />

							<div class="row clearfix">
								<div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
									<label for="senha_redefinirSenha">Senha</label>
								</div>
								<div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
									<div class="form-group">
										<div class="form-line">
											<input type="password" name="senha" id="senha_redefinirSenha" class="form-control">
										</div>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
									<label for="confSenha_redefinirSenha">Confirmar Senha</label>
								</div>
								<div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
									<div class="form-group">
										<div class="form-line">
											<input type="password" name="confSenha" id="confSenha_redefinirSenha" class="form-control">
										</div>
									</div>
								</div>
							</div>
						</form>
						</div>
					</div>
					<div class="modal-footer">
						<button onclick="botaoRedefinirSenha();" class="btn btn-primary waves-effect">
							<i class="material-icons">save</i>
							<span>Salvar</span>
						</button>
						<button type="button" id="closeRedefinirSenhaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
					</div>
						
				</div>
			</div>
		</div>
	    <!--#END of MODAL REDEFINIR SENHA-->
	
	
<script>

	var senha_padrao = '<?=@$_SESSION["senha_padrao"];?>';

	function botaoRedefinirSenha() {
		if ( $("#senha_redefinirSenha").val() != $("#confSenha_redefinirSenha").val() ) {
			alert("Senha incorreta! Confira os dados");
		} else if ( $("#senha_redefinirSenha").val().length < 6) {
			alert("Senha deve possuir 6 ou mais caracteres!");
		} else {
			$("#formRedefinirSenha").submit();
		}
	}

	$(document).ready(function(){
		if (senha_padrao != '') {
			//Se a senha for padrao altera força a alteração de senha
			$("#redefinirSenhaModal").modal();
		}
	});

</script>