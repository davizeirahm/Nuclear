<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.network.debian7.php");
	require_once(DIR_WWW."funcoes/funcoes.sistema.geral_sip.php");


	if (isset($_POST['cmd']) && $_POST['cmd'] == "salvarhostip") {

		$erro = "";
		if (!isset($_POST['extern']) or !isset($_POST['host_ip']) or !isset($_POST['tcpenable']) or !isset($_POST['tcp_port']) ) {
			$erro = "Erro: 0x00000001";
		} elseif ($_POST['extern'] == "externip") {
			if ( !validate_ip($_POST['host_ip']) ) {
				$erro = "Erro: Endereço Inválido!";
			}
		} elseif ($_POST['extern'] == "externhost") {
			if ( !filter_var($_POST['host_ip'], FILTER_VALIDATE_URL) ){
				$erro = "Erro: Host Inválido!";
			}
		}
		if ($_POST['tcpenable'] != "yes" && $_POST['tcpenable'] != "no") {
			$erro = "Erro: Don't try me!";
		}
		if ( !is_numeric($_POST['tcp_port']) ) {
			$erro = "Erro: Porta inválida!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}

		if ( !salvar_tcp($_POST['tcpenable'], $_POST['tcp_port']) || !salvar_host_ip($_POST['extern'], $_POST['host_ip'])) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		} else {
			print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		}

	} elseif (isset($_POST['cmd']) && $_POST['cmd'] == "novolocalnet") {
		//print_r($_POST);
		//[pagina] => sistema [menu] => geral_sip [cmd] => novolocalnet [localnet_address] => 192.168.70.0 [localnet_mask] => 255.255.255.0
		$erro = "";
		if (!isset($_POST['localnet_address']) or !isset($_POST['localnet_mask']) ) {
			$erro = "00000010";
		} elseif ( !validate_ip($_POST['localnet_address']) ) {
			$erro = "Erro: Endereço Inválido!";
		} elseif ( !validate_netmask($_POST['localnet_mask']) ) {
			$erro = "Erro: Mascara Inválida!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}

		if ( !novo_localnet($_POST['localnet_address'], $_POST['localnet_mask']) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
			die();
		} else {
			print "<script>
					alert('Configurações de rotas salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
			die();
		}

	} elseif (isset($_POST['cmd']) && $_POST['cmd'] == "editarlocalnet") {
		//[localnet_id] => 4 [localnet_address] => 192.168.0.0 [localnet_mask] => 255.255.0.0

		$erro = "";
		if (!isset($_POST['localnet_id']) or !isset($_POST['localnet_address']) or !isset($_POST['localnet_mask']) ) {
			$erro = "00000011";
		} elseif ( !validate_ip($_POST['localnet_address']) ) {
			$erro = "Erro: Endereço Inválido!";
		} elseif ( !validate_netmask($_POST['localnet_mask']) ) {
			$erro = "Erro: Mascara Inválida!";
		} elseif ( !isInteger($_POST['localnet_id']) ) {
			$erro = "Erro: ID Inválida!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}

		if ( !editar_localnet($_POST['localnet_id'], $_POST['localnet_address'], $_POST['localnet_mask']) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
			die();
		} else {
			print "<script>
					alert('Configurações de rotas salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
			die();
		}

	} elseif (isset($_POST['cmd']) && $_POST['cmd'] == "excluirlocalnet") {
		//[localnet_id] => 4

		$erro = "";
		if (!isset($_POST['localnet_id']) ) {
			$erro = "00000100";
		} elseif ( !isInteger($_POST['localnet_id']) ) {
			$erro = "Erro: ID Inválida!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}

		if ( !excluir_localnet($_POST['localnet_id']) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
			die();
		} else {
			print "<script>
					alert('Configurações de rotas salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
			die();
		}
	}

	//DEFINIÇÃO DE VARIAVEIS =====================================================================================
	$localnets = get_sip_localnets();
	//Array ( [4] => Array ( [address] => 192.168.0.0 [mask] => 255.255.0.0 ) [5] => Array ( [address] => 192.168.70.0 [mask] => 255.255.255.0 ) )

	$extern = get_sip_extern();
	$host_ip = get_sip_host_ip();
	$tcpenable = get_tcpstatus();
	$tcp_port = get_tcpport();

?>
	
	<form style="margin-block-end: 0em" id="form_<?=$pagina;?>_<?=$menu;?>" method="POST" action="./">
		<input type="hidden" name="pagina" value="<?=$pagina;?>">
		<input type="hidden" name="pagina_nome" value="<?=$pagina_nome;?>">
		<input type="hidden" name="menu" value="<?=$menu;?>">
		<input type="hidden" name="menu_nome" value="<?=$menu_nome;?>">
	</form>

	<!--PAGE CONTENT-->
        <div class="container-fluid">

            <div class="row clearfix">
                <!-- Bloco Pesquisa -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
									<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
						</div>
                        <div class="body" style="padding-bottom: 5px;">
							<!--Formulário-->
			    <form id="filtro-user" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="salvarhostip" />

			    <div class="row clearfix demo-masked-input">
				<div class="col-sm-12 col-md-6">
					<p><b>Configuração de endereço externo</b></p>
					<div class="col-sm-12 col-md-6">
					    <select name="extern" id="extern" class="form-control show-tick">
							<option <?=(@$extern == "externhost"?'selected="selected"':"");?> >Extern Host</option>
							<option <?=(@$extern == "externip"?'selected="selected"':"");?> >Extern IP</option>
						</select>
					</div>
					<div class="col-sm-12 col-md-6">
						<div class="form-group form-float" style="margin-bottom:0px">
							<div class="form-line">
								<input name="host_ip" id="host_ip" type="text" class="form-control" <?=(@$host_ip?'value="'.$host_ip.'"':"");?> />
								<label class="form-label">Hostname ou IP</label>
							</div>
						</div>
					</div>
				</div>
				</div>
				<div class="row clearfix demo-masked-input">
				<div class="col-sm-12 col-md-6">
					<p><b>Configuração SIP TCP</b></p>
					<div class="col-sm-12 col-md-6">
					    <select name="tcpenable" id="tcpenable" class="form-control show-tick">
							<option value="yes" <?=(@$tcpenable == "yes"?'selected="selected"':"");?> >Ativado</option>
							<option value="no" <?=(@$tcpenable == "no"?'selected="selected"':"");?> >Desativado</option>
						</select>
					</div>
					<div class="col-sm-12 col-md-6">
						<div class="form-group form-float" style="margin-bottom:0px">
							<div class="form-line">
								<input name="tcp_port" id="tcp_port" type="text" class="form-control ramal" <?=(@$tcp_port?'value="'.$tcp_port.'"':"");?> />
								<label class="form-label">Porta TCP</label>
							</div>
						</div>
					</div>
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="margin-bottom: 0px;">
					<button id="btnSubmit" type="submit" class="btn btn-primary waves-effect pull-right">
						<i class="material-icons">save</i>
						<span>SALVAR</span>
					</button>
				</div>
				</div>
				</div>

			    </form>
			    <!--FIM FORMULÁRIO-->

                        </div>
                    </div>
                </div>
                <!-- #END# Bloco Pesquisa -->
            </div>



	    <!--LOCALNETS - Table-->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
			<div class="header">
                            <h2>SIP Localnet</h2>
                        </div>
                        <div class="body">

			    <div class="row clearfix">
				<div class="col-xs-12 col-sm-6 col-md-3 col-lg-2" style="margin-bottom: 0px;">
					<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novoLocalnetModal">
						<i class="material-icons">add_circle</i>
						<span>NOVO LOCALNET</span>
					</button>
				</div>
			    </div>

                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination3">
                                    <thead>
                                        <tr>
					    <th>Endereço</th>
					    <th>Mask</th>
					    <th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
			if (isset($localnets)) {
				foreach ($localnets as $key=>$value) {
?>
					<tr>
						<td><?=$value['address'];?></td>
						<td><?=$value['mask'];?></td>
						<td>
							<a href="javascript:;" class="play" onclick="botaoEditarLocalnet('<?=$key;?>', '<?=$value['address'];?>', '<?=$value['mask'];?>')"><i class="material-icons" title="Editar">edit</i></a>
							<a href="javascript:;" class="play" onclick="botaoExcluirLocalnet('<?=$key;?>')"><i class="material-icons" title="Apagar">delete</i></a>
						</td>
					</tr>
<?php
				}
			}
?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# LOCALNETS - Table -->



	</div>
	<!--#END of PAGE CONTENT-->


	    <!-- Modal Dialogs ====================================================================================================================== -->

            <!--MODAL NOVO LOCALNET-->
            <div class="modal fade" id="novoLocalnetModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Novo Localnet</h4>
                        </div>
                        <div class="modal-body">
			    <div class="demo-masked-input">
			    <form id="formNovoLocalnet" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="novolocalnet" />

				</br></br>

				<div class="row clearfix">

                                    <div class="col-sm-12">
					<div class="form-group form-float">
						<div class="form-line">
							<input name="localnet_address" id="localnet_address" type="text" class="form-control ip" />
							<label class="form-label">Endereço</label>
						</div>
					</div>
				    </div>

				    <div class="col-sm-12">
					<div class="form-group form-float">
						<div class="form-line">
							<input name="localnet_mask" id="localnet_mask" type="text" class="form-control ip" />
							<label class="form-label">Mascara</label>
						</div>
					</div>
				    </div>

                                </div>
			    </div>
                        </div>
                        <div class="modal-footer">
			    <button type="submit" class="btn btn-primary waves-effect">
				<i class="material-icons">save</i>
				<span>Salvar</span>
			    </button>
                            <button type="button" id="closeNovoLocalnetModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL NOVO LOCALNET-->




	    <!--MODAL EDITAR LOCALNET-->
            <div class="modal fade" id="editarLocalnetModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Editar Localnet</h4>
                        </div>
                        <div class="modal-body">
			    <div class="demo-masked-input">
			    <form id="formEditarLocalnet" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="editarlocalnet" />
				<input type="hidden" name="localnet_id" id="editarLocalnet_id">
				</br></br>

				<div class="row clearfix">

                                    <div class="col-sm-3 col-xs-5 form-control-label">
                                        <label for="editarLocalnet_address">Endereço</label>
                                    </div>
                                    <div class="col-sm-9 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="localnet_address" id="editarLocalnet_address" class="form-control ip">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-3 col-xs-5 form-control-label">
                                        <label for="editarLocalnet_mask">Mascara</label>
                                    </div>
                                    <div class="col-sm-9 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="localnet_mask" id="editarLocalnet_mask" class="form-control ip">
                                            </div>
                                        </div>
                                    </div>

                                </div>
			    </div>
                        </div>
                        <div class="modal-footer">
			    <button type="submit" class="btn btn-primary waves-effect">
				<i class="material-icons">save</i>
				<span>Salvar</span>
			    </button>
                            <button type="button" id="closeEditarLocalnetModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EDITAR LOCALNET-->



	    <!--MODAL EXCLUIR LOCALNET-->
            <div class="modal fade" id="excluirLocalnetModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Excluir Localnet</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirUsuario" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="excluirlocalnet" />
				<input type="hidden" name="localnet_id" id="excluirLocalnet_id">
			    <p>Tem certeza que deseja excluir o localnet?</p>
                        </div>
                        <div class="modal-footer">
			    <button type="submit" class="btn btn-danger waves-effect">
				<i class="material-icons">delete</i>
				<span>Sim</span>
			    </button>
                            <button type="button" id="closeExcluirLocalnetModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR LOCALNET-->



<script>

	function botaoEditarLocalnet(editarLocalnet_id, editarLocalnet_address, editarLocalnet_mask) {

		$('#editarLocalnet_id').val(editarLocalnet_id);

		$('#editarLocalnet_address').val(editarLocalnet_address);
		$('#editarLocalnet_mask').val(editarLocalnet_mask);

		$("#editarLocalnetModal").modal();
	};

	function botaoExcluirLocalnet(excluirLocalnet_id) {

		$('#excluirLocalnet_id').val(excluirLocalnet_id);
		$("#excluirLocalnetModal").modal();
	}

</script>