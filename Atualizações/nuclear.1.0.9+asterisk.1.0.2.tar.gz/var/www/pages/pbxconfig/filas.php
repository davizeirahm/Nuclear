<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.network.debian7.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.config.ramal.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.filas.php");
	
	//STATIC MEMBERS
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_sip.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_iax2.php");
	
	if ( isset($_GET['tipo']) && $_GET['tipo'] == "criar") {
		$tipo = "criar";
	} else {
		$tipo = "filas";
	}
	
	// DECLARAÇÃO DE VARIÁVEIS ==============================================================================================

	$filas = get_filas();
	//print_r($filas);
	//echo json_encode($filas, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
	
	$audios_fila = get_audios_fila();
	//Array ( [0] => queue-holdtime [1] => queue-seconds [2] => queue-callswaiting [3] => queue-reporthold [4] => queue-youarenext [5] => queue-thankyou [6] => queue-less-than [7] => queue-minutes [8] => queue-thereare [9] => queue-periodic-announce [10] => queue/queue-periodic-announce )
	$categorias_musicais = get_musicclass();
	//Array ( [0] => default )
	
	$ramais_sip = get_ramais();
	$ramais_iax = get_ramais_iax();
	

	//FILA ===============================================================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "novaFila") {
		//print_r($_POST);
	/*
		Array ( [satisfacao] => satisfacao [tipoFila] => no [nome] => 602 [context] => entrada1 [musicclass] => default [announce] => [strategy] => ringall [joinempty] => strict [leavewhenempty] => strict [timeout] => 15 [retry] => 5 [wrapuptime] => 0 [maxlen] => 0 [member] => SIP/4002 [announce-frequency] => 0 [min-announce-frequency] => 15 [announce-position] => no [announce-position-limit] => 0 [announce-holdtime] => no [periodic-announce-frequency] => 0 [queue-callswaiting] => queue-callswaiting [queue-thankyou] => queue-thankyou [queue-thereare] => queue-thereare [queue-youarenext] => queue-youarenext ) 
	*/
		//seta o tempo limite da aplicação para esperar mais tempo grandes loops demoram mais
		set_time_limit(600);
		
		$erro = "";
		
		if ( !isset($_POST['nome']) || $_POST['nome'] == "" ) {
			$erro = "Erro: Nome da Fila inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		unset($_POST['pagina']);
		unset($_POST['menu']);
		unset($_POST['pagina_nome']);
		unset($_POST['menu_nome']);
		unset($_POST['cmd']);
		if ( !nova_fila($_POST, ARQ_FILAS_CONF) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "editarFila") {
		/*
	
		*/
		$erro="";
		if ($_POST['editarFila'] == "") {
			$erro = "Erro: Fila Incorreto!";
		}
		if ( !isset($_POST['nome']) || $_POST['nome'] == "" ) {
			$erro = "Erro: Nome da Fila inválido!";
		}
		unset($_POST['pagina']);
		unset($_POST['menu']);
		unset($_POST['pagina_nome']);
		unset($_POST['menu_nome']);
		unset($_POST['cmd']);
		if ( !editar_fila($_POST, ARQ_FILAS_CONF) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirFila") {
		//[fila] => 610 
		
		$erro="";
		if ($_POST['fila'] == "") {
			$erro = "Erro: Fila Incorreta!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !excluir_fila($_POST['fila'], ARQ_FILAS_CONF) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "apagarFaixa") {
		set_time_limit(600);
		
		$erro = "";

		$inicio = $_POST['filaInicial'];
		$fim = $_POST['filaFinal'];
			
		if ( $inicio != "" && !is_numeric($inicio)) {
			$erro = "Erro: Fila inicial incorreta!";
		}
		if ( $fim != "" && !is_numeric($fim)) {
			$erro = "Erro: Fila final incorreta!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ($fim > $inicio) {
			$qtde = ($fim - $inicio);
		} elseif ($fim == $inicio || ($inicio != "" && $fim == "") ) {
			$qtde = 0;
		} elseif ($inicio > $fim) {
			$qtde = ($inicio - $fim);
			$tmp = $fim;
			$fim = $inicio;
			$inicio = $tmp;
		}
		for ($i = 0; $i <= $qtde; $i++) {
			excluir_fila($inicio, ARQ_FILAS_CONF);
			$inicio++;
		}
		print "<script>
			alert('Configurações salvas com sucesso!');
			document.getElementById('form_{$pagina}_{$menu}').submit();
		</script>";
	}

?>

	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- MENU FILAS -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="row clearfix">
			    <div class="col-xs-12 col-sm-6">
				<ol class="breadcrumb">
					<li>NUCLEAR PABX IP</li>
					<li><?=$pagina_nome;?></li>
					<li class="active"><?=$menu_nome;?></li>
				</ol>
			    </div>
			</div>
                        <div class="body">
                            <ul class="nav nav-tabs tab-nav-right" role="tablist">
                                <li role="presentation" <?php echo ( $tipo == "filas" ? "class=\"active\"" : "" ); ?> ><a href="#filas" data-toggle="tab">FILAS</a></li>
                                <li role="presentation" <?php echo ( $tipo == "criar" ? "class=\"active\"" : "" ); ?> ><a href="#criar" data-toggle="tab">CRIAR FILAS</a></li>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
				<!-- FILAS #####################################################################################################################-->
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "filas" ? "in active" : "" ); ?>" id="filas">


			    <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
                                            <th>Número</th>
                                            <th>Tipo</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					    <?php
						foreach($filas as $fila=>$vetor) {
						    if (is_array($vetor)) {
								if ($vetor['tipoFila'] == "yes") {
									$tipo = "Call Center";
								} else {
									$tipo = "Pabx";
								}
					    ?>
							<tr>
								<td><?=$fila;?></td>
								<td><?=@$tipo;?></td> 
								<td>
									<a href="javascript:;" class="editar-fila" data-fila="<?=$fila;?>"><i class="material-icons" title="Editar">edit</i></a>&nbsp;
									<a href="javascript:;" class="play" onclick="botaoExcluirFila('<?=$fila;?>')"><i class="material-icons" title="Excluir">delete</i></a>
								</td>
							</tr>
					    <?php
						    }
						}
					    ?>
                                    </tbody>
                                </table>
                            </div>

						<button type="button" class="btn btn-danger waves-effect" data-toggle="modal" data-target="#apagarFaixaModal">
							<i class="material-icons">delete</i>
							<span>Apagar Faixa</span>
						</button>

				</div>
				<!--#FIM - FILAS ##############################################################################################################-->
				<!-- CRIAR FILA ###################################################################################################################-->
                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "criar" ? "in active" : "" ); ?>" id="criar">

			</br>
			<h4>Nova Fila</h4>
			</br>
			    <div class="demo-masked-input">
			    <form id="formNovaFila" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="novaFila" />

				<div class="row clearfix">
					<div class="col-md-9 col-sm-12 col-xs-12">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<input type="checkbox" name="satisfacao" id="satisfacao_novaFila" value="yes" class="filled-in chk-col-light-blue"/>
							<label for="satisfacao_novaFila">Ativar Pesquisa Satisfação?</label>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-9 col-sm-12 col-xs-12">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<input type="checkbox" name="ring" id="ring_novaFila" value="yes" class="filled-in chk-col-light-blue"/>
							<label for="ring_novaFila">Ativar ring na fila?</label>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label>Tipo da Fila</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="tipoFila" id="tipoFila_novaFila" class="form-control show-tick">
            					<option value="no">Simples</option>
            					<option value="yes">Call Center</option>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label title="Cria um fila por nome" for="filaNome_novaFila">Fila Nome</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="nome" id="filaNome_novaFila" class="form-control rota">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label>Contexto</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="context" id="context_novaFila" class="form-control show-tick">
            					<option value=""> - </option>
            					<?php
									$tmpcat = get_ini_keys(ARQ_ENTRADASDDR_CONF);
            						foreach($tmpcat as $key=>$value) {
            							print "<option value=\"".$key."\">".$key."</option>";
            						}
									$tmpcat = get_ini_keys(ARQ_ENTRADASDDRCUSTOM_CONF);
            						foreach($tmpcat as $key=>$value) {
            							print "<option value=\"".$key."\">".$key."</option>";
            						}
									//COLOCAR URAS AQUI
            					?>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="musicclass_novaFila">Classe músical</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="musicclass" id="musicclass_novaFila" class="form-control show-tick">
								<option value=""> - </option>
					<?php
					    foreach ($categorias_musicais as $k=>$classe) {
					?>
								<option value="<?=$classe;?>"><?=$classe;?></option>
					<?php
					    }
					?>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="announce_novaFila">Anúncio para agente</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="announce" id="announce_novaFila" class="form-control show-tick">
								<option value=""> - </option>
					<?php
					    foreach ($audios_fila as $k=>$audio) {
					?>
								<option value="<?=$audio;?>"><?=$audio;?></option>
					<?php
					    }
					?>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="strategy_novaFila">Estratégia</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="strategy" id="strategy_novaFila" class="form-control show-tick">
								<option value="ringall">Todos (ringall)</option>
								<option value="leastrecent">Menos recente (leastrecent)</option>
								<option value="fewestcalls">Menos chamadas (fewestcalls)</option>
								<option value="random">Aleatório (random)</option>
								<option value="rrmemory">Aleatório Memória (rrmemory)</option>
								<option value="rrordered">Aleatório Ordenado (rrordered)</option>
								<option value="linear">Linear</option>
								<option value="wrandom">Aleatório com Peso (wrandom)</option>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="joinempty_novaFila">Entra vazio</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="joinempty" id="joinempty_novaFila" class="form-control show-tick">
								<option value="strict">strict</option>
								<option value="yes">yes</option>
								<option value="no">no</option>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="leavewhenempty_novaFila">Sai quando vazio</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="leavewhenempty" id="leavewhenempty_novaFila" class="form-control show-tick">
								<option value="strict">strict</option>
								<option value="yes">yes</option>
								<option value="no">no</option>
							</select>
						</div>
					</div>
				</div>
				<hr>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="servicelevel_novaFila">Segundos para nível de serviço</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="servicelevel" id="servicelevel_novaFila" class="form-control timeout" value="60">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="timeout_novaFila">Tempo toque agente</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="timeout" id="timeout_novaFila" class="form-control timeout" value="15">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="retry_novaFila">Tentar novamente</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="retry" id="retry_novaFila" class="form-control timeout" value="5">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="wrapuptime_novaFila">Repouso agente</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="wrapuptime" id="wrapuptime_novaFila" class="form-control timeout" value="0">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="maxlen_novaFila">Máximo de chamadas</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="maxlen" id="maxlen_novaFila" class="form-control timeout" value="0">
							</div>
						</div>
					</div>
				</div>
				<hr>
				
				<div class="row clearfix">
					<div class="body">
						<ul class="list-group containerNovoMembro">
							<li class="list-group-item">
								<div class="row clearfix">
									<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
										<label for="member_novaFila-0">Membros</label>
									</div>
									<div class="col-md-3 col-sm-3 col-xs-7">
										<div class="form-group form-float" style="margin-bottom: 0px;">
											<select name="member[]" id="member_novaFila-0" class="form-control show-tick">
												<option value=""> - </option>
											<?php
												foreach ($ramais_sip as $ramal=>$vetor) {
											?>
												<option value="SIP/<?=$ramal;?>">SIP/<?=$ramal;?></option>
											<?php
												}
												foreach ($ramais_iax as $ramal=>$vetor) {
											?>
												<option value="IAX2/<?=$ramal;?>">IAX2/<?=$ramal;?></option>
											<?php
												}
											?>
											</select>
										</div>
									</div>
									<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
										<label>Prioridade</label>
									</div>
									<div class="col-md-3 col-sm-3 col-xs-7">
										<div class="form-group form-float" style="margin-bottom: 0px;">
											<select name="prio[]" id="prio_novaFila-0" class="form-control show-tick">
												<option value="no">Não</option>
												<option value="0">0</option>
												<option value="1">1</option>
												<option value="2">2</option>
												<option value="3">3</option>
												<option value="4">4</option>
												<option value="5">5</option>
												<option value="6">6</option>
												<option value="7">7</option>
												<option value="8">8</option>
												<option value="9">9</option>
											</select>
										</div>
									</div>
								</div>
							</li>
						</ul>
						<button type="" class="btn btn-primary waves-effect" id="add_novoMembro">
							<i class="material-icons">add_circle</i>
							<span>Adicionar</span>
						</button>
					</div>
				</div>
				
				<hr>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="announce-frequency_novaFila">Frequência do anúncio</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="announce-frequency" id="announce-frequency_novaFila" class="form-control timeout" value="0">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="min-announce-frequency_novaFila">Minina frequência do anúncio</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="min-announce-frequency" id="min-announce-frequency_novaFila" class="form-control timeout" value="15">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="announce-position_novaFila">Anunciar posição</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="announce-position" id="announce-position_novaFila" class="form-control show-tick">
								<option value="no">no</option>
								<option value="yes">yes</option>
								<option value="more">more</option>
								<option value="limit">limit</option>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="announce-to-first-user_novaFila">Anunciar posição imediatamente ao entrar na fila</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="announce-to-first-user" id="announce-to-first-user_novaFila" class="form-control show-tick">
								<option value="no">no</option>
								<option value="yes">yes</option>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="announce-position-limit_novaFila">Limite para anunciar posição</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="announce-position-limit" id="announce-position-limit_novaFila" class="form-control timeout" value="0">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="announce-holdtime_novaFila">Anunciar tempo de espera</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="announce-holdtime" id="announce-holdtime_novaFila" class="form-control show-tick">
								<option value="no">no</option>
								<option value="yes">yes</option>
								<option value="once">once</option>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="
						-announce-frequency_novaFila">Frequência do anúncio periódico</label>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-7">
						<div class="form-group" style="margin-bottom: 0px;">
							<div class="form-line">
								<input type="text" name="periodic-announce-frequency" id="periodic-announce-frequency_novaFila" class="form-control timeout" value="0">
							</div>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="periodic-announce_novaFila">Anúncio periódico</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="periodic-announce[]" id="periodic-announce_novaFila" class="form-control show-tick" multiple>
					<?php
					    foreach ($audios_fila as $k=>$audio) {
					?>
								<option value="<?=$audio;?>"><?=$audio;?></option>
					<?php
					    }
					?>
							</select>
						</div>
					</div>
				</div>
				<hr>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="queue-callswaiting_novaFila">queue-callswaiting</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="queue-callswaiting" id="queue-callswaiting_novaFila" class="form-control show-tick">
								<option value=""> - </option>
					<?php
					    foreach ($audios_fila as $k=>$audio) {
							if ($audio == "queue-callswaiting") {
					?>
								<option value="<?=$audio;?>" selected='selected'><?=$audio;?></option>
					<?php	} else { ?>
								<option value="<?=$audio;?>"><?=$audio;?></option>
					<?php
							}
					    }
					?>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="queue-thankyou_novaFila">queue-thankyou</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="queue-thankyou" id="queue-thankyou_novaFila" class="form-control show-tick">
								<option value=""> - </option>
					<?php
					    foreach ($audios_fila as $k=>$audio) {
							if ($audio == "queue-thankyou") {
					?>
								<option value="<?=$audio;?>" selected='selected'><?=$audio;?></option>
					<?php	} else { ?>
								<option value="<?=$audio;?>"><?=$audio;?></option>
					<?php
							}
					    }
					?>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="queue-thereare_novaFila">queue-thereare</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="queue-thereare" id="queue-thereare_novaFila" class="form-control show-tick">
								<option value=""> - </option>
					<?php
					    foreach ($audios_fila as $k=>$audio) {
							if ($audio == "queue-thereare") {
					?>
								<option value="<?=$audio;?>" selected='selected'><?=$audio;?></option>
					<?php	} else { ?>
								<option value="<?=$audio;?>"><?=$audio;?></option>
					<?php
							}
					    }
					?>
							</select>
						</div>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
						<label for="queue-youarenext_novaFila">queue-youarenext</label>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-7">
						<div class="form-group form-float" style="margin-bottom: 0px;">
							<select name="queue-youarenext" id="queue-youarenext_novaFila" class="form-control show-tick">
								<option value=""> - </option>
					<?php
					    foreach ($audios_fila as $k=>$audio) {
							if ($audio == "queue-youarenext") {
					?>
								<option value="<?=$audio;?>" selected='selected'><?=$audio;?></option>
					<?php	} else { ?>
								<option value="<?=$audio;?>"><?=$audio;?></option>
					<?php
							}
					    }
					?>
							</select>
						</div>
					</div>
				</div>

					<button type="button" onclick="novaFila()" class="btn btn-primary waves-effect">
						<i class="material-icons">save</i>
						<span>SALVAR</span>
			    	</button>
			    </form>
			    </div>


				</div>
				<!--#FIM - CRIAR FILA ##############################################################################################################-->
                            </div>


                        </div>
                    </div>
                </div>
                <!-- #END# MENU FILAS -->
            </div>
	</div>
	<!--END - PAGE CONTENT-->


	<!-- MODAL ================================================================================================================================== -->

		<!--MODAL EDITAR FILA-->
			<div class="modal fade" id="editarFilaModal" tabindex="-1" role="dialog">
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h4 class="modal-title" id="editarFilaLabel">Editar Fila</h4>
						</div>
						<div class="modal-body">
							<div class="row clearfix demo-masked-input">
								<form id="formEditarFila" method="post">
								<?=$text_form;?>
								<input type="hidden" name="cmd" value="editarFila" />
								<input type="hidden" id="editarFila" name="editarFila" value="" />
								
								<div class="row clearfix">
									<div class="col-md-9 col-sm-12 col-xs-12">
										<div class="form-group form-float" >
											<input type="checkbox" name="satisfacao" id="satisfacao_editarFila" value="yes" class="filled-in chk-col-light-blue"/>
											<label for="satisfacao_editarFila">Ativar Pesquisa Satisfação?</label>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-9 col-sm-12 col-xs-12">
										<div class="form-group form-float" >
											<input type="checkbox" name="ring" id="ring_editarFila" value="yes" class="filled-in chk-col-light-blue"/>
											<label for="ring_editarFila">Ativar ring na fila?</label>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label>Tipo da Fila</label>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-7">
										<div class="form-group form-float" >
											<select name="tipoFila" id="tipoFila_editarFila" class="form-control show-tick">
    				        					<option value="no">Simples</option>
												<option value="yes">Call Center</option>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label title="Cria um fila por nome" for="filaNome_editarFila">Fila Nome</label>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-7">
										<div class="form-group" >
											<div class="form-line">
												<input type="text" name="nome" id="filaNome_editarFila" class="form-control rota">
											</div>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label>Contexto</label>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-7">
										<div class="form-group form-float" >
											<select name="context" id="context_editarFila" class="form-control show-tick">
          				  					<option value=""> - </option>
            									<?php
													$tmpcat = get_ini_keys(ARQ_ENTRADASDDR_CONF);
        				    						foreach($tmpcat as $key=>$value) {
            											print "<option value=\"".$key."\">".$key."</option>";
            										}
													$tmpcat = get_ini_keys(ARQ_ENTRADASDDRCUSTOM_CONF);
            										foreach($tmpcat as $key=>$value) {
            											print "<option value=\"".$key."\">".$key."</option>";
            										}
													//COLOCAR URAS AQUI
     				       					?>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label for="musicclass_editarFila">Classe músical</label>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-7">
										<div class="form-group form-float" >
											<select name="musicclass" id="musicclass_editarFila" class="form-control show-tick">
												<option value=""> - </option>
									<?php
									    foreach ($categorias_musicais as $k=>$classe) {
									?>
												<option value="<?=$classe;?>"><?=$classe;?></option>
									<?php
									    }
									?>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label for="announce_editarFila">Anúncio para agente</label>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-7">
										<div class="form-group form-float" >
											<select name="announce" id="announce_editarFila" class="form-control show-tick">
												<option value=""> - </option>
									<?php
										foreach ($audios_fila as $k=>$audio) {
									?>
												<option value="<?=$audio;?>"><?=$audio;?></option>
									<?php
										}
									?>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label for="strategy_editarFila">Estratégia</label>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-7">
										<div class="form-group form-float" >
											<select name="strategy" id="strategy_editarFila" class="form-control show-tick">
												<option value="ringall">Todos (ringall)</option>
												<option value="leastrecent">Menos recente (leastrecent)</option>
												<option value="fewestcalls">Menos chamadas (fewestcalls)</option>
												<option value="random">Aleatório (random)</option>
												<option value="rrmemory">Aleatório Memória (rrmemory)</option>
												<option value="rrordered">Aleatório Ordenado (rrordered)</option>
												<option value="linear">Linear</option>
												<option value="wrandom">Aleatório com Peso (wrandom)</option>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label for="joinempty_editarFila">Entra vazio</label>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-7">
										<div class="form-group form-float" >
											<select name="joinempty" id="joinempty_editarFila" class="form-control show-tick">
												<option value="strict">strict</option>
												<option value="yes">yes</option>
												<option value="no">no</option>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label for="leavewhenempty_editarFila">Sai quando vazio</label>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-7">
										<div class="form-group form-float" >
											<select name="leavewhenempty" id="leavewhenempty_editarFila" class="form-control show-tick">
												<option value="strict">strict</option>
												<option value="yes">yes</option>
												<option value="no">no</option>
											</select>
										</div>
									</div>
								</div>
								<hr>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label for="servicelevel_editarFila">Segundos para nível de serviço</label>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-7">
										<div class="form-group" style="margin-bottom: 0px;">
											<div class="form-line">
												<input type="text" name="servicelevel" id="servicelevel_editarFila" class="form-control timeout">
											</div>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label for="timeout_editarFila">Tempo toque agente</label>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-7">
										<div class="form-group" >
											<div class="form-line">
												<input type="text" name="timeout" id="timeout_editarFila" class="form-control timeout">
											</div>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label for="retry_editarFila">Tentar novamente</label>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-7">
										<div class="form-group" >
											<div class="form-line">
												<input type="text" name="retry" id="retry_editarFila" class="form-control timeout">
											</div>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label for="wrapuptime_editarFila">Repouso agente</label>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-7">
										<div class="form-group" >
											<div class="form-line">
												<input type="text" name="wrapuptime" id="wrapuptime_editarFila" class="form-control timeout">
											</div>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label for="maxlen_editarFila">Máximo de chamadas</label>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-7">
										<div class="form-group" >
											<div class="form-line">
												<input type="text" name="maxlen" id="maxlen_editarFila" class="form-control timeout">
											</div>
										</div>
									</div>
								</div>
								<hr>
								<div class="row clearfix">
									<div class="body" style="padding: 20px;">
										<ul class="list-group containerEditarMembro">
											<li class="list-group-item">
												<div class="row clearfix">
													<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
														<label for="member_editarFila-1">Membros</label>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-7">
														<div class="form-group form-float" style="margin-bottom: 0px;">
															<select name="member[]" id="member_editarFila-1" class="form-control show-tick">
																<option value=""> - </option>
															<?php
																foreach ($ramais_sip as $ramal=>$vetor) {
															?>
																<option value="SIP/<?=$ramal;?>">SIP/<?=$ramal;?></option>
															<?php
																}
																foreach ($ramais_iax as $ramal=>$vetor) {
															?>
																<option value="IAX2/<?=$ramal;?>">IAX2/<?=$ramal;?></option>
															<?php
																}
															?>
															</select>
														</div>
													</div>
													<div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
														<label>Prioridade</label>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-7">
														<div class="form-group form-float" style="margin-bottom: 0px;">
															<select name="prio[]" id="prio_editarFila-1" class="form-control show-tick">
																<option value="no">Não</option>
																<option value="0">0</option>
																<option value="1">1</option>
																<option value="2">2</option>
																<option value="3">3</option>
																<option value="4">4</option>
																<option value="5">5</option>
																<option value="6">6</option>
																<option value="7">7</option>
																<option value="8">8</option>
																<option value="9">9</option>
															</select>
														</div>
													</div>
												</div>
											</li>
										</ul>
										<button type="" class="btn btn-primary waves-effect" id="add_editarMembro">
											<i class="material-icons">add_circle</i>
											<span>Adicionar</span>
										</button>
									</div>
								</div>
								<hr>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label for="announce-frequency_editarFila">Frequência do anúncio</label>
									</div>
									<div class="col-md-2 col-sm-6 col-xs-7">
										<div class="form-group" >
											<div class="form-line">
												<input type="text" name="announce-frequency" id="announce-frequency_editarFila" class="form-control timeout">
											</div>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label for="min-announce-frequency_editarFila">Minina frequência do anúncio</label>
									</div>
									<div class="col-md-2 col-sm-6 col-xs-7">
										<div class="form-group" >
											<div class="form-line">
												<input type="text" name="min-announce-frequency" id="min-announce-frequency_editarFila" class="form-control timeout">
											</div>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label for="announce-position_editarFila">Anunciar posição</label>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-7">
										<div class="form-group form-float" >
											<select name="announce-position" id="announce-position_editarFila" class="form-control show-tick">
												<option value="no">no</option>
												<option value="yes">yes</option>
												<option value="more">more</option>
												<option value="limit">limit</option>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label for="announce-to-first-user_editarFila">Anunciar posição imediatamente ao entrar na fila</label>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-7">
										<div class="form-group form-float" >
											<select name="announce-to-first-user" id="announce-to-first-user_editarFila" class="form-control show-tick">
												<option value="no">no</option>
												<option value="yes">yes</option>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label for="announce-position-limit_editarFila">Limite para anunciar posição</label>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-7">
										<div class="form-group" >
											<div class="form-line">
												<input type="text" name="announce-position-limit" id="announce-position-limit_editarFila" class="form-control timeout" value="0">
											</div>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label for="announce-holdtime_editarFila">Anunciar tempo de espera</label>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-7">
										<div class="form-group form-float" >
											<select name="announce-holdtime" id="announce-holdtime_editarFila" class="form-control show-tick">
												<option value="no">no</option>
												<option value="yes">yes</option>
												<option value="once">once</option>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label for="periodic-announce-frequency_editarFila">Frequência do anúncio periódico</label>
									</div>
									<div class="col-md-2 col-sm-6 col-xs-7">
										<div class="form-group" >
											<div class="form-line">
												<input type="text" name="periodic-announce-frequency" id="periodic-announce-frequency_editarFila" class="form-control timeout" value="0">
											</div>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label for="periodic-announce_editarFila">Anúncio periódico</label>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-7">
										<div class="form-group form-float" >
											<select name="periodic-announce[]" id="periodic-announce_editarFila" class="form-control show-tick" multiple>
									<?php
										foreach ($audios_fila as $k=>$audio) {
									?>
												<option value="<?=$audio;?>"><?=$audio;?></option>
									<?php
										}
									?>
											</select>
										</div>
									</div>
								</div>
								<hr>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label for="queue-callswaiting_editarFila">queue-callswaiting</label>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-7">
										<div class="form-group form-float" >
											<select name="queue-callswaiting" id="queue-callswaiting_editarFila" class="form-control show-tick">
												<option value=""> - </option>
									<?php
										foreach ($audios_fila as $k=>$audio) {
									?>
											<option value="<?=$audio;?>"><?=$audio;?></option>
									<?php
										}
									?>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label for="queue-thankyou_editarFila">queue-thankyou</label>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-7">
										<div class="form-group form-float" >
											<select name="queue-thankyou" id="queue-thankyou_editarFila" class="form-control show-tick">
												<option value=""> - </option>
									<?php
										foreach ($audios_fila as $k=>$audio) {
									?>
											<option value="<?=$audio;?>"><?=$audio;?></option>
									<?php
										}
									?>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label for="queue-thereare_editarFila">queue-thereare</label>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-7">
										<div class="form-group form-float" >
											<select name="queue-thereare" id="queue-thereare_editarFila" class="form-control show-tick">
												<option value=""> - </option>
									<?php
										foreach ($audios_fila as $k=>$audio) {
									?>
											<option value="<?=$audio;?>"><?=$audio;?></option>
									<?php
										}
									?>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
										<label for="queue-youarenext_editarFila">queue-youarenext</label>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-7">
										<div class="form-group form-float" >
											<select name="queue-youarenext" id="queue-youarenext_editarFila" class="form-control show-tick">
												<option value=""> - </option>
									<?php
										foreach ($audios_fila as $k=>$audio) {
									?>
											<option value="<?=$audio;?>"><?=$audio;?></option>
									<?php
										}
									?>
											</select>
										</div>
									</div>
								</div>
								
							</div>
						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
							<button type="button" id="closeEditarFilaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
						</div>
							</form>
					</div>
				</div>
			</div>
	    <!--#END of MODAL EDITAR FILA-->


	    <!--MODAL EXCLUIR FILA-->
            <div class="modal fade" id="excluirFilaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirFilaLabel">Excluir Fila</h4>
                        </div>
                        <div class="modal-body">
							<form id="formExcluirFila" method="post">
							<?=$text_form;?>
							<input type="hidden" name="tipo" value="fila" />
							<input type="hidden" name="cmd" value="excluirFila" />
							<input type="hidden" id="excluirFila" name="fila" value="" />
							<p>Tem certeza que deseja excluir a Fila?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
							<button type="button" id="closeExcluirFilaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
							</form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR FILA-->


		<!--MODAL APAGAR FAIXA-->
            <div class="modal fade" id="apagarFaixaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Apagar Faixa</h4>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
								<form id="formEditarUsuario" method="post">
									<?=$text_form;?>
									<input type="hidden" name="cmd" value="apagarFaixa" />

								<div class="row clearfix">
									<div class="col-lg-4 col-md-4 col-sm-4 col-xs-5 form-control-label">
										<label for="filaInicial_apagarFaixa">Fila Inicial</label>
									</div>
									<div class="col-lg-8 col-md-8 col-sm-8 col-xs-7">
										<div class="form-group">
											<div class="form-line">
												<input type="text" name="filaInicial" id="filaInicial_apagarFaixa" class="form-control ramal">
											</div>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-lg-4 col-md-4 col-sm-4 col-xs-5 form-control-label">
										<label for="filaFinal_apagarFaixa">Fila Final</label>
									</div>
									<div class="col-lg-8 col-md-8 col-sm-8 col-xs-7">
										<div class="form-group">
											<div class="form-line">
												<input type="text" name="filaFinal" id="filaFinal_apagarFaixa" class="form-control ramal">
											</div>
										</div>
									</div>
								</div>
							</div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Apagar</span>
							</button>
                            <button type="button" id="closeApagarFaixaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL APAGAR FAIXA-->


	<!--#END - MODAL ============================================================================================================================== -->

<script>


function novaFila()
{
	
	document.getElementById("formNovaFila").submit();
} 

function botaoExcluirFila(excluirFila) {
	$('#excluirFila').val(excluirFila);

	$('#excluirFilaLabel').text("Excluir Fila "+excluirFila);
	$("#excluirFilaModal").modal();
};

var wrapper_editar = $(".containerEditarMembro");
var max_fields_editar = 32;
var y = 1;
var w = 1;
var texto = "";

function del_editarMembro() {
	if (w > 1) {
		for (i=2; i<=w; i++) {
			$('#li-'+i).remove();
		}
	}
	y = 1;
	w = 1;
}

function add_editarMembro() {
	if (y < max_fields_editar) {
		y++;
		w++;
		texto = "";
		texto += '<li class="list-group-item" id="li-'+w+'"><div class="row clearfix">';
		texto += '<div class="col-md-2 col-sm-3 col-xs-5 form-control-label"><label for="member_editarFila-'+w+'">Membros</label></div>';
		texto += '<div class="col-md-3 col-sm-3 col-xs-7"><div class="form-group form-float" style="margin-bottom: 0px;">';
		texto += '<select name="member[]" id="member_editarFila-'+w+'" class="form-control show-tick">';
		texto += '<option value=""> - </option>';
		<?php
			foreach ($ramais_sip as $ramal=>$vetor) {
				print "texto += '<option value=\"SIP/".$ramal."\">SIP/".$ramal."</option>';";
			}
			foreach ($ramais_iax as $ramal=>$vetor) {
				print "texto += '<option value=\"IAX2/".$ramal."\">IAX2/".$ramal."</option>';";
			}
		?>
		texto += '</select></div></div>';
		texto += '<div class="col-md-2 col-sm-3 col-xs-5 form-control-label"><label>Prioridade</label></div>';
		texto += '<div class="col-md-3 col-sm-3 col-xs-7"><div class="form-group form-float" style="margin-bottom: 0px;">';
		texto += '<select name="prio[]" id="prio_editarFila-'+w+'" class="form-control show-tick">';
		texto += '<option value="no">Não</option><option value="0">0</option><option value="1">1</option>';
		texto += '<option value="2">2</option><option value="3">3</option><option value="4">4</option>';
		texto += '<option value="5">5</option><option value="6">6</option><option value="7">7</option>';
		texto += '<option value="8">8</option><option value="9">9</option>';
		texto += '</select></div></div>';
		texto += '</div><a href="#" class="delete">Delete</a></li>';
        $(wrapper_editar).append(
			texto
		);
		//REFRESH NO SELECTPICKER PRA PODER ATUALIZAR O VALOR
			$('#member_editarFila-'+w).addClass('selectpicker');
			$('#member_editarFila-'+w).selectpicker('refresh');
			$('#prio_editarFila-'+w).addClass('selectpicker');
			$('#prio_editarFila-'+w).selectpicker('refresh');
    } else {
		alert('Limite alcançado!');
	}
};

$(document).ready(function(){

	var filas = <?php echo json_encode($filas, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
	/*
	"610":{
		"queue-callswaiting":"queue-callswaiting",
		"queue-thankyou":"queue-thankyou",
		"queue-thereare":"queue-thereare",
		"queue-youarenext":"queue-youarenext",
		"strategy":"ringall",
		"announce-frequency":"0",
		"periodic-announce-frequency":"",
		"retry":"5",
		"timeout":"15",
		"wrapuptime":"0",
		"periodic-announce":[""],
		"musicclass":"default",
		"context":"",
		"joinempty":"strict",
		"leavewhenempty":"strict",
		"maxlen":"0",
		"announce-position":"no",
		"announce-holdtime":"no",
		"member":["SIP/4000","SIP/4010"],
		"setinterfacevar":"yes",
		"setqueuevar":"yes",
		"setqueueentryvar":"yes",
		"tipoFila":"no",
		"satisfacao":"no"
	}
	*/

	$(".editar-fila").on('click', function(event) {
		event.preventDefault();

		var fila = $(this).data('fila');

		document.getElementById('editarFilaLabel').innerHTML = "EditarFila: "+fila;

		$('#editarFila').val(fila);

		$('#filaNome_editarFila').val(fila);
		$('#servicelevel_editarFila').val(filas[fila].servicelevel);
		$('#timeout_editarFila').val(filas[fila].timeout);
		$('#retry_editarFila').val(filas[fila].retry);
		$('#wrapuptime_editarFila').val(filas[fila].wrapuptime);
		$('#maxlen_editarFila').val(filas[fila].maxlen);
		$('#announce-frequency_editarFila').val(filas[fila].announce_frequency);
		$('#min-announce-frequency_editarFila').val(filas[fila].min_announce_frequency);
		$('#announce-position-limit_editarFila').val(filas[fila].announce_position_limit);
		$('#announce-position-limit_editarFila').blur();
		$('#periodic-announce-frequency_editarFila').val(filas[fila].periodic_announce_frequency);
		$('#periodic-announce-frequency_editarFila').blur();
		
		$('#satisfacao_editarFila').prop('checked',false);
		if ( filas[fila].satisfacao == "yes" ) {
			$('#satisfacao_editarFila').prop('checked',true);
		}
		$('#ring_editarFila').prop('checked',false);
		if ( filas[fila].ring == "yes" ) {
			$('#ring_editarFila').prop('checked',true);
		}
		
		del_editarMembro();
		for (var i in filas[fila].member) {
			if (i != 1) {
				add_editarMembro();
			}
			
			var aux = 0;
			$('#member_editarFila-'+i+' option').each(function(){
				if ($(this).val() == filas[fila].member[i].ramal) {
					$('#member_editarFila-'+i).selectpicker('val', filas[fila].member[i].ramal);
					aux = 1;
				} else if (aux != 1) {
					$('#member_editarFila-'+i).selectpicker('val', 'null');
				}
			});
			aux = 0;
			$('#prio_editarFila-'+i+' option').each(function(){
				if ($(this).val() == filas[fila].member[i].prio) {
					$('#prio_editarFila-'+i).selectpicker('val', filas[fila].member[i].prio);
					aux = 1;
				} else if (aux != 1) {
					$('#prio_editarFila-'+i).selectpicker('val', 'no');
				}
			});
		}
		
		$('#member_editarFila').selectpicker('deselectAll');
		$('#member_editarFila').selectpicker('val', filas[fila].member);
		
		$("#periodic-announce_editarFila").selectpicker('deselectAll');
		$('#periodic-announce_editarFila').selectpicker('val', filas[fila].periodic_announce);

		var aux = 0;
		$('#tipoFila_editarFila option').each(function(){
			if ($(this).val() == filas[fila].tipoFila) {
				$('#tipoFila_editarFila').selectpicker('val', filas[fila].tipoFila);
				aux = 1;
			} else if (aux != 1) {
				$('#tipoFila_editarFila').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#musicclass_editarFila option').each(function(){
			if ($(this).val() == filas[fila].musicclass) {
				$('#musicclass_editarFila').selectpicker('val', filas[fila].musicclass);
				aux = 1;
			} else if (aux != 1) {
				$('#musicclass_editarFila').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#context_editarFila option').each(function(){
			if ($(this).val() == filas[fila].context) {
				$('#context_editarFila').selectpicker('val', filas[fila].context);
				aux = 1;
			} else if (aux != 1) {
				$('#context_editarFila').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#announce_editarFila option').each(function(){
			if ($(this).val() == filas[fila].announce) {
				$('#announce_editarFila').selectpicker('val', filas[fila].announce);
				aux = 1;
			} else if (aux != 1) {
				$('#announce_editarFila').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#strategy_editarFila option').each(function(){
			if ($(this).val() == filas[fila].strategy) {
				$('#strategy_editarFila').selectpicker('val', filas[fila].strategy);
				aux = 1;
			} else if (aux != 1) {
				$('#strategy_editarFila').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#joinempty_editarFila option').each(function(){
			if ($(this).val() == filas[fila].joinempty) {
				$('#joinempty_editarFila').selectpicker('val', filas[fila].joinempty);
				aux = 1;
			} else if (aux != 1) {
				$('#joinempty_editarFila').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#leavewhenempty_editarFila option').each(function(){
			if ($(this).val() == filas[fila].leavewhenempty) {
				$('#leavewhenempty_editarFila').selectpicker('val', filas[fila].leavewhenempty);
				aux = 1;
			} else if (aux != 1) {
				$('#leavewhenempty_editarFila').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#announce-position_editarFila option').each(function(){
			if ($(this).val() == filas[fila].announce_position) {
				$('#announce-position_editarFila').selectpicker('val', filas[fila].announce_position);
				aux = 1;
			} else if (aux != 1) {
				$('#announce-position_editarFila').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#announce-to-first-user_editarFila option').each(function(){
			if ($(this).val() == filas[fila].announce_to_first_user) {
				$('#announce-to-first-user_editarFila').selectpicker('val', filas[fila].announce_to_first_user);
				aux = 1;
			} else if (aux != 1) {
				$('#announce-to-first-user_editarFila').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#announce-holdtime_editarFila option').each(function(){
			if ($(this).val() == filas[fila].announce_holdtime) {
				$('#announce-holdtime_editarFila').selectpicker('val', filas[fila].announce_holdtime);
				aux = 1;
			} else if (aux != 1) {
				$('#announce-holdtime_editarFila').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#queue-callswaiting_editarFila option').each(function(){
			if ($(this).val() == filas[fila].queue_callswaiting) {
				$('#queue-callswaiting_editarFila').selectpicker('val', filas[fila].queue_callswaiting);
				aux = 1;
			} else if (aux != 1) {
				$('#queue-callswaiting_editarFila').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#queue-thankyou_editarFila option').each(function(){
			if ($(this).val() == filas[fila].queue_thankyou) {
				$('#queue-thankyou_editarFila').selectpicker('val', filas[fila].queue_thankyou);
				aux = 1;
			} else if (aux != 1) {
				$('#queue-thankyou_editarFila').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#queue-thereare_editarFila option').each(function(){
			if ($(this).val() == filas[fila].queue_thereare) {
				$('#queue-thereare_editarFila').selectpicker('val', filas[fila].queue_thereare);
				aux = 1;
			} else if (aux != 1) {
				$('#queue-thereare_editarFila').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#queue-youarenext_editarFila option').each(function(){
			if ($(this).val() == filas[fila].queue_youarenext) {
				$('#queue-youarenext_editarFila').selectpicker('val', filas[fila].queue_youarenext);
				aux = 1;
			} else if (aux != 1) {
				$('#queue-youarenext_editarFila').selectpicker('val', 'null');
			}
		});
		
		$("#editarFilaModal").modal();
		$("#editarFilaModal").css('overflow-y', 'scroll');
		
	});
	
	
	
	var max_fields = 32;
	var wrapper = $(".containerNovoMembro");
  
    var x = 1;
	var z = 1;
	var texto = "";
    $("#add_novoMembro").click(function(e){
        e.preventDefault();
        if (x < max_fields) {
            x++;
			z++;
			texto = "";
			texto += '<li class="list-group-item"><div class="row clearfix">';
			texto += '<div class="col-md-2 col-sm-3 col-xs-5 form-control-label"><label for="member_novaFila-'+z+'">Membros</label></div>';
			texto += '<div class="col-md-3 col-sm-3 col-xs-7"><div class="form-group form-float" style="margin-bottom: 0px;">';
			texto += '<select name="member[]" id="member_novaFila-'+z+'" class="form-control show-tick">';
			texto += '<option value=""> - </option>';
			<?php
				foreach ($ramais_sip as $ramal=>$vetor) {
					print "texto += '<option value=\"SIP/".$ramal."\">SIP/".$ramal."</option>';";
				}
				foreach ($ramais_iax as $ramal=>$vetor) {
					print "texto += '<option value=\"IAX2/".$ramal."\">IAX2/".$ramal."</option>';";
				}
			?>
			texto += '</select></div></div>';
			texto += '<div class="col-md-2 col-sm-3 col-xs-5 form-control-label"><label>Prioridade</label></div>';
			texto += '<div class="col-md-3 col-sm-3 col-xs-7"><div class="form-group form-float" style="margin-bottom: 0px;">';
			texto += '<select name="prio[]" id="prio_novaFila-'+z+'" class="form-control show-tick">';
			texto += '<option value="no">Não</option><option value="0">0</option><option value="1">1</option>';
			texto += '<option value="2">2</option><option value="3">3</option><option value="4">4</option>';
			texto += '<option value="5">5</option><option value="6">6</option><option value="7">7</option>';
			texto += '<option value="8">8</option><option value="9">9</option>';
			texto += '</select></div></div>';
			texto += '</div><a href="#" class="delete">Delete</a></li>';
            $(wrapper).append(
				texto
			);
			$('#member_novaFila-'+z).addClass('selectpicker');
			$('#member_novaFila-'+z).selectpicker('refresh');
			$('#prio_novaFila-'+z).addClass('selectpicker');
			$('#prio_novaFila-'+z).selectpicker('refresh');
        } else {
			alert('Limite alcançado!');
		}
    });
  
    $(wrapper).on("click",".delete", function(e){
        e.preventDefault(); $(this).parent('li').remove(); x--;
    })
	
	$("#add_editarMembro").click(function(e){
		e.preventDefault();
		add_editarMembro();
	})
	
	$(wrapper_editar).on("click",".delete", function(e){
        e.preventDefault(); $(this).parent('li').remove(); y--;
    })
	

});

</script>