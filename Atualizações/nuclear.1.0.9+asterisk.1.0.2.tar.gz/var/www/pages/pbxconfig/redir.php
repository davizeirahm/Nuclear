<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.config.ramal.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.categorias.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.redir.php");

	//PARA OBTER OS DESTINOS
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_sip.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_iax2.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.filas.php");
	//require_once(DIR_WWW."funcoes/funcoes.pbxconfig.telefonista.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.abreviados.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.calendario.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.faixa_discagem.php");//PARA A URA
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.ura.php");

	// DECLARAÇÃO DE VARIÁVEIS ==============================================================================================
	
	$redirs = get_redirs();
	//echo json_encode($redirs, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
	
	$ramais_sip = get_ramais();
	$ramais_iax2 = get_ramais_iax();
	$filas = get_filas();
	$abreviados = get_abreviados();
	$calendarios = get_calendarios();
	$uras = get_uras();
	$uras_custom = get_uras_custom();
	//$opc = get_num_telefonista();
	
	$destinos = array();
	//$destinos[] = "<option value=\"opc\">Telefonista</option>";
	foreach($filas as $key=>$value) {
		$destinos[] = "<option value=\"QUE/".$key."\">QUE/".$key."</option>";
	}
	foreach($calendarios as $key=>$value) {
		$destinos[] = "<option value=\"CAL/".$key."\">CAL/".$key."</option>";
	}
	foreach($uras as $key=>$value) {
		$destinos[] = "<option value=\"URA/".$key."\">URA/".$key."</option>";
	}
	foreach($uras_custom as $key=>$value) {
		$destinos[] = "<option value=\"URA/".$key."\">URA/".$key."</option>";
	}
	foreach($abreviados as $key=>$value) {
		$exp = explode("/", $value['abreviados'][1]['tronco']);
		if ($exp[0] == "SIP" || $exp[0] == "IAX2") {
			$destinos[] = "<option value=\"ABB/".$key."\">ABB/".$key."</option>";
		}
	}
	foreach($ramais_sip as $key=>$value) {
		$destinos[] ="<option value=\"SIP/".$key."\">SIP/".$key."</option>";
	}
	foreach($ramais_iax2 as $key=>$value) {
		$destinos[] = "<option value=\"IAX2/".$key."\">IAX2/".$key."</option>";
	}

	//REDIR ===============================================================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "novoRedirecionamento") {
		//print_r($_POST);
		//die();
		$erro = "";
		if (!isset($_POST['origem']) ) {
			$erro = "Erro: 0x00000000!";
		}
		if ( !isset($_POST['destino']) ) {
			$erro = "Erro: 0x00000001!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !novo_redir($_POST) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "editarRedirecionamento") {
		
		$erro="";
		if (!isset($_POST['editarRedir']) || @$_POST['editarRedir'] == "") {
			$erro = "Erro: Redirecionamento Inválida!";
		}
		if (!isset($_POST['origem']) ) {
			$erro = "Erro: 0x00000000!";
		}
		if ( !isset($_POST['destino']) ) {
			$erro = "Erro: 0x00000001!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !editar_redir($_POST) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirRedirecionamento") {
		
		$erro="";
		if (!isset($_POST['redir']) || @$_POST['redir'] == "") {
			$erro = "Erro: Redirecionamento Inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !excluir_redir($_POST['redir']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}

?>


	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- MENU ROTAS -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
						<div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
                                	<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
						</div>
                        <div class="body">
                            
							<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novoRedirecionamentoModal">
								<i class="material-icons">add_circle</i>
								<span>NOVO REDIRECIONAMENTO</span>
							</button>
							<div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
                                            <th>Origem</th>
											<th>Destino</th>
											<th>Ocupado</th>
											<th>Não Atende</th>
											<th>Externo</th>
											<th>Interno</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<?php
									foreach($redirs as $redir=>$value) {
									?>
										<tr>
											<td><?=$value['origem'];?></td>
											<td><?=$value['destino'];?></td>
											<td><?=$value['busy'];?></td>
											<td><?=$value['noans'];?></td>
											<td><?=$value['ext'];?></td>
											<td><?=$value['int'];?></td>
											<td>
												<a href="javascript:;" class="editar-redir" data-id="<?=$redir;?>" data-toggle="modal" data-target="#editarRedirecionamentoModal"><i class="material-icons" title="Editar">edit</i></a>&nbsp;
												<a href="javascript:;" class="play" onclick="botaoExcluirRedirecionamento('<?=$redir;?>')"><i class="material-icons" title="Excluir">delete</i></a>
											</td>
										</tr>
									<?php
									}
									?>
                                    </tbody>
                                </table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--END - PAGE CONTENT-->


	<!-- MODAL ================================================================================================================================== -->

		<!--MODAL NOVO REDIR-->
            <div class="modal fade" id="novoRedirecionamentoModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="modal-title" id="novoRedirecionamentoLabel">Novo Redirecionamento</h2>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
							<form id="formNovoRedirecionamento" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="novoRedirecionamento" />
							
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="origem_novoRedirecionamento">Origem</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group form-float">
                                            <select name="origem" id="origem_novoRedirecionamento" class="form-control show-tick" data-live-search="true">
											<?php
                                                foreach($ramais_sip as $key=>$value) {
													print "<option value=\"SIP/".$key."\">SIP/".$key."</option>";
												}
												foreach($ramais_iax2 as $key=>$value) {
													print "<option value=\"IAX2/".$key."\">IAX2/".$key."</option>";
												}
												foreach($filas as $key=>$value) {
													print "<option value=\"QUE/".$key."\">QUE/".$key."</option>";
												}
											?>
                                            </select>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="destino_novoRedirecionamento">Destino</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group form-float">
                                            <select name="destino" id="destino_novoRedirecionamento" class="form-control show-tick" data-live-search="true">
											<?php
                                                foreach($destinos as $key=>$value) {
													print $value;
												}
											?>
                                            </select>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
									<div class="col-md-12 col-sm-12 col-xs-12 form-control-label" style="margin-bottom: 0px; width: auto; box-shadow: none;">
										<input type="checkbox" name="busy" id="busy_novoRedirecionamento" value="yes" class="filled-in chk-col-light-blue"/>
										<label for="busy_novoRedirecionamento">Ocupado</label>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-6 col-sm-6 col-xs-12 form-control-label" style="margin-bottom: 0px; width: auto; box-shadow: none;">
										<input type="checkbox" name="noans" id="noans_novoRedirecionamento" value="yes" class="filled-in chk-col-light-blue"/>
										<label for="noans_novoRedirecionamento">Não Atende</label>
									</div>
									<div class="col-md-2 col-sm-2 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="timeout_novoRedirecionamento">Timeout</label>
                                    </div>
                                    <div class="col-md-4 col-sm-4 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="timeout" id="timeout_novoRedirecionamento" class="form-control timeout">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
									<div class="col-md-12 col-sm-12 col-xs-12 form-control-label" style="margin-bottom: 0px; width: auto; box-shadow: none;">
										<input type="checkbox" name="int" id="int_novoRedirecionamento" value="yes" class="filled-in chk-col-light-blue"/>
										<label for="int_novoRedirecionamento">Ativado para ligações internas</label>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-12 col-sm-12 col-xs-12 form-control-label" style="margin-bottom: 0px; width: auto; box-shadow: none;">
										<input type="checkbox" name="ext" id="ext_novoRedirecionamento" value="yes" class="filled-in chk-col-light-blue"/>
										<label for="ext_novoRedirecionamento">Ativado para ligações externas</label>
									</div>
								</div>
								
							</div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
                            <button type="button" id="closenovoRedirecionamentoModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
							</form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL NOVO REDIR-->
		

		<!--MODAL EDITAR REDIR-->
			<div class="modal fade" id="editarRedirecionamentoModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="modal-title" id="editarRedirecionamentoLabel">Editar Redirecionamento</h2>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
							<form id="formNovoRedirecionamento" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="editarRedirecionamento" />
							<input type="hidden" id="editarRedirecionamento" name="editarRedir" value="" />

								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="origem_editarRedirecionamento">Origem</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group form-float">
                                            <select name="origem" id="origem_editarRedirecionamento" class="form-control show-tick" data-live-search="true">
											<?php
                                                foreach($ramais_sip as $key=>$value) {
													print "<option value=\"SIP/".$key."\">SIP/".$key."</option>";
												}
												foreach($ramais_iax2 as $key=>$value) {
													print "<option value=\"IAX2/".$key."\">IAX2/".$key."</option>";
												}
												foreach($filas as $key=>$value) {
													print "<option value=\"QUE/".$key."\">QUE/".$key."</option>";
												}
											?>
                                            </select>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="destino_editarRedirecionamento">Destino</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group form-float">
                                            <select name="destino" id="destino_editarRedirecionamento" class="form-control show-tick" data-live-search="true">
											<?php
                                                foreach($destinos as $key=>$value) {
													print $value;
												}
											?>
                                            </select>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
									<div class="col-md-12 col-sm-12 col-xs-12 form-control-label" style="margin-bottom: 0px; width: auto; box-shadow: none;">
										<input type="checkbox" name="busy" id="busy_editarRedirecionamento" value="yes" class="filled-in chk-col-light-blue"/>
										<label for="busy_editarRedirecionamento">Ocupado</label>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-6 col-sm-6 col-xs-12 form-control-label" style="margin-bottom: 0px; width: auto; box-shadow: none;">
										<input type="checkbox" name="noans" id="noans_editarRedirecionamento" value="yes" class="filled-in chk-col-light-blue"/>
										<label for="noans_editarRedirecionamento">Não Atende</label>
									</div>
									<div class="col-md-2 col-sm-2 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="timeout_editarRedirecionamento">Timeout</label>
                                    </div>
                                    <div class="col-md-4 col-sm-4 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="timeout" id="timeout_editarRedirecionamento" class="form-control timeout">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
									<div class="col-md-12 col-sm-12 col-xs-12 form-control-label" style="margin-bottom: 0px; width: auto; box-shadow: none;">
										<input type="checkbox" name="int" id="int_editarRedirecionamento" value="yes" class="filled-in chk-col-light-blue"/>
										<label for="int_editarRedirecionamento">Ativado para ligações internas</label>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-12 col-sm-12 col-xs-12 form-control-label" style="margin-bottom: 0px; width: auto; box-shadow: none;">
										<input type="checkbox" name="ext" id="ext_editarRedirecionamento" value="yes" class="filled-in chk-col-light-blue"/>
										<label for="ext_editarRedirecionamento">Ativado para ligações externas</label>
									</div>
								</div>

							</div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
                            <button type="button" id="closeeditarRedirecionamentoModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
							</form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EDITAR REDIR-->


	    <!--MODAL EXCLUIR REDIR-->
            <div class="modal fade" id="excluirRedirecionamentoModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirRedirecionamentoLabel">Excluir Redirecionamento</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirRedirecionamento" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="excluirRedirecionamento" />
				<input type="hidden" id="excluirRedirecionamento" name="redir" value="" />
			    <p>Tem certeza que deseja excluir o Redirecionamento?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
							<button type="button" id="closeExcluirRedirecionamentoModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR REDIR-->

	<!--#END - MODAL ============================================================================================================================== -->

<script>

function botaoExcluirRedirecionamento(excluirRedirecionamento) {
	$('#excluirRedirecionamento').val(excluirRedirecionamento);

	$('#excluirRedirecionamentoLabel').text("Excluir Redirecionamento "+excluirRedirecionamento);
	$("#excluirRedirecionamentoModal").modal();
};

$(document).ready(function(){

	var redirs = <?php echo json_encode($redirs, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>
	/*
	{"4004":{
		"busy":"yes",
		"noans":"yes",
		"timeout":"25",
		"ext":"yes",
		"int":"no",
		"origem":"SIP/4004",
		"destino":"SIP/4005"
	},
	"4000":{"busy":"no","noans":"no","timeout":"0","ext":"yes","int":"yes","origem":"SIP/4000","destino":"SIP/4001"}}
	*/

	$(".editar-redir").on('click', function(event) {
		event.preventDefault();

		var redir = $(this).data('id');

		document.getElementById('editarRedirecionamentoLabel').innerHTML = "Editar Redirecionamento: "+redir;

		$('#editarRedirecionamento').val(redir);
		
		var aux = 0;
		$('#origem_editarRedirecionamento option').each(function(){
			if ($(this).val() == redirs[redir].origem) {
				$('#origem_editarRedirecionamento').selectpicker('val', redirs[redir].origem);
				aux = 1;
			} else if (aux != 1) {
				$('#origem_editarRedirecionamento').selectpicker('val', '');
			}
		});
		aux = 0;
		$('#destino_editarRedirecionamento option').each(function(){
			if ($(this).val() == redirs[redir].destino) {
				$('#destino_editarRedirecionamento').selectpicker('val', redirs[redir].destino);
				aux = 1;
			} else if (aux != 1) {
				$('#destino_editarRedirecionamento').selectpicker('val', '');
			}
		});
		
		if (redirs[redir].busy == 'yes') {
			$('#busy_editarRedirecionamento').prop('checked',true);
		} else {
			$('#busy_editarRedirecionamento').prop('checked',false);
		}
		if (redirs[redir].noans == 'yes') {
			$('#noans_editarRedirecionamento').prop('checked',true);
		} else {
			$('#noans_editarRedirecionamento').prop('checked',false);
		}
		
		$('#timeout_editarRedirecionamento').val(redirs[redir].timeout);
		
		if (redirs[redir].ext == 'yes') {
			$('#ext_editarRedirecionamento').prop('checked',true);
		} else {
			$('#ext_editarRedirecionamento').prop('checked',false);
		}
		if (redirs[redir].int == 'yes') {
			$('#int_editarRedirecionamento').prop('checked',true);
		} else {
			$('#int_editarRedirecionamento').prop('checked',false);
		}
		
	});

});

</script>