<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.config_e1.php"); //PARA OBTER TRONCOS G1, G2, etc.
	require_once(DIR_WWW."funcoes/funcoes.config.ramal.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.categorias.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.rotas_saida.php"); //TRONCOS
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.abreviados.php");

	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.filas.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.faixa_discagem.php");//PARA A URA
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.ura.php");

	// DECLARAÇÃO DE VARIÁVEIS ==============================================================================================
	
	$abreviados = get_abreviados();
	//echo json_encode($abreviados, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
	
	$filas = get_filas();
	$uras = get_uras();
	$uras_custom = get_uras_custom();
	
	$troncos = get_troncos();
	foreach($filas as $key=>$value) {
		$troncos[] = "QUE/".$key;
	}
	foreach($uras as $key=>$value) {
		$troncos[] = "URA/".$key;
	}
	foreach($uras_custom as $key=>$value) {
		$troncos[] = "URA/".$key;
	}


	$operadoras = get_operadoras();

	//ROTAS ===============================================================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "novoAbreviado") {
		//print_r($_POST);
		//die();
		$erro = "";
		if (!isset($_POST['numero']) || @$_POST['numero'] == "") {
			$erro = "Erro: Dialplan inválido!";
		}
		if ( !isset($_POST['tronco']) ) {
			$erro = "Erro: 0x00000000!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !novo_abreviado($_POST) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "editarAbreviado") {
		
		$erro="";
		if (!isset($_POST['editarnumero']) || @$_POST['editarnumero'] == "") {
			$erro = "Erro: Abreviado Inválida!";
		}
		if (!isset($_POST['numero']) || @$_POST['numero'] == "") {
			$erro = "Erro: Número inválido!";
		}
		if ( !isset($_POST['tronco']) ) {
			$erro = "Erro: 0x00000000!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !editar_abreviado($_POST) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirAbreviado") {
		
		$erro="";
		if (!isset($_POST['numero']) || @$_POST['numero'] == "") {
			$erro = "Erro: Abreviado Inválida!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !excluir_abreviado($_POST['numero']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}

?>


	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- MENU ROTAS -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
						<div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
                                	<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
						</div>
                        <div class="body">
                            
							<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novoAbreviadoModal">
								<i class="material-icons">add_circle</i>
								<span>NOVO ABREVIADO</span>
							</button>
							<div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
                                            <th>Número</th>
											<th>Categoria</th>
											<th>Destino primário</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<?php
									foreach($abreviados as $abreviado=>$vetor) {
										if (is_array($vetor)) {
											if ( substr($vetor['abreviados'][1]['tronco'], 0, 3) == "QUE" || substr($vetor['abreviados'][1]['tronco'], 0, 3) == "URA") {
												$destino = $vetor['abreviados'][1]['tronco'];
											} else {
												$destino = $vetor['abreviados'][1]['destino'];
											}
									?>
										<tr>
											<td><?=$abreviado;?></td>
											<td><?=$vetor['categoria'];?></td>
											<td><?=$destino;?></td>
											<td>
												<a href="javascript:;" class="editar-abreviado" data-id="<?=$abreviado;?>" data-toggle="modal" data-target="#editarAbreviadoModal"><i class="material-icons" title="Editar">edit</i></a>&nbsp;
												<a href="javascript:;" class="play" onclick="botaoExcluirAbreviado('<?=$abreviado;?>')"><i class="material-icons" title="Excluir">delete</i></a>
											</td>
										</tr>
									<?php
										}
									}
									?>
                                    </tbody>
                                </table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--END - PAGE CONTENT-->


	<!-- MODAL ================================================================================================================================== -->

		<!--MODAL NOVA ROTA-->
            <div class="modal fade" id="novoAbreviadoModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="modal-title" id="novoAbreviadoLabel">Novo Abreviado</h2>
							<small>(Necessário criar faixa de discagem)</small>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
							<form id="formNovoAbreviado" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="novoAbreviado" />

								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="numero_novoAbreviado">Número</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="numero" id="numero_novoAbreviado" class="form-control dialplan">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="categoria_novoAbreviado">Categoria</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group form-float">
                                            <select name="categoria" id="categoria_novoAbreviado" class="form-control show-tick">
                                                <option value="1">1</option>
												<option value="2">2</option>
												<option value="3">3</option>
												<option value="4">4</option>
												<option value="5">5</option>
												<option value="6">6</option>
												<option value="7">7</option>
												<option value="8">8</option>
												<option value="9">9</option>
												<option value="10">10</option>
                                            </select>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
									<div class="col-md-12 col-sm-12 col-xs-12 form-control-label" style="margin-bottom: 0px;">
										<input type="checkbox" name="grava" id="grava_novoAbreviado" value="yes" class="filled-in chk-col-light-blue"/>
										<label for="grava_novoAbreviado">Gravar Abreviado</label>
									</div>
								</div>
								<div class="row clearfix">
									<div class="body">
										<ul class="list-group container1">
											<li class="list-group-item">
												<div class="row clearfix">
													<div class="col-md-2 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label>Tronco</label>
													</div>
													<div class="col-md-10 col-sm-8 col-xs-7">
														<div class="form-group form-float" style="margin-bottom: 0px;">
															<select name="tronco[]" id="tronco_novoAbreviado-0" class="form-control show-tick">
																<option value=""> - </option>
																<?php
																	foreach($troncos as $value) {
																		print "<option value=\"".$value."\">".$value."</option>";
																	}
																?>
															</select>
														</div>
													</div>
													<div class="col-md-2 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label for="insere_novoAbreviado-0">Insere</label>
													</div>
													<div class="col-md-2 col-sm-8 col-xs-7">
														<div class="form-group" style="margin-bottom: 0px;">
															<div class="form-line">
																<input type="text" name="insere[]" id="insere_novoAbreviado-0" value="" class="form-control alphanumeric">
															</div>
														</div>
													</div>
													<div class="col-md-2 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label for="destino_novoAbreviado-0">Destino</label>
													</div>
													<div class="col-md-6 col-sm-8 col-xs-7">
														<div class="form-group" style="margin-bottom: 0px;">
															<div class="form-line">
																<input type="text" name="destino[]" id="destino_novoAbreviado-0" value="" class="form-control alphanumeric">
															</div>
														</div>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label>Portabilidade</label>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-7">
														<div class="form-group form-float" style="margin-bottom: 0px;">
															<select name="portabilidade[]" id="portabilidade_novoAbreviado-0" class="form-control show-tick">
																<option value="0">Não</option>
																<option value="1">Sim</option>
															</select>
														</div>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label>Operadora</label>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-7">
														<div class="form-group form-float" style="margin-bottom: 0px;">
															<select name="operadora[]" id="operadora_novoAbreviado-0" class="form-control show-tick">
																<option value=""> - </option>
																<?php
																	foreach($operadoras as $key=>$value) {
																		print "<option value=\"".$key."\">".$key."</option>";
																	}
																?>
															</select>
														</div>
													</div>
												</div>
											</li>
										</ul>
										<button type="" class="btn btn-primary waves-effect" id="add_novoAbreviado">
											<i class="material-icons">add_circle</i>
											<span>Adicionar</span>
										</button>
									</div>
								</div>

							</div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
                            <button type="button" id="closenovoAbreviadoModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
							</form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL NOVA ROTA-->
		

		<!--MODAL EDITAR ROTA-->
			<div class="modal fade" id="editarAbreviadoModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="modal-title" id="editarAbreviadoLabel">Editar Abreviado</h2>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
							<form id="formNovoAbreviado" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="editarAbreviado" />
							<input type="hidden" id="editarAbreviado" name="editarnumero" value="" />

								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="numero_editarAbreviado">Número</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="numero" id="numero_editarAbreviado" class="form-control dialplan">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="categoria_editarAbreviado">Categoria</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group form-float">
                                            <select name="categoria" id="categoria_editarAbreviado" class="form-control show-tick">
                                                <option value="1">1</option>
												<option value="2">2</option>
												<option value="3">3</option>
												<option value="4">4</option>
												<option value="5">5</option>
												<option value="6">6</option>
												<option value="7">7</option>
												<option value="8">8</option>
												<option value="9">9</option>
												<option value="10">10</option>
                                            </select>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
									<div class="col-md-12 col-sm-12 col-xs-12 form-control-label" style="margin-bottom: 0px;">
										<input type="checkbox" name="grava" id="grava_editarAbreviado" value="yes" class="filled-in chk-col-light-blue"/>
										<label for="grava_editarAbreviado">Gravar Abreviado</label>
									</div>
								</div>
								<div class="row clearfix">
									<div class="body">
										<ul class="list-group container-editar">
											<li class="list-group-item">
												<div class="row clearfix">
													<div class="col-md-2 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label>Tronco</label>
													</div>
													<div class="col-md-10 col-sm-8 col-xs-7">
														<div class="form-group form-float" style="margin-bottom: 0px;">
															<select name="tronco[]" id="tronco_editarAbreviado-1" class="form-control show-tick">
																<option value=""> - </option>
																<?php
																	foreach($troncos as $value) {
																		print "<option value=\"".$value."\">".$value."</option>";
																	}
																?>
															</select>
														</div>
													</div>
													<div class="col-md-2 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label for="insere_editarAbreviado-1">Insere</label>
													</div>
													<div class="col-md-2 col-sm-8 col-xs-7">
														<div class="form-group" style="margin-bottom: 0px;">
															<div class="form-line">
																<input type="text" name="insere[]" id="insere_editarAbreviado-1" value="" class="form-control alphanumeric">
															</div>
														</div>
													</div>
													<div class="col-md-2 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label for="destino_editarAbreviado-1">Destino</label>
													</div>
													<div class="col-md-6 col-sm-8 col-xs-7">
														<div class="form-group" style="margin-bottom: 0px;">
															<div class="form-line">
																<input type="text" name="destino[]" id="destino_editarAbreviado-1" value="" class="form-control alphanumeric">
															</div>
														</div>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label>Portabilidade</label>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-7">
														<div class="form-group form-float" style="margin-bottom: 0px;">
															<select name="portabilidade[]" id="portabilidade_editarAbreviado-1" class="form-control show-tick">
																<option value="0">Não</option>
																<option value="1">Sim</option>
															</select>
														</div>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label>Operadora</label>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-7">
														<div class="form-group form-float" style="margin-bottom: 0px;">
															<select name="operadora[]" id="operadora_editarAbreviado-1" class="form-control show-tick">
																<option value=""> - </option>
																<?php
																	foreach($operadoras as $key=>$value) {
																		print "<option value=\"".$key."\">".$key."</option>";
																	}
																?>
															</select>
														</div>
													</div>
												</div>
											</li>
										</ul>
										<button type="" class="btn btn-primary waves-effect" id="add_editarAbreviado">
											<i class="material-icons">add_circle</i>
											<span>Adicionar</span>
										</button>
									</div>
								</div>

							</div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
                            <button type="button" id="closeeditarAbreviadoModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
							</form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EDITAR ROTA-->


	    <!--MODAL EXCLUIR ROTA-->
            <div class="modal fade" id="excluirAbreviadoModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirAbreviadoLabel">Excluir Abreviado</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirAbreviado" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="excluirAbreviado" />
				<input type="hidden" id="excluirAbreviado" name="numero" value="" />
			    <p>Tem certeza que deseja excluir a Abreviado?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
							<button type="button" id="closeExcluirAbreviadoModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR ROTA-->

	<!--#END - MODAL ============================================================================================================================== -->

<script>

var wrapper_editar = $(".container-editar");
var max_fields_editar = 32;
var y = 1;
var w = 1;
var arrayEditar = [1];
var texto = "";

//Variaveis novo abreviado add_novoAbreviado
var x = 1;
var z = 1;
var arrayNovo = [0];

function del_editarAbreviado() {
	if (w > 1) {
		for (i=2; i<=w; i++) {
			$('#li-'+i).remove();
		}
	}
	y = 1;
	w = 1;
}

function add_editarAbreviado() {
	if (y < max_fields_editar) {
		y++;
		w++;
		texto = "";
		texto += '<li class="list-group-item" id="li-'+w+'"><div class="row clearfix">';
		texto += '<div class="col-md-2 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;"><label>Tronco</label></div>';
		texto += '<div class="col-md-10 col-sm-8 col-xs-7"><div class="form-group form-float" style="margin-bottom: 0px;">';
		texto += '<select name="tronco[]" id="tronco_editarAbreviado-'+w+'" class="form-control show-tick">';
		texto += '<option value=""> - </option>';
		<?php
			foreach($troncos as $value) {
				print "texto += '<option value=\"".$value."\">".$value."</option>';";
			}
		?>
		texto += '</select></div></div>';
		texto += '<div class="col-md-2 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;">';
		texto += '<label for="insere_editarAbreviado-'+w+'">Insere</label></div>';
		texto += '<div class="col-md-2 col-sm-8 col-xs-7"><div class="form-group" style="margin-bottom: 0px;"><div class="form-line">';
		texto += '<input type="text" name="insere[]" id="insere_editarAbreviado-'+w+'" value="" class="form-control alphanumeric">';
		texto += '</div></div></div>';
		texto += '<div class="col-md-2 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;">';
		texto += '<label for="destino_editarAbreviado-'+w+'">Destino</label></div>';
		texto += '<div class="col-md-6 col-sm-8 col-xs-7"><div class="form-group" style="margin-bottom: 0px;"><div class="form-line">';
		texto += '<input type="text" name="destino[]" id="destino_editarAbreviado-'+w+'" value="" class="form-control alphanumeric">';
		texto += '</div></div></div>';
		texto += '<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;"><label>Portabilidade</label></div>';
		texto += '<div class="col-md-3 col-sm-3 col-xs-7"><div class="form-group form-float" style="margin-bottom: 0px;">';
		texto += '<select name="portabilidade[]" id="portabilidade_editarAbreviado-'+w+'" class="form-control show-tick">';
		texto += '<option value="0">Não</option><option value="1">Sim</option>';
		texto += '</select></div></div>';
		texto += '<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;"><label>Operadora</label></div>';
		texto += '<div class="col-md-3 col-sm-3 col-xs-7"><div class="form-group form-float" style="margin-bottom: 0px;">';
		texto += '<select name="operadora[]" id="operadora_editarAbreviado-'+w+'" class="form-control show-tick">';
		texto += '<option value=""> - </option>';
		<?php
			foreach($operadoras as $key=>$value) {
				print "texto += '<option value=\"".$key."\">".$key."</option>';";
			}
		?>
		texto += '</select></div></div></div><a href="#" data-id="'+w+'" class="delete">Delete</a></li>';
        $(wrapper_editar).append(
			texto
		);
		//REFRESH NO SELECTPICKER PRA PODER ATUALIZAR O VALOR
		$('#tronco_editarAbreviado-'+w).addClass('selectpicker');
		$('#tronco_editarAbreviado-'+w).selectpicker('refresh');
		$('#portabilidade_editarAbreviado-'+w).addClass('selectpicker');
		$('#portabilidade_editarAbreviado-'+w).selectpicker('refresh');
		$('#operadora_editarAbreviado-'+w).addClass('selectpicker');
		$('#operadora_editarAbreviado-'+w).selectpicker('refresh');
		reloadOnChange();
		arrayEditar.push(w);
    } else {
		alert('Limite alcançado!')
	}
};

function botaoExcluirAbreviado(excluirAbreviado) {
	$('#excluirAbreviado').val(excluirAbreviado);

	$('#excluirAbreviadoLabel').text("Excluir Abreviado "+excluirAbreviado);
	$("#excluirAbreviadoModal").modal();
};

function reloadOnChange() {
	$(function () {
		$('select[name="tronco[]"]').on("changed.bs.select", function(e, clickedIndex, newValue, oldValue) {
			var selected = $(this).find('option').eq(clickedIndex).text();
			//console.log('Selecionado: ' + selected);
			//console.log(e.target.id);
			if (selected.substring(0,3) == "QUE" || selected.substring(0,3) == "URA" || selected.substring(0,3) == "CAL") {
				//alert("Qualquer rota adcionada neste abreviado após esta será ignorada!");
				if (e.target.id.substring(7,11) == "novo") {
					$("#add_novoAbreviado").prop('disabled', true);
				} else {
					$("#add_editarAbreviado").prop('disabled', true);
				}
			} else {
				var indiceTronco = e.target.id.substr(e.target.id.indexOf("-")+1);
				//console.log( indiceTronco );
				if (e.target.id.substring(7,11) == "novo") {
					//console.log( z-1 );
					//if ( z-1 == indiceTronco )
					if (indiceTronco == arrayNovo[arrayNovo.length - 1])
						$("#add_novoAbreviado").prop('disabled', false);
				} else {
					//if ( w == indiceTronco )
					if (indiceTronco == arrayEditar[arrayEditar.length - 1])
						$("#add_editarAbreviado").prop('disabled', false);
				}
			}
		});
	});
};

$(document).ready(function(){
	
	reloadOnChange();

	var abreviados = <?php echo json_encode($abreviados, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>
	/*
	{"500":{
		"grava":"no","categoria":"1",
		"abreviados":{
			"1":{"destino":"02117991299005","tronco":"SIP/1000)","portabilidade":"0","operadora":""},
			"2":{"destino":"02117991299005","tronco":"SIP/1050)","portabilidade":"0","operadora":""}
		}
	},
	"3955":{"grava":"no","categoria":"1","abreviados":{"1":{"destino":"3955","tronco":"IAX2/realtimeDEV)","portabilidade":"0","operadora":""}}}}
	*/

	$(".editar-abreviado").on('click', function(event) {
		event.preventDefault();

		var abreviado = $(this).data('id');

		document.getElementById('editarAbreviadoLabel').innerHTML = "Editar Abreviado: "+abreviado;
		$("#add_editarAbreviado").prop('disabled', false);

		$('#editarAbreviado').val(abreviado);
		
		$('#numero_editarAbreviado').val(abreviado);
		
		if (abreviados[abreviado].grava == 'yes') {
			$('#grava_editarAbreviado').prop('checked',true);
		} else {
			$('#grava_editarAbreviado').prop('checked',false);
		}
		
		var aux = 0;
		$('#categoria_editarAbreviado option').each(function(){
			if ($(this).val() == abreviados[abreviado].categoria) {
				$('#categoria_editarAbreviado').selectpicker('val', abreviados[abreviado].categoria);
				aux = 1;
			} else if (aux != 1) {
				$('#categoria_editarAbreviado').selectpicker('val', 'null');
			}
		});
		
		del_editarAbreviado();
		for (var i in abreviados[abreviado].abreviados) {
			
			if (i != 1) {
				add_editarAbreviado();
			}
			
			$('#insere_editarAbreviado-'+i).val(abreviados[abreviado].abreviados[i].insere);
			$('#destino_editarAbreviado-'+i).val(abreviados[abreviado].abreviados[i].destino);
			
			aux = 0;
			$('#tronco_editarAbreviado-'+i+' option').each(function(){
				if ($(this).val() == abreviados[abreviado].abreviados[i].tronco) {
					$('#tronco_editarAbreviado-'+i).selectpicker('val', abreviados[abreviado].abreviados[i].tronco);
					aux = 1;
				} else if (aux != 1) {
					$('#tronco_editarAbreviado-'+i).selectpicker('val', 'null');
				}
				//Rotina para desabilitar o botão de adicionar
				var last = abreviados[abreviado].abreviados[i].tronco.substring(0,3);
				if ( last == "QUE" || last == "URA" || last == "CAL" ) {
					$("#add_editarAbreviado").prop('disabled', true);
				}
			});
			aux = 0;
			$('#portabilidade_editarAbreviado-'+i+' option').each(function(){
				if ($(this).val() == abreviados[abreviado].abreviados[i].portabilidade) {
					$('#portabilidade_editarAbreviado-'+i).selectpicker('val', abreviados[abreviado].abreviados[i].portabilidade);
					aux = 1;
				} else if (aux != 1) {
					$('#portabilidade_editarAbreviado-'+i).selectpicker('val', '0');
				}
			});
			aux = 0;
			$('#operadora_editarAbreviado-'+i+' option').each(function(){
				if ($(this).val() == abreviados[abreviado].abreviados[i].operadora) {
					$('#operadora_editarAbreviado-'+i).selectpicker('val', abreviados[abreviado].abreviados[i].operadora);
					aux = 1;
				} else if (aux != 1) {
					$('#operadora_editarAbreviado-'+i).selectpicker('val', 'null');
				}
			});
		}
		
	});
	
	var max_fields = 32;
	var wrapper = $(".container1");
  
	var texto = "";
    $("#add_novoAbreviado").click(function(e){
        e.preventDefault();
		if (x < max_fields) {
			texto = "";
			texto += '<li class="list-group-item"><div class="row clearfix">';
			texto += '<div class="col-md-2 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;"><label>Tronco</label></div>';
			texto += '<div class="col-md-10 col-sm-8 col-xs-7"><div class="form-group form-float" style="margin-bottom: 0px;">';
			texto += '<select name="tronco[]" id="tronco_novoAbreviado-'+z+'" class="form-control show-tick">';
			texto += '<option value=""> - </option>';
			<?php
				foreach($troncos as $value) {
					print "texto += '<option value=\"".$value."\">".$value."</option>';";
				}
			?>
			texto += '</select></div></div>';
			texto += '<div class="col-md-2 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;">';
			texto += '<label for="insere_novoAbreviado-'+z+'">Insere</label></div>';
			texto += '<div class="col-md-2 col-sm-8 col-xs-7"><div class="form-group" style="margin-bottom: 0px;"><div class="form-line">';
			texto += '<input type="text" name="insere[]" id="insere_novoAbreviado-'+z+'" value="" class="form-control alphanumeric">';
			texto += '</div></div></div>';
			texto += '<div class="col-md-2 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;">';
			texto += '<label for="destino_novoAbreviado-'+z+'">Destino</label></div>';
			texto += '<div class="col-md-6 col-sm-8 col-xs-7"><div class="form-group" style="margin-bottom: 0px;"><div class="form-line">';
			texto += '<input type="text" name="destino[]" id="destino_novoAbreviado-'+z+'" value="" class="form-control alphanumeric">';
			texto += '</div></div></div>';
			texto += '<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;"><label>Portabilidade</label></div>';
			texto += '<div class="col-md-3 col-sm-3 col-xs-7"><div class="form-group form-float" style="margin-bottom: 0px;">';
			texto += '<select name="portabilidade[]" id="portabilidade_novoAbreviado-'+z+'" class="form-control show-tick">';
			texto += '<option value="0">Não</option><option value="1">Sim</option>';
			texto += '</select></div></div>';
			texto += '<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;"><label>Operadora</label></div>';
			texto += '<div class="col-md-3 col-sm-3 col-xs-7"><div class="form-group form-float" style="margin-bottom: 0px;">';
			texto += '<select name="operadora[]" id="operadora_novoAbreviado-'+z+'" class="form-control show-tick">';
			texto += '<option value=""> - </option>';
			<?php
				foreach($operadoras as $key=>$value) {
					print "texto += '<option value=\"".$key."\">".$key."</option>';";
				}
			?>
			texto += '</select></div></div></div><a href="#" data-id="'+z+'" class="delete">Delete</a></li>';
            $(wrapper).append(
				/*'<li class="list-group-item"><div><p>some text</p></div><a href="#" class="delete">Delete</a></li>'*/
				texto
			);
			$('#tronco_novoAbreviado-'+z).addClass('selectpicker');
			$('#tronco_novoAbreviado-'+z).selectpicker('refresh');
			$('#portabilidade_novoAbreviado-'+z).addClass('selectpicker');
			$('#portabilidade_novoAbreviado-'+z).selectpicker('refresh');
			$('#operadora_novoAbreviado-'+z).addClass('selectpicker');
			$('#operadora_novoAbreviado-'+z).selectpicker('refresh');
			reloadOnChange();
			arrayNovo.push(z);
			x++;
			z++;
        } else {
			alert('Limite alcançado!')
		}
    });
  
    $(wrapper).on("click",".delete", function(e){
        e.preventDefault(); 
		$(this).parent('li').remove(); 
		x--;
		//console.log( $(this).data('id') );
		arrayNovo.splice(arrayNovo.indexOf($(this).data('id')), 1);
		//console.log( arrayNovo[arrayNovo.length - 1] );
		var last = $('#tronco_novoAbreviado-'+arrayNovo[arrayNovo.length - 1]).val().substring(0,3);
		//console.log(last);
		if ( last != "QUE" && last != "URA" && last != "CAL" ) {
			$("#add_novoAbreviado").prop('disabled', false);
		}
    })
	
	$("#add_editarAbreviado").click(function(e){
		e.preventDefault();
		add_editarAbreviado();
	})
	
	$(wrapper_editar).on("click",".delete", function(e){
        e.preventDefault(); 
		$(this).parent('li').remove(); 
		y--;
		//console.log( $(this).data('id') );
		arrayEditar.splice(arrayEditar.indexOf($(this).data('id')), 1);
		var last = $('#tronco_editarAbreviado-'+arrayEditar[arrayEditar.length - 1]).val().substring(0,3);
		//console.log(last);
		if ( last != "QUE" && last != "URA" && last != "CAL" ) {
			$("#add_editarAbreviado").prop('disabled', false);
		}
    })

});

</script>