<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.config_e1.php"); //PARA OBTER TRONCOS G1, G2, etc.
	require_once(DIR_WWW."funcoes/funcoes.config.ramal.php");
	//require_once(DIR_WWW."funcoes/funcoes.pbxconfig.categorias.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.entrada.php");
	
	//PARA OBTER OS DESTINOS
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_sip.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_iax2.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.filas.php");
	//require_once(DIR_WWW."funcoes/funcoes.pbxconfig.telefonista.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.abreviados.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.calendario.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.faixa_discagem.php");//PARA A URA
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.ura.php");

	if ( isset($_GET['tipo']) && $_GET['tipo'] == "custom") {
		$tipo = "custom";
	} else {
		$tipo = "entradas";
	}

	// DECLARAÇÃO DE VARIÁVEIS ==============================================================================================
	
	$ramais_sip = get_ramais();
	$ramais_iax2 = get_ramais_iax();
	$filas = get_filas();
	$abreviados = get_abreviados();
	$calendarios = get_calendarios();
	$uras = get_uras();
	$uras_custom = get_uras_custom();
	
	$entradas = get_entradas();
	//echo json_encode($entradas, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
	
	$entradas_custom = get_entradas_custom();
	
	//$troncos = get_troncos();

	//ENTRADAS ===============================================================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "novaEntrada") {
		//print_r($_POST);
		//die();
		//[entrada] => entrada1 [did] => [nome] => [tipo] => ABB [destino] => SIP/4000

		$erro = "";
		if (!isset($_POST['entrada']) || @$_POST['entrada'] == "") {
			$erro = "Erro: Entrada inválida!";
		}
		if ( !isset($_POST['did']) || @$_POST['did'] == "") {
			$erro = "Erro: DID inválido!";
		}
		if ( !isset($_POST['tipo']) || @$_POST['tipo'] == "") {
			$erro = "Erro: Tipo inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !nova_entrada($_POST) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "editarEntrada") {
		//print_r($_POST);
		//die();
		//[editar_contexto] => entrada1 [editar_did] => 4050 [entrada] => entrada1 [did] => 4050 [nome] => RAMAL4000 [tipo] => ramal [destino] => SIP/4000
		
		$erro = "";
		if (!isset($_POST['editar_contexto']) || @$_POST['editar_contexto'] == "") {
			$erro = "Erro: 0x00000000!";
		}
		if ( !isset($_POST['editar_did']) || @$_POST['editar_did'] == "") {
			$erro = "Erro: 0x00000001!";
		}
		if (!isset($_POST['entrada']) || @$_POST['entrada'] == "") {
			$erro = "Erro: Entrada inválida!";
		}
		if ( !isset($_POST['did']) || @$_POST['did'] == "") {
			$erro = "Erro: DID inválido!";
		}
		if ( !isset($_POST['tipo']) || @$_POST['tipo'] == "") {
			$erro = "Erro: Tipo inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !editar_entrada($_POST) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirEntrada") {
		
		$erro="";
		if (!isset($_POST['contexto']) || @$_POST['contexto'] == "") {
			$erro = "Erro: 0x00000010!";
		}
		if ( !isset($_POST['did']) || @$_POST['did'] == "") {
			$erro = "Erro: 0x00000011!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !excluir_entrada($_POST['contexto'], $_POST['did']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	
	//ENTRADAS CUSTOM =============================================================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "entradaCustom") {
		
		$erro = "";
		if (!isset($_POST['nome']) || @$_POST['nome'] == "") {
			$erro = "Erro: Nome Inválido!";
		}
		if (!isset($_POST['contexto']) || @$_POST['contexto'] == "") {
			$erro = "Erro: Contexto inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if (isset($_POST['new']) && $_POST['new'] == "1") {
			//NOVO
			if ( !nova_entrada_custom($_POST['nome'], $_POST['contexto']) ) {
				print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
			} else {
				print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
			}

		} elseif (isset($_POST['new']) && $_POST['new'] == "0") {
			//EDITAR
			if ( !editar_entrada_custom($_POST['editarnome'], $_POST['nome'], $_POST['contexto']) ) {
				print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
			} else {
				print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
			}
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirEntradaCustom") {
		
		$erro="";
		if (!isset($_POST['nome']) || @$_POST['nome'] == "") {
			$erro = "Erro:  0x00000011!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !excluir_entrada_custom($_POST['nome']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}

?>


	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- MENU ENTRADAS -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
						<div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
                                	<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
						</div>
                        <div class="body">
                            <ul class="nav nav-tabs tab-nav-right" role="tablist">
                                <li role="presentation" <?php echo ( $tipo == "entradas" ? "class=\"active\"" : "" ); ?> ><a href="#entradas" data-toggle="tab">ENTRADAS</a></li>
                                <li role="presentation" <?php echo ( $tipo == "custom" ? "class=\"active\"" : "" ); ?> ><a href="#custom" data-toggle="tab">CUSTOM</a></li>
							</ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
				<!-- ENTRADAS #####################################################################################################################-->
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "entradas" ? "in active" : "" ); ?>" id="entradas">


				<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novaEntradaModal">
					<i class="material-icons">add_circle</i>
					<span>NOVA ENTRADA</span>
			    </button>
			    <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
                                            <th>DID</th>
											<th>Contexto</th>
											<th>Nome</th>
											<th>Destino</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					    <?php
						foreach ($entradas as $contexto=>$vetor) {
							foreach ($vetor as $did=>$value) {
								if ( is_array($value) ) {
									if ($value['tipo'] == "CUS") {
										$destino = "Faixa DID";
									} elseif ($value['tipo'] == "OPC") {
										$destino = "Telefonista";
									} else {
										$destino = $value['tipo']."/".$value['destino'];
									}
					    ?>
							<tr>
								<td><?=$did;?></td>
								<td><?=$contexto;?></td>
								<td><?=$value['nome'];?></td>
								<td><?=$destino;?></td>
								<td>
									<a href="javascript:;" class="play" onclick="botaoEditarEntrada('<?=$contexto;?>','<?=$did;?>')"><i class="material-icons" title="Editar">edit</i></a>&nbsp;
									<a href="javascript:;" class="play" onclick="botaoExcluirEntrada('<?=$contexto;?>','<?=$did;?>')"><i class="material-icons" title="Excluir">delete</i></a>
								</td>
						    </tr>
					    <?php
								}
							}
						}
					    ?>
                                    </tbody>
                                </table>
                </div>


								</div>
				<!--#FIM - ENTRADAS ##############################################################################################################-->
				<!-- ENTRADAS CUSTOM ##################################################################################################################-->
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "custom" ? "in active" : "" ); ?>" id="custom">
								
			    <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
                                            <th>Nome</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					    <?php
						foreach($entradas_custom as $entrada=>$vetor) {
						    if (is_array($vetor)) {
					    ?>
							<tr>
								<td><?=$entrada;?></td>
								<td>
									<a href="javascript:;" class="play" onclick="botaoEditarEntradaCustom('<?=$entrada;?>')"><i class="material-icons" title="Editar">edit</i></a>&nbsp;
									<a href="javascript:;" class="play" onclick="botaoExcluirEntradaCustom('<?=$entrada;?>')"><i class="material-icons" title="Excluir">delete</i></a>
								</td>
						    </tr>
					    <?php
						    }
						}
					    ?>
                                    </tbody>
                                </table>
                </div>
				<hr>
				<div class="body">
				
					<button type="button" class="btn btn-primary waves-effect" onclick="botaoNovaEntradaCustom()">
						<i class="material-icons">add_circle</i>
						<span>NOVA ENTRADA</span>
					</button>
				
					<form name="form_txt" id="form_entradaCustom" method="post">
						<?=$text_form;?>
						<input type="hidden" id="cmd_entradaCustom" name="cmd" value="entradaCustom" />
						<input type="hidden" id="new_entradaCustom" name="new" value="1" />
						<input type="hidden" id="editarnome_entradaCustom" name="editarnome" value="" />
						
					<div class="row clearfix">
                        <div class="col-md-2 col-sm-2 col-xs-4 form-control-label" style="margin-bottom: 0px;">
                            <label for="nome_entradaCustom">Nome</label>
                        </div>
						<div class="col-md-4 col-sm-6 col-xs-8" style="margin-bottom: 0px;">
							<div class="form-group">
								<div class="form-line">
									<input type="text" name="nome" id="nome_entradaCustom" class="form-control rota">
								</div>
							</div>
						</div>
					</div>
					
					<small>Contexto Asterisk:</small>
					<div class="form-group">
                        <div class="form-line">
							<textarea name="contexto" id="textarea_entradaCustom" rows="16" class="form-control no-resize auto-growth"></textarea>
						</div>
					</div>
					<button type="submit" class="btn btn-primary waves-effect">
						<i class="material-icons">save</i>
						<span>Salvar</span>
					</button>
					</form>
				</div>
				
								</div>
				<!-- #END# ENTRADAS CUSTOM ############################################################################################################-->

	</div>
	<!--END - PAGE CONTENT-->


	<!-- MODAL ================================================================================================================================== -->

		<!--MODAL NOVA ENTRADA-->
            <div class="modal fade" id="novaEntradaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="modal-title" id="novaEntradaLabel">Nova Entrada</h2>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
							<form id="formNovaEntrada" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="novaEntrada" />
								<div class="row clearfix">
									<div class="col-md-3 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;">
										<label>Entrada</label>
									</div>
									<div class="col-md-9 col-sm-8 col-xs-7">
										<div class="form-group form-float" style="margin-bottom: 0px;">
											<select name="entrada" id="entrada_novaEntrada" class="form-control show-tick">
												<?php
													foreach($entradas as $key=>$value) {
														print "<option value=\"".$key."\">".$key."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
                                    <div class="col-md-3 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="did_novaEntrada">Número DID</label>
                                    </div>
                                    <div class="col-md-9 col-sm-8 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="did" id="did_novaEntrada" class="form-control dialplan">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
                                    <div class="col-md-3 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="novaEntrada_nome">Nome</label>
                                    </div>
                                    <div class="col-md-9 col-sm-8 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="nome" id="nome_novaEntrada" class="form-control rota">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
									<div class="col-md-3 col-sm-3 col-xs-6" style="margin-bottom: 0px;">
										<div class="form-group demo-radio-button">
											<input name="tipo" type="radio" id="tipo_cus_novaEntrada" value="CUS"/>
											<label for="tipo_cus_novaEntrada">Faixa DID</label>
										</div>
									</div>
									<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="cut_cus_novaEntrada">Cortar digítos</label>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="cut_cus" id="cut_cus_novaEntrada" class="form-control timeout">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
									<div class="col-md-3 col-sm-3 col-xs-6" style="margin-bottom: 0px;">
										<div class="form-group demo-radio-button">
											<input name="tipo" type="radio" id="tipo_fila_novaEntrada" value="QUE"/>
											<label for="tipo_fila_novaEntrada">Fila</label>
										</div>
									</div>
									<div class="col-md-6 col-sm-6 col-xs-6">
										<div class="form-group form-float" style="margin-bottom: 0px;">
											<select name="destino" id="fila_novaEntrada" class="form-control show-tick">
												<option value=""> - </option>
												<?php
													foreach($filas as $key=>$value) {
														print "<option value=\"QUE/".$key."\">QUE/".$key."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-3 col-sm-3 col-xs-6" style="margin-bottom: 0px;">
										<div class="form-group demo-radio-button">
											<input name="tipo" type="radio" id="tipo_ura_novaEntrada" value="URA"/>
											<label for="tipo_ura_novaEntrada">URA</label>
										</div>
									</div>
									<div class="col-md-6 col-sm-6 col-xs-6">
										<div class="form-group form-float" style="margin-bottom: 0px;">
											<select name="destino" id="ura_novaEntrada" class="form-control show-tick">
												<option value=""> - </option>
												<?php
													foreach($uras as $key=>$value) {
														print "<option value=\"URA/".$key."\">URA/".$key."</option>";
													}
													foreach($uras_custom as $key=>$value) {
														print "<option value=\"URA/".$key."\">URA/".$key."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-3 col-sm-3 col-xs-6" style="margin-bottom: 0px;">
										<div class="form-group demo-radio-button">
											<input name="tipo" type="radio" id="tipo_ramal_novaEntrada" value="ramal"/>
											<label for="tipo_ramal_novaEntrada">Ramal</label>
										</div>
									</div>
									<div class="col-md-6 col-sm-6 col-xs-6">
										<div class="form-group form-float" style="margin-bottom: 0px;">
											<select name="destino" id="ramal_novaEntrada" class="form-control show-tick">
												<option value=""> - </option>
												<?php
													foreach($ramais_sip as $key=>$value) {
														print "<option value=\"SIP/".$key."\">SIP/".$key."</option>";
													}
													foreach($ramais_iax2 as $key=>$value) {
														print "<option value=\"IAX2/".$key."\">IAX2/".$key."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>
								<!--<div class="row clearfix">
									<div class="col-md-3 col-sm-3 col-xs-6" style="margin-bottom: 0px;">
										<div class="form-group demo-radio-button">
											<input name="tipo" type="radio" id="tipo_opc_novaEntrada" value="OPC"/>
											<label for="tipo_opc_novaEntrada">Telefonista</label>
										</div>
									</div>
								</div>-->
								<div class="row clearfix">
									<div class="col-md-3 col-sm-3 col-xs-6" style="margin-bottom: 0px;">
										<div class="form-group demo-radio-button">
											<input name="tipo" type="radio" id="tipo_abb_novaEntrada" value="ABB"/>
											<label for="tipo_abb_novaEntrada">Abreviado</label>
										</div>
									</div>
									<div class="col-md-6 col-sm-6 col-xs-6">
										<div class="form-group form-float" style="margin-bottom: 0px;">
											<select name="destino" id="abb_novaEntrada" class="form-control show-tick">
												<option value=""> - </option>
												<?php
													foreach($abreviados as $key=>$value) {
														print "<option value=\"ABB/".$key."\">ABB/".$key."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-3 col-sm-3 col-xs-6" style="margin-bottom: 0px;">
										<div class="form-group demo-radio-button">
											<input name="tipo" type="radio" id="tipo_cal_novaEntrada" value="CAL"/>
											<label for="tipo_cal_novaEntrada">Calendário</label>
										</div>
									</div>
									<div class="col-md-6 col-sm-6 col-xs-6">
										<div class="form-group form-float" style="margin-bottom: 0px;">
											<select name="destino" id="cal_novaEntrada" class="form-control show-tick">
												<option value=""> - </option>
												<?php
													foreach($calendarios as $key=>$value) {
														print "<option value=\"CAL/".$key."\">CAL/".$key."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>
								<div class="modal-footer">
									<button type="submit" class="btn btn-primary waves-effect">
										<i class="material-icons">save</i>
										<span>Salvar</span>
									</button>
									<button type="button" id="closenovaEntradaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
								</div>
							</form>
							</div>
						</div>
					</div>
				</div>
			</div>
	    <!--#END of MODAL NOVA ENTRADA-->

		<!--MODAL EDITAR ENTRADA-->
			<div class="modal fade" id="editarEntradaModal" tabindex="-1" role="dialog">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h4 class="modal-title" id="editarEntradaLabel">Editar Entrada</h4>
						</div>
						<div class="modal-body">
							<div class="row clearfix demo-masked-input">
								<form id="formEditarEntrada" method="post">
								<?=$text_form;?>
								<input type="hidden" name="cmd" value="editarEntrada" />
								<input type="hidden" id="editarcontexto_editarEntrada" name="editar_contexto" value="" />
								<input type="hidden" id="editardid_editarEntrada" name="editar_did" value="" />
								
								<div class="row clearfix">
									<div class="col-md-3 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;">
										<label>Entrada</label>
									</div>
									<div class="col-md-9 col-sm-8 col-xs-7">
										<div class="form-group form-float" style="margin-bottom: 0px;">
											<select name="entrada" id="entrada_editarEntrada" class="form-control show-tick">
												<?php
													foreach($entradas as $key=>$value) {
														print "<option value=\"".$key."\">".$key."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
                                    <div class="col-md-3 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="did_editarEntrada">Número DID</label>
                                    </div>
                                    <div class="col-md-9 col-sm-8 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="did" id="did_editarEntrada" class="form-control dialplan">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
                                    <div class="col-md-3 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="nome_editarEntrada">Nome</label>
                                    </div>
                                    <div class="col-md-9 col-sm-8 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="nome" id="nome_editarEntrada" class="form-control rota">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
									<div class="col-md-3 col-sm-3 col-xs-6" style="margin-bottom: 0px;">
										<div class="form-group demo-radio-button">
											<input name="tipo" type="radio" id="tipo_cus_editarEntrada" value="CUS"/>
											<label for="tipo_cus_editarEntrada">Faixa DID</label>
										</div>
									</div>
									<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="cut_cus_editarEntrada">Cortar digítos</label>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="cut_cus" id="cut_cus_editarEntrada" class="form-control timeout">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
									<div class="col-md-3 col-sm-3 col-xs-6" style="margin-bottom: 0px;">
										<div class="form-group demo-radio-button">
											<input name="tipo" type="radio" id="tipo_fila_editarEntrada" value="QUE"/>
											<label for="tipo_fila_editarEntrada">Fila</label>
										</div>
									</div>
									<div class="col-md-6 col-sm-6 col-xs-6">
										<div class="form-group form-float" style="margin-bottom: 0px;">
											<select name="destino" id="fila_editarEntrada" class="form-control show-tick">
												<option value=""> - </option>
												<?php
													foreach($filas as $key=>$value) {
														print "<option value=\"QUE/".$key."\">QUE/".$key."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-3 col-sm-3 col-xs-6" style="margin-bottom: 0px;">
										<div class="form-group demo-radio-button">
											<input name="tipo" type="radio" id="tipo_ura_editarEntrada" value="URA"/>
											<label for="tipo_ura_editarEntrada">URA</label>
										</div>
									</div>
									<div class="col-md-6 col-sm-6 col-xs-6">
										<div class="form-group form-float" style="margin-bottom: 0px;">
											<select name="destino" id="ura_editarEntrada" class="form-control show-tick">
												<option value=""> - </option>
												<?php
													foreach($uras as $key=>$value) {
														print "<option value=\"URA/".$key."\">URA/".$key."</option>";
													}
													foreach($uras_custom as $key=>$value) {
														print "<option value=\"URA/".$key."\">URA/".$key."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-3 col-sm-3 col-xs-6" style="margin-bottom: 0px;">
										<div class="form-group demo-radio-button">
											<input name="tipo" type="radio" id="tipo_ramal_editarEntrada" value="ramal"/>
											<label for="tipo_ramal_editarEntrada">Ramal</label>
										</div>
									</div>
									<div class="col-md-6 col-sm-6 col-xs-6">
										<div class="form-group form-float" style="margin-bottom: 0px;">
											<select name="destino" id="ramal_editarEntrada" class="form-control show-tick">
												<option value=""> - </option>
												<?php
													foreach($ramais_sip as $key=>$value) {
														print "<option value=\"SIP/".$key."\">SIP/".$key."</option>";
													}
													foreach($ramais_iax2 as $key=>$value) {
														print "<option value=\"IAX2/".$key."\">IAX2/".$key."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>
								<!--<div class="row clearfix">
									<div class="col-md-3 col-sm-3 col-xs-6" style="margin-bottom: 0px;">
										<div class="form-group demo-radio-button">
											<input name="tipo" type="radio" id="tipo_opc_editarEntrada" value="OPC"/>
											<label for="tipo_opc_editarEntrada">Telefonista</label>
										</div>
									</div>
								</div>-->
								<div class="row clearfix">
									<div class="col-md-3 col-sm-3 col-xs-6" style="margin-bottom: 0px;">
										<div class="form-group demo-radio-button">
											<input name="tipo" type="radio" id="tipo_abb_editarEntrada" value="ABB"/>
											<label for="tipo_abb_editarEntrada">Abreviado</label>
										</div>
									</div>
									<div class="col-md-6 col-sm-6 col-xs-6">
										<div class="form-group form-float" style="margin-bottom: 0px;">
											<select name="destino" id="abb_editarEntrada" class="form-control show-tick">
												<option value=""> - </option>
												<?php
													foreach($abreviados as $key=>$value) {
														print "<option value=\"ABB/".$key."\">ABB/".$key."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-3 col-sm-3 col-xs-6" style="margin-bottom: 0px;">
										<div class="form-group demo-radio-button">
											<input name="tipo" type="radio" id="tipo_cal_editarEntrada" value="CAL"/>
											<label for="tipo_cal_editarEntrada">Calendário</label>
										</div>
									</div>
									<div class="col-md-6 col-sm-6 col-xs-6">
										<div class="form-group form-float" style="margin-bottom: 0px;">
											<select name="destino" id="cal_editarEntrada" class="form-control show-tick">
												<option value=""> - </option>
												<?php
													foreach($calendarios as $key=>$value) {
														print "<option value=\"CAL/".$key."\">CAL/".$key."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>
								
							</div>
						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
							<button type="button" id="closeEditarEntradaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
						</div>
							</form>
					</div>
				</div>
			</div>
	    <!--#END of MODAL EDITAR ENTRADA-->


	    <!--MODAL EXCLUIR ENTRADA-->
            <div class="modal fade" id="excluirEntradaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirEntradaLabel">Excluir Entrada</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirEntrada" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="excluirEntrada" />
				<input type="hidden" id="contexto_excluirEntrada" name="contexto" value="" />
				<input type="hidden" id="did_excluirEntrada" name="did" value="" />
			    <p>Tem certeza que deseja excluir a Entrada?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
							<button type="button" id="closeExcluirEntradaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR ENTRADA-->
		
			<!-- ENTRADA CUSTOM =========================================================== -->
			
		<!--MODAL EXCLUIR ENTRADA CUSTOM-->
            <div class="modal fade" id="excluirEntradaCustomModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirEntradaCustomLabel">Excluir Entrada</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirEntradaCustom" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="excluirEntradaCustom" />
				<input type="hidden" id="excluirEntradaCustom" name="nome" value="" />
			    <p>Tem certeza que deseja excluir a Entrada?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
							<button type="button" id="closeExcluirEntradaCustomModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR ENTRADA CUSTOM-->


	<!--#END - MODAL ============================================================================================================================== -->

<script>

function disable_load(){
	$('#tipo_cus_novaEntrada').prop('checked', 'checked');
	$("#fila_novaEntrada").prop('disabled', 'disabled');
	$("#ura_novaEntrada").prop('disabled', 'disabled');
	$("#ramal_novaEntrada").prop('disabled', 'disabled');
	$("#abb_novaEntrada").prop('disabled', 'disabled');
	$("#cal_novaEntrada").prop('disabled', 'disabled');
}

function disable_load_editar(){
	$("#fila_editarEntrada").prop('disabled', 'disabled');
	$("#fila_editarEntrada").selectpicker('refresh')
	$("#ura_editarEntrada").prop('disabled', 'disabled');
	$("#ura_editarEntrada").selectpicker('refresh')
	$("#ramal_editarEntrada").prop('disabled', 'disabled');
	$("#ramal_editarEntrada").selectpicker('refresh')
	$("#abb_editarEntrada").prop('disabled', 'disabled');
	$("#abb_editarEntrada").selectpicker('refresh')
	$("#cal_editarEntrada").prop('disabled', 'disabled');
	$("#cal_editarEntrada").selectpicker('refresh')
	
	$('#fila_editarEntrada').selectpicker('val', '');
	$('#ura_editarEntrada').selectpicker('val', '');
	$('#ramal_editarEntrada').selectpicker('val', '');
	$('#abb_editarEntrada').selectpicker('val', '');
	$('#cal_editarEntrada').selectpicker('val', '');
}

function botaoExcluirEntrada(contexto, did) {
	$('#contexto_excluirEntrada').val(contexto);
	$('#did_excluirEntrada').val(did);

	$('#excluirEntradaLabel').text("Excluir Entrada "+did);
	$('#excluirEntradaModal').modal();
};

function botaoEditarEntrada(contexto, did) {
	var entradas = <?php echo json_encode($entradas, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
	
	$('#entrada_editarEntrada').selectpicker('val', contexto);
	$('#did_editarEntrada').val(did);
	document.getElementById('editarEntradaLabel').innerHTML = "Editar Entrada: "+did;
	
	$('#editarcontexto_editarEntrada').val(contexto);
	$('#editardid_editarEntrada').val(did);
	
	$('#tronco_editarEntrada').selectpicker('val', contexto);
	$('#did_editarEntrada').val(did);
	$('#nome_editarEntrada').val(entradas[contexto][did].nome);
	$('#cut_cus_editarEntrada').val(entradas[contexto][did].cut_cus);
	
	var destino = entradas[contexto][did].tipo+"/"+entradas[contexto][did].destino;
	
	disable_load_editar();
	
	switch (entradas[contexto][did].tipo) {
		case 'CUS':
			$('#tipo_cus_editarEntrada').prop('checked', 'checked');
			break;
		case 'QUE':
			$('#tipo_fila_editarEntrada').prop('checked', 'checked');
			$("#fila_editarEntrada").prop('disabled', false);
			$("#fila_editarEntrada").selectpicker('refresh');
			$('#fila_editarEntrada').selectpicker('val', destino);
			break;
		case 'URA':
			$('#tipo_ura_editarEntrada').prop('checked', 'checked');
			$("#ura_editarEntrada").prop('disabled', false);
			$("#ura_editarEntrada").selectpicker('refresh');
			$('#ura_editarEntrada').selectpicker('val', destino);
			break;
		case 'SIP':
			$('#tipo_ramal_editarEntrada').prop('checked', 'checked');
			$("#ramal_editarEntrada").prop('disabled', false);
			$("#ramal_editarEntrada").selectpicker('refresh');
			$('#ramal_editarEntrada').selectpicker('val', destino);
			break;
		case 'IAX2':
			$('#tipo_ramal_editarEntrada').prop('checked', 'checked');
			$("#ramal_editarEntrada").prop('disabled', false);
			$("#ramal_editarEntrada").selectpicker('refresh');
			$('#ramal_editarEntrada').selectpicker('val', destino);
			break;
		case 'OPC':
			$('#tipo_opc_editarEntrada').prop('checked', 'checked');
			break;
		case 'ABB':
			$('#tipo_abb_editarEntrada').prop('checked', 'checked');
			$("#abb_editarEntrada").prop('disabled', false);
			$("#abb_editarEntrada").selectpicker('refresh');
			$('#abb_editarEntrada').selectpicker('val', destino);
			break;
		case 'CAL':
			$('#tipo_cal_editarEntrada').prop('checked', 'checked');
			$("#cal_editarEntrada").prop('disabled', false);
			$("#cal_editarEntrada").selectpicker('refresh');
			$('#cal_editarEntrada').selectpicker('val', destino);
			break;
		default:
			console.log('Sorry.');
	}
	
	$("#editarEntradaModal").modal();
};

$(document).ready(function(){
	
	$("#tipo_cus_novaEntrada").on('click',function(){
		$("#fila_novaEntrada").prop('disabled', 'disabled');
		$("#fila_novaEntrada").selectpicker('refresh');
		$("#ura_novaEntrada").prop('disabled', 'disabled');
		$("#ura_novaEntrada").selectpicker('refresh');
		$("#ramal_novaEntrada").prop('disabled', 'disabled');
		$("#ramal_novaEntrada").selectpicker('refresh');
		$("#abb_novaEntrada").prop('disabled', 'disabled');
		$("#abb_novaEntrada").selectpicker('refresh');
		$("#cal_novaEntrada").prop('disabled', 'disabled');
		$("#cal_novaEntrada").selectpicker('refresh');
	});
	
	$("#tipo_fila_novaEntrada").on('click',function(){
		$("#fila_novaEntrada").prop('disabled', false);
		$("#fila_novaEntrada").selectpicker('refresh');
		$("#ura_novaEntrada").prop('disabled', 'disabled');
		$("#ura_novaEntrada").selectpicker('refresh');
		$("#ramal_novaEntrada").prop('disabled', 'disabled');
		$("#ramal_novaEntrada").selectpicker('refresh');
		$("#abb_novaEntrada").prop('disabled', 'disabled');
		$("#abb_novaEntrada").selectpicker('refresh');
		$("#cal_novaEntrada").prop('disabled', 'disabled');
		$("#cal_novaEntrada").selectpicker('refresh');
	});
	
	$("#tipo_ura_novaEntrada").on('click',function(){
		$("#fila_novaEntrada").prop('disabled', 'disabled');
		$("#fila_novaEntrada").selectpicker('refresh');
		$("#ura_novaEntrada").prop('disabled', false);
		$("#ura_novaEntrada").selectpicker('refresh');
		$("#ramal_novaEntrada").prop('disabled', 'disabled');
		$("#ramal_novaEntrada").selectpicker('refresh');
		$("#abb_novaEntrada").prop('disabled', 'disabled');
		$("#abb_novaEntrada").selectpicker('refresh');
		$("#cal_novaEntrada").prop('disabled', 'disabled');
		$("#cal_novaEntrada").selectpicker('refresh');
	});
	
	$("#tipo_ramal_novaEntrada").on('click',function(){
		$("#fila_novaEntrada").prop('disabled', 'disabled');
		$("#fila_novaEntrada").selectpicker('refresh');
		$("#ura_novaEntrada").prop('disabled', 'disabled');
		$("#ura_novaEntrada").selectpicker('refresh');
		$("#ramal_novaEntrada").prop('disabled', false);
		$("#ramal_novaEntrada").selectpicker('refresh');
		$("#abb_novaEntrada").prop('disabled', 'disabled');
		$("#abb_novaEntrada").selectpicker('refresh');
		$("#cal_novaEntrada").prop('disabled', 'disabled');
		$("#cal_novaEntrada").selectpicker('refresh');
	});
	
	$("#tipo_opc_novaEntrada").on('click',function(){
		$("#fila_novaEntrada").prop('disabled', 'disabled');
		$("#fila_novaEntrada").selectpicker('refresh');
		$("#ura_novaEntrada").prop('disabled', 'disabled');
		$("#ura_novaEntrada").selectpicker('refresh');
		$("#ramal_novaEntrada").prop('disabled', 'disabled');
		$("#ramal_novaEntrada").selectpicker('refresh');
		$("#abb_novaEntrada").prop('disabled', 'disabled');
		$("#abb_novaEntrada").selectpicker('refresh');
		$("#cal_novaEntrada").prop('disabled', 'disabled');
		$("#cal_novaEntrada").selectpicker('refresh');
	});
	
	$("#tipo_abb_novaEntrada").on('click',function(){
		$("#fila_novaEntrada").prop('disabled', 'disabled');
		$("#fila_novaEntrada").selectpicker('refresh');
		$("#ura_novaEntrada").prop('disabled', 'disabled');
		$("#ura_novaEntrada").selectpicker('refresh');
		$("#ramal_novaEntrada").prop('disabled', 'disabled');
		$("#ramal_novaEntrada").selectpicker('refresh');
		$("#abb_novaEntrada").prop('disabled', false);
		$("#abb_novaEntrada").selectpicker('refresh');
		$("#cal_novaEntrada").prop('disabled', 'disabled');
		$("#cal_novaEntrada").selectpicker('refresh');
	});
	
	$("#tipo_cal_novaEntrada").on('click',function(){
		$("#fila_novaEntrada").prop('disabled', 'disabled');
		$("#fila_novaEntrada").selectpicker('refresh');
		$("#ura_novaEntrada").prop('disabled', 'disabled');
		$("#ura_novaEntrada").selectpicker('refresh');
		$("#ramal_novaEntrada").prop('disabled', 'disabled');
		$("#ramal_novaEntrada").selectpicker('refresh');
		$("#abb_novaEntrada").prop('disabled', 'disabled');
		$("#abb_novaEntrada").selectpicker('refresh');
		$("#cal_novaEntrada").prop('disabled', false);
		$("#cal_novaEntrada").selectpicker('refresh');
	});

	disable_load();
	
	//EDITAR ENTRADA
	
	$("#tipo_cus_editarEntrada").on('click',function(){
		$("#fila_editarEntrada").prop('disabled', 'disabled');
		$("#fila_editarEntrada").selectpicker('refresh');
		$("#ura_editarEntrada").prop('disabled', 'disabled');
		$("#ura_editarEntrada").selectpicker('refresh');
		$("#ramal_editarEntrada").prop('disabled', 'disabled');
		$("#ramal_editarEntrada").selectpicker('refresh');
		$("#abb_editarEntrada").prop('disabled', 'disabled');
		$("#abb_editarEntrada").selectpicker('refresh');
		$("#cal_editarEntrada").prop('disabled', 'disabled');
		$("#cal_editarEntrada").selectpicker('refresh');
	});
	
	$("#tipo_fila_editarEntrada").on('click',function(){
		$("#fila_editarEntrada").prop('disabled', false);
		$("#fila_editarEntrada").selectpicker('refresh');
		$("#ura_editarEntrada").prop('disabled', 'disabled');
		$("#ura_editarEntrada").selectpicker('refresh');
		$("#ramal_editarEntrada").prop('disabled', 'disabled');
		$("#ramal_editarEntrada").selectpicker('refresh');
		$("#abb_editarEntrada").prop('disabled', 'disabled');
		$("#abb_editarEntrada").selectpicker('refresh');
		$("#cal_editarEntrada").prop('disabled', 'disabled');
		$("#cal_editarEntrada").selectpicker('refresh');
	});
	
	$("#tipo_ura_editarEntrada").on('click',function(){
		$("#fila_editarEntrada").prop('disabled', 'disabled');
		$("#fila_editarEntrada").selectpicker('refresh');
		$("#ura_editarEntrada").prop('disabled', false);
		$("#ura_editarEntrada").selectpicker('refresh');
		$("#ramal_editarEntrada").prop('disabled', 'disabled');
		$("#ramal_editarEntrada").selectpicker('refresh');
		$("#abb_editarEntrada").prop('disabled', 'disabled');
		$("#abb_editarEntrada").selectpicker('refresh');
		$("#cal_editarEntrada").prop('disabled', 'disabled');
		$("#cal_editarEntrada").selectpicker('refresh');
	});
	
	$("#tipo_ramal_editarEntrada").on('click',function(){
		$("#fila_editarEntrada").prop('disabled', 'disabled');
		$("#fila_editarEntrada").selectpicker('refresh');
		$("#ura_editarEntrada").prop('disabled', 'disabled');
		$("#ura_editarEntrada").selectpicker('refresh');
		$("#ramal_editarEntrada").prop('disabled', false);
		$("#ramal_editarEntrada").selectpicker('refresh');
		$("#abb_editarEntrada").prop('disabled', 'disabled');
		$("#abb_editarEntrada").selectpicker('refresh');
		$("#cal_editarEntrada").prop('disabled', 'disabled');
		$("#cal_editarEntrada").selectpicker('refresh');
	});
	
	$("#tipo_opc_editarEntrada").on('click',function(){
		$("#fila_editarEntrada").prop('disabled', 'disabled');
		$("#fila_editarEntrada").selectpicker('refresh');
		$("#ura_editarEntrada").prop('disabled', 'disabled');
		$("#ura_editarEntrada").selectpicker('refresh');
		$("#ramal_editarEntrada").prop('disabled', 'disabled');
		$("#ramal_editarEntrada").selectpicker('refresh');
		$("#abb_editarEntrada").prop('disabled', 'disabled');
		$("#abb_editarEntrada").selectpicker('refresh');
		$("#cal_editarEntrada").prop('disabled', 'disabled');
		$("#cal_editarEntrada").selectpicker('refresh');
	});
	
	$("#tipo_abb_editarEntrada").on('click',function(){
		$("#fila_editarEntrada").prop('disabled', 'disabled');
		$("#fila_editarEntrada").selectpicker('refresh');
		$("#ura_editarEntrada").prop('disabled', 'disabled');
		$("#ura_editarEntrada").selectpicker('refresh');
		$("#ramal_editarEntrada").prop('disabled', 'disabled');
		$("#ramal_editarEntrada").selectpicker('refresh');
		$("#abb_editarEntrada").prop('disabled', false);
		$("#abb_editarEntrada").selectpicker('refresh');
		$("#cal_editarEntrada").prop('disabled', 'disabled');
		$("#cal_editarEntrada").selectpicker('refresh');
	});
	
	$("#tipo_cal_editarEntrada").on('click',function(){
		$("#fila_editarEntrada").prop('disabled', 'disabled');
		$("#fila_editarEntrada").selectpicker('refresh');
		$("#ura_editarEntrada").prop('disabled', 'disabled');
		$("#ura_editarEntrada").selectpicker('refresh');
		$("#ramal_editarEntrada").prop('disabled', 'disabled');
		$("#ramal_editarEntrada").selectpicker('refresh');
		$("#abb_editarEntrada").prop('disabled', 'disabled');
		$("#abb_editarEntrada").selectpicker('refresh');
		$("#cal_editarEntrada").prop('disabled', false);
		$("#cal_editarEntrada").selectpicker('refresh');
	});
});

//FUNCOES ENTRADA CUSTOM
function botaoNovaEntradaCustom() {
	$('#new_entradaCustom').val('1');
	$('#nome_entradaCustom').val('');
	$('#textarea_entradaCustom').val('');
}

function botaoEditarEntradaCustom(entrada) {
	var entradas_custom = <?php echo json_encode($entradas_custom, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
	
	$('#new_entradaCustom').val('0');
	$('#editarnome_entradaCustom').val(entrada);
	$('#nome_entradaCustom').val(entrada);
	
	var text = "";
	for (var alfa in entradas_custom[entrada].linhas) {
		text += entradas_custom[entrada].linhas[alfa]+"\n";
	}
	$('#textarea_entradaCustom').val(text);
}

function botaoExcluirEntradaCustom(entrada) {
	$('#excluirEntradaCustom').val(entrada);

	$('#excluirEntradaCustomLabel').text("Excluir Entrada "+entrada);
	$("#excluirEntradaCustomModal").modal();
};
//FIM FUNCOES ENTRADA CUSTOM

</script>