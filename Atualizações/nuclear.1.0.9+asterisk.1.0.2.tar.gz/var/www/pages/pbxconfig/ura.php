<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.db.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.config_e1.php"); //PARA OBTER TRONCOS G1, G2, etc.
	require_once(DIR_WWW."funcoes/funcoes.ramais.faixa_discagem.php");
	require_once(DIR_WWW."funcoes/funcoes.config.ramal.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.ura.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.rotas_saida.php");
	
	//PARA OBTER OS DESTINOS
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_sip.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_iax2.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.filas.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.telefonista.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.abreviados.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.calendario.php");

	if ( isset($_GET['tipo']) && $_GET['tipo'] == "satisfacao") {
		$tipo = "satisfacao";
	} else if ( isset($_GET['tipo']) && $_GET['tipo'] == "custom") {
		$tipo = "custom";
	} else {
		$tipo = "uras";
	}

	// DECLARAÇÃO DE VARIÁVEIS ==============================================================================================
	
	$uras = get_uras();
	$uras_custom = get_uras_custom();
	$audios = get_audios_ura();
	
	$ramais_sip = get_ramais();
	$ramais_iax2 = get_ramais_iax();
	$filas = get_filas();
	$abreviados = get_abreviados();
	$calendarios = get_calendarios();
	$troncos = get_troncos();
	
	$destinos = array();
	foreach($filas as $key=>$value) {
		$destinos[] = "<option value=\"QUE/".$key."\">QUE/".$key."</option>";
	}
	foreach($calendarios as $key=>$value) {
		$destinos[] = "<option value=\"CAL/".$key."\">CAL/".$key."</option>";
	}
	foreach($uras as $key=>$value) {
		$destinos[] = "<option value=\"URA/".$key."\">URA/".$key."</option>";
	}
	foreach($uras_custom as $key=>$value) {
		$destinos[] = "<option value=\"URA/".$key."\">URA/".$key."</option>";
	}
	foreach($abreviados as $key=>$value) {
		$destinos[] = "<option value=\"ABB/".$key."\">ABB/".$key."</option>";
	}
	foreach($ramais_sip as $key=>$value) {
		$destinos[] ="<option value=\"SIP/".$key."\">SIP/".$key."</option>";
	}
	foreach($ramais_iax2 as $key=>$value) {
		$destinos[] = "<option value=\"IAX2/".$key."\">IAX2/".$key."</option>";
	}
	
	//Pesquisa de Satisfação
	
	$ura_satisfacao = get_ura_pesquisa();
	//print_r($ura_satisfacao);
	/*Array ( 
		[notas] => Array ( [0] => Ruim [1] => Razoável [2] => Bom [3] => Excelente ) 
		[ura_pesquisa_satisfacao] => Array ( [anuncio] => KS-URA-pesquisa-satisfacao [wait] => 10 [agradecimento] => Sinal Ocupado ) 
	)*/

	//URAS ===============================================================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "novaUra") {
		//print_r($_POST);
		//die();
		/*[nome] => TESTE 
		[anuncio-ura] => Agradecemos 
		[wait] => 5 
		[faixa] => 1
		[opcao] => Array ( [i] => i [t] => t [0] => 0 [1] => 1 ) 
		[anuncio] => Array ( [i] => Para Seguranca [t] => Agradecemos [0] => Por Favor Aguarde [1] => ) 
		[destino] => Array ( [i] => repetir [t] => [0] => QUE/600 [1] => URA/TESTE ) 
		[prioridade] => Array ( [i] => 1 [t] => 1 [0] => 3 [1] => 1 ) )
		*/
		$erro = "";
		if (!isset($_POST['nome']) || @$_POST['nome'] == "") {
			$erro = "Erro: Nome Inválido!";
		}
		if (!isset($_POST['anuncio-ura']) || @$_POST['anuncio-ura'] == "") {
			$erro = "Erro: Anuncio inválido!";
		}
		if ( !isset($_POST['opcao']) ) {
			$erro = "Erro: 0x00000000!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !nova_ura($_POST) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "editarUra") {
		
		$erro="";
		if (!isset($_POST['editarnome']) || @$_POST['editarnome'] == "") {
			$erro = "Erro: Ura Inválida!";
		}
		if (!isset($_POST['nome']) || @$_POST['nome'] == "") {
			$erro = "Erro: Nome Inválido!";
		}
		if (!isset($_POST['anuncio-ura']) || @$_POST['anuncio-ura'] == "") {
			$erro = "Erro: Anuncio inválido!";
		}
		if ( !isset($_POST['opcao']) ) {
			$erro = "Erro: 0x00000000!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !editar_ura($_POST) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirUra") {
		
		$erro="";
		if (!isset($_POST['nome']) || @$_POST['nome'] == "") {
			$erro = "Erro: Ura Inválida!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !excluir_ura($_POST['nome']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	
	//URAS CUSTOM =============================================================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "uraCustom") {
		
		$erro = "";
		if (!isset($_POST['nome']) || @$_POST['nome'] == "") {
			$erro = "Erro: Nome Inválido!";
		}
		if (!isset($_POST['contexto']) || @$_POST['contexto'] == "") {
			$erro = "Erro: Contexto inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if (isset($_POST['new']) && $_POST['new'] == "1") {
			//NOVO
			if ( !nova_ura_custom($_POST['nome'], $_POST['contexto']) ) {
				print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
			} else {
				print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
			}

		} elseif (isset($_POST['new']) && $_POST['new'] == "0") {
			//EDITAR
			if ( !editar_ura_custom($_POST['editarnome'], $_POST['nome'], $_POST['contexto']) ) {
				print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
			} else {
				print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
			}
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirUraCustom") {
		
		$erro="";
		if (!isset($_POST['nome']) || @$_POST['nome'] == "") {
			$erro = "Erro:  0x00000011!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !excluir_ura_custom($_POST['nome']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	//PESQUISA de SATISFAÇÃO =============================================================================================
	if (isset($_POST['cmd']) && $_POST['cmd'] == "salvarSatisfacao") {
		//print_r($_POST);
		/*[anuncio-ura] => fpm-world-mix [wait] => 10 [agradecimento] => Agradecemos 
		[nota] => Array ( [0] => 0 [1] => 1 [2] => 2 [3] => 3 ) 
		[descricao] => Array ( [0] => Ruim [1] => Razoável [2] => Bom [3] => Excelente ) )
		*/
		$erro="";
		if (count(array_not_unique($_POST['nota'])) != 0) {
			$erro="Notas Duplicadas, verifique a configuração!";
		}
		if (!isset($_POST['anuncio-ura']) || @$_POST['anuncio-ura'] == "") {
			$erro="Nenhum anúncio selecionado!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !salvar_ura_pesquisa($_POST) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
?>


	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- MENU URAS -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
						<div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
                                	<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
						</div>
                        <div class="body">
                            <ul class="nav nav-tabs tab-nav-right" role="tablist">
                                <li role="presentation" <?php echo ( $tipo == "uras" ? "class=\"active\"" : "" ); ?> ><a href="#uras" data-toggle="tab">URAS</a></li>
                                <li role="presentation" <?php echo ( $tipo == "custom" ? "class=\"active\"" : "" ); ?> ><a href="#custom" data-toggle="tab">CUSTOM</a></li>
								<li role="presentation" <?php echo ( $tipo == "satisfacao" ? "class=\"active\"" : "" ); ?> ><a href="#satisfacao" data-toggle="tab">PESQUISA DE SATISFAÇÃO</a></li>
							</ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
				<!-- URAS #####################################################################################################################-->
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "uras" ? "in active" : "" ); ?>" id="uras">


							<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novaUraModal">
								<i class="material-icons">add_circle</i>
								<span>NOVA URA</span>
							</button>
							<div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
                                            <th>Nome</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					    <?php
						foreach($uras as $ura=>$vetor) {
						    if (is_array($vetor)) {
					    ?>
							<tr>
								<td><?=$ura;?></td>
								<td>
									<a href="javascript:;" class="editar-ura" data-id="<?=$ura;?>" data-toggle="modal" data-target="#editarUraModal"><i class="material-icons" title="Editar">edit</i></a>&nbsp;
									<a href="javascript:;" class="play" onclick="botaoExcluirUra('<?=$ura;?>')"><i class="material-icons" title="Excluir">delete</i></a>
								</td>
						    </tr>
					    <?php
						    }
						}
					    ?>
                                    </tbody>
                                </table>
							</div>


								</div>
				<!--#FIM - URAS ##############################################################################################################-->
				<!-- URAS CUSTOM ##################################################################################################################-->
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "custom" ? "in active" : "" ); ?>" id="custom">
								
			    <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
                                            <th>Nome</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					    <?php
						foreach($uras_custom as $ura=>$vetor) {
						    if (is_array($vetor)) {
					    ?>
							<tr>
								<td><?=$ura;?></td>
								<td>
									<a href="javascript:;" class="play" onclick="botaoEditarUraCustom('<?=$ura;?>')"><i class="material-icons" title="Editar">edit</i></a>&nbsp;
									<a href="javascript:;" class="play" onclick="botaoExcluirUraCustom('<?=$ura;?>')"><i class="material-icons" title="Excluir">delete</i></a>
								</td>
						    </tr>
					    <?php
						    }
						}
					    ?>
                                    </tbody>
                                </table>
                </div>
				<hr>
				<div class="body">
				
					<button type="button" class="btn btn-primary waves-effect" onclick="botaoNovaUraCustom()">
						<i class="material-icons">add_circle</i>
						<span>NOVA URA</span>
					</button>
				
					<form name="form_txt" id="form_uraCustom" method="post">
						<?=$text_form;?>
						<input type="hidden" id="cmd_uraCustom" name="cmd" value="uraCustom" />
						<input type="hidden" id="new_uraCustom" name="new" value="1" />
						<input type="hidden" id="editarnome_uraCustom" name="editarnome" value="" />
						
					<div class="row clearfix">
                        <div class="col-md-2 col-sm-2 col-xs-4 form-control-label" style="margin-bottom: 0px;">
                            <label for="nome_uraCustom">Nome</label>
                        </div>
						<div class="col-md-4 col-sm-6 col-xs-8" style="margin-bottom: 0px;">
							<div class="form-group">
								<div class="form-line">
									<input type="text" name="nome" id="nome_uraCustom" class="form-control rota" onchange="verifica_contexto(this)">
								</div>
							</div>
						</div>
					</div>
					
					<small>Contexto Asterisk:</small>
					<div class="form-group">
                        <div class="form-line">
							<textarea name="contexto" id="textarea_uraCustom" rows="16" class="form-control no-resize auto-growth"></textarea>
						</div>
					</div>
					<button type="submit" class="btn btn-primary waves-effect">
						<i class="material-icons">save</i>
						<span>Salvar</span>
					</button>
					</form>
				</div>
				
								</div>
				<!-- #END# URAS CUSTOM ############################################################################################################-->
				<!-- SATISFAÇÃO ###################################################################################################################-->
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "satisfacao" ? "in active" : "" ); ?>" id="satisfacao">


							<form id="formEditarUra" method="post">
								<?=$text_form;?>
								<input type="hidden" name="cmd" value="salvarSatisfacao" />
								
								<h4>URA Pesquisa de Satisfação</h4>
								<br>
								
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-2 col-xs-5 form-control-label">
										<label>Anúncio</label>
									</div>
									<div class="col-md-4 col-sm-4 col-xs-7" style="margin-bottom: 5px;">
										<div class="form-group form-float">
											<select name="anuncio-ura" id="anuncio_satisfacaoUra" class="form-control show-tick">
												<option value=""> - </option>
												<?php
													foreach($audios as $value) {
														print "<option value=\"".$value."\">".$value."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-2 col-xs-5 form-control-label">
										<label>Tempo Limite</label>
									</div>
									<div class="col-md-4 col-sm-4 col-xs-7">
										<div class="form-group form-float" style="margin-bottom: 5px;">
											<select name="wait" id="wait_satisfacaoUra" class="form-control show-tick">
												<?php
													for ($i = 0; $i <= 20; $i++) {
														print "<option value=\"".$i."\">".$i."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-2 col-xs-5 form-control-label">
										<label>Agradecimento</label>
									</div>
									<div class="col-md-4 col-sm-4 col-xs-7">
										<div class="form-group form-float" style="margin-bottom: 5px;">
											<select name="agradecimento" id="agradecimento_satisfacaoUra" class="form-control show-tick">
												<option value=""> - </option>
												<?php
													foreach($audios as $value) {
														print "<option value=\"".$value."\">".$value."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>

								<div class="row clearfix">
									<div class="body">
										<ul class="list-group containerUraSatisfacao">
										<?php
										$cont = 0;
										foreach ($ura_satisfacao['notas'] as $key=>$value) {
										?>
											<li class="list-group-item">
												<div class="row clearfix">
													<div class="col-md-1 col-sm-1 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label>Nota</label>
													</div>
													<div class="col-md-1 col-sm-1 col-xs-7">
														<div class="form-group form-float" style="margin-bottom: 0px;">
															<select name="nota[]" id="nota_satisfacaoUra-<?=$cont;?>" class="form-control show-tick">
																<?php
																	for ($i = 0; $i <= 9; $i++) {
																		if ($i == $key) {
																			
																		}
																		print "<option value=\"".$i."\" ".($i == $key?"selected=\"selected\"":"").">".$i."</option>";
																	}
																?>
															</select>
														</div>
													</div>
													<div class="col-md-1 col-sm-1 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label for="descricao_satisfacaoUra-<?=$cont;?>">Descrição</label>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-7" style="margin-bottom: 0px;">
														<div class="form-group">
															<div class="form-line">
																<input type="text" name="descricao[]" id="descricao_satisfacaoUra-<?=$cont;?>" value="<?=$value;?>" class="form-control">
															</div>
														</div>
													</div>
												</div>
											</li>
										<?php
											$cont++;
										}
										?>
										</ul>
										<button type="" class="btn btn-primary waves-effect" id="add_satisfacaoUra">
											<i class="material-icons">add_circle</i>
											<span>Adicionar</span>
										</button>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-6 col-sm-12 col-xs-12">
										<button type="submit" class="btn btn-primary waves-effect pull-right">
											<i class="material-icons">save</i>
											<span>Salvar</span>
										</button>
									</div>
								</div>
							</form>

								</div>
				<!--#FIM - SATISFAÇÃO #############################################################################################################-->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	<!--END - PAGE CONTENT-->


	<!-- MODAL ================================================================================================================================== -->

		<!--MODAL NOVA URA-->
            <div class="modal fade" id="novaUraModal" tabindex="-1" role="dialog">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="modal-title" id="novaUraLabel">Nova Ura</h2>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
							<form id="formNovaUra" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="novaUra" />

								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
                                        <label for="novaUra_nome">Nome</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 5px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="nome" id="nome_novaUra" class="form-control rota" onchange="verifica_contexto(this)">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-2 col-xs-5 form-control-label">
										<label>Anúncio</label>
									</div>
									<div class="col-md-4 col-sm-4 col-xs-7" style="margin-bottom: 5px;">
										<div class="form-group form-float">
											<select name="anuncio-ura" id="anuncio-ura_novaUra" class="form-control show-tick">
												<option value=""> - </option>
												<?php
													foreach($audios as $value) {
														print "<option value=\"".$value."\">".$value."</option>";
													}
												?>
											</select>
										</div>
									</div>
									<div class="col-md-2 col-sm-2 col-xs-5 form-control-label">
										<label>Tempo Limite</label>
									</div>
									<div class="col-md-4 col-sm-4 col-xs-7">
										<div class="form-group form-float" style="margin-bottom: 5px;">
											<select name="wait" id="wait_novaUra" class="form-control show-tick">
												<?php
													for ($i = 0; $i <= 20; $i++) {
														print "<option value=\"".$i."\">".$i."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>
								<small>Opção Inválida</small>
								<input type="hidden" name="opcao[i]" value="i" />
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-2 col-xs-5 form-control-label">
										<label>Anúncio</label>
									</div>
									<div class="col-md-3 col-sm-4 col-xs-7">
										<div class="form-group form-float" style="margin-bottom: 5px;">
											<select name="anuncio[i]" id="anuncio_novaUra-i" class="form-control show-tick">
												<option value=""> - </option>
												<?php
													foreach($audios as $value) {
														print "<option value=\"".$value."\">".$value."</option>";
													}
												?>
											</select>
										</div>
									</div>
									<div class="col-md-2 col-sm-2 col-xs-5 form-control-label">
										<label>Destino</label>
									</div>
									<div class="col-md-3 col-sm-4 col-xs-7">
										<div class="form-group form-float" style="margin-bottom: 5px;">
											<select name="destino[i]" id="destino_novaUra-i" class="form-control show-tick" data-live-search="true">
												<option value=""> - </option>
												<option value="repetir">Repetir URA</option>
												<!--<option value="opc">Telefonista</option>-->
												<option value="hangup">Terminar Ligação</option>
												<?php
													foreach($destinos as $key=>$value) {
														print $value;
													}
												?>
											</select>
										</div>
									</div>
									<div class="col-md-1 col-sm-2 col-xs-6 form-control-label">
										<label>Prio</label>
									</div>
									<div class="col-md-1 col-sm-2 col-xs-6">
										<div class="form-group form-float" title="prioridade fila" style="margin-bottom: 5px;">
											<select name="prioridade[i]" id="prioridade_novaUra-i" class="form-control show-tick">
												<?php
													for ($i = 1; $i <= 10; $i++) {
														print "<option value=\"".$i."\">".$i."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>
								<small>Tempo Esgotado</small>
								<input type="hidden" name="opcao[t]" value="t" />
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-2 col-xs-5 form-control-label">
										<label>Anúncio</label>
									</div>
									<div class="col-md-3 col-sm-4 col-xs-7">
										<div class="form-group form-float" style="margin-bottom: 5px;">
											<select name="anuncio[t]" id="anuncio_novaUra-t" class="form-control show-tick">
												<option value=""> - </option>
												<?php
													foreach($audios as $value) {
														print "<option value=\"".$value."\">".$value."</option>";
													}
												?>
											</select>
										</div>
									</div>
									<div class="col-md-2 col-sm-2 col-xs-5 form-control-label">
										<label>Destino</label>
									</div>
									<div class="col-md-3 col-sm-4 col-xs-7">
										<div class="form-group form-float" style="margin-bottom: 5px;">
											<select name="destino[t]" id="destino_novaUra-t" class="form-control show-tick" data-live-search="true">
												<option value=""> - </option>
												<option value="repetir">Repetir URA</option>
												<!--<option value="opc">Telefonista</option>-->
												<option value="hangup">Terminar Ligação</option>
												<?php
													foreach($destinos as $key=>$value) {
														print $value;
													}
												?>
											</select>
										</div>
									</div>
									<div class="col-md-1 col-sm-2 col-xs-6 form-control-label">
										<label>Prio</label>
									</div>
									<div class="col-md-1 col-sm-2 col-xs-6">
										<div class="form-group form-float" title="prioridade fila" style="margin-bottom: 5px;">
											<select name="prioridade[t]" id="prioridade_novaUra-t" class="form-control show-tick">
												<?php
													for ($i = 1; $i <= 10; $i++) {
														print "<option value=\"".$i."\">".$i."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-12 col-sm-12 col-xs-12 form-control-label">
										<input type="checkbox" name="faixa" id="faixa_novaUra" value="1" class="filled-in chk-col-light-blue"/>
										<label for="faixa_novaUra">Ativar redirecionamento ao teclar ramal</label>
									</div>
								</div>
								<div class="row clearfix">
									<div class="body">
										<ul class="list-group container1">
											<li class="list-group-item">
												<div class="row clearfix">
													<div class="col-md-1 col-sm-1 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label>Menu</label>
													</div>
													<div class="col-md-1 col-sm-1 col-xs-7">
														<div class="form-group form-float" style="margin-bottom: 0px;">
															<select name="opcao[]" id="menu_novaUra-0" class="form-control show-tick">
																<?php
																	for ($i = 0; $i <= 9; $i++) {
																		print "<option value=\"".$i."\">".$i."</option>";
																	}
																?>
															</select>
														</div>
													</div>
													<div class="col-md-1 col-sm-2 col-xs-5 form-control-label">
														<label>Anúncio</label>
													</div>
													<div class="col-md-3 col-sm-4 col-xs-7">
														<div class="form-group form-float" style="margin-bottom: 5px;">
															<select name="anuncio[]" id="anuncio_novaUra-0" class="form-control show-tick">
																<option value=""> - </option>
																<?php
																	foreach($audios as $value) {
																		print "<option value=\"".$value."\">".$value."</option>";
																	}
																?>
															</select>
														</div>
													</div>
													<div class="col-md-1 col-sm-2 col-xs-5 form-control-label">
														<label>Destino</label>
													</div>
													<div class="col-md-3 col-sm-4 col-xs-7">
														<div class="form-group form-float" style="margin-bottom: 5px;">
															<select name="destino[]" id="destino_novaUra-0" class="form-control show-tick" data-live-search="true">
																<option value=""> - </option>
																<option value="repetir">Repetir URA</option>
																<!--<option value="opc">Telefonista</option>-->
																<option value="hangup">Terminar Ligação</option>
																<?php
																	foreach($destinos as $key=>$value) {
																		print $value;
																	}
																?>
															</select>
														</div>
													</div>
													<div class="col-md-1 col-sm-2 col-xs-6 form-control-label">
														<label>Prio</label>
													</div>
													<div class="col-md-1 col-sm-2 col-xs-6">
														<div class="form-group form-float" title="prioridade fila" style="margin-bottom: 5px;">
															<select name="prioridade[]" id="prioridade_novaUra-0" class="form-control show-tick">
																<?php
																	for ($i = 1; $i <= 10; $i++) {
																		print "<option value=\"".$i."\">".$i."</option>";
																	}
																?>
															</select>
														</div>
													</div>
												</div>
											</li>
										</ul>
										<button type="" class="btn btn-primary waves-effect" id="add_novaUra">
											<i class="material-icons">add_circle</i>
											<span>Adicionar</span>
										</button>
									</div>
								</div>

							</div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
                            <button type="button" id="closenovaUraModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
							</form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL NOVA URA-->

		<!--MODAL EDITAR URA-->
			<div class="modal fade" id="editarUraModal" tabindex="-1" role="dialog">
				<div class="modal-dialog modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h4 class="modal-title" id="editarUraLabel">Editar Ura</h4>
						</div>
						<div class="modal-body">
							<div class="demo-masked-input">
								<form id="formEditarUra" method="post">
								<?=$text_form;?>
								<input type="hidden" name="cmd" value="editarUra" />
								<input type="hidden" id="editarUra" name="editarnome" value="" />
								
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
                                        <label for="nome_editarUra">Nome</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 5px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="nome" id="nome_editarUra" class="form-control rota" onchange="verifica_contexto(this)">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-2 col-xs-5 form-control-label">
										<label>Anúncio</label>
									</div>
									<div class="col-md-4 col-sm-4 col-xs-7" style="margin-bottom: 5px;">
										<div class="form-group form-float">
											<select name="anuncio-ura" id="anuncio-ura_editarUra" class="form-control show-tick">
												<option value=""> - </option>
												<?php
													foreach($audios as $value) {
														print "<option value=\"".$value."\">".$value."</option>";
													}
												?>
											</select>
										</div>
									</div>
									<div class="col-md-2 col-sm-2 col-xs-5 form-control-label">
										<label>Tempo Limite</label>
									</div>
									<div class="col-md-4 col-sm-4 col-xs-7">
										<div class="form-group form-float" style="margin-bottom: 5px;">
											<select name="wait" id="wait_editarUra" class="form-control show-tick">
												<?php
													for ($i = 0; $i <= 20; $i++) {
														print "<option value=\"".$i."\">".$i."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>
								<small>Opção Inválida</small>
								<input type="hidden" name="opcao[i]" value="i" />
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-2 col-xs-5 form-control-label">
										<label>Anúncio</label>
									</div>
									<div class="col-md-3 col-sm-4 col-xs-7">
										<div class="form-group form-float" style="margin-bottom: 5px;">
											<select name="anuncio[i]" id="anuncio_editarUra-i" class="form-control show-tick">
												<option value=""> - </option>
												<?php
													foreach($audios as $value) {
														print "<option value=\"".$value."\">".$value."</option>";
													}
												?>
											</select>
										</div>
									</div>
									<div class="col-md-2 col-sm-2 col-xs-5 form-control-label">
										<label>Destino</label>
									</div>
									<div class="col-md-3 col-sm-4 col-xs-7">
										<div class="form-group form-float" style="margin-bottom: 5px;">
											<select name="destino[i]" id="destino_editarUra-i" class="form-control show-tick" data-live-search="true">
												<option value=""> - </option>
												<option value="repetir">Repetir URA</option>
												<!--<option value="opc">Telefonista</option>-->
												<option value="hangup">Terminar Ligação</option>
												<?php
													foreach($destinos as $key=>$value) {
														print $value;
													}
												?>
											</select>
										</div>
									</div>
									<div class="col-md-1 col-sm-2 col-xs-6 form-control-label">
										<label>Prio</label>
									</div>
									<div class="col-md-1 col-sm-2 col-xs-6">
										<div class="form-group form-float" title="prioridade fila" style="margin-bottom: 5px;">
											<select name="prioridade[i]" id="prioridade_editarUra-i" class="form-control show-tick">
												<?php
													for ($i = 1; $i <= 10; $i++) {
														print "<option value=\"".$i."\">".$i."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>
								<small>Tempo Esgotado</small>
								<input type="hidden" name="opcao[t]" value="t" />
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-2 col-xs-5 form-control-label">
										<label>Anúncio</label>
									</div>
									<div class="col-md-3 col-sm-4 col-xs-7">
										<div class="form-group form-float" style="margin-bottom: 5px;">
											<select name="anuncio[t]" id="anuncio_editarUra-t" class="form-control show-tick">
												<option value=""> - </option>
												<?php
													foreach($audios as $value) {
														print "<option value=\"".$value."\">".$value."</option>";
													}
												?>
											</select>
										</div>
									</div>
									<div class="col-md-2 col-sm-2 col-xs-5 form-control-label">
										<label>Destino</label>
									</div>
									<div class="col-md-3 col-sm-4 col-xs-7">
										<div class="form-group form-float" style="margin-bottom: 5px;">
											<select name="destino[t]" id="destino_editarUra-t" class="form-control show-tick" data-live-search="true">
												<option value=""> - </option>
												<option value="repetir">Repetir URA</option>
												<!--<option value="opc">Telefonista</option>-->
												<option value="hangup">Terminar Ligação</option>
												<?php
													foreach($destinos as $key=>$value) {
														print $value;
													}
												?>
											</select>
										</div>
									</div>
									<div class="col-md-1 col-sm-2 col-xs-6 form-control-label">
										<label>Prio</label>
									</div>
									<div class="col-md-1 col-sm-2 col-xs-6">
										<div class="form-group form-float" title="prioridade fila" style="margin-bottom: 5px;">
											<select name="prioridade[t]" id="prioridade_editarUra-t" class="form-control show-tick">
												<?php
													for ($i = 1; $i <= 10; $i++) {
														print "<option value=\"".$i."\">".$i."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-12 col-sm-12 col-xs-12 form-control-label">
										<input type="checkbox" name="faixa" id="faixa_editarUra" value="1" class="filled-in chk-col-light-blue"/>
										<label for="faixa_editarUra">Ativar redirecionamento ao teclar ramal</label>
									</div>
								</div>
								<div class="row clearfix">
									<div class="body">
										<ul class="list-group container-editar">
											<li class="list-group-item">
												<div class="row clearfix">
													<div class="col-md-1 col-sm-1 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label>Menu</label>
													</div>
													<div class="col-md-1 col-sm-1 col-xs-7">
														<div class="form-group form-float" style="margin-bottom: 0px;">
															<select name="opcao[]" id="menu_editarUra-1" class="form-control show-tick">
																<?php
																	for ($i = 0; $i <= 9; $i++) {
																		print "<option value=\"".$i."\">".$i."</option>";
																	}
																?>
															</select>
														</div>
													</div>
													<div class="col-md-1 col-sm-2 col-xs-5 form-control-label">
														<label>Anúncio</label>
													</div>
													<div class="col-md-3 col-sm-4 col-xs-7">
														<div class="form-group form-float" style="margin-bottom: 5px;">
															<select name="anuncio[]" id="anuncio_editarUra-1" class="form-control show-tick">
																<option value=""> - </option>
																<?php
																	foreach($audios as $value) {
																		print "<option value=\"".$value."\">".$value."</option>";
																	}
																?>
															</select>
														</div>
													</div>
													<div class="col-md-1 col-sm-2 col-xs-5 form-control-label">
														<label>Destino</label>
													</div>
													<div class="col-md-3 col-sm-4 col-xs-7">
														<div class="form-group form-float" style="margin-bottom: 5px;">
															<select name="destino[]" id="destino_editarUra-1" class="form-control show-tick" data-live-search="true">
																<option value=""> - </option>
																<option value="repetir">Repetir URA</option>
																<!--<option value="opc">Telefonista</option>-->
																<option value="hangup">Terminar Ligação</option>
																<?php
																	foreach($destinos as $key=>$value) {
																		print $value;
																	}
																?>
															</select>
														</div>
													</div>
													<div class="col-md-1 col-sm-2 col-xs-6 form-control-label">
														<label>Prio</label>
													</div>
													<div class="col-md-1 col-sm-2 col-xs-6">
														<div class="form-group form-float" title="prioridade fila" style="margin-bottom: 5px;">
															<select name="prioridade[]" id="prioridade_editarUra-1" class="form-control show-tick">
																<?php
																	for ($i = 1; $i <= 10; $i++) {
																		print "<option value=\"".$i."\">".$i."</option>";
																	}
																?>
															</select>
														</div>
													</div>
												</div>
											</li>
										</ul>
										<button type="" class="btn btn-primary waves-effect" id="add_editarUra">
											<i class="material-icons">add_circle</i>
											<span>Adicionar</span>
										</button>
									</div>
								</div>
								
							</div>
						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
							<button type="button" id="closeEditarUraModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
						</div>
							</form>
					</div>
				</div>
			</div>
	    <!--#END of MODAL EDITAR URA-->


	    <!--MODAL EXCLUIR URA-->
            <div class="modal fade" id="excluirUraModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirUraLabel">Excluir Ura</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirUra" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="excluirUra" />
				<input type="hidden" id="excluirUra" name="nome" value="" />
			    <p>Tem certeza que deseja excluir a Ura?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
							<button type="button" id="closeExcluirUraModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR URA-->

			<!-- URA CUSTOM =========================================================== -->
			
		<!--MODAL EXCLUIR URA CUSTOM-->
            <div class="modal fade" id="excluirUraCustomModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirUraCustomLabel">Excluir Ura</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirUraCustom" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="excluirUraCustom" />
				<input type="hidden" id="excluirUraCustom" name="nome" value="" />
			    <p>Tem certeza que deseja excluir a Ura?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
							<button type="button" id="closeExcluirUraCustomModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR URA CUSTOM-->


	<!--#END - MODAL ============================================================================================================================== -->

<script>

var wrapper_editar = $(".container-editar");
var max_fields_editar = 10;
var y = 1;
var w = 1;
var texto = "";

function del_editarUra() {
	if (w > 1) {
		for (i=2; i<=w; i++) {
			$('#li-'+i).remove();
		}
	}
	y = 1;
	w = 1;
}

function add_editarUra() {
	if (y < max_fields_editar) {
		y++;
		w++;
		texto = "";
		texto += '<li class="list-group-item" id="li-'+w+'"><div class="row clearfix">';
		texto += '<div class="col-md-1 col-sm-1 col-xs-5 form-control-label" style="margin-bottom: 0px;">';
		texto += '<label>Menu</label></div>';
		texto += '<div class="col-md-1 col-sm-1 col-xs-7"><div class="form-group form-float" style="margin-bottom: 0px;">';
		texto += '<select name="opcao[]" id="menu_editarUra-'+w+'" class="form-control show-tick">';
		for ($i = 0; $i <= 9; $i++) {
			texto += '<option value='+$i+'>'+$i+'</option>';
		}
		texto += '</select></div></div>';
		texto += '<div class="col-md-1 col-sm-2 col-xs-5 form-control-label"><label>Anúncio</label></div>';
		texto += '<div class="col-md-3 col-sm-4 col-xs-7"><div class="form-group form-float" style="margin-bottom: 5px;">';
		texto += '<select name="anuncio[]" id="anuncio_editarUra-'+w+'" class="form-control show-tick">';
		texto += '<option value=""> - </option>';
		<?php
			foreach($audios as $value) {
				print "texto += '<option value=\"".$value."\">".$value."</option>';";
			}
		?>
		texto += '</select></div></div>';
		texto += '<div class="col-md-1 col-sm-2 col-xs-5 form-control-label"><label>Destino</label></div>';
		texto += '<div class="col-md-3 col-sm-4 col-xs-7"><div class="form-group form-float" style="margin-bottom: 5px;">';
		texto += '<select name="destino[]" id="destino_editarUra-'+w+'" class="form-control show-tick" data-live-search="true">';
		texto += '<option value=""> - </option>';
		texto += '<option value="repetir">Repetir URA</option>';
		texto += '<!--<option value="opc">Telefonista</option>-->';
		texto += '<option value="hangup">Terminar Ligação</option>';
		<?php
			foreach($destinos as $key=>$value) {
				print "texto += '".$value."';";
			}
		?>
		texto += '</select></div></div>';
		texto += '<div class="col-md-1 col-sm-2 col-xs-6 form-control-label"><label>Prio</label></div>';
		texto += '<div class="col-md-1 col-sm-2 col-xs-6"><div class="form-group form-float" title="prioridade fila" style="margin-bottom: 5px;">';
		texto += '<select name="prioridade[]" id="prioridade_editarUra-'+w+'" class="form-control show-tick">';
		for ($i = 1; $i <= 10; $i++) {
			texto += '<option value='+$i+'>'+$i+'</option>';
		}
		texto += '</select></div></div>';
		texto += '</div><a href="#" class="delete">Delete</a></li>';
        $(wrapper_editar).append(
			texto
		);
		//REFRESH NO SELECTPICKER PRA PODER ATUALIZAR O VALOR
		$('#menu_editarUra-'+w).addClass('selectpicker');
		$('#menu_editarUra-'+w).selectpicker('refresh');
		$('#anuncio_editarUra-'+w).addClass('selectpicker');
		$('#anuncio_editarUra-'+w).selectpicker('refresh');
		$('#destino_editarUra-'+w).addClass('selectpicker');
		$('#destino_editarUra-'+w).selectpicker('refresh');
		$('#prioridade_editarUra-'+w).addClass('selectpicker');
		$('#prioridade_editarUra-'+w).selectpicker('refresh');
    } else {
		alert('Limite alcançado!')
	}
};

function botaoExcluirUra(excluirUra) {
	$('#excluirUra').val(excluirUra);

	$('#excluirUraLabel').text("Excluir Ura "+excluirUra);
	$("#excluirUraModal").modal();
};


//FUNCOES URA CUSTOM
function botaoNovaUraCustom() {
	$('#new_uraCustom').val('1');
	$('#nome_uraCustom').val('');
	$('#textarea_uraCustom').val('');
}

function botaoEditarUraCustom(ura) {
	var uras_custom = <?php echo json_encode($uras_custom, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
	
	$('#new_uraCustom').val('0');
	$('#editarnome_uraCustom').val(ura);
	$('#nome_uraCustom').val(ura);
	
	var text = "";
	for (var alfa in uras_custom[ura].linhas) {
		text += uras_custom[ura].linhas[alfa]+"\n";
	}
	$('#textarea_uraCustom').val(text);
}

function botaoExcluirUraCustom(ura) {
	$('#excluirUraCustom').val(ura);

	$('#excluirUraCustomLabel').text("Excluir Ura "+ura);
	$("#excluirUraCustomModal").modal();
};
//FIM FUNCOES URA CUSTOM


$(document).ready(function(){

	var uras = <?php echo json_encode($uras, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
	/*
	"TESTE":{
		"anuncio":"Por Favor Aguarde",
		"wait":"5",
		"opcao":{
			"i":{"anuncio":"Agradecemos","destino":"hangup"},
			"t":{"anuncio":"Agradecemos","destino":"hangup"},
			"1":{"anuncio":"Agradecemos","destino":"QUE/600","prioridade":"1"},
			"2":{"anuncio":"Agradecemos","destino":"SIP/4000","prioridade":1}
		}
	}
	*/

	$(".editar-ura").on('click', function(event) {
		event.preventDefault();

		var ura = $(this).data('id');

		document.getElementById('editarUraLabel').innerHTML = "Editar Ura: "+ura;

		$('#editarUra').val(ura);
		
		$('#nome_editarUra').val(ura);
		var aux = 0;
		$('#anuncio-ura_editarUra option').each(function(){
			if ($(this).val() == uras[ura].anuncio) {
				$('#anuncio-ura_editarUra').selectpicker('val', uras[ura].anuncio);
				aux = 1;
			} else if (aux != 1) {
				$('#anuncio-ura_editarUra').selectpicker('val', 'null');
			}
		});
		aux = 0;
		$('#wait_editarUra option').each(function(){
			if ($(this).val() == uras[ura].wait) {
				$('#wait_editarUra').selectpicker('val', uras[ura].wait);
				aux = 1;
			} else if (aux != 1) {
				$('#wait_editarUra').selectpicker('val', '1');
			}
		});
		
		if (uras[ura].faixa == '1') {
			$('#faixa_editarUra').prop('checked',true);
		} else {
			$('#faixa_editarUra').prop('checked',false);
		}
		
		del_editarUra();
		var menu = 1;
		for (var i in uras[ura].opcoes) {
			
			if (i != 1 && i != "i" && i != "t") {
				add_editarUra();
			}

			if (i == "i" || i == "t") {
				aux = 0;
				$('#anuncio_editarUra-'+i+' option').each(function(){
					if ($(this).val() == uras[ura].opcoes[i].anuncio) {
						$('#anuncio_editarUra-'+i).selectpicker('val', uras[ura].opcoes[i].anuncio);
						aux = 1;
					} else if (aux != 1) {
						$('#anuncio_editarUra-'+i).selectpicker('val', '');
					}
				});
				aux = 0;
				$('#destino_editarUra-'+i+' option').each(function(){
					if ($(this).val() == uras[ura].opcoes[i].destino) {
						$('#destino_editarUra-'+i).selectpicker('val', uras[ura].opcoes[i].destino);
						aux = 1;
					} else if (aux != 1) {
						$('#destino_editarUra-'+i).selectpicker('val', '');
					}
				});
				aux = 0;
				$('#prioridade_editarUra-'+i+' option').each(function(){
					if ($(this).val() == uras[ura].opcoes[i].prioridade) {
						$('#prioridade_editarUra-'+i).selectpicker('val', uras[ura].opcoes[i].prioridade);
						aux = 1;
					} else if (aux != 1) {
						$('#prioridade_editarUra-'+i).selectpicker('val', '1');
					}
				});
			} else if (i != "i" || i != "t") {
				aux = 0;
				$('#menu_editarUra-'+menu+' option').each(function(){
					if ($(this).val() == i) {
						$('#menu_editarUra-'+menu).selectpicker('val', i);
						aux = 1;
					} else if (aux != 1) {
						$('#menu_editarUra-'+menu).selectpicker('val', 'null');
					}
				});
				$('#anuncio_editarUra-'+menu+' option').each(function(){
					if ($(this).val() == uras[ura].opcoes[i].anuncio) {
						$('#anuncio_editarUra-'+menu).selectpicker('val', uras[ura].opcoes[i].anuncio);
						aux = 1;
					} else if (aux != 1) {
						$('#anuncio_editarUra-'+menu).selectpicker('val', 'null');
					}
				});
				aux = 0;
				$('#destino_editarUra-'+menu+' option').each(function(){
					if ($(this).val() == uras[ura].opcoes[i].destino) {
						$('#destino_editarUra-'+menu).selectpicker('val', uras[ura].opcoes[i].destino);
						aux = 1;
					} else if (aux != 1) {
						$('#destino_editarUra-'+menu).selectpicker('val', 'null');
					}
				});
				aux = 0;
				$('#prioridade_editarUra-'+menu+' option').each(function(){
					if ($(this).val() == uras[ura].opcoes[i].prioridade) {
						$('#prioridade_editarUra-'+menu).selectpicker('val', uras[ura].opcoes[i].prioridade);
						aux = 1;
					} else if (aux != 1) {
						$('#prioridade_editarUra-'+menu).selectpicker('val', '1');
					}
				});
				menu++;
			}
		}
	});
	
	$(function () {
		$('#nestable-contextos').nestable({
			maxDepth: 1
		})
	});
	
	$('#editarUraModal').on('show.bs.modal', function (e) {
		$('.dd').nestable({
		    maxDepth: 1
		});
	});
	
	$('#novaUraModal').on('show.bs.modal', function (e) {
		$('.dd').nestable({
		    maxDepth: 1
		});
	});
	
	
	var max_fields = 10;
	var wrapper = $(".container1");
  
    var x = 1;
	var z = 1;
	var texto = "";
    $("#add_novaUra").click(function(e){
        e.preventDefault();
        if (x < max_fields) {
            x++;
			z++;
			texto = "";
			texto += '<li class="list-group-item"><div class="row clearfix">';
			texto += '<div class="col-md-1 col-sm-1 col-xs-5 form-control-label" style="margin-bottom: 0px;">';
			texto += '<label>Menu</label></div>';
			texto += '<div class="col-md-1 col-sm-1 col-xs-7"><div class="form-group form-float" style="margin-bottom: 0px;">';
			texto += '<select name="opcao[]" id="menu_novaUra-'+z+'" class="form-control show-tick">';
			for ($i = 0; $i <= 9; $i++) {
				texto += '<option value='+$i+'>'+$i+'</option>';
			}
			texto += '</select></div></div>';
			texto += '<div class="col-md-1 col-sm-2 col-xs-5 form-control-label"><label>Anúncio</label></div>';
			texto += '<div class="col-md-3 col-sm-4 col-xs-7"><div class="form-group form-float" style="margin-bottom: 5px;">';
			texto += '<select name="anuncio[]" id="anuncio_novaUra-'+z+'" class="form-control show-tick">';
			texto += '<option value=""> - </option>';
			<?php
				foreach($audios as $value) {
					print "texto += '<option value=\"".$value."\">".$value."</option>';";
				}
			?>
			texto += '</select></div></div>';
			texto += '<div class="col-md-1 col-sm-2 col-xs-5 form-control-label"><label>Destino</label></div>';
			texto += '<div class="col-md-3 col-sm-4 col-xs-7"><div class="form-group form-float" style="margin-bottom: 5px;">';
			texto += '<select name="destino[]" id="destino_novaUra-'+z+'" class="form-control show-tick" data-live-search="true">';
			texto += '<option value=""> - </option>';
			texto += '<option value="repetir">Repetir URA</option>';
			texto += '<!--<option value="opc">Telefonista</option>-->';
			texto += '<option value="hangup">Terminar Ligação</option>';
			<?php
				foreach($destinos as $key=>$value) {
					print "texto += '".$value."';";
				}
			?>
			texto += '</select></div></div>';
			texto += '<div class="col-md-1 col-sm-2 col-xs-6 form-control-label"><label>Prio</label></div>';
			texto += '<div class="col-md-1 col-sm-2 col-xs-6"><div class="form-group form-float" title="prioridade fila" style="margin-bottom: 5px;">';
			texto += '<select name="prioridade[]" id="prioridade_novaUra-'+z+'" class="form-control show-tick">';
			for ($i = 1; $i <= 10; $i++) {
				texto += '<option value='+$i+'>'+$i+'</option>';
			}
			texto += '</select></div></div>';
			texto += '</div><a href="#" class="delete">Delete</a></li>';
            $(wrapper).append(
				/*'<li class="list-group-item"><div><p>some text</p></div><a href="#" class="delete">Delete</a></li>'*/
				texto
			);
			$('#menu_novaUra-'+z).addClass('selectpicker');
			$('#menu_novaUra-'+z).selectpicker('refresh');
			$('#anuncio_novaUra-'+z).addClass('selectpicker');
			$('#anuncio_novaUra-'+z).selectpicker('refresh');
			$('#destino_novaUra-'+z).addClass('selectpicker');
			$('#destino_novaUra-'+z).selectpicker('refresh');
			$('#prioridade_novaUra-'+z).addClass('selectpicker');
			$('#prioridade_novaUra-'+z).selectpicker('refresh');
        } else {
			alert('Limite alcançado!')
		}
    });
  
    $(wrapper).on("click",".delete", function(e){
        e.preventDefault(); $(this).parent('li').remove(); x--;
    })
	
	$("#add_editarUra").click(function(e){
		e.preventDefault();
		add_editarUra();
	})
	
	$(wrapper_editar).on("click",".delete", function(e){
        e.preventDefault(); $(this).parent('li').remove(); y--;
    })

});

//Pesquisa e Satisfacao ==================================================================================================

var ura_satisfacao = <?php echo json_encode($ura_satisfacao, JSON_FORCE_OBJECT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
//{"notas":{"0":"Ruim","1":"Razoável","2":"Bom","3":"Excelente"},"ura_pesquisa_satisfacao":{"anuncio":"fpm-world-mix","wait":"10","agradecimento":"Agradecemos"}};

var max_fields_satisfacao = 10;
var wrapper_satisfacao = $(".containerUraSatisfacao");
var field_value = <?=$cont;?>;

function add_satisfacaoUra() {
	if (field_value < max_fields_editar) {
		field_value++;
		texto = "";
		texto += '<li class="list-group-item"><div class="row clearfix">';
		texto += '<div class="col-md-1 col-sm-1 col-xs-5 form-control-label" style="margin-bottom: 0px;">';
		texto += '<label>Nota</label></div>';
		texto += '<div class="col-md-1 col-sm-1 col-xs-7"><div class="form-group form-float" style="margin-bottom: 0px;">';
		texto += '<select name="nota[]" id="nota_satisfacaoUra-'+field_value+'" class="form-control show-tick">';
		for ($i = 0; $i <= 9; $i++) {
			texto += '<option value='+$i+'>'+$i+'</option>';
		}
		texto += '</select></div></div>';
		texto += '<div class="col-md-1 col-sm-1 col-xs-5 form-control-label" style="margin-bottom: 0px;">';
		texto += '<label for="descricao_satisfacaoUra-'+field_value+'">Descrição</label></div>';
		texto += '<div class="col-md-3 col-sm-3 col-xs-7" style="margin-bottom: 0px;">';
		texto += '<div class="form-group"><div class="form-line">';
		texto += '<input type="text" name="descricao[]" id="descricao_satisfacaoUra-'+field_value+'" class="form-control">';
		texto += '</div></div></div>';
		texto += '</div><a href="#" class="delete">Delete</a></li>';

        $(wrapper_satisfacao).append(
			texto
		);
		//REFRESH NO SELECTPICKER PRA PODER ATUALIZAR O VALOR
		$('#nota_satisfacaoUra-'+field_value).addClass('selectpicker');
		$('#nota_satisfacaoUra-'+field_value).selectpicker('refresh');
    } else {
		alert('Limite alcançado!');
	}
};

var satisfacaoAnuncio = "<?=@$ura_satisfacao['ura_pesquisa_satisfacao']['anuncio'];?>";
var satisfacaoAgradecimento = "<?=@$ura_satisfacao['ura_pesquisa_satisfacao']['agradecimento'];?>";
var satisfacaoWait = "<?=@$ura_satisfacao['ura_pesquisa_satisfacao']['wait'];?>";

function pre_load(){
	$('#anuncio_satisfacaoUra').selectpicker('refresh');
	$('#anuncio_satisfacaoUra').selectpicker('val', satisfacaoAnuncio);
	$('#agradecimento_satisfacaoUra').selectpicker('refresh');
	$('#agradecimento_satisfacaoUra').selectpicker('val', satisfacaoAgradecimento);
	$('#wait_satisfacaoUra').selectpicker('refresh');
	$('#wait_satisfacaoUra').selectpicker('val', satisfacaoWait);
}

$(document).ready(function(){
	pre_load();
	
	$("#add_satisfacaoUra").click(function(e){
		e.preventDefault();
		add_satisfacaoUra();
	})
	
	$(wrapper_satisfacao).on("click",".delete", function(e){
        e.preventDefault(); $(this).parent('li').remove(); field_value--;
    })
});

</script>