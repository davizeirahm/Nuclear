<?php
	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.telefonista.php");
	
	//PARA OBTER OS DESTINOS
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_sip.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_iax2.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.filas.php");
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "salvar") {
		//salva as interfaces
		$num_telefonista = $_POST["num_telefonista"];
		$op1 = $_POST['op1'];
		$op2 = $_POST['op2'];
		$destino = $_POST['destino'];

		$erro = "";
		if ( isset($_POST['op1']) && $_POST['op1'] != "") {
			if ( !is_numeric($_POST['op1']) ) {
				$erro = "Erro: Operadora inválida!";
			}
		}
		if ( isset($_POST['op2']) && $_POST['op2'] != "") {
			if ( !is_numeric($_POST['op2']) ) {
				$erro = "Erro: Operadora inválida!";
			}
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !salvar_telefonista($_POST) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}

	// DECLARAÇÃO DE VARIÁVEIS ==============================================================================================
	
	$op = get_op();
	$destino = get_destino();
	
	//DESTINOS
	$ramais_sip = get_ramais();
	$ramais_iax2 = get_ramais_iax();
	$filas = get_filas();


?>

	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- Bloco Pesquisa -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
                                	<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
						</div>
                        <div class="body" style="padding-bottom: 5px;">
                            <!--Formulário-->
							<form id="filtro-user" method="post">
								<?=$text_form;?>
								<input type="hidden" name="cmd" value="salvar" />
								<div class="row clearfix">
									<div class="col-sm-6">
										<div class="form-group form-float" style="margin-bottom:0px">
											<div class="form-line">
												<input name="num_telefonista" id="num_telefonista" type="text" class="form-control dialplan" <?=(@$op['OP_COMUM']?'value="'.$op['OP_COMUM'].'"':"");?> />
												<label class="form-label">Número telefonista</label>
											</div>
										</div>
									</div>
								</div>
								<div class="row clearfix demo-masked-input">
									<div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
										<label>Operadora 1</label>
									</div>
									<div class="col-md-4 col-sm-3 col-xs-7">
										<div class="form-group form-float" style="margin-bottom: 0px;">
											<select name="op1" id="op1" class="form-control show-tick">
												<option value=""> - </option>
													<?php
														foreach($ramais_sip as $key=>$value) {
															print "<option value=\"".$key."\">SIP/".$key."</option>";
														}
														foreach($ramais_iax2 as $key=>$value) {
															print "<option value=\"".$key."\">IAX2/".$key."</option>";
														}
													?>
											</select>
										</div>
									</div>
									<div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
										<label>Operadora 2</label>
									</div>
									<div class="col-md-4 col-sm-3 col-xs-7">
										<div class="form-group form-float" style="margin-bottom: 0px;">
											<select name="op2" id="op2" class="form-control show-tick">
												<option value=""> - </option>
													<?php
														foreach($ramais_sip as $key=>$value) {
															print "<option value=\"".$key."\">SIP/".$key."</option>";
														}
														foreach($ramais_iax2 as $key=>$value) {
															print "<option value=\"".$key."\">IAX2/".$key."</option>";
														}
													?>
											</select>
										</div>
									</div>
								</div>
								<hr>
								<small>Selecione o destino</small>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-3 col-xs-6" style="margin-bottom: 0px;">
										<div class="form-group demo-radio-button">
											<input name="tipo" type="radio" id="tipo_fila" value="QUE"/>
											<label for="tipo_fila">Fila</label>
										</div>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-6">
										<div class="form-group form-float" style="margin-bottom: 0px;">
											<select name="destino" id="fila" class="form-control show-tick">
												<option value=""> - </option>
												<?php
													foreach($filas as $key=>$value) {
														print "<option value=\"QUE/".$key."\">QUE/".$key."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-md-2 col-sm-3 col-xs-6" style="margin-bottom: 0px;">
										<div class="form-group demo-radio-button">
											<input name="tipo" type="radio" id="tipo_ramal" value="ramal"/>
											<label for="tipo_ramal">Ramal</label>
										</div>
									</div>
									<div class="col-md-4 col-sm-6 col-xs-6">
										<div class="form-group form-float" style="margin-bottom: 0px;">
											<select name="destino" id="ramal" class="form-control show-tick">
												<option value=""> - </option>
												<?php
													foreach($ramais_sip as $key=>$value) {
														print "<option value=\"SIP/".$key."\">SIP/".$key."</option>";
													}
													foreach($ramais_iax2 as $key=>$value) {
														print "<option value=\"IAX2/".$key."\">IAX2/".$key."</option>";
													}
												?>
											</select>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
										<button id="btnSubmit" type="submit" class="btn btn-primary waves-effect">
											<i class="material-icons">save</i>
											<span>SALVAR</span>
										</button>
									</div>
								</div>
						</div>
						</form>
						<!--FIM FORMULÁRIO-->
					</div>
                </div>
            </div>
            <!-- #END# Bloco Pesquisa -->
        </div>
		<!--#END of PAGE CONTENT-->


<script>

var num_telefonista = "<?=$op['OP_COMUM'];?>";
var op1 = "<?=$op['OP1'];?>";
var op2 = "<?=$op['OP2'];?>";
var tipo = "<?=$destino['tipo'];?>";
var destino = "<?=$destino['destino'];?>";

function pre_load(){
	if (tipo == "QUE" || tipo == "") {
		$('#tipo_fila').prop('checked', 'checked');
		$('#fila').selectpicker('refresh');
		$('#fila').selectpicker('val', destino);
		$('#ramal').prop('disabled', 'disabled');
		$('#ramal').selectpicker('refresh');
	} else if (tipo == "SIP" || tipo == "IAX2") {
		$('#tipo_ramal').prop('checked', 'checked');
		$('#ramal').selectpicker('refresh');
		$('#ramal').selectpicker('val', destino);
		$('#fila').prop('disabled', 'disabled');
		$('#fila').selectpicker('refresh');
	}
	$('#op1').selectpicker('refresh');
	$('#op1').selectpicker('val', op1);
	$('#op2').selectpicker('refresh');
	$('#op2').selectpicker('val', op2);
}

$(document).ready(function(){
	
	$("#tipo_fila").on('click',function(){
		$("#fila").prop('disabled', false);
		$("#fila").selectpicker('refresh');
		$("#ramal").prop('disabled', 'disabled');
		$("#ramal").selectpicker('refresh');
	});
	
	$("#tipo_ramal").on('click',function(){
		$("#fila").prop('disabled', 'disabled');
		$("#fila").selectpicker('refresh');
		$("#ramal").prop('disabled', false);
		$("#ramal").selectpicker('refresh');
	});
	
	pre_load();
});

</script>
