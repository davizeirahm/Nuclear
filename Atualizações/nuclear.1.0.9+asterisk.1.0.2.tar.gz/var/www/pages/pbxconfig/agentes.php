<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.db.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.config.ramal.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.agentes.php");
	
	require_once(DIR_WWW."funcoes/funcoes.config.usuarios.php");

	// DECLARAÇÃO DE VARIÁVEIS ==============================================================================================
	
	$agentes = get_agentes();
	//echo json_encode($agentes, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
	
	$users = get_users();

	//ROTAS ===============================================================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "novoAgente") {
		//print_r($_POST);
		//die();
		$erro = "";
		if (!isset($_POST['agente']) || @$_POST['agente'] == "" || @$_POST['agente'] == "admin") {
			$erro = "Erro: Agente inválido!";
		}
		if ( array_search(@$_POST['agente'], array_column($users, 'nome')) !== FALSE ) {
			$erro = "Erro: Nome de agente já utilizado como usuário!";
		}
		if ( array_key_exists($_POST['agente'], $agentes) ) {
			$erro = "Erro: Agente já utilizado!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !novo_agente($_POST) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "editarAgente") {
		
		$erro="";
		if (!isset($_POST['editaragente']) || @$_POST['editaragente'] == "") {
			$erro = "Erro: Agente Inválido!";
		}
		if (!isset($_POST['agente']) || @$_POST['agente'] == "") {
			$erro = "Erro: Agente inválido!";
		}
		if ( array_search(@$_POST['agente'], array_column($users, 'nome')) !== FALSE ) {
			$erro = "Erro: Nome de agente já utilizado como usuário!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !editar_agente($_POST) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirAgente") {
		
		$erro="";
		if (!isset($_POST['agente']) || @$_POST['agente'] == "") {
			$erro = "Erro: Agente Inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !excluir_agente($_POST['agente']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "resetAgente") {
		
		$erro="";
		if (!isset($_POST['agente']) || @$_POST['agente'] == "") {
			$erro = "Erro: Agente Inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !reset_agente($_POST['agente']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}

?>


	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- MENU AGENTES -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
						<div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
                                	<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
						</div>
                        <div class="body">
                            
							<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novoAgenteModal">
								<i class="material-icons">add_circle</i>
								<span>NOVO AGENTE</span>
							</button>
							<div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
                                            <th>Login</th>
											<th>Nome</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<?php
									foreach($agentes as $agente=>$vetor) {
										if (is_array($vetor)) {
									?>
										<tr>
											<td><?=$agente;?></td>
											<td><?=$vetor['nome'];?></td>
											<td>
												<a href="javascript:;" class="editar-agente" data-id="<?=$agente;?>" data-toggle="modal" data-target="#editarAgenteModal"><i class="material-icons" title="Editar">edit</i></a>&nbsp;
												<a href="javascript:;" class="play" onclick="botaoResetAgente('<?=$agente;?>')"><i class="material-icons" title="Reset Senha">cached</i></a>
												<a href="javascript:;" class="play" onclick="botaoExcluirAgente('<?=$agente;?>')"><i class="material-icons" title="Excluir">delete</i></a>
											</td>
										</tr>
									<?php
										}
									}
									?>
                                    </tbody>
                                </table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--END - PAGE CONTENT-->


	<!-- MODAL ================================================================================================================================== -->

		<!--MODAL NOVO AGENTE-->
            <div class="modal fade" id="novoAgenteModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="modal-title" id="novoAgenteLabel">Novo Agente</h2>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
							<form id="formNovoAgente" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="novoAgente" />

								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="agente_novoAgente">Login</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="agente" id="agente_novoAgente" class="form-control alphanumeric">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="nome_novoAgente">Nome</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="nome" id="nome_novoAgente" class="form-control nome">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
									<div class="col-md-9 col-sm-12 col-xs-12">
										<div class="form-group form-float" style="margin-bottom: 0px;">
											<input type="checkbox" name="agendar" id="agendar_novoAgente" value="1" class="filled-in chk-col-light-blue"/>
											<label for="agendar_novoAgente">Mostrar agendar ligação para o agente?</label>
										</div>
									</div>
								</div>
								<div class="row clearfix">
                                    <div class="col-xs-12" style="margin-bottom: 10px;">
                                        <label>Senha web padrão 123456 (alterar no primeiro acesso)</label>
                                    </div>
								</div>

							</div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
                            <button type="button" id="closenovoAgenteModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
							</form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL NOVA AGENTE-->
		

		<!--MODAL EDITAR AGENTE-->
			<div class="modal fade" id="editarAgenteModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="modal-title" id="editarAgenteLabel">Editar Agente</h2>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
							<form id="formNovoAgente" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="editarAgente" />
							<input type="hidden" id="editarAgente" name="editaragente" value="" />

								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="agente_editarAgente">Login</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="agente" id="agente_editarAgente" class="form-control alphanumeric">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="nome_editarAgente">Nome</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="nome" id="nome_editarAgente" class="form-control nome">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
									<div class="col-md-9 col-sm-12 col-xs-12">
										<div class="form-group form-float" style="margin-bottom: 0px;">
											<input type="checkbox" name="agendar" id="agendar_editarAgente" value="1" class="filled-in chk-col-light-blue"/>
											<label for="agendar_editarAgente">Mostrar agendar ligação para o agente?</label>
										</div>
									</div>
								</div>

							</div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
                            <button type="button" id="closeeditarAgenteModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
							</form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EDITAR AGENTE-->


	    <!--MODAL EXCLUIR AGENTE-->
            <div class="modal fade" id="excluirAgenteModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirAgenteLabel">Excluir Agente</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirAgente" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="excluirAgente" />
				<input type="hidden" id="excluirAgente" name="agente" value="" />
			    <p>Tem certeza que deseja excluir o Agente?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
							<button type="button" id="closeExcluirAgenteModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR AGENTE-->
		
		<!--MODAL RESET SENHA AGENTE-->
            <div class="modal fade" id="resetAgenteModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="resetAgenteLabel">Excluir Agente</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirAgente" method="post">
					<?=$text_form;?>
					<input type="hidden" name="cmd" value="resetAgente" />
					<input type="hidden" id="resetAgente" name="agente" value="" />
					<p>Tem certeza que deseja resetar a senha web?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">done</i>
								<span>Sim</span>
							</button>
							<button type="button" id="closeResetAgenteModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
				</form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL RESET SENHA AGENTE-->

	<!--#END - MODAL ============================================================================================================================== -->

<script>

function botaoExcluirAgente(excluirAgente) {
	$('#excluirAgente').val(excluirAgente);

	$('#excluirAgenteLabel').text("Excluir Agente "+excluirAgente);
	$("#excluirAgenteModal").modal();
};

function botaoResetAgente(resetAgente) {
	$('#resetAgente').val(resetAgente);

	$('#resetAgenteLabel').text("Resetar senha do agente "+resetAgente);
	$("#resetAgenteModal").modal();
};

$(document).ready(function(){

	var agentes = <?php echo json_encode($agentes, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>
	/*
	{"100":{
		"senha":"1234",
		"nome":"agente 100",
		"agendar":"1"
		}
	}
	*/

	$(".editar-agente").on('click', function(event) {
		event.preventDefault();

		var agente = $(this).data('id');

		document.getElementById('editarAgenteLabel').innerHTML = "Editar Agente: "+agente;

		$('#editarAgente').val(agente);
		
		$('#agente_editarAgente').val(agente);
		$('#nome_editarAgente').val(agentes[agente].nome);
		$('#agendar_editarAgente').prop('checked',false);
		if ( agentes[agente].agendar == "1" ) {
			$('#agendar_editarAgente').prop('checked',true);
		}
	});

});

</script>