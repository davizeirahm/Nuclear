<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.config.ramal.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.funcionalidades.php");
	
	if ( isset($_GET['tipo']) && $_GET['tipo'] == "codigos") {
		$tipo = "codigos";
	} else {
		$tipo = "features";
	}
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "salvarFeatures") {

		$erro = "";
		/*if ( !is_numeric($_POST['mfcr2_max_ani']) ) {
			$erro = "Erro: mfcr2_max_ani inválido!";
		}
		if ( !is_numeric($_POST['mfcr2_max_dnis']) ) {
			$erro = "Erro: mfcr2_max_dnis inválido!";
		}
		if ( !is_numeric($_POST['mfcr2_metering_pulse_timeout']) ) {
			$erro = "Erro: mfcr2_metering_pulse_timeout inválido!";
		}*/
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		unset($_POST['pagina']);
		unset($_POST['menu']);
		unset($_POST['cmd']);
		if ( !salvar_features_conf($_POST) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		} else {
			print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		}
	} elseif (isset($_POST['cmd']) && $_POST['cmd'] == "salvarCodigos") {

		$erro = "";
		/*if ( !isset($_POST['loadzone']) ) {
			$erro = "Erro: loadzone inválido!";
		}
		if ( !isset($_POST['defaultzone']) ) {
			$erro = "Erro: defaultzone inválido!";
		}*/
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		unset($_POST['pagina']);
		unset($_POST['menu']);
		unset($_POST['cmd']);
		if ( !salvar_codigos_conf($_POST) ) {
			print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		} else {
			print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
		}
	}
	
	//DEFINIÇAO DE VARIAVEIS ============================================
	$features = get_features_config();
	//print_r($config);
	
	$codigos = get_codigos_config();
	//print_r($codigos);
	/*[sigame-interno] => 1 
	[dnd] => 0 
	[captura-individual] => 1 
	[pega_trote] => 0 
	[num-ramal] => 1 
	[caixa-postal] => 1 
	[spy] => 1 
	[spy-callcenter-escuta] => 0 
	[spy-callcenter-fala] => 0 
	[hora-certa] => 1 
	[cadeado] => 1 
	[codigo_contabil] => 1 
	[login-agent] => 1 
	[pausa] => 1 
	[sala_de_conferencia] => 1 
	[parkedcalls] => 1 
	[park-hints] => 1 
	[login-agent-crm] => 1 
	[pausa-crm] => 0
	*/

?>

		<!--PAGE CONTENT-->
        <div class="container-fluid">

            <div class="row clearfix">
                <!-- Bloco Pesquisa -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
									<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
						</div>
                        <div class="body" style="padding-bottom: 5px;">
                            <ul class="nav nav-tabs tab-nav-right" role="tablist">
                                <li role="presentation" <?php echo ( @$tipo == "features" ? "class=\"active\"" : "" ); ?> ><a href="#features" data-toggle="tab">FEATURES</a></li>
                                <li role="presentation" <?php echo ( @$tipo == "codigos" ? "class=\"active\"" : "" ); ?> ><a href="#codigos" data-toggle="tab">CÓDIGOS</a></li>
							</ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
								<div role="tabpanel" class="tab-pane fade <?php echo ( @$tipo == "features" ? "in active" : "" ); ?>" id="features">



					<!--Formulário-->
					<div class="demo-masked-input">
						<form id="filtro-user" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="salvarFeatures" />
							
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label for="pickupexten">Puxar Ligação</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group" style="margin-bottom: 0px;">
										<div class="form-line">
											<input type="text" name="pickupexten" id="pickupexten" class="form-control " <?=(@$features['pickupexten']?'value="'.$features['pickupexten'].'"':"");?> >
										</div>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label for="atxferswap">Pêndulo</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group" style="margin-bottom: 0px;">
										<div class="form-line">
											<input type="text" name="atxferswap" id="atxferswap" class="form-control " <?=(@$features['atxferswap']?'value="'.$features['atxferswap'].'"':"");?> >
										</div>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label for="atxferthreeway">Conferência</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group" style="margin-bottom: 0px;">
										<div class="form-line">
											<input type="text" name="atxferthreeway" id="atxferthreeway" class="form-control " <?=(@$features['atxferthreeway']?'value="'.$features['atxferthreeway'].'"':"");?> >
										</div>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label for="parkcall">Estacionamento</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group" style="margin-bottom: 0px;">
										<div class="form-line">
											<input type="text" name="parkcall" id="parkcall" class="form-control " <?=(@$features['parkcall']?'value="'.$features['parkcall'].'"':"");?> >
										</div>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label for="blindxfer">Transferência Direta (Blind transfer)</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group" style="margin-bottom: 0px;">
										<div class="form-line">
											<input type="text" name="blindxfer" id="blindxfer" class="form-control " <?=(@$features['blindxfer']?'value="'.$features['blindxfer'].'"':"");?> >
										</div>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label for="atxfer">Transferência Atendida (Attended transfer)</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group" style="margin-bottom: 0px;">
										<div class="form-line">
											<input type="text" name="atxfer" id="atxfer" class="form-control " <?=(@$features['atxfer']?'value="'.$features['atxfer'].'"':"");?> >
										</div>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label for="atxferabort">Abortar Transferência</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group" style="margin-bottom: 0px;">
										<div class="form-line">
											<input type="text" name="atxferabort" id="atxferabort" class="form-control " <?=(@$features['atxferabort']?'value="'.$features['atxferabort'].'"':"");?> >
										</div>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-3 col-sm-3 col-xs-5 form-control-label">
									<label for="atxfernoanswertimeout">Transferência Timeout</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-7">
									<div class="form-group" style="margin-bottom: 0px;">
										<div class="form-line">
											<input type="text" name="atxfernoanswertimeout" id="atxfernoanswertimeout" class="form-control timeout" <?=(@$features['atxfernoanswertimeout']?'value="'.$features['atxfernoanswertimeout'].'"':"");?> >
										</div>
									</div>
								</div>
							</div>

							<div class="row clearfix">
								<div class="col-xs-12">
									<button id="btnSubmit" type="submit" class="btn btn-primary waves-effect">
										<i class="material-icons">save</i>
										<span>SALVAR</span>
									</button>
								</div>
							</div>
						</form>
					</div>
					<!--FIM FORMULÁRIO-->
					
								</div>
								<div role="tabpanel" class="tab-pane fade <?php echo ( @$tipo == "codigos" ? "in active" : "" ); ?>" id="codigos">

					<!--Codigos-->
					<div class="demo-masked-input">
						<form id="filtro-user" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="salvarCodigos" />
							
							<h4>Habilitar Códigos</h4>
						<?php
						foreach ($codigos as $key=>$value) {
						?>
							<div class="row clearfix">
								<div class="col-md-6 col-sm-12 col-xs-12" style="margin-bottom: 0px;">
									<input type="hidden" name="<?=$key;?>" value="no" />
									<div class="col-md-3 col-sm-6 col-xs-12 form-control-label" style="margin-bottom: 0px; width: auto; box-shadow: none;">
										<input type="checkbox" name="<?=$key;?>" id="<?=$key;?>" value="yes" class="filled-in chk-col-light-blue" <?php echo ($value == 1?'checked':'');?>/>
										<label for="<?=$key;?>"><?=$key;?></label>
									</div>
								</div>
							</div>
						<?php
						}
						?>
							
							<div class="row clearfix">
								<div class="col-xs-12">
									<button id="btnSubmit" type="submit" class="btn btn-primary waves-effect">
										<i class="material-icons">save</i>
										<span>SALVAR</span>
									</button>
								</div>
							</div>
						</form>
					</div>
					<!--System-->
					
								</div>
							</div>
                        </div>
                    </div>
                </div>
                <!-- #END# Bloco Pesquisa -->
            </div>


		</div>
		<!--#END of PAGE CONTENT-->
	
	    <!-- Modal Dialogs ====================================================================================================================== -->


<script>

</script>