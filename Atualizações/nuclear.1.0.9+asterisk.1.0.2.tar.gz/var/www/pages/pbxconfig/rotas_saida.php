<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.db.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.astdb.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.config_e1.php"); //PARA OBTER TRONCOS G1, G2, etc.
	require_once(DIR_WWW."funcoes/funcoes.config.ramal.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.categorias.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.rotas_saida.php");

	if ( isset($_GET['tipo']) && $_GET['tipo'] == "portabilidade") {
		$tipo = "portabilidade";
	} elseif ( isset($_GET['tipo']) && $_GET['tipo'] == "custom") {
		$tipo = "custom";
	} else {
		$tipo = "rotas";
	}

	// DECLARAÇÃO DE VARIÁVEIS ==============================================================================================
	
	$rotas_saida = get_rotas_saida();
	//echo json_encode($rotas_saida, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
	
	$rotas_custom = get_rotas_custom();
	
	$troncos = get_troncos();
	$operadoras = get_operadoras();
	
	//$cidades = get_cidades();
	$codigos_ddd = get_cod_area();
	
	//ARQ_CATEGORIASAD_CONF - categorias_adicional.conf
	$rotas_adicional = get_rotas();
	//print_r($rotas);
	//Array ( [1] => interno [2] => abreviados [3] => facilidades [4] => grupo_sequencial [5] => grupo_ciclico [6] => grupo_paralelo [7] => noturno [8] => telefonista [9] => ESPECIAL [10] => EMERGENCIA [11] => 0300 [12] => 0800 [13] => LOCAL [14] => CELULAR_OITO_DIGITOS [15] => CELULAR_NONO_DIGITO [16] => CELULAR_DDD_OITO_DIGITOS [17] => CELULAR_DDD_NONO_DIGITO [18] => DDD [19] => DDI [20] => COBRAR_LOCAL [21] => DISCADOR [22] => COBRAR_DDD
	//echo json_encode($rotas, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

	//$editar_rota_codlocal = @printini(ARQ_EXTENSIONS_ADICIONAL, 'globals', 'COD_OP_LOCAL');
	$editar_rota_codlocal = get_astdb_value("ROTA", "COD_OP_LOCAL");
	$editar_rota_cidadelocal = get_astdb_value("ROTA", "CIDADE_LOCAL");

	//CODIGO LOCAL ============================================================================================================

	if ( isset($_POST['cmd']) && $_POST['cmd'] == "codlocal" ) {
	
		$codlocal = $_POST["rota_codlocal"];
		save_astdb_value('ROTA', 'COD_OP_LOCAL', $codlocal);
		
		$cidadelocal = $_POST["rota_cidadelocal"];
		save_astdb_value('ROTA', 'CIDADE_LOCAL', $cidadelocal);
		
		print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
		die();
	}

	//ROTAS ===============================================================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "novaRota") {
		//print_r($_POST);
		//die();
		//Array ( [nome] => teste [dialplan] => 010 [tronco] => Array ( [0] => SIP/1000 [1] => SIP/1050 ) [delete] => Array ( [0] => [1] => 1 ) [insere] => Array ( [0] => [1] => 1 ) [portabilidade] => Array ( [0] => 0 [1] => 1 ) [operadora] => Array ( [0] => [1] => CLARO ) )

		$erro = "";
		if (!isset($_POST['nome']) || @$_POST['nome'] == "") {
			$erro = "Erro: Nome Inválido!";
		}
		if (!isset($_POST['dialplan']) || @$_POST['dialplan'] == "") {
			$erro = "Erro: Dialplan inválido!";
		}
		if ( !isset($_POST['tronco']) ) {
			$erro = "Erro: 0x00000000!";
		}
		if ( isset($_POST['cidade']) ) {
			foreach ($_POST['cidade'] as $value) {
				if ($value != "") {
					if ( !verifica_cidade($value) ) {
						print "<script>
							alert('Cidade: ".$value." não encontrada!');
						</script>";
					}
				}
			}
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !nova_rota($_POST) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "editarRota") {
		
		$erro="";
		if (!isset($_POST['editarnome']) || @$_POST['editarnome'] == "") {
			$erro = "Erro: Rota Inválida!";
		}
		if (!isset($_POST['nome']) || @$_POST['nome'] == "") {
			$erro = "Erro: Nome Inválido!";
		}
		if (!isset($_POST['dialplan']) || @$_POST['dialplan'] == "") {
			$erro = "Erro: Dialplan inválido!";
		}
		if ( !isset($_POST['tronco']) ) {
			$erro = "Erro: 0x00000000!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		if ( isset($_POST['cidade']) ) {
			foreach ($_POST['cidade'] as $value) {
				if ($value != "") {
					if ( !verifica_cidade($value) ) {
						print "<script>
							alert('Cidade: ".$value." não encontrada!');
						</script>";
					}
				}
			}
		}
		
		if ( !editar_rota($_POST) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirRota") {
		
		$erro="";
		if (!isset($_POST['nome']) || @$_POST['nome'] == "") {
			$erro = "Erro: Rota Inválida!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !excluir_rota($_POST['nome']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	
	//ROTAS CUSTOM =============================================================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "rotaCustom") {
		
		$erro = "";
		if (!isset($_POST['nome']) || @$_POST['nome'] == "") {
			$erro = "Erro: Nome Inválido!";
		}
		if (!isset($_POST['contexto']) || @$_POST['contexto'] == "") {
			$erro = "Erro: Contexto inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if (isset($_POST['new']) && $_POST['new'] == "1") {
			//NOVO
			if ( !nova_rota_custom($_POST['nome'], $_POST['contexto'], @$_POST['transfer']) ) {
				print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
			} else {
				print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
			}

		} elseif (isset($_POST['new']) && $_POST['new'] == "0") {
			//EDITAR
			if ( !editar_rota_custom($_POST['editarnome'], $_POST['nome'], $_POST['contexto'], @$_POST['transfer']) ) {
				print "<script>
					alert('Erro ao salvar as configurações!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
			} else {
				print "<script>
					alert('Configurações salvas com sucesso!');
					document.getElementById('form_{$pagina}_{$menu}').submit();
				</script>";
				die();
			}
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirRotaCustom") {
		
		$erro="";
		if (!isset($_POST['nome']) || @$_POST['nome'] == "") {
			$erro = "Erro:  0x00000011!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !excluir_rota_custom($_POST['nome']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	
	//OPERADORAS ===============================================================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "novaOperadora") {
		
		$erro = "";
		if (!isset($_POST['nome']) || @$_POST['nome'] == "") {
			$erro = "Erro: Nome Inválido!";
		}
		if (!isset($_POST['codigos']) || @$_POST['codigos'] == "") {
			$erro = "Erro: Código inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !nova_operadora($_POST['nome'], $_POST['codigos']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "editarOperadora") {
		
		$erro="";
		if (!isset($_POST['editarnome']) || @$_POST['editarnome'] == "") {
			$erro = "Erro: 0x00000010!";
		}
		if (!isset($_POST['nome']) || @$_POST['nome'] == "") {
			$erro = "Erro: Nome Inválido!";
		}
		if (!isset($_POST['codigos']) || @$_POST['codigos'] == "") {
			$erro = "Erro: Código inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !editar_operadora($_POST['editarnome'], $_POST['nome'], $_POST['codigos']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirOperadora") {
		
		$erro="";
		if (!isset($_POST['nome']) || @$_POST['nome'] == "") {
			$erro = "Erro:  0x00000001!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !excluir_operadora($_POST['nome']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}

?>


	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- MENU ROTAS -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
						<div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
                                	<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
						</div>
                        <div class="body">
                            <ul class="nav nav-tabs tab-nav-right" role="tablist">
                                <li role="presentation" <?php echo ( $tipo == "rotas" ? "class=\"active\"" : "" ); ?> ><a href="#rotas" data-toggle="tab">ROTAS</a></li>
                                <li role="presentation" <?php echo ( $tipo == "custom" ? "class=\"active\"" : "" ); ?> ><a href="#custom" data-toggle="tab">CUSTOM</a></li>
								<li role="presentation" <?php echo ( $tipo == "portabilidade" ? "class=\"active\"" : "" ); ?> ><a href="#portabilidade" data-toggle="tab">PORTABILIDADE</a></li>
							</ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
				<!-- ROTAS #####################################################################################################################-->
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "rotas" ? "in active" : "" ); ?>" id="rotas">


					<div class="row clearfix">
						<div class="body" style="padding-bottom: 5px;">
                            <!--Formulário-->
							<form id="filtro-user" method="post">
								<?=$text_form;?>
								<input type="hidden" name="cmd" value="codlocal" />
							<div class="row clearfix">
								<div class="col-md-2 col-sm-3 col-xs-6 form-control-label" style="margin-bottom: 0px;">
									<label>Código de Área Local</label>
								</div>
								<div class="col-md-2 col-sm-2 col-xs-6">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="rota_codlocal" id="rota_codlocal" class="form-control show-tick codigo">
											<option value=""> - </option>
											<?php
												foreach($codigos_ddd as $key=>$value) {
													print "<option value=\"".$value."\" ".(@$editar_rota_codlocal == $value?"selected=\"selected\"":"").">".$value."</option>";
												}
											?>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-1 col-sm-2 col-xs-3 form-control-label" style="margin-bottom: 0px;">
									<label>Cidade</label>
								</div>
								<div class="col-md-3 col-sm-3 col-xs-9">
									<div class="form-group form-float" style="margin-bottom: 0px;">
										<select name="rota_cidadelocal" id="rota_cidadelocal" class="form-control show-tick cidade" data-live-search="true">
											<option value=""> - </option>
										</select>
									</div>
								</div>
								<div class="col-xs-6 col-sm-3">
									<button id="btnSubmit" type="submit" class="btn btn-primary waves-effect">
										<i class="material-icons">save</i>
										<span>SALVAR</span>
									</button>
								</div>
							</div>
						</div>
							</form>
							<!--FIM FORMULÁRIO-->
                    </div>



				<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novaRotaModal">
					<i class="material-icons">add_circle</i>
					<span>NOVA ROTA</span>
			    </button>
			    <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
                                            <th>Nome</th>
											<th>Discagem</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					    <?php
						foreach($rotas_saida as $rota=>$vetor) {
						    if (is_array($vetor)) {
					    ?>
							<tr>
								<td><?=$rota;?></td>
								<td><?=$vetor['dialplan'];?></td>
								<td>
									<a href="javascript:;" class="editar-rota" data-id="<?=$rota;?>" data-toggle="modal" data-target="#editarRotaModal"><i class="material-icons" title="Editar">edit</i></a>&nbsp;
									<a href="javascript:;" class="play" onclick="botaoExcluirRota('<?=$rota;?>')"><i class="material-icons" title="Excluir">delete</i></a>
								</td>
						    </tr>
					    <?php
						    }
						}
					    ?>
                                    </tbody>
                                </table>
                </div>


								</div>
				<!--#FIM - ROTAS ##############################################################################################################-->
				<!-- ROTAS CUSTOM ##################################################################################################################-->
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "custom" ? "in active" : "" ); ?>" id="custom">
								
			    <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
                                            <th>Nome</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					    <?php
						foreach($rotas_custom as $rota=>$vetor) {
						    if (is_array($vetor)) {
					    ?>
							<tr>
								<td><?=$rota;?></td>
								<td>
									<a href="javascript:;" class="play" onclick="botaoEditarRotaCustom('<?=$rota;?>')"><i class="material-icons" title="Editar">edit</i></a>&nbsp;
									<a href="javascript:;" class="play" onclick="botaoExcluirRotaCustom('<?=$rota;?>')"><i class="material-icons" title="Excluir">delete</i></a>
								</td>
						    </tr>
					    <?php
						    }
						}
					    ?>
                                    </tbody>
                                </table>
                </div>
				<hr>
				<div class="body">
				
					<button type="button" class="btn btn-primary waves-effect" onclick="botaoNovaRotaCustom()">
						<i class="material-icons">add_circle</i>
						<span>NOVA ROTA</span>
					</button>
				
					<form name="form_txt" id="form_rotaCustom" method="post">
						<?=$text_form;?>
						<input type="hidden" id="cmd_rotaCustom" name="cmd" value="rotaCustom" />
						<input type="hidden" id="new_rotaCustom" name="new" value="1" />
						<input type="hidden" id="editarnome_rotaCustom" name="editarnome" value="" />
						
					<div class="row clearfix">
                        <div class="col-md-2 col-sm-2 col-xs-4 form-control-label" style="margin-bottom: 0px;">
                            <label for="nome_rotaCustom">Nome</label>
                        </div>
						<div class="col-md-4 col-sm-6 col-xs-8" style="margin-bottom: 0px;">
							<div class="form-group">
								<div class="form-line">
									<input type="text" name="nome" id="nome_rotaCustom" class="form-control rota" onchange="verifica_contexto(this)">
								</div>
							</div>
						</div>
						<div class="col-md-3 col-sm-12 col-xs-12 form-control-label">
							<input type="checkbox" name="transfer" id="transfer_rotaCustom" value="1" class="filled-in chk-col-light-blue"/>
							<label for="transfer_rotaCustom">Habilitar Transferência</label>
						</div>
					</div>
					
					<small>Contexto Asterisk:</small>
					<div class="form-group">
                        <div class="form-line">
							<textarea name="contexto" id="textarea_rotaCustom" rows="16" class="form-control no-resize auto-growth"></textarea>
						</div>
					</div>
					<button type="submit" class="btn btn-primary waves-effect">
						<i class="material-icons">save</i>
						<span>Salvar</span>
					</button>
					</form>
				</div>
				
								</div>
				<!-- #END# ROTAS CUSTOM ############################################################################################################-->
				<!-- PORTABILIDADE #################################################################################################################-->
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "portabilidade" ? "in active" : "" ); ?>" id="portabilidade">

			</br>
			<h4>CÓDIGOS DE RETORNO DA PORTABILIDADE</h4>
			<small>Configure os códigos por operadora para serem usados nas rotas com consulta de portabilidade.</small>
			</br>
				<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novaOperadoraModal">
					<i class="material-icons">add_circle</i>
					<span>NOVA OPERADORA</span>
			    </button>
			    <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
                                            <th>Nome</th>
											<th>Códigos</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					    <?php
						foreach($operadoras as $operadora=>$codigos) {
					    ?>
							<tr>
								<td><?=$operadora;?></td>
								<td><?=$codigos;?></td>
								<td>
									<a href="javascript:;" class="play" onclick="botaoEditarOperadora('<?=$operadora;?>','<?=$codigos;?>')"><i class="material-icons" title="Editar">edit</i></a>&nbsp;
									<a href="javascript:;" class="play" onclick="botaoExcluirOperadora('<?=$operadora;?>')"><i class="material-icons" title="Excluir">delete</i></a>
								</td>
						    </tr>
					    <?php
						}
					    ?>
                                    </tbody>
                                </table>
                </div>
						
								</div>
				<!-- #END# PORTABILIDADE #############################################################################################################-->
	</div>
	<!--END - PAGE CONTENT-->


	<!-- MODAL ================================================================================================================================== -->

		<!--MODAL NOVA ROTA-->
            <div class="modal fade" id="novaRotaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="modal-title" id="novaRotaLabel">Nova Rota</h2>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
							<form id="formNovaRota" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="novaRota" />

								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="novaRota_nome">Nome</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="nome" id="nome_novaRota" class="form-control rota" onchange="verifica_contexto(this)">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="dialplan_novaRota">Dialplan</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="dialplan" id="dialplan_novaRota" class="form-control dialplan">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
									<div class="col-md-12 col-sm-12 col-xs-12 form-control-label" style="margin-bottom: 0px;">
										<input type="checkbox" name="transfer" id="transfer_novaRota" value="1" class="filled-in chk-col-light-blue"/>
										<label for="transfer_novaRota">Habilitar Transferência</label>
									</div>
								</div>
								<div class="row clearfix">
									<div class="body">
										<ul class="list-group container1">
											<li class="list-group-item">
												<div class="row clearfix">
													<div class="col-md-3 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label>Tronco</label>
													</div>
													<div class="col-md-9 col-sm-8 col-xs-7">
														<div class="form-group form-float" style="margin-bottom: 0px;">
															<select name="tronco[]" id="tronco_novaRota-0" class="form-control show-tick">
																<option value=""> - </option>
																<?php
																	foreach($troncos as $value) {
																		print "<option value=\"".$value."\">".$value."</option>";
																	}
																?>
															</select>
														</div>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label for="delete_novaRota-0">Deletar</label>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-7">
														<div class="form-group" style="margin-bottom: 0px;">
															<div class="form-line">
																<input type="text" name="delete[]" id="delete_novaRota-0" value="" class="form-control timeout">
															</div>
														</div>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label for="insere_novaRota-0">Inserir</label>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-7">
														<div class="form-group" style="margin-bottom: 0px;">
															<div class="form-line">
																<input type="text" name="insere[]" id="insere_novaRota-0" value="" class="form-control alphanumeric">
															</div>
														</div>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label>Portabilidade</label>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-7">
														<div class="form-group form-float" style="margin-bottom: 0px;">
															<select name="portabilidade[]" id="portabilidade_novaRota-0" class="form-control show-tick">
																<option value="0">Não</option>
																<option value="1">Sim</option>
															</select>
														</div>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label>Operadora</label>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-7">
														<div class="form-group form-float" style="margin-bottom: 0px;">
															<select name="operadora[]" id="operadora_novaRota-0" class="form-control show-tick">
																<option value=""> - </option>
																<?php
																	foreach($operadoras as $key=>$value) {
																		print "<option value=\"".$key."\">".$key."</option>";
																	}
																?>
															</select>
														</div>
													</div>
													<div class="col-sm-12"><small>Rota Menor Custo (somente fixo)</small></div>
													<div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label>Cidade</label>
													</div>
													<div class="col-md-10 col-sm-9 col-xs-7">
														<div class="form-group" style="margin-bottom: 0px;">
															<div class="form-line">
																<input type="text" name="cidade[]" id="cidade_novaRota-0" value="" class="form-control cidade">
															</div>
														</div>
													</div>
												</div>
											</li>
										</ul>
										<button type="" class="btn btn-primary waves-effect" id="add_novaRota">
											<i class="material-icons">add_circle</i>
											<span>Adicionar</span>
										</button>
									</div>
								</div>

							</div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
                            <button type="button" id="closenovaRotaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
							</form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL NOVA ROTA-->

		<!--MODAL EDITAR ROTA-->
			<div class="modal fade" id="editarRotaModal" tabindex="-1" role="dialog">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h4 class="modal-title" id="editarRotaLabel">Editar Rota</h4>
						</div>
						<div class="modal-body">
							<div class="row clearfix demo-masked-input">
								<form id="formEditarRota" method="post">
								<?=$text_form;?>
								<input type="hidden" name="cmd" value="editarRota" />
								<input type="hidden" id="editarRota" name="editarnome" value="" />
								
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="nome_editarRota">Nome</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="nome" id="nome_editarRota" class="form-control rota" onchange="verifica_contexto(this)">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="dialplan_editarRota">Dialplan</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="dialplan" id="dialplan_editarRota" class="form-control dialplan">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
									<div class="col-md-12 col-sm-12 col-xs-12 form-control-label" style="margin-bottom: 0px;">
										<input type="checkbox" name="transfer" id="transfer_editarRota" value="1" class="filled-in chk-col-light-blue"/>
										<label for="transfer_editarRota">Habilitar Transferência</label>
									</div>
								</div>
								<div class="row clearfix">
									<div class="body">
										<ul class="list-group container-editar">
											<li class="list-group-item">
												<div class="row clearfix">
													<div class="col-md-3 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label>Tronco</label>
													</div>
													<div class="col-md-9 col-sm-8 col-xs-7">
														<div class="form-group form-float" style="margin-bottom: 0px;">
															<select name="tronco[]" id="tronco_editarRota-1" class="form-control show-tick">
																<option value=""> - </option>
																<?php
																	foreach($troncos as $value) {
																		print "<option value=\"".$value."\">".$value."</option>";
																	}
																?>
															</select>
														</div>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label for="delete_editarRota-1">Deletar</label>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-7">
														<div class="form-group" style="margin-bottom: 0px;">
															<div class="form-line">
																<input type="text" name="delete[]" id="delete_editarRota-1" value="" class="form-control timeout">
															</div>
														</div>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label for="insere_editarRota-1">Inserir</label>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-7">
														<div class="form-group" style="margin-bottom: 0px;">
															<div class="form-line">
																<input type="text" name="insere[]" id="insere_editarRota-1" value="" class="form-control alphanumeric">
															</div>
														</div>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label>Portabilidade</label>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-7">
														<div class="form-group form-float" style="margin-bottom: 0px;">
															<select name="portabilidade[]" id="portabilidade_editarRota-1" class="form-control show-tick">
																<option value="0">Não</option>
																<option value="1">Sim</option>
															</select>
														</div>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label>Operadora</label>
													</div>
													<div class="col-md-3 col-sm-3 col-xs-7">
														<div class="form-group form-float" style="margin-bottom: 0px;">
															<select name="operadora[]" id="operadora_editarRota-1" class="form-control show-tick">
																<option value=""> - </option>
																<?php
																	foreach($operadoras as $key=>$value) {
																		print "<option value=\"".$key."\">".$key."</option>";
																	}
																?>
															</select>
														</div>
													</div>
													<div class="col-sm-12"><small>Rota Menor Custo (somente fixo)</small></div>
													<div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
														<label>Cidade</label>
													</div>
													<div class="col-md-10 col-sm-9 col-xs-7">
														<div class="form-group" style="margin-bottom: 0px;">
															<div class="form-line">
																<input type="text" name="cidade[]" id="cidade_editarRota-1" value="" class="form-control cidade">
															</div>
														</div>
													</div>
												</div>
											</li>
										</ul>
										<button type="" class="btn btn-primary waves-effect" id="add_editarRota">
											<i class="material-icons">add_circle</i>
											<span>Adicionar</span>
										</button>
									</div>
								</div>
								
							</div>
						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
							<button type="button" id="closeEditarRotaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
						</div>
							</form>
					</div>
				</div>
			</div>
	    <!--#END of MODAL EDITAR ROTA-->


	    <!--MODAL EXCLUIR ROTA-->
            <div class="modal fade" id="excluirRotaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirRotaLabel">Excluir Rota</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirRota" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="excluirRota" />
				<input type="hidden" id="excluirRota" name="nome" value="" />
			    <p>Tem certeza que deseja excluir a Rota?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
							<button type="button" id="closeExcluirRotaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR ROTA-->


			<!-- OPERADORA ================================================================================= -->
			
		<!--MODAL NOVA OPERADORA-->
            <div class="modal fade" id="novaOperadoraModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="modal-title" id="novaOperadoraLabel">Nova Operadora</h2>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
							<form id="formNovaOperadora" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="novaOperadora" />

								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="novaOperadora_nome">Nome</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="nome" id="nome_novaOperadora" class="form-control rota">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="codigos_novaOperadora">Códigos</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="codigos" id="codigos_novaOperadora" class="form-control">
                                            </div>
                                        </div>
                                    </div>
								</div>

							</div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
                            <button type="button" id="closenovaOperadoraModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
							</form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL NOVA OPERADORA-->

		<!--MODAL EDITAR OPERADORA-->
			<div class="modal fade" id="editarOperadoraModal" tabindex="-1" role="dialog">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h4 class="modal-title" id="editarOperadoraLabel">Editar Operadora</h4>
						</div>
						<div class="modal-body">
							<div class="row clearfix demo-masked-input">
								<form id="formEditarOperadora" method="post">
								<?=$text_form;?>
								<input type="hidden" name="cmd" value="editarOperadora" />
								<input type="hidden" id="editarOperadora" name="editarnome" value="" />
								
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="nome_editarOperadora">Nome</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="nome" id="nome_editarOperadora" class="form-control rota">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="codigos_editarOperadora">Códigos</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="codigos" id="codigos_editarOperadora" class="form-control">
                                            </div>
                                        </div>
                                    </div>
								</div>
								
							</div>
						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
							<button type="button" id="closeEditarOperadoraModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
						</div>
							</form>
					</div>
				</div>
			</div>
	    <!--#END of MODAL EDITAR OPERADORA-->


	    <!--MODAL EXCLUIR OPERADORA-->
            <div class="modal fade" id="excluirOperadoraModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirOperadoraLabel">Excluir Operadora</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirOperadora" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="excluirOperadora" />
				<input type="hidden" id="excluirOperadora" name="nome" value="" />
			    <p>Tem certeza que deseja excluir a Operadora?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
							<button type="button" id="closeExcluirOperadoraModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR OPERADORA-->
		
			<!-- ROTA CUSTOM =========================================================== -->
			
		<!--MODAL EXCLUIR ROTA CUSTOM-->
            <div class="modal fade" id="excluirRotaCustomModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirRotaCustomLabel">Excluir Rota</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirRotaCustom" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="excluirRotaCustom" />
				<input type="hidden" id="excluirRotaCustom" name="nome" value="" />
			    <p>Tem certeza que deseja excluir a Rota?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
							<button type="button" id="closeExcluirRotaCustomModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR ROTA CUSTOM-->


	<!--#END - MODAL ============================================================================================================================== -->

<script>

var wrapper_editar = $(".container-editar");
var max_fields_editar = 32;
var y = 1;
var w = 1;
var texto = "";

function del_editarRota() {
	if (w > 1) {
		for (i=2; i<=w; i++) {
			$('#li-'+i).remove();
		}
	}
	y = 1;
	w = 1;
}

function add_editarRota() {
	if (y < max_fields_editar) {
		y++;
		w++;
		texto = "";
		texto += '<li class="list-group-item" id="li-'+w+'"><div class="row clearfix">';
		texto += '<div class="col-md-3 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;"><label>Tronco</label></div>';
		texto += '<div class="col-md-9 col-sm-8 col-xs-7"><div class="form-group form-float" style="margin-bottom: 0px;">';
		texto += '<select name="tronco[]" id="tronco_editarRota-'+w+'" class="form-control show-tick">';
		texto += '<option value=""> - </option>';
		<?php
			foreach($troncos as $value) {
				print "texto += '<option value=\"".$value."\">".$value."</option>';";
			}
		?>
		texto += '</select></div></div>';
		texto += '<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">';
		texto += '<label for="delete_editarRota-'+w+'">Deletar</label></div>';
		texto += '<div class="col-md-3 col-sm-3 col-xs-7"><div class="form-group" style="margin-bottom: 0px;"><div class="form-line">';
		texto += '<input type="text" name="delete[]" id="delete_editarRota-'+w+'" value="" class="form-control timeout">';
		texto += '</div></div></div>';
		texto += '<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">';
		texto += '<label for="insere_editarRota-'+w+'">Inserir</label></div>';
		texto += '<div class="col-md-3 col-sm-3 col-xs-7"><div class="form-group" style="margin-bottom: 0px;"><div class="form-line">';
		texto += '<input type="text" name="insere[]" id="insere_editarRota-'+w+'" value="" class="form-control alphanumeric">';
		texto += '</div></div></div>';
		texto += '<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;"><label>Portabilidade</label></div>';
		texto += '<div class="col-md-3 col-sm-3 col-xs-7"><div class="form-group form-float" style="margin-bottom: 0px;">';
		texto += '<select name="portabilidade[]" id="portabilidade_editarRota-'+w+'" class="form-control show-tick">';
		texto += '<option value="0">Não</option><option value="1">Sim</option>';
		texto += '</select></div></div>';
		texto += '<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;"><label>Operadora</label></div>';
		texto += '<div class="col-md-3 col-sm-3 col-xs-7"><div class="form-group form-float" style="margin-bottom: 0px;">';
		texto += '<select name="operadora[]" id="operadora_editarRota-'+w+'" class="form-control show-tick">';
		texto += '<option value=""> - </option>';
		<?php
			foreach($operadoras as $key=>$value) {
				print "texto += '<option value=\"".$key."\">".$key."</option>';";
			}
		?>
		texto += '</select></div></div>';
		texto += '<div class="col-sm-12"><small>Rota Menor Custo (somente fixo)</small></div>';
		texto += '<div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;"><label>Cidade</label></div>';
		texto += '<div class="col-md-10 col-sm-9 col-xs-7"><div class="form-group" style="margin-bottom: 0px;"><div class="form-line">';
		texto += '<input type="text" name="cidade[]" id="cidade_editarRota-'+w+'" value="" class="form-control cidade">';
		texto += '</div></div></div>';
		texto += '</div><a href="#" class="delete">Delete</a></li>';
        $(wrapper_editar).append(
			texto
		);
		//REFRESH NO SELECTPICKER PRA PODER ATUALIZAR O VALOR
		$('#tronco_editarRota-'+w).addClass('selectpicker');
		$('#tronco_editarRota-'+w).selectpicker('refresh');
		$('#portabilidade_editarRota-'+w).addClass('selectpicker');
		$('#portabilidade_editarRota-'+w).selectpicker('refresh');
		$('#operadora_editarRota-'+w).addClass('selectpicker');
		$('#operadora_editarRota-'+w).selectpicker('refresh');
    } else {
		alert('Limite alcançado!')
	}
};

function botaoExcluirRota(excluirRota) {
	$('#excluirRota').val(excluirRota);

	$('#excluirRotaLabel').text("Excluir Rota "+excluirRota);
	$("#excluirRotaModal").modal();
};


//FUNCOES ROTA CUSTOM
function botaoNovaRotaCustom() {
	$('#new_rotaCustom').val('1');
	$('#nome_rotaCustom').val('');
	$('#transfer_rotaCustom').prop('checked',false);
	$('#textarea_rotaCustom').val('');
}

function botaoEditarRotaCustom(rota) {
	var rotas_custom = <?php echo json_encode($rotas_custom, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
	
	$('#new_rotaCustom').val('0');
	$('#editarnome_rotaCustom').val(rota);
	$('#nome_rotaCustom').val(rota);
	
	if (rotas_custom[rota].transfer == '1') {
		$('#transfer_rotaCustom').prop('checked',true);
	} else {
		$('#transfer_rotaCustom').prop('checked',false);
	}
	
	var text = "";
	for (var alfa in rotas_custom[rota].linhas) {
		text += rotas_custom[rota].linhas[alfa]+"\n";
	}
	$('#textarea_rotaCustom').val(text);
}

function botaoExcluirRotaCustom(rota) {
	$('#excluirRotaCustom').val(rota);

	$('#excluirRotaCustomLabel').text("Excluir Rota "+rota);
	$("#excluirRotaCustomModal").modal();
};
//FIM FUNCOES ROTA CUSTOM


//FUNCOES OPERADORA
function botaoEditarOperadora(operadora, codigos) {
	$('#editarOperadora').val(operadora);
	$('#nome_editarOperadora').val(operadora);
	$('#codigos_editarOperadora').val(codigos);
	
	document.getElementById('editarOperadoraLabel').innerHTML = "Editar Operadora: "+operadora;
	$("#editarOperadoraModal").modal();
};

function botaoExcluirOperadora(operadora) {
	$('#excluirOperadora').val(operadora);

	$('#excluirOperadoraLabel').text("Excluir Operadora "+operadora);
	$("#excluirOperadoraModal").modal();
};
//FIM FUNCOES OPERADORA

function load_cidades(select_ddd) {
	$.ajax({
		url: '/funcoes/process.pbxconfig.cidades.php',
		type: 'post',
		data: {
			ddd : select_ddd
		},
		dataType: 'html',
		success: function(data, textStatus, jqXHR) {
			$("#rota_cidadelocal").find('option').remove();
			$("#rota_cidadelocal").append(data);
			$("#rota_cidadelocal").addClass('selectpicker');
			$("#rota_cidadelocal").selectpicker('refresh');
			$("#rota_cidadelocal").selectpicker('val', "<?php echo $editar_rota_cidadelocal; ?>");
		},
		error: function(errormsg, textStatus) {
			console.log('Falha process.pbxconfig.cidades');
		}
	});
}

$(document).ready(function(){
	
	load_cidades($("#rota_codlocal :selected").val());
	
	$(function () {
		$("#rota_codlocal").on("changed.bs.select", function(e, clickedIndex, newValue, oldValue) {
			var selectedD = $(this).find('option').eq(clickedIndex).text();
			console.log('DDD selecionado: ' + selectedD);
			load_cidades(selectedD);
		});
	});

	var rotas_saida = <?php echo json_encode($rotas_saida, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
	/*
	"CELULAR_DDD_NONO_DIGITO":{
		"dialplan":"00XX9XXXXXXXX",
		"rotas":{
			"1":{"insere":"015","delete":"2","tronco":"SIP/1000","portabilidade":true,"operadora":"VIVO"},
			"2":{"insere":"021","delete":"2","tronco":"SIP/1050","portabilidade":true,"operadora":"CLARO"}
		}
	},
	*/

	$(".editar-rota").on('click', function(event) {
		event.preventDefault();

		var rota = $(this).data('id');

		document.getElementById('editarRotaLabel').innerHTML = "Editar Rota: "+rota;

		$('#editarRota').val(rota);
		
		$('#nome_editarRota').val(rota);
		$('#dialplan_editarRota').val(rotas_saida[rota].dialplan);
		
		if (rotas_saida[rota].transfer == '1') {
			$('#transfer_editarRota').prop('checked',true);
		} else {
			$('#transfer_editarRota').prop('checked',false);
		}
		
		del_editarRota();
		for (var i in rotas_saida[rota].rotas) {
			
			if (i != 1) {
				add_editarRota();
			}
			
			$('#delete_editarRota-'+i).val(rotas_saida[rota].rotas[i].delete);
			$('#insere_editarRota-'+i).val(rotas_saida[rota].rotas[i].insere);
			$('#cidade_editarRota-'+i).val(rotas_saida[rota].rotas[i].cidade);
			
			var aux = 0;
			$('#tronco_editarRota-'+i+' option').each(function(){
				if ($(this).val() == rotas_saida[rota].rotas[i].tronco) {
					$('#tronco_editarRota-'+i).selectpicker('val', rotas_saida[rota].rotas[i].tronco);
					aux = 1;
				} else if (aux != 1) {
					$('#tronco_editarRota-'+i).selectpicker('val', 'null');
				}
			});
			aux = 0;
			$('#portabilidade_editarRota-'+i+' option').each(function(){
				if ($(this).val() == rotas_saida[rota].rotas[i].portabilidade) {
					$('#portabilidade_editarRota-'+i).selectpicker('val', rotas_saida[rota].rotas[i].portabilidade);
					aux = 1;
				} else if (aux != 1) {
					$('#portabilidade_editarRota-'+i).selectpicker('val', '0');
				}
			});
			aux = 0;
			$('#operadora_editarRota-'+i+' option').each(function(){
				if ($(this).val() == rotas_saida[rota].rotas[i].operadora) {
					$('#operadora_editarRota-'+i).selectpicker('val', rotas_saida[rota].rotas[i].operadora);
					aux = 1;
				} else if (aux != 1) {
					$('#operadora_editarRota-'+i).selectpicker('val', 'null');
				}
			});
		}
		
	});
	
	$(function () {
		$('#nestable-contextos').nestable({
			maxDepth: 1
		})
	});
	
	$('#editarRotaModal').on('show.bs.modal', function (e) {
		$('.dd').nestable({
		    maxDepth: 1
		});
	});
	
	$('#novaRotaModal').on('show.bs.modal', function (e) {
		$('.dd').nestable({
		    maxDepth: 1
		});
	});
	
	
	var max_fields = 32;
	var wrapper = $(".container1");
  
    var x = 1;
	var z = 1;
	var texto = "";
    $("#add_novaRota").click(function(e){
        e.preventDefault();
        if (x < max_fields) {
            x++;
			z++;
			texto = "";
			texto += '<li class="list-group-item"><div class="row clearfix">';
			texto += '<div class="col-md-3 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;"><label>Tronco</label></div>';
			texto += '<div class="col-md-9 col-sm-8 col-xs-7"><div class="form-group form-float" style="margin-bottom: 0px;">';
			texto += '<select name="tronco[]" id="tronco_novaRota-'+z+'" class="form-control show-tick">';
			texto += '<option value=""> - </option>';
			<?php
				foreach($troncos as $value) {
					print "texto += '<option value=\"".$value."\">".$value."</option>';";
				}
			?>
			texto += '</select></div></div>';
			texto += '<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">';
			texto += '<label for="delete_novaRota-'+z+'">Deletar</label></div>';
			texto += '<div class="col-md-3 col-sm-3 col-xs-7"><div class="form-group" style="margin-bottom: 0px;"><div class="form-line">';
			texto += '<input type="text" name="delete[]" id="delete_novaRota-'+z+'" value="" class="form-control timeout">';
			texto += '</div></div></div>';
			texto += '<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">';
			texto += '<label for="insere_novaRota-'+z+'">Inserir</label></div>';
			texto += '<div class="col-md-3 col-sm-3 col-xs-7"><div class="form-group" style="margin-bottom: 0px;"><div class="form-line">';
			texto += '<input type="text" name="insere[]" id="insere_novaRota-'+z+'" value="" class="form-control alphanumeric">';
			texto += '</div></div></div>';
			texto += '<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;"><label>Portabilidade</label></div>';
			texto += '<div class="col-md-3 col-sm-3 col-xs-7"><div class="form-group form-float" style="margin-bottom: 0px;">';
			texto += '<select name="portabilidade[]" id="portabilidade_novaRota-'+z+'" class="form-control show-tick">';
			texto += '<option value="0">Não</option><option value="1">Sim</option>';
			texto += '</select></div></div>';
			texto += '<div class="col-md-3 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;"><label>Operadora</label></div>';
			texto += '<div class="col-md-3 col-sm-3 col-xs-7"><div class="form-group form-float" style="margin-bottom: 0px;">';
			texto += '<select name="operadora[]" id="operadora_novaRota-'+z+'" class="form-control show-tick">';
			texto += '<option value=""> - </option>';
			<?php
				foreach($operadoras as $key=>$value) {
					print "texto += '<option value=\"".$key."\">".$key."</option>';";
				}
			?>
			texto += '</select></div></div>';
			texto += '<div class="col-sm-12"><small>Rota Menor Custo (somente fixo)</small></div>';
			texto += '<div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;"><label>Cidade</label></div>';
			texto += '<div class="col-md-10 col-sm-9 col-xs-7"><div class="form-group" style="margin-bottom: 0px;"><div class="form-line">';
			texto += '<input type="text" name="cidade[]" id="cidade_novaRota-'+z+'" value="" class="form-control cidade">';
			texto += '</div></div></div>';
			texto += '</div><a href="#" class="delete">Delete</a></li>';
            $(wrapper).append(
				/*'<li class="list-group-item"><div><p>some text</p></div><a href="#" class="delete">Delete</a></li>'*/
				texto
			);
			$('#tronco_novaRota-'+z).addClass('selectpicker');
			$('#tronco_novaRota-'+z).selectpicker('refresh');
			$('#portabilidade_novaRota-'+z).addClass('selectpicker');
			$('#portabilidade_novaRota-'+z).selectpicker('refresh');
			$('#operadora_novaRota-'+z).addClass('selectpicker');
			$('#operadora_novaRota-'+z).selectpicker('refresh');
        } else {
			alert('Limite alcançado!')
		}
    });
  
    $(wrapper).on("click",".delete", function(e){
        e.preventDefault(); $(this).parent('li').remove(); x--;
    })
	
	$("#add_editarRota").click(function(e){
		e.preventDefault();
		add_editarRota();
	})
	
	$(wrapper_editar).on("click",".delete", function(e){
        e.preventDefault(); $(this).parent('li').remove(); y--;
    })

});

</script>