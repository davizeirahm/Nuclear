<?php
	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.noturno.php");
	
	//PARA OBTER OS DESTINOS
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_sip.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_iax2.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.filas.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.telefonista.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.abreviados.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.calendario.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.faixa_discagem.php");//PARA A URA
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.ura.php");
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "salvar") {
		//print_r($_POST);
		//die();
		//

		$erro = "";
		foreach ($_POST['destino'] as $key=>$value) {
			if ( !isset($_POST['destino'][$key]) || @$_POST['destino'][$key] == "") {
				$erro = "Erro: Operação inválida!";
				break;
			}
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !salvar_noturno($_POST) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}

	// DECLARAÇÃO DE VARIÁVEIS ==============================================================================================
	
	$noturno = get_destino_noturno();
	
	//DESTINOS
	$ramais_sip = get_ramais();
	$ramais_iax2 = get_ramais_iax();
	$filas = get_filas();
	$abreviados = get_abreviados();
	$calendarios = get_calendarios();
	$uras = get_uras();
	$uras_custom = get_uras_custom();
	
	$destinos = array();
	foreach($filas as $key=>$value) {
		$destinos[] = "<option value=\"QUE/".$key."\">QUE/".$key."</option>";
	}
	foreach($calendarios as $key=>$value) {
		$destinos[] = "<option value=\"CAL/".$key."\">CAL/".$key."</option>";
	}
	foreach($uras as $key=>$value) {
		$destinos[] = "<option value=\"URA/".$key."\">URA/".$key."</option>";
	}
	foreach($uras_custom as $key=>$value) {
		$destinos[] = "<option value=\"URA/".$key."\">URA/".$key."</option>";
	}
	foreach($abreviados as $key=>$value) {
		$destinos[] = "<option value=\"ABB/".$key."\">ABB/".$key."</option>";
	}
	foreach($ramais_sip as $key=>$value) {
		$destinos[] ="<option value=\"SIP/".$key."\">SIP/".$key."</option>";
	}
	foreach($ramais_iax2 as $key=>$value) {
		$destinos[] = "<option value=\"IAX2/".$key."\">IAX2/".$key."</option>";
	}

?>

	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- Bloco Pesquisa -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
                                	<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
						</div>
                        <div class="body" style="padding-bottom: 5px;">
                            <!--Formulário-->
							<form id="filtro-user" method="post">
								<?=$text_form;?>
								<input type="hidden" name="cmd" value="salvar" />
								<div class="row clearfix">
									<?php
									for ($i = 1; $i <= 9; $i++) {
									?>
									<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-2 col-sm-4 col-xs-5 form-control-label">
											<label>Destino Noturno <?=$i;?></label>
										</div>
										<div class="col-md-4 col-sm-8 col-xs-7">
											<div class="form-group form-float" style="margin-bottom: 5px;">
												<select name="destino[<?=$i;?>]" id="destino_noturno-<?=$i;?>" class="form-control show-tick" data-live-search="true">
													<option value="not">Não Configurado</option>
													<?php
														foreach($destinos as $key=>$value) {
															print $value;
														}
													?>
												</select>
											</div>
										</div>
									</div>
									<?php
									}	
									?>
								</div>
								<div class="row clearfix">
									<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
										<button id="btnSubmit" type="submit" class="btn btn-primary waves-effect">
											<i class="material-icons">save</i>
											<span>SALVAR</span>
										</button>
									</div>
								</div>
						</div>
						</form>
						<!--FIM FORMULÁRIO-->
					</div>
                </div>
            </div>
            <!-- #END# Bloco Pesquisa -->
        </div>
		<!--#END of PAGE CONTENT-->


<script>

<?php
	for ($i = 1; $i <= 9; $i++) {
?>
		var destino<?=$i;?> = "<?=$noturno[$i];?>";
<?php
	}
?>

function pre_load(){
	<?php
	for ($i = 1; $i <= 9; $i++) {
	?>
			$('#destino_noturno-<?=$i;?>').selectpicker('refresh');
			$('#destino_noturno-<?=$i;?>').selectpicker('val', destino<?=$i;?>);
	<?php
		}
	?>
}

$(document).ready(function(){
	pre_load();
});

</script>
