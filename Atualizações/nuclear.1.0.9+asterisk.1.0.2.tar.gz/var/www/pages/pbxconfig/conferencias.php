<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.config.ramal.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.conferencias.php");

	// DECLARAÇÃO DE VARIÁVEIS ==============================================================================================
	
	$conferencias = get_conferencias();
	//echo json_encode($conferencias, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

	//CONFERENCIAS ===============================================================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "novoConferencia") {
		//print_r($_POST);
		//die();
		$erro = "";
		if (!isset($_POST['numero']) || @$_POST['numero'] == "") {
			$erro = "Erro: Dialplan inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !novo_conferencia($_POST) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "editarConferencia") {
		
		$erro="";
		if (!isset($_POST['editarnumero']) || @$_POST['editarnumero'] == "") {
			$erro = "Erro: Conferencia Inválida!";
		}
		if (!isset($_POST['numero']) || @$_POST['numero'] == "") {
			$erro = "Erro: Número inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !editar_conferencia($_POST) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirConferencia") {
		
		$erro="";
		if (!isset($_POST['numero']) || @$_POST['numero'] == "") {
			$erro = "Erro: Conferencia Inválida!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !excluir_conferencia($_POST['numero']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}

?>


	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- MENU CONFERENCIAS -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
						<div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
                                	<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
						</div>
                        <div class="body">
                            
							<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novoConferenciaModal">
								<i class="material-icons">add_circle</i>
								<span>NOVA SALA</span>
							</button>
							<div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
                                            <th>Número</th>
											<th>Limite</th>
											<th>Senha</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<?php
									foreach($conferencias as $conferencia=>$vetor) {
										if (is_array($vetor)) {
									?>
										<tr>
											<td><?=$conferencia;?></td>
											<td><?=$vetor['limite'];?></td>
											<td><?=$vetor['senha'];?></td>
											<td>
												<a href="javascript:;" class="editar-conferencia" data-id="<?=$conferencia;?>" data-toggle="modal" data-target="#editarConferenciaModal"><i class="material-icons" title="Editar">edit</i></a>&nbsp;
												<a href="javascript:;" class="play" onclick="botaoExcluirConferencia('<?=$conferencia;?>')"><i class="material-icons" title="Excluir">delete</i></a>
											</td>
										</tr>
									<?php
										}
									}
									?>
                                    </tbody>
                                </table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--END - PAGE CONTENT-->


	<!-- MODAL ================================================================================================================================== -->

		<!--MODAL NOVA CONFERENCIA-->
            <div class="modal fade" id="novoConferenciaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="modal-title" id="novoConferenciaLabel">Nova Conferência</h2>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
							<form id="formNovoConferencia" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="novoConferencia" />

								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="numero_novoConferencia">Número</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="numero" id="numero_novoConferencia" class="form-control ramal">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="limite_novoConferencia">Limite</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="limite" id="limite_novoConferencia" class="form-control ramal">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="senha_novoConferencia">Senha</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="senha" id="senha_novoConferencia" class="form-control ramal">
                                            </div>
                                        </div>
                                    </div>
								</div>
							</div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
                            <button type="button" id="closenovoConferenciaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
							</form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL NOVA CONFERENCIA-->
		

		<!--MODAL EDITAR CONFERENCIA-->
			<div class="modal fade" id="editarConferenciaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="modal-title" id="editarConferenciaLabel">Editar Conferência</h2>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
							<form id="formNovoConferencia" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="editarConferencia" />
							<input type="hidden" id="editarConferencia" name="editarnumero" value="" />

								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="numero_editarConferencia">Número</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="numero" id="numero_editarConferencia" class="form-control ramal">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="limite_editarConferencia">Limite</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="limite" id="limite_editarConferencia" class="form-control ramal">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="senha_editarConferencia">Senha</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="senha" id="senha_editarConferencia" class="form-control ramal">
                                            </div>
                                        </div>
                                    </div>
								</div>
							</div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
                            <button type="button" id="closeeditarConferenciaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
							</form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EDITAR CONFERENCIA-->


	    <!--MODAL EXCLUIR CONFERENCIA-->
            <div class="modal fade" id="excluirConferenciaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirConferenciaLabel">Excluir Conferência</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirConferencia" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="excluirConferencia" />
				<input type="hidden" id="excluirConferencia" name="numero" value="" />
			    <p>Tem certeza que deseja excluir a Conferência?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
							<button type="button" id="closeExcluirConferenciaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR CONFERENCIA-->

	<!--#END - MODAL ============================================================================================================================== -->

<script>

function botaoExcluirConferencia(excluirConferencia) {
	$('#excluirConferencia').val(excluirConferencia);

	$('#excluirConferenciaLabel').text("Excluir Conferencia "+excluirConferencia);
	$("#excluirConferenciaModal").modal();
};

$(document).ready(function(){

	var conferencias = <?php echo json_encode($conferencias, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>

	$(".editar-conferencia").on('click', function(event) {
		event.preventDefault();

		var conferencia = $(this).data('id');

		document.getElementById('editarConferenciaLabel').innerHTML = "Editar Conferencia: "+conferencia;

		$('#editarConferencia').val(conferencia);
		
		$('#numero_editarConferencia').val(conferencia);
		$('#limite_editarConferencia').val(conferencias[conferencia].limite);
		$('#senha_editarConferencia').val(conferencias[conferencia].senha);
		
	});

});

</script>