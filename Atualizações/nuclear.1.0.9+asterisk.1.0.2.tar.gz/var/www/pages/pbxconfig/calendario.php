<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.db.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.config_e1.php"); //PARA OBTER TRONCOS G1, G2, etc.
	require_once(DIR_WWW."funcoes/funcoes.config.ramal.php");
	//require_once(DIR_WWW."funcoes/funcoes.pbxconfig.categorias.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.rotas_saida.php"); //TRONCOS
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.calendario.php");
	
	//PARA OBTER OS DESTINOS
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_sip.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_iax2.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.filas.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.telefonista.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.abreviados.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.faixa_discagem.php");//PARA A URA
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.ura.php");


	// DECLARAÇÃO DE VARIÁVEIS ==============================================================================================
	
	$calendarios = get_calendarios();
	//print_r($calendarios);
	/*[calendario2] => Array ( 
		[0] => Array ( [hora_inicial] => 08:00 [hora_final] => 11:30 [semana_inicial] => mon [semana_final] => fri [dia_inicial] => * [dia_final] => [mes_inicial] => * [mes_final] => [destino] => QUE/600 [tipo] => QUE ) 
		[1] => Array ( [hora_inicial] => 13:00 [hora_final] => 17:59 [semana_inicial] => mon [semana_final] => fri [dia_inicial] => * [dia_final] => [mes_inicial] => * [mes_final] => [destino] => QUE/600 [tipo] => QUE ) 
		[2] => Array ( [hora_inicial] => 00:00 [hora_final] => 23:59 [semana_inicial] => sat [semana_final] => sun [dia_inicial] => * [dia_final] => [mes_inicial] => * [mes_final] => [destino] => SIP/9985 [tipo] => SIP ) 
	)*/
	$ramais_sip = get_ramais();
	$ramais_iax2 = get_ramais_iax();
	$filas = get_filas();
	$abreviados = get_abreviados();
	$uras = get_uras();
	$uras_custom = get_uras_custom();
	$troncos = get_troncos();

	//CALENDARIOS ===============================================================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "novoCalendario") {
		//print_r($_POST);
		//die();

		$erro = "";
		if (!isset($_POST['nome']) || @$_POST['nome'] == "") {
			$erro = "Erro: Nome Inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !novo_calendario($_POST) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "editarCalendario") {
		//print_r($_POST);
		//die();
		
		$erro="";
		if (!isset($_POST['editarnome']) || @$_POST['editarnome'] == "") {
			$erro = "Erro: Calendário Inválido!";
		}
		if (!isset($_POST['nome']) || @$_POST['nome'] == "") {
			$erro = "Erro: Nome Inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}

		if ( !editar_calendario($_POST) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirCalendario") {
		
		$erro="";
		if (!isset($_POST['nome']) || @$_POST['nome'] == "") {
			$erro = "Erro: Calendário Inválida!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !excluir_calendario($_POST['nome']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}

?>

<style type="text/css">
.list-group-item:first-child .upbutton {
    display: none;
}
.list-group-item:last-child .downbutton {
    display: none;
}
</style>

	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- MENU CALENDARIOS -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
						<div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
                                	<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
						</div>
                        <div class="body">
							<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novoCalendarioModal">
								<i class="material-icons">add_circle</i>
								<span>NOVO CALENDÁRIO</span>
							</button>
							<div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
                                            <th>Nome</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<?php
									foreach($calendarios as $calendario=>$vetor) {
										if (is_array($vetor)) {
									?>
										<tr>
											<td><?=$calendario;?></td>
											<td>
												<a href="javascript:;" class="editar-calendario" data-id="<?=$calendario;?>" data-toggle="modal" data-target="#editarCalendarioModal"><i class="material-icons" title="Editar">edit</i></a>&nbsp;
												<a href="javascript:;" class="play" onclick="botaoExcluirCalendario('<?=$calendario;?>')"><i class="material-icons" title="Excluir">delete</i></a>
											</td>
										</tr>
									<?php
										}
									}
									?>
                                    </tbody>
                                </table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	<!--END - PAGE CONTENT-->


	<!-- MODAL ================================================================================================================================== -->

	<!--MODAL NOVO CALENDARIO-->
		<div class="modal fade" id="novoCalendarioModal" tabindex="-1" role="dialog">
			<div class="modal-dialog modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h2 class="modal-title" id="novoCalendarioLabel">Novo Calendário</h2>
					</div>
					<div class="modal-body">
						<div class="demo-masked-input">
						<form id="formNovoCalendario" method="post">
						<?=$text_form;?>
						<input type="hidden" name="cmd" value="novoCalendario" />

							<div class="row clearfix">
								<div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
									<label for="novoCalendario_nome">Nome</label>
								</div>
								<div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
									<div class="form-group">
										<div class="form-line">
											<input type="text" name="nome" id="nome_novoCalendario" class="form-control rota" onchange="verifica_contexto(this)">
										</div>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="body">
									<ul class="list-group container1">
										<li class="list-group-item">
											<div class="row clearfix">
												<div class="col-md-2 col-sm-2 col-xs-4 form-control-label" style="margin-bottom: 0px;">
													<label for="hora_novoCalendario-0">Hora</label>
												</div>
												<div class="col-md-2 col-sm-2 col-xs-4">
													<div class="form-group" style="margin-bottom: 0px;">
														<div class="form-line">
															<input type="text" name="hora_inicial[]" id="horaInicial_novoCalendario-0" value="" class="form-control time24">
														</div>
													</div>
												</div>
												<div class="col-md-2 col-sm-2 col-xs-4">
													<div class="form-group" style="margin-bottom: 0px;">
														<div class="form-line">
															<input type="text" name="hora_final[]" id="horaFinal_novoCalendario-0" value="" class="form-control time24">
														</div>
													</div>
												</div>
												<div class="col-md-2 col-sm-2 col-xs-4 form-control-label" style="margin-bottom: 0px;">
													<label>Dia da semana</label>
												</div>
												<div class="col-md-2 col-sm-2 col-xs-4">
													<div class="form-group form-float">
														<select name="semana_inicial[]" id="semanaInicial_novoCalendario-0" class="form-control show-tick">
															<option value="*">* (any)</option>
															<option value="mon">mon (segunda)</option>
															<option value="tue">tue (terça)</option>
															<option value="wed">wed (quarta)</option>
															<option value="thu">thu (quinta)</option>
															<option value="fri">fri (sexta)</option>
															<option value="sat">sat (sabado)</option>
															<option value="sun">sun (domingo)</option>
														</select>
													</div>
												</div>
												<div class="col-md-2 col-sm-2 col-xs-4">
													<div class="form-group form-float">
														<select name="semana_final[]" id="semanaFinal_novoCalendario-0" class="form-control show-tick">
															<option value=""> - </option>
															<option value="mon">mon (segunda)</option>
															<option value="tue">tue (terça)</option>
															<option value="wed">wed (quarta)</option>
															<option value="thu">thu (quinta)</option>
															<option value="fri">fri (sexta)</option>
															<option value="sat">sat (sabado)</option>
															<option value="sun">sun (domingo)</option>
														</select>
													</div>
												</div>
											</div>
											<div class="row clearfix">
												<div class="col-md-2 col-sm-2 col-xs-4 form-control-label" style="margin-bottom: 0px;">
													<label>Dia do mês</label>
												</div>
												<div class="col-md-2 col-sm-2 col-xs-4">
													<div class="form-group form-float">
														<select name="dia_inicial[]" id="diaInicial_novoCalendario-0" class="form-control show-tick">
															<option value="*">* (any)</option>
															<?php
															for ($i=1;$i<=31;$i++) {
															?>
																<option value="<?=$i;?>"><?=$i;?></option>
															<?php
															}
															?>
														</select>
													</div>
												</div>
												<div class="col-md-2 col-sm-2 col-xs-4">
													<div class="form-group form-float">
														<select name="dia_final[]" id="diaFinal_novoCalendario-0" class="form-control show-tick">
															<option value=""> - </option>
															<?php
															for ($i=1;$i<=31;$i++) {
															?>
																<option value="<?=$i;?>"><?=$i;?></option>
															<?php
															}
															?>
														</select>
													</div>
												</div>
												<div class="col-md-2 col-sm-2 col-xs-4 form-control-label" style="margin-bottom: 0px;">
													<label>Mês</label>
												</div>
												<div class="col-md-2 col-sm-2 col-xs-4">
													<div class="form-group form-float">
														<select name="mes_inicial[]" id="mesInicial_novoCalendario-0" class="form-control show-tick">
															<option value="*">* (any)</option>
															<option value="jan">jan (Janeiro)</option>
															<option value="feb">feb (Fevereiro)</option>
															<option value="mar">mar (Março)</option>
															<option value="apr">apr (Abril)</option>
															<option value="may">may (Maio)</option>
															<option value="jun">jun (Junho)</option>
															<option value="jul">jul (Julho)</option>
															<option value="aug">aug (Agosto)</option>
															<option value="sep">sep (Setembro)</option>
															<option value="oct">oct (Outubro)</option>
															<option value="nov">nov (Novembro)</option>
															<option value="dec">dec (Dezembro)</option>
														</select>
													</div>
												</div>
												<div class="col-md-2 col-sm-2 col-xs-4">
													<div class="form-group form-float">
														<select name="mes_final[]" id="mesFinal_novoCalendario-0" class="form-control show-tick">
															<option value=""> - </option>
															<option value="jan">jan (Janeiro)</option>
															<option value="feb">feb (Fevereiro)</option>
															<option value="mar">mar (Março)</option>
															<option value="apr">apr (Abril)</option>
															<option value="may">may (Maio)</option>
															<option value="jun">jun (Junho)</option>
															<option value="jul">jul (Julho)</option>
															<option value="aug">aug (Agosto)</option>
															<option value="sep">sep (Setembro)</option>
															<option value="oct">oct (Outubro)</option>
															<option value="nov">nov (Novembro)</option>
															<option value="dec">dec (Dezembro)</option>
														</select>
													</div>
												</div>
											</div>
											<div class="row clearfix">
												<div class="col-md-3 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;">
													<label>Destino</label>
												</div>
												<div class="col-md-9 col-sm-8 col-xs-7">
													<div class="form-group form-float">
														<select name="destino[]" id="destino_novoCalendario-0" class="form-control show-tick" data-live-search="true">
															<option value=""> - </option>
															<?php
																foreach($filas as $key=>$value) {
																	print "<option value=\"QUE/".$key."\">QUE/".$key."</option>";
																}
																foreach($calendarios as $key=>$value) {
																	print "<option value=\"CAL/".$key."\">CAL/".$key."</option>";
																}
																foreach($uras as $key=>$value) {
																	print "<option value=\"URA/".$key."\">URA/".$key."</option>";
																}
																foreach($uras_custom as $key=>$value) {
																	print "<option value=\"URA/".$key."\">URA/".$key."</option>";
																}
																foreach($abreviados as $key=>$value) {
																	print "<option value=\"ABB/".$key."\">ABB/".$key."</option>";
																}
																foreach($ramais_sip as $key=>$value) {
																	print "<option value=\"SIP/".$key."\">SIP/".$key."</option>";
																}
																foreach($ramais_iax2 as $key=>$value) {
																	print "<option value=\"IAX2/".$key."\">IAX2/".$key."</option>";
																}
															?>
														</select>
													</div>
												</div>
											</div>
											<button type="button" class="btn btn-default waves-effect upbutton">
												<i class="material-icons">arrow_upward</i>
											</button>
											<button type="button" class="btn btn-default waves-effect downbutton">
												<i class="material-icons">arrow_downward</i>
											</button>
										</li>
									</ul>
									<button type="" class="btn btn-primary waves-effect" id="add_novoCalendario">
										<i class="material-icons">add_circle</i>
										<span>Adicionar</span>
									</button>
								</div>
							</div>

						</div>
					</div>
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary waves-effect">
							<i class="material-icons">save</i>
							<span>Salvar</span>
						</button>
						<button type="button" id="closenovoCalendarioModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
					</div>
						</form>
				</div>
			</div>
		</div>
	<!--#END of MODAL NOVA CALENDARIO-->

	<!--MODAL EDITAR CALENDARIO-->
		<div class="modal fade" id="editarCalendarioModal" tabindex="-1" role="dialog">
			<div class="modal-dialog modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="editarCalendarioLabel">Editar Calendário</h4>
					</div>
					<div class="modal-body">
						<div class="demo-masked-input">
							<form id="formEditarCalendario" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="editarCalendario" />
							<input type="hidden" id="editarCalendario" name="editarnome" value="" />
							
							<div class="row clearfix">
								<div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
									<label for="nome_editarCalendario">Nome</label>
								</div>
								<div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
									<div class="form-group">
										<div class="form-line">
											<input type="text" name="nome" id="nome_editarCalendario" class="form-control rota" onchange="verifica_contexto(this)">
										</div>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="body">
									<ul class="list-group container-editar">
										<li class="list-group-item">
											<div class="row clearfix">
												<div class="col-md-2 col-sm-2 col-xs-4 form-control-label" style="margin-bottom: 0px;">
													<label for="hora_novoCalendario-0">Hora</label>
												</div>
												<div class="col-md-2 col-sm-2 col-xs-4">
													<div class="form-group" style="margin-bottom: 0px;">
														<div class="form-line">
															<input type="text" name="hora_inicial[]" id="horaInicial_editarCalendario-1" value="" class="form-control time24">
														</div>
													</div>
												</div>
												<div class="col-md-2 col-sm-2 col-xs-4">
													<div class="form-group" style="margin-bottom: 0px;">
														<div class="form-line">
															<input type="text" name="hora_final[]" id="horaFinal_editarCalendario-1" value="" class="form-control time24">
														</div>
													</div>
												</div>
												<div class="col-md-2 col-sm-2 col-xs-4 form-control-label" style="margin-bottom: 0px;">
													<label>Dia da semana</label>
												</div>
												<div class="col-md-2 col-sm-2 col-xs-4">
													<div class="form-group form-float">
														<select name="semana_inicial[]" id="semanaInicial_editarCalendario-1" class="form-control show-tick">
															<option value="*">* (any)</option>
															<option value="mon">mon (segunda)</option>
															<option value="tue">tue (terça)</option>
															<option value="wed">wed (quarta)</option>
															<option value="thu">thu (quinta)</option>
															<option value="fri">fri (sexta)</option>
															<option value="sat">sat (sabado)</option>
															<option value="sun">sun (domingo)</option>
														</select>
													</div>
												</div>
												<div class="col-md-2 col-sm-2 col-xs-4">
													<div class="form-group form-float">
														<select name="semana_final[]" id="semanaFinal_editarCalendario-1" class="form-control show-tick">
															<option value=""> - </option>
															<option value="mon">mon (segunda)</option>
															<option value="tue">tue (terça)</option>
															<option value="wed">wed (quarta)</option>
															<option value="thu">thu (quinta)</option>
															<option value="fri">fri (sexta)</option>
															<option value="sat">sat (sabado)</option>
															<option value="sun">sun (domingo)</option>
														</select>
													</div>
												</div>
											</div>
											<div class="row clearfix">
												<div class="col-md-2 col-sm-2 col-xs-4 form-control-label" style="margin-bottom: 0px;">
													<label>Dia do mês</label>
												</div>
												<div class="col-md-2 col-sm-2 col-xs-4">
													<div class="form-group form-float">
														<select name="dia_inicial[]" id="diaInicial_editarCalendario-1" class="form-control show-tick">
															<option value="*">* (any)</option>
															<?php
															for ($i=1;$i<=31;$i++) {
															?>
																<option value="<?=$i;?>"><?=$i;?></option>
															<?php
															}
															?>
														</select>
													</div>
												</div>
												<div class="col-md-2 col-sm-2 col-xs-4">
													<div class="form-group form-float">
														<select name="dia_final[]" id="diaFinal_editarCalendario-1" class="form-control show-tick">
															<option value=""> - </option>
															<?php
															for ($i=1;$i<=31;$i++) {
															?>
																<option value="<?=$i;?>"><?=$i;?></option>
															<?php
															}
															?>
														</select>
													</div>
												</div>
												<div class="col-md-2 col-sm-2 col-xs-4 form-control-label" style="margin-bottom: 0px;">
													<label>Mês</label>
												</div>
												<div class="col-md-2 col-sm-2 col-xs-4">
													<div class="form-group form-float">
														<select name="mes_inicial[]" id="mesInicial_editarCalendario-1" class="form-control show-tick">
															<option value="*">* (any)</option>
															<option value="jan">jan (Janeiro)</option>
															<option value="feb">feb (Fevereiro)</option>
															<option value="mar">mar (Março)</option>
															<option value="apr">apr (Abril)</option>
															<option value="may">may (Maio)</option>
															<option value="jun">jun (Junho)</option>
															<option value="jul">jul (Julho)</option>
															<option value="aug">aug (Agosto)</option>
															<option value="sep">sep (Setembro)</option>
															<option value="oct">oct (Outubro)</option>
															<option value="nov">nov (Novembro)</option>
															<option value="dec">dec (Dezembro)</option>
														</select>
													</div>
												</div>
												<div class="col-md-2 col-sm-2 col-xs-4">
													<div class="form-group form-float">
														<select name="mes_final[]" id="mesFinal_editarCalendario-1" class="form-control show-tick">
															<option value=""> - </option>
															<option value="jan">jan (Janeiro)</option>
															<option value="feb">feb (Fevereiro)</option>
															<option value="mar">mar (Março)</option>
															<option value="apr">apr (Abril)</option>
															<option value="may">may (Maio)</option>
															<option value="jun">jun (Junho)</option>
															<option value="jul">jul (Julho)</option>
															<option value="aug">aug (Agosto)</option>
															<option value="sep">sep (Setembro)</option>
															<option value="oct">oct (Outubro)</option>
															<option value="nov">nov (Novembro)</option>
															<option value="dec">dec (Dezembro)</option>
														</select>
													</div>
												</div>
											</div>
											<div class="row clearfix">
												<div class="col-md-3 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;">
													<label>Destino</label>
												</div>
												<div class="col-md-9 col-sm-8 col-xs-7">
													<div class="form-group form-float">
														<select name="destino[]" id="destino_editarCalendario-1" class="form-control show-tick" data-live-search="true">
															<option value=""> - </option>
															<?php
																foreach($filas as $key=>$value) {
																	print "<option value=\"QUE/".$key."\">QUE/".$key."</option>";
																}
																foreach($calendarios as $key=>$value) {
																	print "<option value=\"CAL/".$key."\">CAL/".$key."</option>";
																}
																foreach($uras as $key=>$value) {
																	print "<option value=\"URA/".$key."\">URA/".$key."</option>";
																}
																foreach($uras_custom as $key=>$value) {
																	print "<option value=\"URA/".$key."\">URA/".$key."</option>";
																}
																foreach($abreviados as $key=>$value) {
																	print "<option value=\"ABB/".$key."\">ABB/".$key."</option>";
																}
																foreach($ramais_sip as $key=>$value) {
																	print "<option value=\"SIP/".$key."\">SIP/".$key."</option>";
																}
																foreach($ramais_iax2 as $key=>$value) {
																	print "<option value=\"IAX2/".$key."\">IAX2/".$key."</option>";
																}
															?>
														</select>
													</div>
												</div>
											</div>
											<button type="button" class="btn btn-default waves-effect upbutton">
												<i class="material-icons">arrow_upward</i>
											</button>
											<button type="button" class="btn btn-default waves-effect downbutton">
												<i class="material-icons">arrow_downward</i>
											</button>
										</li>
									</ul>
									<button type="" class="btn btn-primary waves-effect" id="add_editarCalendario">
										<i class="material-icons">add_circle</i>
										<span>Adicionar</span>
									</button>
								</div>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary waves-effect">
							<i class="material-icons">save</i>
							<span>Salvar</span>
						</button>
						<button type="button" id="closeEditarCalendarioModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
					</div>
						</form>
				</div>
			</div>
		</div>
	<!--#END of MODAL EDITAR CALENDARIO-->


	<!--MODAL EXCLUIR CALENDARIO-->
		<div class="modal fade" id="excluirCalendarioModal" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="excluirCalendarioLabel">Excluir Calendário</h4>
					</div>
					<div class="modal-body">
			<form id="formExcluirCalendario" method="post">
			<?=$text_form;?>
			<input type="hidden" name="cmd" value="excluirCalendario" />
			<input type="hidden" id="excluirCalendario" name="nome" value="" />
			<p>Tem certeza que deseja excluir o Calendário?</p>
					</div>
					<div class="modal-footer">
						<button type="submit" class="btn btn-danger waves-effect">
							<i class="material-icons">delete</i>
							<span>Sim</span>
						</button>
						<button type="button" id="closeExcluirCalendarioModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
					</div>
			</form>
				</div>
			</div>
		</div>
	<!--#END of MODAL EXCLUIR CALENDARIO-->


	<!--#END - MODAL ============================================================================================================================== -->

<script>

var wrapper_editar = $(".container-editar");
var max_fields_editar = 32;
var y = 1;
var w = 1;
var texto = "";

function del_editarCalendario() {
	if (w > 1) {
		for (i=2; i<=w; i++) {
			$('#li-'+i).remove();
		}
	}
	y = 1;
	w = 1;
}

function add_editarCalendario() {
	if (y < max_fields_editar) {
		y++;
		w++;
		texto = "";
		texto += '<li class="list-group-item" id="li-'+w+'"><div class="row clearfix">';
		texto += '<div class="col-md-2 col-sm-2 col-xs-4 form-control-label" style="margin-bottom: 0px;"><label for="hora_novoCalendario-0">Hora</label></div>';
		texto += '<div class="col-md-2 col-sm-2 col-xs-4"><div class="form-group" style="margin-bottom: 0px;"><div class="form-line">';
		texto += '<input type="text" name="hora_inicial[]" id="horaInicial_editarCalendario-'+w+'" value="" class="form-control time24">';
		texto += '</div></div></div>';
		texto += '<div class="col-md-2 col-sm-2 col-xs-4"><div class="form-group" style="margin-bottom: 0px;"><div class="form-line">';
		texto += '<input type="text" name="hora_final[]" id="horaFinal_editarCalendario-'+w+'" value="" class="form-control time24">';
		texto += '</div></div></div>';
		texto += '<div class="col-md-2 col-sm-2 col-xs-4 form-control-label" style="margin-bottom: 0px;"><label>Dia da semana</label></div>';
		texto += '<div class="col-md-2 col-sm-2 col-xs-4"><div class="form-group form-float">';
		texto += '<select name="semana_inicial[]" id="semanaInicial_editarCalendario-'+w+'" class="form-control show-tick">';
		texto += '<option value="*">* (any)</option><option value="mon">mon (segunda)</option><option value="tue">tue (terça)</option>';
		texto += '<option value="wed">wed (quarta)</option><option value="thu">thu (quinta)</option><option value="fri">fri (sexta)</option>';
		texto += '<option value="sat">sat (sabado)</option><option value="sun">sun (domingo)</option>';
		texto += '</select></div></div>';
		texto += '<div class="col-md-2 col-sm-2 col-xs-4"><div class="form-group form-float">';
		texto += '<select name="semana_final[]" id="semanaFinal_editarCalendario-'+w+'" class="form-control show-tick">';
		texto += '<option value=""> - </option><option value="mon">mon (segunda)</option><option value="tue">tue (terça)</option>';
		texto += '<option value="wed">wed (quarta)</option><option value="thu">thu (quinta)</option><option value="fri">fri (sexta)</option>';
		texto += '<option value="sat">sat (sabado)</option><option value="sun">sun (domingo)</option>';
		texto += '</select></div></div></div>';
		texto += '<div class="row clearfix">';
		texto += '<div class="col-md-2 col-sm-2 col-xs-4 form-control-label" style="margin-bottom: 0px;"><label>Dia do mês</label></div>';
		texto += '<div class="col-md-2 col-sm-2 col-xs-4"><div class="form-group form-float">';
		texto += '<select name="dia_inicial[]" id="diaInicial_editarCalendario-'+w+'" class="form-control show-tick">';
		texto += '<option value="*">* (any)</option>';
		for (var i = 0; i <=31; i++) { 
			texto += '<option value="'+i+'">'+i+'</option>';
		}
		texto += '</select></div></div>';
		texto += '<div class="col-md-2 col-sm-2 col-xs-4"><div class="form-group form-float">';
		texto += '<select name="dia_final[]" id="diaFinal_editarCalendario-'+w+'" class="form-control show-tick">';
		texto += '<option value=""> - </option>';
		for (var i = 0; i <=31; i++) { 
			texto += '<option value="'+i+'">'+i+'</option>';
		}
		texto += '</select></div></div>';
		texto += '<div class="col-md-2 col-sm-2 col-xs-4 form-control-label" style="margin-bottom: 0px;"><label>Mês</label></div>';
		texto += '<div class="col-md-2 col-sm-2 col-xs-4"><div class="form-group form-float">';
		texto += '<select name="mes_inicial[]" id="mesInicial_editarCalendario-'+w+'" class="form-control show-tick">';
		texto += '<option value="*">* (any)</option><option value="jan">jan (Janeiro)</option>';
		texto += '<option value="feb">feb (Fevereiro)</option><option value="mar">mar (Março)</option>';
		texto += '<option value="apr">apr (Abril)</option><option value="may">may (Maio)</option>';
		texto += '<option value="jun">jun (Junho)</option><option value="jul">jul (Julho)</option>';
		texto += '<option value="aug">aug (Agosto)</option><option value="sep">sep (Setembro)</option>';
		texto += '<option value="oct">oct (Outubro)</option><option value="nov">nov (Novembro)</option>';
		texto += '<option value="dec">dec (Dezembro)</option>';
		texto += '</select></div></div>';
		texto += '<div class="col-md-2 col-sm-2 col-xs-4"><div class="form-group form-float">';
		texto += '<select name="mes_final[]" id="mesFinal_editarCalendario-'+w+'" class="form-control show-tick">';
		texto += '<option value=""> - </option><option value="jan">jan (Janeiro)</option>';
		texto += '<option value="feb">feb (Fevereiro)</option><option value="mar">mar (Março)</option>';
		texto += '<option value="apr">apr (Abril)</option><option value="may">may (Maio)</option>';
		texto += '<option value="jun">jun (Junho)</option><option value="jul">jul (Julho)</option>';
		texto += '<option value="aug">aug (Agosto)</option><option value="sep">sep (Setembro)</option>';
		texto += '<option value="oct">oct (Outubro)</option><option value="nov">nov (Novembro)</option>';
		texto += '<option value="dec">dec (Dezembro)</option>';
		texto += '</select></div></div></div>';
		texto += '<div class="row clearfix">';
		texto += '<div class="col-md-3 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;"><label>Destino</label></div>';
		texto += '<div class="col-md-9 col-sm-8 col-xs-7"><div class="form-group form-float">';
		texto += '<select name="destino[]" id="destino_editarCalendario-'+w+'" class="form-control show-tick" data-live-search="true">';
		texto += '<option value=""> - </option>';
		<?php
			foreach($filas as $key=>$value) {
				print "texto += '<option value=\"QUE/".$key."\">QUE/".$key."</option>';";
			}
			foreach($calendarios as $key=>$value) {
				print "texto += '<option value=\"CAL/".$key."\">CAL/".$key."</option>';";
			}
			foreach($uras as $key=>$value) {
				print "texto += '<option value=\"URA/".$key."\">URA/".$key."</option>';";
			}
			foreach($uras_custom as $key=>$value) {
				print "texto += '<option value=\"URA/".$key."\">URA/".$key."</option>';";
			}
			foreach($abreviados as $key=>$value) {
				print "texto += '<option value=\"ABB/".$key."\">ABB/".$key."</option>';";
			}
			foreach($ramais_sip as $key=>$value) {
				print "texto += '<option value=\"SIP/".$key."\">SIP/".$key."</option>';";
			}
			foreach($ramais_iax2 as $key=>$value) {
				print "texto += '<option value=\"IAX2/".$key."\">IAX2/".$key."</option>';";
			}
		?>
		texto += '</select></div></div>';
		texto += '</div>';
		texto += '<button type="button" class="btn btn-default waves-effect upbutton"><i class="material-icons">arrow_upward</i></button>';
		texto += '<button type="button" class="btn btn-default waves-effect downbutton"><i class="material-icons">arrow_downward</i></button>';
		texto += '<a href="#" class="delete">Delete</a></li>';
        $(wrapper_editar).append(
			texto
		);
		//REFRESH NO SELECTPICKER PRA PODER ATUALIZAR O VALOR
		$('#horaInicial_editarCalendario-'+w).inputmask('hh:mm', { placeholder: '__:__ _m', alias: 'time24', hourFormat: '24' });
		$('#horaFinal_editarCalendario-'+w).inputmask('hh:mm', { placeholder: '__:__ _m', alias: 'time24', hourFormat: '24' });
		$('#diaInicial_editarCalendario-'+w).addClass('selectpicker');
		$('#diaInicial_editarCalendario-'+w).selectpicker('refresh');
		$('#diaFinal_editarCalendario-'+w).addClass('selectpicker');
		$('#diaFinal_editarCalendario-'+w).selectpicker('refresh');
		$('#semanaInicial_editarCalendario-'+w).addClass('selectpicker');
		$('#semanaInicial_editarCalendario-'+w).selectpicker('refresh');
		$('#semanaFinal_editarCalendario-'+w).addClass('selectpicker');
		$('#semanaFinal_editarCalendario-'+w).selectpicker('refresh');
		$('#mesInicial_editarCalendario-'+w).addClass('selectpicker');
		$('#mesInicial_editarCalendario-'+w).selectpicker('refresh');
		$('#mesFinal_editarCalendario-'+w).addClass('selectpicker');
		$('#mesFinal_editarCalendario-'+w).selectpicker('refresh');
		$('#destino_editarCalendario-'+w).addClass('selectpicker');
		$('#destino_editarCalendario-'+w).selectpicker('refresh');
    } else {
		alert('Limite alcançado!');
	}
};

function botaoExcluirCalendario(excluirCalendario) {
	$('#excluirCalendario').val(excluirCalendario);

	$('#excluirCalendarioLabel').text("Excluir Calendario "+excluirCalendario);
	$("#excluirCalendarioModal").modal();
};

$(document).ready(function(){

	var calendarios = <?php echo json_encode($calendarios, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
	/*
	"calendario2":[
		{"hora_inicial":"08:00","hora_final":"11:30","semana_inicial":"mon","semana_final":"fri","dia_inicial":"*","dia_final":"","mes_inicial":"*","mes_final":"","destino":"QUE/600","tipo":"QUE"},
		{"hora_inicial":"13:00","hora_final":"17:59","semana_inicial":"mon","semana_final":"fri","dia_inicial":"*","dia_final":"","mes_inicial":"*","mes_final":"","destino":"QUE/600","tipo":"QUE"},
		{"hora_inicial":"00:00","hora_final":"23:59","semana_inicial":"sat","semana_final":"sun","dia_inicial":"*","dia_final":"","mes_inicial":"*","mes_final":"","destino":"SIP/4055","tipo":"SIP"}
	]
	*/

	$(".editar-calendario").on('click', function(event) {
		event.preventDefault();

		var calendario = $(this).data('id');

		document.getElementById('editarCalendarioLabel').innerHTML = "Editar Calendario: "+calendario;

		$('#editarCalendario').val(calendario);
		
		$('#nome_editarCalendario').val(calendario);
		
		del_editarCalendario();
		for (var i in calendarios[calendario]) {
			
			if (i != 1) {
				add_editarCalendario();
			}
			
			$('#horaInicial_editarCalendario-'+i).val(calendarios[calendario][i].hora_inicial);
			$('#horaFinal_editarCalendario-'+i).val(calendarios[calendario][i].hora_final);
			
			var aux = 0;
			$('#semanaInicial_editarCalendario-'+i+' option').each(function(){
				if ($(this).val() == calendarios[calendario][i].semana_inicial) {
					$('#semanaInicial_editarCalendario-'+i).selectpicker('val', calendarios[calendario][i].semana_inicial);
					aux = 1;
				} else if (aux != 1) {
					$('#semanaInicial_editarCalendario-'+i).selectpicker('val', 'null');
				}
			});
			aux = 0;
			$('#semanaFinal_editarCalendario-'+i+' option').each(function(){
				if ($(this).val() == calendarios[calendario][i].semana_final) {
					$('#semanaFinal_editarCalendario-'+i).selectpicker('val', calendarios[calendario][i].semana_final);
					aux = 1;
				} else if (aux != 1) {
					$('#semanaFinal_editarCalendario-'+i).selectpicker('val', 'null');
				}
			});
			aux = 0;
			$('#diaInicial_editarCalendario-'+i+' option').each(function(){
				if ($(this).val() == calendarios[calendario][i].dia_inicial) {
					$('#diaInicial_editarCalendario-'+i).selectpicker('val', calendarios[calendario][i].dia_inicial);
					aux = 1;
				} else if (aux != 1) {
					$('#diaInicial_editarCalendario-'+i).selectpicker('val', 'null');
				}
			});
			aux = 0;
			$('#diaFinal_editarCalendario-'+i+' option').each(function(){
				if ($(this).val() == calendarios[calendario][i].dia_final) {
					$('#diaFinal_editarCalendario-'+i).selectpicker('val', calendarios[calendario][i].dia_final);
					aux = 1;
				} else if (aux != 1) {
					$('#diaFinal_editarCalendario-'+i).selectpicker('val', 'null');
				}
			});
			aux = 0;
			$('#mesInicial_editarCalendario-'+i+' option').each(function(){
				if ($(this).val() == calendarios[calendario][i].mes_inicial) {
					$('#mesInicial_editarCalendario-'+i).selectpicker('val', calendarios[calendario][i].mes_inicial);
					aux = 1;
				} else if (aux != 1) {
					$('#mesInicial_editarCalendario-'+i).selectpicker('val', 'null');
				}
			});
			aux = 0;
			$('#mesFinal_editarCalendario-'+i+' option').each(function(){
				if ($(this).val() == calendarios[calendario][i].mes_final) {
					$('#mesFinal_editarCalendario-'+i).selectpicker('val', calendarios[calendario][i].mes_final);
					aux = 1;
				} else if (aux != 1) {
					$('#mesFinal_editarCalendario-'+i).selectpicker('val', 'null');
				}
			});
			aux = 0;
			$('#destino_editarCalendario-'+i+' option').each(function(){
				if ($(this).val() == calendarios[calendario][i].destino) {
					$('#destino_editarCalendario-'+i).selectpicker('val', calendarios[calendario][i].destino);
					aux = 1;
				} else if (aux != 1) {
					$('#destino_editarCalendario-'+i).selectpicker('val', 'null');
				}
			});
		}
		
	});
	
	$(function () {
		$('#nestable-contextos').nestable({
			maxDepth: 1
		})
	});
	
	$('#editarCalendarioModal').on('show.bs.modal', function (e) {
		$('.dd').nestable({
		    maxDepth: 1
		});
	});
	
	$('#novoCalendarioModal').on('show.bs.modal', function (e) {
		$('.dd').nestable({
		    maxDepth: 1
		});
	});
	
	
	var max_fields = 32;
	var wrapper = $(".container1");
  
    var x = 1;
	var z = 1;
	var texto = "";
    $("#add_novoCalendario").click(function(e){
        e.preventDefault();
        if (x < max_fields) {
            x++;
			z++;
			texto = "";
			texto += '<li class="list-group-item"><div class="row clearfix">';
			texto += '<div class="col-md-2 col-sm-2 col-xs-4 form-control-label" style="margin-bottom: 0px;"><label for="hora_novoCalendario-0">Hora</label></div>';
			texto += '<div class="col-md-2 col-sm-2 col-xs-4"><div class="form-group" style="margin-bottom: 0px;"><div class="form-line">';
			texto += '<input type="text" name="hora_inicial[]" id="horaInicial_novoCalendario-'+z+'" value="" class="form-control time24">';
			texto += '</div></div></div>';
			texto += '<div class="col-md-2 col-sm-2 col-xs-4"><div class="form-group" style="margin-bottom: 0px;"><div class="form-line">';
			texto += '<input type="text" name="hora_final[]" id="horaFinal_novoCalendario-'+z+'" value="" class="form-control time24">';
			texto += '</div></div></div>';
			texto += '<div class="col-md-2 col-sm-2 col-xs-4 form-control-label" style="margin-bottom: 0px;"><label>Dia da semana</label></div>';
			texto += '<div class="col-md-2 col-sm-2 col-xs-4"><div class="form-group form-float">';
			texto += '<select name="semana_inicial[]" id="semanaInicial_novoCalendario-'+z+'" class="form-control show-tick">';
			texto += '<option value="*">* (any)</option><option value="mon">mon (segunda)</option><option value="tue">tue (terça)</option>';
			texto += '<option value="wed">wed (quarta)</option><option value="thu">thu (quinta)</option><option value="fri">fri (sexta)</option>';
			texto += '<option value="sat">sat (sabado)</option><option value="sun">sun (domingo)</option>';
			texto += '</select></div></div>';
			texto += '<div class="col-md-2 col-sm-2 col-xs-4"><div class="form-group form-float">';
			texto += '<select name="semana_final[]" id="semanaFinal_novoCalendario-'+z+'" class="form-control show-tick">';
			texto += '<option value=""> - </option><option value="mon">mon (segunda)</option><option value="tue">tue (terça)</option>';
			texto += '<option value="wed">wed (quarta)</option><option value="thu">thu (quinta)</option><option value="fri">fri (sexta)</option>';
			texto += '<option value="sat">sat (sabado)</option><option value="sun">sun (domingo)</option>';
			texto += '</select></div></div></div>';
			texto += '<div class="row clearfix">';
			texto += '<div class="col-md-2 col-sm-2 col-xs-4 form-control-label" style="margin-bottom: 0px;"><label>Dia do mês</label></div>';
			texto += '<div class="col-md-2 col-sm-2 col-xs-4"><div class="form-group form-float">';
			texto += '<select name="dia_inicial[]" id="diaInicial_novoCalendario-'+z+'" class="form-control show-tick">';
			texto += '<option value="*">* (any)</option>';
			for (var i = 0; i <=31; i++) { 
				texto += '<option value="'+i+'">'+i+'</option>';
			}
			texto += '</select></div></div>';
			texto += '<div class="col-md-2 col-sm-2 col-xs-4"><div class="form-group form-float">';
			texto += '<select name="dia_final[]" id="diaFinal_novoCalendario-'+z+'" class="form-control show-tick">';
			texto += '<option value=""> - </option>';
			for (var i = 0; i <=31; i++) { 
				texto += '<option value="'+i+'">'+i+'</option>';
			}
			texto += '</select></div></div>';
			texto += '<div class="col-md-2 col-sm-2 col-xs-4 form-control-label" style="margin-bottom: 0px;"><label>Mês</label></div>';
			texto += '<div class="col-md-2 col-sm-2 col-xs-4"><div class="form-group form-float">';
			texto += '<select name="mes_inicial[]" id="mesInicial_novoCalendario-'+z+'" class="form-control show-tick">';
			texto += '<option value="*">* (any)</option><option value="jan">jan (Janeiro)</option>';
			texto += '<option value="feb">feb (Fevereiro)</option><option value="mar">mar (Março)</option>';
			texto += '<option value="apr">apr (Abril)</option><option value="may">may (Maio)</option>';
			texto += '<option value="jun">jun (Junho)</option><option value="jul">jul (Julho)</option>';
			texto += '<option value="aug">aug (Agosto)</option><option value="sep">sep (Setembro)</option>';
			texto += '<option value="oct">oct (Outubro)</option><option value="nov">nov (Novembro)</option>';
			texto += '<option value="dec">dec (Dezembro)</option>';
			texto += '</select></div></div>';
			texto += '<div class="col-md-2 col-sm-2 col-xs-4"><div class="form-group form-float">';
			texto += '<select name="mes_final[]" id="mesFinal_novoCalendario-'+z+'" class="form-control show-tick">';
			texto += '<option value=""> - </option><option value="jan">jan (Janeiro)</option>';
			texto += '<option value="feb">feb (Fevereiro)</option><option value="mar">mar (Março)</option>';
			texto += '<option value="apr">apr (Abril)</option><option value="may">may (Maio)</option>';
			texto += '<option value="jun">jun (Junho)</option><option value="jul">jul (Julho)</option>';
			texto += '<option value="aug">aug (Agosto)</option><option value="sep">sep (Setembro)</option>';
			texto += '<option value="oct">oct (Outubro)</option><option value="nov">nov (Novembro)</option>';
			texto += '<option value="dec">dec (Dezembro)</option>';
			texto += '</select></div></div></div>';
			texto += '<div class="row clearfix">';
			texto += '<div class="col-md-3 col-sm-4 col-xs-5 form-control-label" style="margin-bottom: 0px;"><label>Destino</label></div>';
			texto += '<div class="col-md-9 col-sm-8 col-xs-7"><div class="form-group form-float">';
			texto += '<select name="destino[]" id="destino_novoCalendario-'+z+'" class="form-control show-tick" data-live-search="true">';
			texto += '<option value=""> - </option>';
			<?php
				foreach($filas as $key=>$value) {
					print "texto += '<option value=\"QUE/".$key."\">QUE/".$key."</option>';";
				}
				foreach($calendarios as $key=>$value) {
					print "texto += '<option value=\"CAL/".$key."\">CAL/".$key."</option>';";
				}
				foreach($uras as $key=>$value) {
					print "texto += '<option value=\"URA/".$key."\">URA/".$key."</option>';";
				}
				foreach($uras_custom as $key=>$value) {
					print "texto += '<option value=\"URA/".$key."\">URA/".$key."</option>';";
				}
				foreach($abreviados as $key=>$value) {
					print "texto += '<option value=\"ABB/".$key."\">ABB/".$key."</option>';";
				}
				foreach($ramais_sip as $key=>$value) {
					print "texto += '<option value=\"SIP/".$key."\">SIP/".$key."</option>';";
				}
				foreach($ramais_iax2 as $key=>$value) {
					print "texto += '<option value=\"IAX2/".$key."\">IAX2/".$key."</option>';";
				}
			?>
			texto += '</select></div></div>';
			texto += '</div>';
			texto += '<button type="button" class="btn btn-default waves-effect upbutton"><i class="material-icons">arrow_upward</i></button>';
			texto += '<button type="button" class="btn btn-default waves-effect downbutton"><i class="material-icons">arrow_downward</i></button>';
			texto += '<a href="#" class="delete">Delete</a></li>';
			$(wrapper).append(
				texto
			);
			//REFRESH NO SELECTPICKER PRA PODER ATUALIZAR O VALOR
			$('#horaInicial_novoCalendario-'+z).inputmask('hh:mm', { placeholder: '__:__ _m', alias: 'time24', hourFormat: '24' });
			$('#horaFinal_novoCalendario-'+z).inputmask('hh:mm', { placeholder: '__:__ _m', alias: 'time24', hourFormat: '24' });
			$('#diaInicial_novoCalendario-'+z).addClass('selectpicker');
			$('#diaInicial_novoCalendario-'+z).selectpicker('refresh');
			$('#diaFinal_novoCalendario-'+z).addClass('selectpicker');
			$('#diaFinal_novoCalendario-'+z).selectpicker('refresh');
			$('#semanaInicial_novoCalendario-'+z).addClass('selectpicker');
			$('#semanaInicial_novoCalendario-'+z).selectpicker('refresh');
			$('#semanaFinal_novoCalendario-'+z).addClass('selectpicker');
			$('#semanaFinal_novoCalendario-'+z).selectpicker('refresh');
			$('#mesInicial_novoCalendario-'+z).addClass('selectpicker');
			$('#mesInicial_novoCalendario-'+z).selectpicker('refresh');
			$('#mesFinal_novoCalendario-'+z).addClass('selectpicker');
			$('#mesFinal_novoCalendario-'+z).selectpicker('refresh');
			$('#destino_novoCalendario-'+z).addClass('selectpicker');
			$('#destino_novoCalendario-'+z).selectpicker('refresh');
        } else {
			alert('Limite alcançado!');
		}
    });
  
    $(wrapper).on("click",".delete", function(e){
        e.preventDefault(); $(this).parent('li').remove(); x--;
    })
	
	$("#add_editarCalendario").click(function(e){
		e.preventDefault();
		add_editarCalendario();
	})
	
	$(wrapper_editar).on("click",".delete", function(e){
        e.preventDefault(); $(this).parent('li').remove(); y--;
    })
	
	$(document).on("click",".upbutton", function(){
		//e.preventDefault();
		var hook = $(this).closest('.list-group-item').prev('.list-group-item');
		if (hook.length) {
			var elementToMove = $(this).closest('.list-group-item').detach();
			hook.before(elementToMove);
		}
	});
	$(document).on("click",".downbutton", function(){
		//e.preventDefault();
		var hook = $(this).closest('.list-group-item').next('.list-group-item');
		if (hook.length) {
			var elementToMove = $(this).closest('.list-group-item').detach();
			hook.after(elementToMove);
		}
	});

});

</script>