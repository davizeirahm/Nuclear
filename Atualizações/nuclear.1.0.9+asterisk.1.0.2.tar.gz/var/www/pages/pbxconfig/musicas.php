<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.db.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.musicas.php");

	if ( isset($_GET['tipo']) && $_GET['tipo'] == "fila") {
		$tipo = "fila";
	} elseif ( isset($_GET['tipo']) && $_GET['tipo'] == "ura") {
		$tipo = "ura";
	} else {
		$tipo = "categoria";
	}

	// DECLARAÇÃO DE VARIÁVEIS ==============================================================================================
	
	$categorias = get_categorias_musicais();
	
	$audios_ura = listar_musicas(DIR_AUDIOS."/ura");
	
	$audios_fila = listar_musicas(DIR_AUDIOS."/queue");

	//CATEGORIAS ===============================================================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "novaCategoria") {
		//print_r($_POST);
		//die();
		//Array ( [nome] => teste )

		$erro = "";
		if (!isset($_POST['nome']) || @$_POST['nome'] == "") {
			$erro = "Erro: Nome Inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !nova_categoria($_POST['nome']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "editarCategoria") {
		
		$erro="";
		if (!isset($_POST['editarnome']) || @$_POST['editarnome'] == "") {
			$erro = "Erro: Categoria Inválida!";
		}
		if (!isset($_POST['nome']) || @$_POST['nome'] == "") {
			$erro = "Erro: Nome Inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !editar_categoria($_POST) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirCategoria") {
		
		$erro="";
		if (!isset($_POST['nome']) || @$_POST['nome'] == "") {
			$erro = "Erro: Categoria Inválida!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !excluir_categoria($_POST['nome']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	
	//AUDIO ===================================================================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "upload") {
		
		$erro="";
		if (!isset($_POST['tipo']) || @$_POST['tipo'] == "") {
			$erro = "Erro: Diretório Inválido!";
		}
		if (!isset($_POST['dir']) || @$_POST['dir'] == "") {
			$erro = "Erro: Diretório Inválido!";
		}
		if(!isset($_FILES['arquivo']['name'])){
			$erro = "Erro: Diretório Inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !upload_audio($_FILES['arquivo'],$_POST['tipo'],$_POST['dir']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	} elseif (isset($_POST['cmd']) && $_POST['cmd'] == "excluirAudio") {
		
		$erro="";
		if (!isset($_POST['file']) || @$_POST['file'] == "") {
			$erro = "Erro: Arquivo Inválida!";
		}
		if (!isset($_POST['tipo']) || @$_POST['tipo'] == "") {
			$erro = "Erro: Diretório Inválido!";
		}
		if (!isset($_POST['dir']) || @$_POST['dir'] == "") {
			$erro = "Erro: Diretório Inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !excluir_audio($_POST['file'],$_POST['tipo'],$_POST['dir']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
?>

	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- MENU MUSICAS -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
						<div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
                                	<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
						</div>
                        <div class="body">
                            <ul class="nav nav-tabs tab-nav-right" role="tablist">
                                <li role="presentation" <?php echo ( $tipo == "categoria" ? "class=\"active\"" : "" ); ?> ><a href="#categoria" data-toggle="tab">CATEGORIAS MUSICAIS</a></li>
                                <li role="presentation" <?php echo ( $tipo == "ura" ? "class=\"active\"" : "" ); ?> ><a href="#ura" data-toggle="tab">ÁUDIOS URA</a></li>
								<li role="presentation" <?php echo ( $tipo == "fila" ? "class=\"active\"" : "" ); ?> ><a href="#fila" data-toggle="tab">ÁUDIOS FILA</a></li>
							</ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
				<!-- CATEGORIAS #####################################################################################################################-->
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "categoria" ? "in active" : "" ); ?>" id="categoria">



				<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novaCategoriaModal">
					<i class="material-icons">add_circle</i>
					<span>NOVA CATEGORIA</span>
			    </button>
				<hr>
				

				<?php
				foreach($categorias as $categoria=>$vetor) {
					if (is_array($vetor)) {
				?>
					<h4>Categoria: <?=$categoria;?></h4>
					<?php if ($categoria != "default") { ?>
						<button type="button" class="btn btn-primary waves-effect" onclick="botaoExcluirCategoria('<?=$categoria;?>')">
							<i class="material-icons">delete</i>
						</button>
						<button type="button" class="btn btn-primary waves-effect" onclick="botaoEditarCategoria('<?=$categoria;?>')">
							<i class="material-icons">edit</i>
						</button>
					<?php } ?>
					<hr>
							
							<!--Formulário-->
							<form method="post" name="upload_audio-<?=$categoria;?>" enctype="multipart/form-data">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="upload" />
							<input type="hidden" name="tipo" value="categoria" />
							<input type="hidden" name="dir" value="<?=$categoria;?>" />
							<div class="row clearfix">
								<div class="col-md-3 col-sm-6 col-xs-12">
									<label>Enviar Arquivo .wav</label>
								</div>
								<div class="col-md-3 col-sm-6 col-xs-12">
									<div class="form-group form-float" style="margin-bottom:0px">
										<div class="form-line">
											<input name="arquivo" type="file" class="form-control" />
										</div>
									</div>
								</div>
								<div class="col-md-3 col-sm-12">
									<Button onclick="document.upload_audio-<?=$categoria;?>.submit()" class="btn btn-primary waves-effect">
										<i class="material-icons">publish</i>
										<span>ENVIAR MÚSICA</span>
									</Button>
								</div>
							</div>
							</form>
							<!--FIM FORMULÁRIO-->
							
					<div class="table-responsive">
							<table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
								<thead>
									<tr>
										<th>Nome</th>
										<th>Opções</th>
									</tr>
								</thead>
								<tbody>
							<?php
							foreach($vetor as $audio) {
								if (is_array($vetor)) {
							?>
								<tr>
									<td><?=$audio;?></td>
									<td>
										<a href="javascript:;" class="play" onclick="botaoExcluirAudio('<?=$audio;?>','categoria','<?=$categoria;?>')"><i class="material-icons" title="Excluir">delete</i></a>&nbsp;
										<a href="javascript:;" class="play" data-url="/download_musicas.php?file=<?=$audio;?>&tipo=categoria&dir=<?=$categoria;?>" onclick="loadModalAudio('<?=$audio;?>')" data-toggle="modal" data-target="#defaultModal" ><i class="material-icons" title="Ouvir a gravação">play_arrow</i></a>&nbsp;
										<a href="/download_musicas.php?file=<?=$audio;?>&tipo=categoria&dir=<?=$categoria;?>"><i class="material-icons" title="Clique aqui para baixar a gravação no seu computador">file_download</i></a>
									</td>
								</tr>
							<?php
								}
							}
							?>
								</tbody>
							</table>
						<hr>
					</div>
				<?php
					}
				}
				?>


								</div>
				<!--#FIM - CATEGORIAS ########################################################################################################-->
				<!-- URA #####################################################################################################################-->
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "ura" ? "in active" : "" ); ?>" id="ura">
								
							<!--Formulário-->
							<form method="post" name="upload_audio-ura" enctype="multipart/form-data">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="upload" />
							<input type="hidden" name="tipo" value="audio" />
							<input type="hidden" name="dir" value="ura" />
							<div class="row clearfix">
								<div class="col-md-3 col-sm-6 col-xs-12">
									<label>Enviar Arquivo .wav</label>
								</div>
								<div class="col-md-3 col-sm-6 col-xs-12">
									<div class="form-group form-float" style="margin-bottom:0px">
										<div class="form-line">
											<input name="arquivo" type="file" class="form-control" />
										</div>
									</div>
								</div>
								<div class="col-md-3 col-sm-12">
									<Button id="btnSubmit" onclick="document.upload_audio-ura.submit()" class="btn btn-primary waves-effect">
										<i class="material-icons">publish</i>
										<span>ENVIAR MÚSICA</span>
									</Button>
								</div>
							</div>
							</form>
							<!--FIM FORMULÁRIO-->	
							
							<div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
                                            <th>Nome</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					    <?php
						foreach($audios_ura as $audio) {
						    if (is_array($vetor)) {
					    ?>
							<tr>
								<td><?=$audio;?></td>
								<td>
									<a href="javascript:;" class="play" onclick="botaoExcluirAudio('<?=$audio;?>','audio','ura')"><i class="material-icons" title="Excluir">delete</i></a>&nbsp;
									<a href="javascript:;" class="play" data-url="/download_musicas.php?file=<?=$audio;?>&tipo=audio&dir=ura" onclick="loadModalAudio('<?=$audio;?>')" data-toggle="modal" data-target="#defaultModal" ><i class="material-icons" title="Ouvir a gravação">play_arrow</i></a>&nbsp;
									<a href="/download_musicas.php?file=<?=$audio;?>&tipo=audio&dir=ura"><i class="material-icons" title="Clique aqui para baixar a gravação no seu computador">file_download</i></a>
								</td>
						    </tr>
					    <?php
						    }
						}
					    ?>
                                    </tbody>
                                </table>
							</div>
				
								</div>
				<!-- #END# URA #################################################################################################################-->
				<!-- FILA ######################################################################################################################-->
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "fila" ? "in active" : "" ); ?>" id="fila">

							<!--Formulário-->
							<form method="post" name="upload_audio-fila" enctype="multipart/form-data">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="upload" />
							<input type="hidden" name="tipo" value="audio" />
							<input type="hidden" name="dir" value="queue" />
							<div class="row clearfix">
								<div class="col-md-3 col-sm-6 col-xs-12">
									<label>Enviar Arquivo .wav</label>
								</div>
								<div class="col-md-3 col-sm-6 col-xs-12">
									<div class="form-group form-float" style="margin-bottom:0px">
										<div class="form-line">
											<input name="arquivo" type="file" class="form-control" />
										</div>
									</div>
								</div>
								<div class="col-md-3 col-sm-12">
									<Button id="btnSubmit" onclick="document.upload_audio-fila.submit()" class="btn btn-primary waves-effect">
										<i class="material-icons">publish</i>
										<span>ENVIAR MÚSICA</span>
									</Button>
								</div>
							</div>
							</form>
							<!--FIM FORMULÁRIO-->

							<div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
                                            <th>Nome</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					    <?php
						foreach($audios_fila as $audio) {
						    if (is_array($vetor)) {
					    ?>
							<tr>
								<td><?=$audio;?></td>
								<td>
									<a href="javascript:;" class="play" onclick="botaoExcluirAudio('<?=$audio;?>','audio','queue')"><i class="material-icons" title="Excluir">delete</i></a>&nbsp;
									<a href="javascript:;" class="play" data-url="/download_musicas.php?file=<?=$audio;?>&tipo=audio&dir=queue" onclick="loadModalAudio('<?=$audio;?>')" data-toggle="modal" data-target="#defaultModal" ><i class="material-icons" title="Ouvir a gravação">play_arrow</i></a>&nbsp;
									<a href="/download_musicas.php?file=<?=$audio;?>&tipo=audio&dir=queue"><i class="material-icons" title="Clique aqui para baixar a gravação no seu computador">file_download</i></a>
								</td>
						    </tr>
					    <?php
						    }
						}
					    ?>
                                    </tbody>
                                </table>
							</div>
						
								</div>
				<!-- #END# FILA ###############################################################################################################-->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	<!--END - PAGE CONTENT-->


	<!-- MODAL ================================================================================================================================== -->

		<!--MODAL NOVA CATEGORIA-->
            <div class="modal fade" id="novaCategoriaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="modal-title" id="novaCategoriaLabel">Nova Categoria</h2>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
							<form id="formNovaCategoria" method="post">
							<?=$text_form;?>
							<input type="hidden" name="pagina" value="pbxconfig" />
							<input type="hidden" name="menu" value="musicas" />
							<input type="hidden" name="cmd" value="novaCategoria" />

								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="novaCategoria_nome">Nome</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="nome" id="nome_novaCategoria" class="form-control rota">
                                            </div>
                                        </div>
                                    </div>
								</div>
								
							</div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
                            <button type="button" id="closenovaCategoriaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
							</form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL NOVA CATEGORIA-->

		<!--MODAL EDITAR CATEGORIA-->
			<div class="modal fade" id="editarCategoriaModal" tabindex="-1" role="dialog">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h4 class="modal-title" id="editarCategoriaLabel">Editar Categoria</h4>
						</div>
						<div class="modal-body">
							<div class="row clearfix demo-masked-input">
								<form id="formEditarCategoria" method="post">
								<?=$text_form;?>
								<input type="hidden" name="cmd" value="editarCategoria" />
								<input type="hidden" id="editarCategoria" name="editarnome" value="" />
								
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="nome_editarCategoria">Nome</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="nome" id="nome_editarCategoria" class="form-control rota">
                                            </div>
                                        </div>
                                    </div>
								</div>
								
							</div>
						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
							<button type="button" id="closeEditarCategoriaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
						</div>
							</form>
					</div>
				</div>
			</div>
	    <!--#END of MODAL EDITAR CATEGORIA-->


	    <!--MODAL EXCLUIR CATEGORIA-->
            <div class="modal fade" id="excluirCategoriaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirCategoriaLabel">Excluir Categoria</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirCategoria" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="excluirCategoria" />
				<input type="hidden" id="excluirCategoria" name="nome" value="" />
			    <p>Tem certeza que deseja excluir a Categoria?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
							<button type="button" id="closeExcluirCategoriaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR CATEGORIA-->
		
	<!-- AUDIO -->
	
		<!--MODAL EXCLUIR AUDIO-->
            <div class="modal fade" id="excluirAudioModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirAudioLabel">Excluir Áudio</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirAudio" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="excluirAudio" />
				<input type="hidden" id="excluirAudioFile" name="file" value="" />
				<input type="hidden" id="excluirAudioTipo" name="tipo" value="" />
				<input type="hidden" id="excluirAudioDir" name="dir" value="" />
			    <p>Tem certeza que deseja excluir o áudio?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
							<button type="button" id="closeExcluirAudioModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR AUDIO-->
		
		<!-- Modal AudioPlayer -->
		<div class="modal fade" id="defaultModal" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="defaultModalLabel">Ouvindo Áudio</h4>
					</div>
					<div class="modal-body">
						<div id="audioerror"></div>
						<div id="audioplayer"></div>

						<div style="float:left;" id="audioCurrent">00:00:00</div>
						<div align="right" style="float:right;" id="audioDuration">00:00:00</div>
						<p></br></p>

						<div class="row clearfix">
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8" style="padding-right:0px;">
								<button type="button" id="audioplay" class="btn btn-default waves-effect">
									<i class="material-icons">play_arrow</i>
								</button>
								<button type="button" id="audiopause" class="btn btn-default waves-effect">
									<i class="material-icons">pause</i>
								</button>
								<i style="float:right;padding-top:6px" class="material-icons">volume_up</i>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4" style="padding-top:10px;">
								<div id="volumeControl"></div>
							</div>
						</div>
						<div class="row clearfix">
							<div class="col-xs-12" style="padding-top:10px;">
								<p id="nameAudio">Arquivo</p>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" id="closemodal" class="btn btn-link waves-effect" data-dismiss="modal">Fechar</button>
					</div>
				</div>
			</div>
		</div>
		<!--#END of Modal AudioPlayer -->

	<!--#END - MODAL ============================================================================================================================== -->

<script>

function botaoExcluirCategoria(excluirCategoria) {
	$('#excluirCategoria').val(excluirCategoria);

	$('#excluirCategoriaLabel').text("Excluir Categoria "+excluirCategoria);
	$("#excluirCategoriaModal").modal();
};

function botaoEditarCategoria(editarCategoria) {
	$('#editarCategoria').val(editarCategoria);
	$('#nome_editarCategoria').val(editarCategoria);
	
	$('#editarCategoriaLabel').text("Editar Categoria: "+editarCategoria);
	$('#editarCategoriaModal').modal();
};

function botaoExcluirAudio(excluirAudio,tipo,dir) {
	$('#excluirAudioFile').val(excluirAudio);
	$('#excluirAudioTipo').val(tipo);
	$('#excluirAudioDir').val(dir);
	
	$('#excluirAudioLabel').text("Excluir Áudio: "+excluirAudio);
	$('#excluirAudioModal').modal();
};

$(document).ready(function(){

});

function loadModalAudio(audio) {
	$('#nameAudio').text("Arquivo: "+audio);
}

$(function() {
	var wavesurfer = WaveSurfer.create({
		container: '#audioplayer',
		waveColor: '#448CCC',
		progressColor: 'cyan'
	});

	$('[data-url]').on('click', function(event) {
		event.preventDefault();

		wavesurfer.load(
			$(this).data('url')
		);

		document.getElementById("audioerror").innerHTML = "";

		wavesurfer.on('ready', function () {
		wavesurfer.play();
		var duration = formatSeconds(wavesurfer.getDuration());
		document.getElementById("audioDuration").innerHTML = duration;

		setInterval(function() {
			var current = formatSeconds(wavesurfer.getCurrentTime());
			document.getElementById("audioCurrent").innerHTML = current;
		}, 1000);

		});
	});

	wavesurfer.on('error', function () {
	    document.getElementById("audioerror").innerHTML = "Ocorreu um erro na abertura do arquivo!";
	});

	$('#closemodal').click(function() {
		wavesurfer.stop();
	});
	$('#audioplay').click(function() {
		wavesurfer.play();
	});
	$('#audiopause').click(function() {
		wavesurfer.pause();
	});

	var sliderBasic = document.getElementById('volumeControl');
    	noUiSlider.create(sliderBasic, {
		start: [100],
        	connect: 'lower',
        	step: 1,
        	range: {
            		'min': [0],
            		'max': [100]
        	}
    	});
    	getNoUISliderValue(sliderBasic, true);

	function getNoUISliderValue(slider) {
		slider.noUiSlider.on('update', function () {
			var val = slider.noUiSlider.get()
			wavesurfer.setVolume(val/100);
		});
	}

});

</script>