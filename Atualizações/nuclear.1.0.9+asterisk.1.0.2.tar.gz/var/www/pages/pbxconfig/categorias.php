<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.config.ramal.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.categorias.php");

	if ( isset($_GET['tipo']) && $_GET['tipo'] == "config") {
		$tipo = "config";
	} else {
		$tipo = "categorias";
	}

	// DECLARAÇÃO DE VARIÁVEIS ==============================================================================================
	
	//ARQ_CATEGORIASAD_CONF - categorias_adicional.conf
	$rotas = get_rotas();
	//print_r($rotas);
	//Array ( [1] => interno [2] => abreviados [3] => facilidades [4] => noturno [5] => telefonista [6] => ESPECIAL [7] => EMERGENCIA [8] => 0300 [9] => 0800 [10] => LOCAL [11] => CELULAR_NONO_DIGITO [12] => CELULAR_DDD_NONO_DIGITO [13] => DDD [14] => DDI [15] => COBRAR_LOCAL [16] => COBRAR_DDD [17] => DISCADOR
	//echo json_encode($rotas, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

	//categorias.conf
	$categorias = get_categorias();
	//print_r($categorias);
	//[1] => Array ( [0] => interno [1] => abreviados [2] => facilidades [3] => noturno [4] => telefonista [5] => ESPECIAL [6] => EMERGENCIA [7] => 0300 [8] => 0800 [9] => LOCAL [10] => CELULAR_OITO_DIGITOS [11] => CELULAR_NONO_DIGITO [12] => CELULAR_DDD_OITO_DIGITOS [13] => CELULAR_DDD_NONO_DIGITO [14] => DDD [15] => DDI [16] => COBRAR_LOCAL [17] => COBRAR_DDD )
	//echo json_encode($categorias, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

	//CATEGORIAS ===============================================================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "novaCategoria") {
		//Array ( [pagina] => pbxconfig [menu] => categorias [tipo] => categoria [cmd] => novaCategoria [nome] => teste [descricao] => asdasd [rotas] => Array ( [0] => interno [1] => LOCAL [2] => DDD ) )
		
		$erro = "";
		if (!isset($_POST['nome']) || @$_POST['nome'] == "") {
			$erro = "Erro: Categoria Incorreta!";
		}
		if (!isset($_POST['rotas']) ) {
			$erro = "Erro: Nenhuma rota selecionada!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !nova_categoria($_POST) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "editarCategoria") {
		
		$erro="";
		if (!isset($_POST['categoria']) || @$_POST['categoria'] == "") {
			$erro = "Erro: Categoria Incorreta!";
		}
		if (!isset($_POST['nome']) || @$_POST['nome'] == "") {
			$erro = "Erro: Categoria Incorreta!";
		}
		if (!isset($_POST['rotas']) ) {
			$erro = "Erro: Nenhuma rota selecionada!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !editar_categoria($_POST) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirCategoria") {
		
		$erro="";
		if (!isset($_POST['categoria']) || @$_POST['categoria'] == "") {
			$erro = "Erro: Categoria Incorreta!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !excluir_categoria($_POST['categoria']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	//CONTEXTOS
	if (isset($_POST['cmd']) && $_POST['cmd'] == "ordemContextos") {
		
		$erro="";
		if ( !isset($_POST['rotas']) ) {
			$erro = "Erro: 0x00000001!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !ordem_contextos($_POST['rotas']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}

?>


	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- MENU CATEGORIAS -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
						<div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
                                	<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
						</div>
                        <div class="body">
                            <ul class="nav nav-tabs tab-nav-right" role="tablist">
                                <li role="presentation" <?php echo ( $tipo == "categorias" ? "class=\"active\"" : "" ); ?> ><a href="#categorias" data-toggle="tab">CATEGORIAS</a></li>
                                <li role="presentation" <?php echo ( $tipo == "config" ? "class=\"active\"" : "" ); ?> ><a href="#config" data-toggle="tab">CONFIGURAÇÃO</a></li>
							</ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
				<!-- CATEGORIAS #####################################################################################################################-->
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "categorias" ? "in active" : "" ); ?>" id="categorias">

				<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novaCategoriaModal">
					<i class="material-icons">add_circle</i>
					<span>NOVA CATEGORIA</span>
			    </button>
			    <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
                                    <thead>
                                        <tr>
                                            <th>Nome</th>
											<th>Descrição</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					    <?php
						foreach($categorias as $categoria=>$vetor) {
						    if (is_array($vetor)) {
					    ?>
							<tr>
								<td><?=$categoria;?></td>
								<td><?=$vetor['descricao'];?></td>
								<td>
									<a href="javascript:;" class="editar-categoria" data-id="<?=$categoria;?>" data-toggle="modal" data-target="#editarCategoriaModal"><i class="material-icons" title="Editar">edit</i></a>&nbsp;
									<a href="javascript:;" class="play" onclick="botaoExcluirCategoria('<?=$categoria;?>')"><i class="material-icons" title="Excluir">delete</i></a>
								</td>
						        </tr>
					    <?php
						    }
						}
					    ?>
                                    </tbody>
                                </table>
                            </div>


								</div>
				<!--#FIM - CATEGORIAS ##############################################################################################################-->
				<!-- CONFIGURAÇÃO ##################################################################################################################-->
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "config" ? "in active" : "" ); ?>" id="config">

			</br>
			<h4>ORDEM DOS CONTEXTOS</h4>
			<small>Altere a ordem dos itens da categoria clicando e arrastando com o mouse.</small>
			</br>
						<form id="formOrdemContextos" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="ordemContextos" />
							<div class="clearfix m-b-20">
                                <div class="dd" id="nestable-contextos">
                                    <ol class="dd-list">
                                    <?php
										foreach ($rotas as $k=>$nome) {
									?>
											<li class="dd-item" data-id="dd-<?=$k;?>">
												<div class="dd-handle">
													<input type="hidden" name="rotas[]" id="rota-<?=$k;?>" value="<?=$nome;?>" />
													<label><?=$nome;?></label>
												</div>
											</li>
									<?php
										}
									?>
                                    </ol>
                                </div>
                            </div>
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
						</form>
                <!-- #END# CONFIGURAÇÃO -->
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	<!--END - PAGE CONTENT-->


	<!-- MODAL ================================================================================================================================== -->

		<!--MODAL NOVA CATEGORIA-->
            <div class="modal fade" id="novaCategoriaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="novaCategoriaLabel">Nova Categoria</h4>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
							<form id="formNovaCategoria" method="post">
							<?=$text_form;?>
							<input type="hidden" name="tipo" value="categoria" />
							<input type="hidden" name="cmd" value="novaCategoria" />

								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
                                        <label for="novaCategoria_nome">Nome</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="nome" id="novaCategoria_nome" class="form-control rota" onchange="verifica_contexto(this)">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
                                        <label for="novaCategoria_descricao">Descrição</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="descricao" id="novaCategoria_descricao" class="form-control">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="clearfix">
									<div class="dd">
										<ol class="dd-list">
									<?php
										foreach ($rotas as $k=>$nome) {
									?>
											<li class="dd-item">
												<div class="dd-handle">
													<input type="checkbox" name="rotas[]" id="novaCategoria_rota-<?=$k;?>" value="<?=$nome;?>" class="filled-in chk-col-light-blue" />
													<label for="novaCategoria_rota-<?=$k;?>"><?=$nome;?></label>
												</div>
											</li>
									<?php
										}
									?>
										</ol>
									</div>
								</div>

							</div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
                            <button type="button" id="closenovaCategoriaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
							</form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL NOVA CATEGORIA-->

		<!--MODAL EDITAR CATEGORIA-->
			<div class="modal fade" id="editarCategoriaModal" tabindex="-1" role="dialog">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h4 class="modal-title" id="editarCategoriaLabel">Editar Categoria</h4>
						</div>
						<div class="modal-body">
							<div class="row clearfix demo-masked-input">
								<form id="formEditarCategoria" method="post">
								<?=$text_form;?>
								<input type="hidden" name="cmd" value="editarCategoria" />
								<input type="hidden" id="editarCategoria" name="categoria" value="" />
								
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
                                        <label for="nome_editarCategoria">Nome</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="nome" id="nome_editarCategoria" class="form-control rota" onchange="verifica_contexto(this)">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label">
                                        <label for="descricao_editarCategoria">Descrição</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="descricao" id="descricao_editarCategoria" class="form-control">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="clearfix">
									<div class="dd">
										<ol class="dd-list">
									<?php
										foreach ($rotas as $k=>$nome) {
									?>
											<li class="dd-item" data-id="dd-<?=$k;?>">
												<div class="dd-handle">
													<input type="checkbox" name="rotas[]" id="editarCategoria_rota-<?=$nome;?>" value="<?=$nome;?>" class="filled-in chk-col-light-blue"/>
													<label for="editarCategoria_rota-<?=$nome;?>"><?=$nome;?></label>
												</div>
											</li>
									<?php
										}
									?>
										</ol>
									</div>
								</div>
								
							</div>
						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
							<button type="button" id="closeEditarCategoriaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
						</div>
							</form>
					</div>
				</div>
			</div>
	    <!--#END of MODAL EDITAR RAMAL-->


	    <!--MODAL EXCLUIR CATEGORIA-->
            <div class="modal fade" id="excluirCategoriaModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirCategoriaLabel">Excluir Categoria</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirCategoria" method="post">
				<?=$text_form;?>
				<input type="hidden" name="tipo" value="categoria" />
				<input type="hidden" name="cmd" value="excluirCategoria" />
				<input type="hidden" id="excluirCategoria" name="categoria" value="" />
			    <p>Tem certeza que deseja excluir a Categoria?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
							<button type="button" id="closeExcluirCategoriaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR CATEGORIA-->



	<!--#END - MODAL ============================================================================================================================== -->

<script>

function botaoExcluirCategoria(excluirCategoria) {
	$('#excluirCategoria').val(excluirCategoria);

	$('#excluirCategoriaLabel').text("Excluir Categoria "+excluirCategoria);
	$("#excluirCategoriaModal").modal();
};


$(document).ready(function(){

	var categorias = <?php echo json_encode($categorias, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
	var rotas = <?php echo json_encode($rotas, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
	/*
	"8":{"descricao":"INTERNO","includes":["interno","abreviados","facilidades","telefonista"]}
	*/

	$(".editar-categoria").on('click', function(event) {
		event.preventDefault();

		var categoria = $(this).data('id');

		document.getElementById('editarCategoriaLabel').innerHTML = "Editar Categoria: "+categoria;

		$('#editarCategoria').val(categoria);
		
		$('#nome_editarCategoria').val(categoria);
		$('#descricao_editarCategoria').val(categorias[categoria].descricao);

		for (var z in rotas) {
			$('#editarCategoria_rota-'+rotas[z]).prop('checked',false);
		}
		
		for (var i in categorias[categoria].includes) {
			$('#editarCategoria_rota-'+categorias[categoria].includes[i]).prop('checked',true);
		}
	});
	
	$(function () {
		$('#nestable-contextos').nestable({
			maxDepth: 1
		})
	});
	
	$('#editarCategoriaModal').on('show.bs.modal', function (e) {
		$('.dd').nestable({
		    maxDepth: 0,
            noDragClass:'dd-nodrag',
		    handleClass:'123'
		});
	});
	
	$('#novaCategoriaModal').on('show.bs.modal', function (e) {
		$('.dd').nestable({
		    maxDepth: 0,
            noDragClass:'dd-nodrag',
		    handleClass:'123'
		});
	});

});

</script>