<?php
	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.db.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.blacklist.php");

	//CMD ======================================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "novoNumero") {
		//print_r($_POST);
		//die();
		$erro = "";
		if (!isset($_POST['numero']) || @$_POST['numero'] == "") {
			$erro = "Erro: Número inválido!";
		} elseif ( !is_numeric($_POST['numero']) ) {
			$erro = "Erro: Número inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !novo_numero($_POST['numero'], $_POST['entrada'], $_POST['saida']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "excluirNumero") {
		
		$erro="";
		if (!isset($_POST['numero']) || @$_POST['numero'] == "") {
			$erro = "Erro: Número inválido!";
		} elseif ( !is_numeric($_POST['numero']) ) {
			$erro = "Erro: Número inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !excluir_numero($_POST['numero']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "upload") {
		
		$erro="";
		if(!isset($_FILES['arquivo']['name'])){
			$erro = "Erro: Diretório Inválido!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !upload_lista($_FILES['arquivo'],$_POST['entrada'],$_POST['saida']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	if (isset($_POST['cmd']) && $_POST['cmd'] == "numerosSelecionados") {
		
		$erro="";
		if (!isset($_POST['numeros']) || @$_POST['numeros'] == "") {
			$erro = "Erro: Número inválido!";
		} 
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
		
		if ( !excluir_selecionados($_POST['numeros']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.getElementById('form_{$pagina}_{$menu}').submit();
			</script>";
			die();
		}
	}
	
	//DECLARAÇÃO DE VARIAVEIS ==================================================
	
	$blacklist = get_blacklist();
	
?>

	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- MENU BLACKLIST -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
						<div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
                                	<li>NUCLEAR PABX IP</li>
									<li><?=$pagina_nome;?></li>
                                	<li class="active"><?=$menu_nome;?></li>
								</ol>
							</div>
						</div>
                        <div class="body">
							
							<button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#novoBlacklistModal">
								<i class="material-icons">add_circle</i>
								<span>ADD NÚMERO</span>
							</button>
							<hr>
							<!--Formulário-->
							<form method="post" name="upload_lista" enctype="multipart/form-data">
								<?=$text_form;?>
								<input type="hidden" name="cmd" value="upload" />
								<div class="row clearfix">
									<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
										<label>Importar lista</label>
									</div>
									<div class="col-sm-6 col-md-6">
										<div class="form-group form-float" style="margin-bottom:0px">
											<div class="form-line">
												<input name="arquivo" type="file" class="form-control" />
											</div>
										</div>
									</div>
									<input type="hidden" name="entrada" value="no" />
									<div class="col-md-3 col-sm-6 col-xs-12 form-control-label" style="margin-bottom: 0px; width: auto; box-shadow: none;">
										<input type="checkbox" name="entrada" id="entrada_lista" value="yes" class="filled-in chk-col-light-blue" checked/>
										<label for="entrada_lista">Bloquear Entrada</label>
									</div>
									<input type="hidden" name="saida" value="no" />
									<div class="col-md-3 col-sm-6 col-xs-12 form-control-label" style="margin-bottom: 0px; width: auto; box-shadow: none;">
										<input type="checkbox" name="saida" id="saida_lista" value="yes" class="filled-in chk-col-light-blue"/>
										<label for="saida_lista">Bloquear Saída</label>
									</div>
									<div class="col-sm-12 col-md-12 col-lg-12">
										<Button id="btnSubmit" onclick="document.upload_lista.submit()" class="btn btn-primary waves-effect">
											<i class="material-icons">publish</i>
											<span>ENVIAR LISTA</span>
										</Button>
									</div>
								</div>
							</form>
							<!--FIM FORMULÁRIO-->
							<hr>
							<!--FORM TABELA-->
							<form id="formNovaCategoria" method="post">
								<?=$text_form;?>
								<input type="hidden" name="cmd" value="numerosSelecionados" />
								<div class="table-responsive">
									<table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination4">
										<thead>
											<tr>
												<th>
													<input type="checkbox" name="marcarTodos" onclick="marcarTodosNumeros()" id="marcarTodos" class="filled-in chk-col-light-blue"/>
													<label for="marcarTodos">Sel. Todos</label>
												</th>
												<th>Número</th>
												<th>Entrada</th>
												<th>Saída</th>
												<th>Opções</th>
											</tr>
										</thead>
										<tbody>
											<?php
											foreach($blacklist as $key=>$vetor) {
												if (is_array($vetor)) {
													$entrada = ($vetor['entrada'] == true? "yes" : "no");
													$saida = ($vetor['saida'] == true? "yes" : "no");
											?>
												<tr>
													<td>
														<input type="checkbox" name="numeros[]" id="<?=$vetor['numero'];?>" value="<?=$vetor['numero'];?>" class="filled-in chk-col-light-blue"/>
														<label for="<?=$vetor['numero'];?>"></label>
													</td>
													<td><?=$vetor['numero'];?></td>
													<td><?=$entrada;?></td>
													<td><?=$saida;?></td>
													<td>
														<a href="javascript:;" class="editar-blacklist" data-id="<?=$vetor['numero'];?>" data-toggle="modal" data-target="#editarBlacklistModal"><i class="material-icons" title="Editar">edit</i></a>&nbsp;
														<a href="javascript:;" class="play" onclick="botaoExcluirBlacklist('<?=$vetor['numero'];?>')"><i class="material-icons" title="Excluir">delete</i></a>
													</td>
												</tr>
											<?php
												}
											}
											?>
										</tbody>
									</table>
								</div>
								<button type="submit" class="btn btn-danger waves-effect">
									<i class="material-icons">delete</i>
									<span>Excluir Selecionados</span>
								</button>
							</form>
							<!--FIM FORM TABELA-->
						</div>
					</div>
				</div>
			</div>
		</div>
	<!--END - PAGE CONTENT-->


	<!-- MODAL ================================================================================================================================== -->
	
		<!--MODAL NOVO NÚMERO-->
            <div class="modal fade" id="novoBlacklistModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="modal-title" id="novaCategoriaLabel">Add Número</h2>
							<small>O número de telefone deve conter o ddd+número (sem 0 e sem espaços)</small>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
							<form id="formNovaCategoria" method="post">
							<?=$text_form;?>
							<input type="hidden" name="cmd" value="novoNumero" />

								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="numero_novoNumero">Número</label>
                                    </div>
                                    <div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="numero" id="numero_novoNumero" class="form-control numero">
                                            </div>
                                        </div>
                                    </div>
								</div>
								<div class="row clearfix">
									<input type="hidden" name="entrada" value="no" />
									<div class="col-md-6 col-sm-6 col-xs-12 form-control-label" style="margin-bottom: 0px; width: auto; box-shadow: none;">
										<input type="checkbox" name="entrada" id="entrada_novoNumero" value="yes" class="filled-in chk-col-light-blue" checked/>
										<label for="entrada_novoNumero">Bloquear Entrada</label>
									</div>
									<input type="hidden" name="saida" value="no" />
									<div class="col-md-6 col-sm-6 col-xs-12 form-control-label" style="margin-bottom: 0px; width: auto; box-shadow: none;">
										<input type="checkbox" name="saida" id="saida_novoNumero" value="yes" class="filled-in chk-col-light-blue"/>
										<label for="saida_novoNumero">Bloquear Saída</label>
									</div>
								</div>
								
							</div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
                            <button type="button" id="closenovaCategoriaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
							</form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL NOVO NUMERO-->
		
		<!--MODAL EDITAR NÚMERO-->
            <div class="modal fade" id="editarBlacklistModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="modal-title" id="editarBlacklistLabel">Editar Número</h2>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
							<form id="formNovaCategoria" method="post">
							<?=$text_form;?>
							<input type="hidden" name="numero" id="editarNumero" /> 
							<input type="hidden" name="cmd" value="novoNumero" />
							
								<div class="row clearfix">
									<input type="hidden" name="entrada" value="no" />
									<div class="col-md-6 col-sm-6 col-xs-12 form-control-label" style="margin-bottom: 0px; width: auto; box-shadow: none;">
										<input type="checkbox" name="entrada" id="entrada_editarNumero" value="yes" class="filled-in chk-col-light-blue"/>
										<label for="entrada_editarNumero">Bloquear Entrada</label>
									</div>
									<input type="hidden" name="saida" value="no" />
									<div class="col-md-6 col-sm-6 col-xs-12 form-control-label" style="margin-bottom: 0px; width: auto; box-shadow: none;">
										<input type="checkbox" name="saida" id="saida_editarNumero" value="yes" class="filled-in chk-col-light-blue"/>
										<label for="saida_editarNumero">Bloquear Saída</label>
									</div>
								</div>
								
							</div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
                            <button type="button" id="closeeditarBlacklistModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
							</form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EDITAR NUMERO-->
		
		<!--MODAL EXCLUIR NUMERO-->
            <div class="modal fade" id="excluirBlacklistModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirBlacklistLabel">Excluir Número</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirAudio" method="post">
				<?=$text_form;?>
				<input type="hidden" name="cmd" value="excluirNumero" />
				<input type="hidden" id="excluirNumero" name="numero" value="" />
			    <p>Tem certeza que deseja excluir o número da blacklist?</p>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-danger waves-effect">
								<i class="material-icons">delete</i>
								<span>Sim</span>
							</button>
							<button type="button" id="closeExcluirBlacklistModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR NUMERO-->

	<!--#END - MODAL ============================================================================================================================== -->
	
<script>

function botaoExcluirBlacklist(excluirNumero) {
	$('#excluirNumero').val(excluirNumero);
	
	$('#excluirBlacklistLabel').text("Excluir número: "+excluirNumero);
	$('#excluirBlacklistModal').modal();
};

function marcarTodosNumeros() {
	if ( $('#marcarTodos').is(":checked") == true) {
		$("input[name='numeros[]']").each(function(){
			//alert($(this).val());
			document.getElementById($(this).attr("id")).checked = true;
			//$(this).checked = true;
		});
	} else {
		$("input[name='numeros[]']").each(function(){
			document.getElementById($(this).attr("id")).checked = false;
			//$(this).checked = false;
		});
	}
};

$(document).ready(function(){

	var blacklist = <?php echo json_encode($blacklist, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>
	/*
	{"500":{
		"grava":"no","categoria":"1",
		"abreviados":{
			"1":{"destino":"02117991299005","tronco":"SIP/1000)","portabilidade":"0","operadora":""},
			"2":{"destino":"02117991299005","tronco":"SIP/1050)","portabilidade":"0","operadora":""}
			}
		},
	"3955":{"grava":"no","categoria":"1","abreviados":{"1":{"destino":"3955","tronco":"IAX2/realtimeDEV)","portabilidade":"0","operadora":""}}}}
	*/

	$(".editar-blacklist").on('click', function(event) {
		event.preventDefault();

		var numero = $(this).data('id');

		document.getElementById('editarBlacklistLabel').innerHTML = "Editar Número: "+numero;

		$('#editarNumero').val(numero);
		
		if (blacklist[numero].entrada == 1) {
			$('#entrada_editarNumero').prop('checked',true);
		} else {
			$('#entrada_editarNumero').prop('checked',false);
		}
		if (blacklist[numero].saida == 1) {
			$('#saida_editarNumero').prop('checked',true);
		} else {
			$('#saida_editarNumero').prop('checked',false);
		}

	});

});

</script>