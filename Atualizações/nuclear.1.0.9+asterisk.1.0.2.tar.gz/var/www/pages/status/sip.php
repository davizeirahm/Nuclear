<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.status.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.config.ramal.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_sip.php");
	require_once(DIR_WWW."funcoes/funcoes.network.debian7.php");
	
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.filas.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.redir.php");
	//require_once(DIR_WWW."funcoes/funcoes.pbxconfig.telefonista.php");

	// DECLARAÇÃO DE VARIÁVEIS ==============================================================================================

	$ramaissip = get_ramais();
	//print_r($ramaissip);
	//echo json_encode($ramaissip, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
	
	$redirs = get_redirs();
	$filas = get_filas();
	//$telefonista = get_op();
	
	$gruposCaptura = get_ini_array("grupos-captura", ARQ_CONFIG_RAMAL);
	//Array ( [1] => vendas [2] => comercial [3] => suporte [4] => desenvolvimento )
	
	$colors = array('bg-red','bg-pink','bg-purple','bg-deep-purple','bg-indigo','bg-blue','bg-teal','bg-green','bg-light-green','bg-amber','bg-orange','bg-deep-orange','bg-brown');

?>

	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- MENU STATUS SIP -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
						<div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
                                	<li>NUCLEAR PABX IP</li>
									<li>Status</li>
                                	<li class="active">SIP</li>
								</ol>
							</div>
						</div>
                        <div class="body">
						
							<div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination2">
                                    <thead>
                                        <tr>
											<th>Ramal</th>
											<th>Dado</th>
											<th>Valores</th>
										</tr>
									</thead>
									<tbody>
									<?php
									$lastRamal = "";
									$lastColor = "";
									$color = "";
									foreach($ramaissip as $ramal=>$vetor) {
										
										if ($ramal != $lastRamal) {
											$lastColor = $color;
											do {
												$color = $colors[rand(0,12)];
											} while ($lastColor == $color);
										}
										$lastRamal = $ramal;
										
										if (is_array($vetor)) {
											$statusRamal = infoRamalSIP($ramal);
											if ($statusRamal['Addr->IP'] != "-") {
									?>
											<tr>
												<td><span class="badge <?=$color;?>"><?=$ramal;?></span></td>
												<td>Dispositivo</td>
												<td><?=$statusRamal['Useragent'];?></td>
											</tr>
											<tr>
												<td><span class="badge <?=$color;?>"><?=$ramal;?></span></td>
												<td>IP</td>
												<td><?=$statusRamal['Addr->IP'];?></td>
											</tr>
											<tr>
												<td><span class="badge <?=$color;?>"><?=$ramal;?></span></td>
												<td>Status</td>
												<td><?=$statusRamal['Status'];?></td>
											</tr>
									<?php
											} else {
									?>
											<tr>
												<td><span class="badge <?=$color;?>"><?=$ramal;?></span></td>
												<td>Status</td>
												<td>Offline</td>
											</tr>
									<?php
											}
									?>
											<tr>
												<td><span class="badge <?=$color;?>"><?=$ramal;?></span></td>
												<td>Contexto</td>
												<td><?=$statusRamal['Context'];?></td>
											</tr>
											<tr>
												<td><span class="badge <?=$color;?>"><?=$ramal;?></span></td>
												<td>Grupos de captura</td>
												<td><?=$statusRamal['Nam. Pickupgr'];?></td>
											</tr>
											<tr>
												<td><span class="badge <?=$color;?>"><?=$ramal;?></span></td>
												<td>Grupos de chamada</td>
												<td><?=$statusRamal['Named Callgr'];?></td>
											</tr>
											<tr>
												<td><span class="badge <?=$color;?>"><?=$ramal;?></span></td>
												<td>Codecs</td>
												<td><?=$statusRamal['Codecs'];?></td>
											</tr>
									<?php
											$membrofila = array();
											foreach ($filas as $fila=>$value) {
												foreach ($value['member'] as $k=>$member) {
													if ($member == "SIP/".$ramal) {
														$membrofila[] = $fila;
													}
												}
											}
											if (count($membrofila) > 0) {
												$membrofilastxt = implode(", ",$membrofila);
									?>
											<tr>
												<td><span class="badge <?=$color;?>"><?=$ramal;?></span></td>
												<td>Filas</td>
												<td><?=$membrofilastxt;?></td>
											</tr>
									<?php
											}
											foreach ($redirs as $redir=>$value) {
												if ($redir == $ramal) {
									?>
											<tr>
												<td><span class="badge <?=$color;?>"><?=$ramal;?></span></td>
												<td>Redir</td>
												<td><?=$value['destino'];?></td>
											</tr>
									<?php
												}
											}
										}
									}
									?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- #END# MENU STATUS SIP -->
            </div>
		</div>
	<!--END - PAGE CONTENT-->


	<!-- MODAL ================================================================================================================================== -->

	    <!--MODAL NOVO GRUPO DE CAPTURA-->
            <div class="modal fade" id="novoGrupoModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="novoGrupoLabel">Novo Grupo de Captura</h4>
                        </div>
                        <div class="modal-body">
							<div class="demo-masked-input">
							<form id="formNovoGrupo" method="post">
							<?=$text_form;?>
							<input type="hidden" name="tipo" value="grupos" />
							<input type="hidden" name="cmd" value="novoGrupo" />

								<div class="row clearfix">
                                    <div class="col-sm-3 col-xs-5 form-control-label">
                                        <label for="novoGrupo_nome">Nome</label>
                                    </div>
                                    <div class="col-sm-9 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="nome" id="novoGrupo_nome" class="form-control">
                                            </div>
                                        </div>
                                    </div>
								</div>

							</div>
                        </div>
                        <div class="modal-footer">
							<button type="submit" class="btn btn-primary waves-effect">
								<i class="material-icons">save</i>
								<span>Salvar</span>
							</button>
                            <button type="button" id="closeNovoGrupoModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
							</form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL NOVO GRUPO DE CAPTURA-->

	    <!--MODAL EDITAR GRUPO DE CAPTURA-->
            <div class="modal fade" id="editarGrupoModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="editarGrupoLabel">Editar Grupo de Captura</h4>
                        </div>
                        <div class="modal-body">
			    <div class="demo-masked-input">
			    <form id="formEditarGrupo" method="post">
				<?=$text_form;?>
				<input type="hidden" name="tipo" value="grupos" />
				<input type="hidden" name="cmd" value="editarGrupo" />
				<input type="hidden" id="id_editarGrupo" name="id" value="" />

				<div class="row clearfix">
                                    <div class="col-sm-3 col-xs-5 form-control-label">
                                        <label for="editarGrupo_nome">Nome</label>
                                    </div>
                                    <div class="col-sm-9 col-xs-7">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="nome" id="nome_editarGrupo" class="form-control">
                                            </div>
                                        </div>
                                    </div>
				</div>

			    </div>
                        </div>
                        <div class="modal-footer">
			    <button type="submit" class="btn btn-primary waves-effect">
				<i class="material-icons">save</i>
				<span>Salvar</span>
			    </button>
                            <button type="button" id="closeEditarGrupoModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EDITAR GRUPO DE CAPTURA-->

	    <!--MODAL EXCLUIR GRUPO DE CAPTURA-->
            <div class="modal fade" id="excluirGrupoModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="excluirGrupoLabel">Excluir Rota</h4>
                        </div>
                        <div class="modal-body">
			    <form id="formExcluirGrupo" method="post">
				<?=$text_form;?>
				<input type="hidden" name="tipo" value="grupos" />
				<input type="hidden" name="cmd" value="excluirGrupo" />
				<input type="hidden" id="id_excluirGrupo" name="id" value="" />
				<input type="hidden" id="nome_excluirGrupo" name="nome" value="" />
			    <p>Tem certeza que deseja excluir o Grupo de Captura?</p>
			    <small>Todas as configurações do grupo serão desfeitas</small>
                        </div>
                        <div class="modal-footer">
			    <button type="submit" class="btn btn-danger waves-effect">
				<i class="material-icons">delete</i>
				<span>Sim</span>
			    </button>
                            <button type="button" id="closeExcluirGrupoModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
                        </div>
			    </form>
                    </div>
                </div>
            </div>
	    <!--#END of MODAL EXCLUIR GRUPO DE CAPTURA-->

	<!--#END - MODAL ============================================================================================================================== -->

<script>

$(document).ready(function(){

	var ramais = <?php echo json_encode($ramaissip, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
	/*
	"3954":{
		"type":"friend",
		"secret":"102030",
		"qualify":"1",
		"port":"5060",
		"nat":"force_rport,comedia",
		"mailbox":"3954@device",
		"host":"dynamic",
		"dtmfmode":"rfc2833",
		"disallow":"all",
		"dial":"SIP/3954",
		"context":"1",
		"canreinvite":"1",
		"limit":"",
		"accountcode":"",
		"cc_agent_policy":"generic",
		"cc_monitor_policy":"generic",
		"pickupgroup":["vendas"],
		"callgroup":["vendas"],
		"codec":["alaw"," ulaw"," gsm"],
		"calleridname":"Kenko ",
		"proibeAddress":"",
		"proibeMask":"",
		"permiteAddress":"",
		"permiteMask":"",
		"abreviado":"1",
		"tipoRamal":"no",
		"gravaIn":"yes",
		"gravaOut":"yes",
		"gravaInterno":"yes"
	}
	*/
});

//FUNÇÕES GRUPOS
	function botaoEditarGrupo(editarGrupo_id, editarGrupo_nome) {
		$('#id_editarGrupo').val(editarGrupo_id);
		$('#nome_editarGrupo').val(editarGrupo_nome);

		$("#editarGrupoModal").modal();
	};

	function botaoExcluirGrupo(excluirGrupo_id, excluirGrupo_nome) {
		$('#id_excluirGrupo').val(excluirGrupo_id);
		$('#nome_excluirGrupo').val(excluirGrupo_nome);

		$('#excluirGrupoLabel').text("Excluir Grupo "+excluirGrupo_nome);
		$("#excluirGrupoModal").modal();
	};

</script>