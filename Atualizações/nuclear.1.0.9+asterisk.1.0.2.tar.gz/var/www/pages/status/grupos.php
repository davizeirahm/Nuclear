<?php

	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.status.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.config.ramal.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_sip.php");
	require_once(DIR_WWW."funcoes/funcoes.network.debian7.php");

	if ( isset($_GET['tipo']) && $_GET['tipo'] == "callgroup") {
		$tipo = "callgroup";
	} elseif ( isset($_GET['tipo']) && $_GET['tipo'] == "pickupgroup") {
		$tipo = "pickupgroup";
	} else {
		$tipo = "grupos";
	}

	// DECLARAÇÃO DE VARIÁVEIS ==============================================================================================

	$ramaissip = get_ramais();
	//print_r($ramaissip);
	//echo json_encode($ramaissip, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
	
	$gruposCaptura = get_ini_array("grupos-captura", ARQ_CONFIG_RAMAL);
	//Array ( [1] => vendas [2] => comercial [3] => suporte [4] => desenvolvimento )
	$codecs = get_ini_array("codecs", ARQ_CONFIG_RAMAL);
	//Array ( [1] => alaw [2] => ulaw [3] => g729 [4] => gsm )

?>


	<!--PAGE CONTENT-->
        <div class="container-fluid">
            <div class="row clearfix">
                <!-- MENU GRUPOS DE CAPTURA -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
						<div class="row clearfix">
							<div class="col-xs-12 col-sm-6">
								<ol class="breadcrumb">
                                	<li>NUCLEAR PABX IP</li>
									<li>Status</li>
                                	<li class="active">Grupos</li>
								</ol>
							</div>
						</div>
                        <div class="body">
                            <ul class="nav nav-tabs tab-nav-right" role="tablist">
                                <li role="presentation" <?php echo ( $tipo == "grupos" ? "class=\"active\"" : "" ); ?> ><a href="#grupos" data-toggle="tab">GRUPOS</a></li>
                                <li role="presentation" <?php echo ( $tipo == "pickupgroup" ? "class=\"active\"" : "" ); ?> ><a href="#pickupgroup" data-toggle="tab">PICKUPGROUP</a></li>
								<li role="presentation" <?php echo ( $tipo == "callgroup" ? "class=\"active\"" : "" ); ?> ><a href="#callgroup" data-toggle="tab">CALLGROUP</a></li>
							</ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
				<!-- RAMAIS SIP #####################################################################################################################-->
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "grupos" ? "in active" : "" ); ?>" id="grupos">

							<div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination2">
                                    <thead>
                                        <tr>
                                            <th>Número</th>
											<th>Tipo</th>
											<th>Pickupgroup</th>
                                            <th>Callgroup</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<?php
									foreach($ramaissip as $ramal=>$vetor) {
										if (is_array($vetor)) {
											$statusRamal = infoRamalSIP($ramal);
											if ($vetor['tipoRamal'] == "yes") {
												$tipo = "Call Center";
											} else {
												$tipo = "Pabx";
											}
											$pickupgroup = implode(", ",$vetor['pickupgroup']);
											$callgroup = implode(", ",$vetor['pickupgroup']);
									?>
										<tr>
											<td><?=$ramal;?></td>
											<td><?=$tipo;?></td>
											<td><?=$pickupgroup;?></td>
											<td><?=$callgroup;?></td> 
										</tr>
									<?php
										}
									}
									?>
                                    </tbody>
                                </table>
                            </div>

								</div>
				<!--#FIM - RAMAIS SIP ##############################################################################################################-->
				<!-- CRIAR RAMAL ###################################################################################################################-->
								<div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "pickupgroup" ? "in active" : "" ); ?>" id="pickupgroup">

							<div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination2">
                                    <thead>
                                        <tr>
											<th>Grupo</th>
											<th>Ramais</th>
										</tr>
									</thead>
									<tbody>
									<?php
									foreach ($gruposCaptura as $id=>$grupo){
										foreach ($ramaissip as $ramal=>$vetor) {
											foreach ($vetor['pickupgroup'] as $grp) {
												if ($grupo == $grp) {
									?>
										<tr>
											<td><?=$grupo;?></td>
											<td><?=$ramal;?></td>
										</tr>
									<?php
												}
											}
										}
									}
									?>
                                    </tbody>
                                </table>
                            </div>

								</div>
				<!--#FIM - CRIAR RAMAL ##############################################################################################################-->
				<!-- GRUPOS DE CAPTURA ##############################################################################################################-->
                                <div role="tabpanel" class="tab-pane fade <?php echo ( $tipo == "callgroup" ? "in active" : "" ); ?>" id="callgroup">

							<div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination2">
                                    <thead>
                                        <tr>
											<th>Grupo</th>
											<th>Ramais</th>
										</tr>
									</thead>
									<tbody>
									<?php
									foreach ($gruposCaptura as $id=>$grupo){
										foreach ($ramaissip as $ramal=>$vetor) {
											foreach ($vetor['callgroup'] as $grp) {
												if ($grupo == $grp) {
									?>
										<tr>
											<td><?=$grupo;?></td>
											<td><?=$ramal;?></td>
										</tr>
									<?php
												}
											}
										}
									}
									?>
                                    </tbody>
                                </table>
                            </div>

                                </div>
				<!--#FIM - GRUPOS DE CAPTURA ########################################################################################################-->
                            </div>


                        </div>
                    </div>
                </div>
                <!-- #END# MENU RAMAIS SIP -->
            </div>
	</div>
	<!--END - PAGE CONTENT-->