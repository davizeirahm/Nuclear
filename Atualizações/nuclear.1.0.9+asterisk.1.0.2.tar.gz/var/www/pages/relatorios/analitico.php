<?php
	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.config.ramal.php");
	require_once(DIR_WWW."funcoes/funcoes.db.php");
	require_once(DIR_WWW."funcoes/funcoes.relatorios.analitico.php");
	
	require_once(DIR_WWW."funcoes/funcoes.ramais.config_e1.php"); //PARA OBTER TRONCOS G1, G2, etc.
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.rotas_saida.php"); //TRONCOS
	
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_sip.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_iax2.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.filas.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.contabil.php");

	//DATA E HORA =====================================================================================================
	if (isset($_REQUEST['data_inicial']) && $_REQUEST['data_inicial'] != "") {
		$data_inicial = $_REQUEST['data_inicial'];
	} else {
		$data_inicial = date("d/m/Y");
	}
	
	if (isset($_REQUEST['data_final']) && $_REQUEST['data_final'] != "") {
		$data_final = $_REQUEST['data_final'];
	} else {
		$data_final = date("d/m/Y");
	}

	if (isset($_REQUEST['hora_inicial']) && $_REQUEST['hora_inicial'] != "") {
		$hora_inicial = $_REQUEST['hora_inicial'];
	} else {
		$hora_inicial = "00:00";
	}
	
	if (isset($_REQUEST['hora_final']) && $_REQUEST['hora_final'] != "") {
		$hora_final = $_REQUEST['hora_final'];
	} else {
		$hora_final = "23:59";
	}

	if (isset($_REQUEST['input_Data']) && $_REQUEST['input_Data'] == "periodo") {
		$atalho = $_REQUEST['inputPeriodo'];
		switch ($_REQUEST['inputPeriodo']) {
			case "hoje" :
				$data_inicial = date("d/m/Y");
				$data_final = date("d/m/Y");
			break;
			
			case "ontem" :
				$timestamp = strtotime("-1 days");
				$data_inicial = date("d/m/Y", $timestamp);
				$data_final = date("d/m/Y", $timestamp);
			break;
			
			case "semana" :
				$timestamp = strtotime(sprintf("-%s days", date('w')));
				$data_inicial = date("d/m/Y", $timestamp);
				$data_final = date("d/m/Y");
			break;
			
			case "mes" :
				$data_inicial = "01/".date("m/Y");
				$data_final = date("d/m/Y");
			break;
			
			case "trimestre" :
				$timestamp = strtotime("-3 months");
				$data_inicial = date("d/m/Y", $timestamp);
				$data_final = date("d/m/Y");
			break;

			case "semestre" :
				$timestamp = strtotime("-6 months");
				$data_inicial = date("d/m/Y", $timestamp);
				$data_final = date("d/m/Y");
			break;

			case "ano" :
				$timestamp = strtotime("-12 months");
				$data_inicial = date("d/m/Y", $timestamp);
				$data_final = date("d/m/Y");
			break;
		}
	} else {
		$atalho = "";
	}
	
	$tmp1 = explode("/",$data_inicial);
	$data_inicial_mysql = $tmp1[2]."-".$tmp1[1]."-".$tmp1[0]." ".$hora_inicial.":00";
	$data_inicial_1 = $tmp1[2]."-".$tmp1[1]."-".$tmp1[0];
	$tmp1 = explode("/",$data_final);
	$data_final_mysql = $tmp1[2]."-".$tmp1[1]."-".$tmp1[0]." ".$hora_final.":59";
	$data_final_1 = $tmp1[2]."-".$tmp1[1]."-".$tmp1[0];

	if (isset($_REQUEST['input_Data']) && $_REQUEST['input_Data'] == "data") {
		$radio_Data = "checked";
		$radio_Periodo = "";
	} else {
		$radio_Data = "";
		$radio_Periodo = "checked";
	}
	
	$txtwhere = "";
	$sql = new conexao();
	//TRONCOS =============================================================================================================
	$troncos = get_troncos();
	
	if (isset($_REQUEST['troncos'])) {
		$filtrotroncos = $_REQUEST['troncos'];
	} else {
		$filtrotroncos = array();
		$filtrotroncos[] = "";
	}
	
	if (strlen($filtrotroncos[0]) > 1) {
		$txtwhere .= " and (";
		foreach ($filtrotroncos as $k=>$value) {
			if ($k != 0) {
				$txtwhere .= " or ";
			}
			$txtwhere .= "tronco = '".$value."'";
		}
		$txtwhere .= ")";
	}
	
	//$cidades = get_cidades();
	//$codigos_ddd = get_cod_area();
	
	//RAMAIS ==============================================================================================================
	$ramais_sip = get_ramais();
	$ramais_iax2 = get_ramais_iax();
	
	if (isset($_REQUEST['ramais'])) {
		$filtroramais = $_REQUEST['ramais'];
	} else {
		$filtroramais = array();
		$filtroramais[] = "";
	}
	
	if (strlen($filtroramais[0]) > 1) {
		$txtwhere .= " and (";
		foreach ($filtroramais as $k=>$value) {
			if ($k != 0) {
				$txtwhere .= " or ";
			}
			$txtwhere .= "origem = '".$value."' or destino = '".$value."'";
		}
		$txtwhere .= ")";
	}

	//FILAS ===============================================================================================================
	
	$filas = get_filas();

	if (isset($_REQUEST['filas'])) {
		$filtrofilas = $_REQUEST['filas'];
	} else {
		$filtrofilas = array();
		$filtrofilas[] = "";
	}
	
	if (strlen($filtrofilas[0]) > 1) {
		$lista_filas = "'".implode("', '", $filtrofilas)."'";
		$txtwhere .= " and queue in (".$lista_filas.")";
	}
	
	//CONTABIL ===========================================================================================================
	$codigos = get_codigos();
	
	if (isset($_REQUEST['codigos'])) {
		$filtrocodigos = $_REQUEST['codigos'];
	} else {
		$filtrocodigos = array();
		$filtrocodigos[] = "";
	}
	
	if (strlen($filtrocodigos[0]) > 1) {
		$txtwhere .= " and (";
		foreach ($filtrocodigos as $k=>$value) {
			if ($k != 0) {
				$txtwhere .= " or ";
			}
			$txtwhere .= "origem = '".$value."'";
		}
		$txtwhere .= ")";
	}

	//TIPO ============================================================================================================

	$vtipo = array("IN", "OUT", "INTERNO");

	if (isset($_REQUEST['tipo'])) {
		$filtrotipo = $_REQUEST['tipo'];
	} else {
		$filtrotipo = array();
		$filtrotipo[] = "";
	}

	$tipo_disponivel = "";
	foreach($vtipo as $valor) {
		if (in_array ( $valor,$filtrotipo)) {
			$tipo_disponivel .= "<option value=\"".$valor."\" selected=\"selected\">".$valor."</option>".PHP_EOL; 
		} else {
			$tipo_disponivel .= "<option value=\"".$valor."\">".$valor."</option>".PHP_EOL;
		}
	}
	
	if (strlen($filtrotipo[0]) > 1) {
		$lista_tipo = "'".implode("', '", $filtrotipo)."'";
		$txtwhere .= " and tipo in (".$lista_tipo.")";
	}

	//STATUS =============================================================================================================

	$vstatus = array(
		'Atendido' => 'ANSWER', 
		'Ocupado' => 'BUSY', 
		'Não atendido' => 'NOANSWER', 
		'Congestionado' => 'CONGESTION', 
		'Cancelada' => 'CANCEL', 
		'Indisponível' => 'CHANUNAVAIL',
		'Falhou' => 'FAILED'
	);

	if (isset($_REQUEST['status'])) {
		$filtrostatus = $_REQUEST['status'];
	} else {
		$filtrostatus = array();
		$filtrostatus[] = "";
	}

	$status_disponivel = "";
	foreach($vstatus as $key=>$valor) {
		if ( in_array($valor, $filtrostatus) ) {
			$status_disponivel .= "<option value=\"".$valor."\" selected=\"selected\">".$key."</option>".PHP_EOL; 
		} else {
			$status_disponivel .= "<option value=\"".$valor."\">".$key."</option>".PHP_EOL;
		}
	}
	
	if (strlen($filtrostatus[0]) > 1) {
		$lista_status = "'".implode("', '", $filtrostatus)."'";
		$txtwhere .= " and status in (".$lista_status.")";
	}

	//CAMPOS NÚMERO, DDR, TRF E PROTOCOLO ================================================================================

	if (isset($_REQUEST['numero']) and $_REQUEST['numero'] != "") {
		$numero = mysqli_real_escape_string($sql->conexao, $_REQUEST['numero']);
		if ($_REQUEST['condicaonumero'] == "igual") {
			$txtwhere .= ' and (origem = "'.$numero.'" or destino = "'.$numero.'") ';
		} elseif ($_REQUEST['condicaonumero'] == "contem") {
			$txtwhere .= ' and (origem LIKE "%'.$numero.'%" or destino LIKE "%'.$numero.'%") ';
		}
	}

	if (isset($_REQUEST['ddr']) And $_REQUEST['ddr'] != "") {
		$ddr = mysqli_real_escape_string($sql->conexao, $_REQUEST['ddr']);
		$txtwhere .= ' and ddr LIKE "%'.$ddr.'%" ';
	}

	if (isset($_REQUEST['trf']) and $_REQUEST['trf'] != "") {
		$trf = mysqli_real_escape_string($sql->conexao, $_REQUEST['trf']);
		$txtwhere .= ' and trf LIKE "%'.$trf.'%" ';
	}
	
	if (isset($_REQUEST['protocolo']) and $_REQUEST['protocolo'] != "") {
		$protocolo = mysqli_real_escape_string($sql->conexao, $_REQUEST['protocolo']);
		$txtwhere .= ' and linkedid LIKE "'.$protocolo.'%" ';
	}

	//CAMPOS ESPERA E DURAÇÃO ============================================================================================

	if (isset($_REQUEST['tempoespera']) and is_numeric($_REQUEST['tempoespera'])) {
		$espera = mysqli_real_escape_string($sql->conexao, $_REQUEST['tempoespera']);
		if ($_REQUEST['condicaoespera'] == "Maior") {
			$txtwhere .= ' and `holdtime` >= '.$espera.' ';
		} elseif ($_REQUEST['condicaoespera'] == "Menor") {
			$txtwhere .= ' and `holdtime` <= '.$espera.' ';
		} elseif ($_REQUEST['condicaoespera'] == "Igual") {
			$txtwhere .= ' and `holdtime` = '.$espera.' ';
		}
	}

	if (isset($_REQUEST['tempoduracao']) and is_numeric($_REQUEST['tempoduracao'])) {
		$duracao = mysqli_real_escape_string($sql->conexao, $_REQUEST['tempoduracao']);
		if ($_REQUEST['condicaoduracao'] == "Maior") {
			$txtwhere .= ' and `callduration` >= '.$duracao.' ';
		} elseif ($_REQUEST['condicaoduracao'] == "Menor") {
			$txtwhere .= ' and `callduration` <= '.$duracao.' ';
		} elseif ($_REQUEST['condicaoduracao'] == "Igual") {
			$txtwhere .= ' and `callduration` = '.$duracao.' ';
		}
	}

	//Cidade =============================================================================================================
	
	if (isset($_REQUEST['cidade']) And $_REQUEST['cidade'] != "") {
		$cidade = mysqli_real_escape_string($sql->conexao, $_REQUEST['cidade']);
		$txtwhere .= ' and cidade LIKE "%'.$cidade.'%" ';
	}

	//Funcoes e resultados ===============================================================================================
	$relatorio = relatorio($txtwhere,$data_inicial_mysql,$data_final_mysql);
	$resumo = relatorio_resumo($txtwhere,$data_inicial_mysql,$data_final_mysql);
	//print_r($relatorio);
	/*
	[0] => Array ( 
		[timestamp] => 2018-09-03 16:21:42 
		[queue] => SAIDA 
		[agent] => ERIKA (506) 
		[ddr] => 
		[callerId] => 17981422376 
		[trf] => 
		[cidade] => CELULAR AREA17 
		[status] => COMPLETEAGENT 
		[holdtime] => 00:00:30 
		[callduration] => 00:01:00 
		[audio] => FILA-OUT--20180903-1921-1536013272.4847.wav 
		[evento] => Completada )
	*/

	//print_r($resumo);
	//Array ( [total] => 770 [entrada_atendidas] => 569 [entrada_abandonadas] => 0 [saida_atendidas] => 201 [saida_abandonadas] => 0 [tempo_chamada] => 37:11:30 [tempo_espera] => 17:30:24 [tempo_total] => 54:41:54 )
	
	$colors = array('bg-red','bg-pink','bg-purple','bg-deep-purple','bg-indigo','bg-blue','bg-teal','bg-green','bg-light-green','bg-amber','bg-orange','bg-deep-orange','bg-brown');
?>

    <script src="plugins/raphael/raphael.min.js"></script>
    <script src="plugins/morrisjs/morris.js"></script>
    <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/prettify/r224/prettify.min.js"></script>-->
    <script src="plugins/prettify/prettify.min.js"></script>

    <!--PAGE CONTENT-->
	<div class="container-fluid">

		<!-- Bloco de Pesquisa -->
		<div class="row clearfix">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<div class="card">
					<div class="row clearfix">
						<div class="col-xs-12 col-sm-6">
							<ol class="breadcrumb">
								<li>NUCLEAR PABX IP</li>
								<li><?=$pagina_nome;?></li>
								<li class="active"><?=$menu_nome;?></li>
							</ol>
						</div>
					</div>
					<div class="body" style="padding-bottom: 5px;">
						<!--Formulário-->
						<form id="filtro-filas" method="post">
						<?=$text_form;?>
						<div class="row clearfix">
							<div class="col-sm-6 col-md-2">
								<input name="input_Data" type="radio" onclick="periodo_click()" id="radio_Periodo" class="radio-col-blue" value="periodo" <?=$radio_Periodo;?> />
								<label for="radio_Periodo">Por Período</label>
							</div>
							<div class="col-sm-6 col-md-2">
								<select name="inputPeriodo" id="inputPeriodo" class="form-control show-tick" class="form-control show-tick">
									<option value="hoje">Hoje</option>
									<option value="ontem">Ontem</option>
									<option value="semana">Semana</option>
									<option value="mes">Mês</option>
									<option value="trimestre">Trimestre</option>
									<option value="semestre">Semestre</option>
									<option value="ano">Ano</option>
								</select>
							</div>
							<div class="col-sm-6 col-md-4">
								<input name="input_Data" type="radio" onclick="data_click()" id="radio_Data" class="radio-col-blue" value="data" <?=$radio_Data;?> />
								<label for="radio_Data">Por Data</label>
								<div class="demo-masked-input">
									<div class="col-md-6">
										<b>Data inicial</b>
										<div class="input-group">
											<span class="input-group-addon">
												<i class="material-icons">date_range</i>
											</span>
											<div class="form-line">
												<input type="text" name="data_inicial" id="data_inicial" class="form-control date" value="<?=$data_inicial;?>" disabled="disabled">
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<b>Data Final</b>
										<div class="input-group">
											<span class="input-group-addon">
												<i class="material-icons">date_range</i>
											</span>
											<div class="form-line">
												<input type="text" name="data_final" id="data_final" class="form-control date" value="<?=$data_final;?>" disabled="disabled">
											</div>
										</div>
									</div>
								</div>
								<div class="demo-masked-input">
									<div class="col-md-6">
										<b>Hora Inicial</b>
										<div class="input-group">
											<span class="input-group-addon">
												<i class="material-icons">access_time</i>
											</span>
											<div class="form-line">
												<input type="text" name="hora_inicial" id="hora_inicial" class="form-control time24" value="<?=$hora_inicial;?>" placeholder="Ex: 00:00" disabled="disabled">
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<b>Hora Final</b>
										<div class="input-group">
											<span class="input-group-addon">
												<i class="material-icons">access_time</i>
											</span>
											<div class="form-line">
												<input type="text" name="hora_final" id="hora_final" class="form-control time24" value="<?=$hora_final;?>" placeholder="Ex: 23:59" disabled="disabled">
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-6 col-md-4">
								<!-- NUCLEAR FILAS -->
							</div>
							<div style="align-self: flex-end; margin-right: 15px">
								<button id="btnPesquisar" type="submit" class="btn bg-default waves-effect pull-right">
									<i class="material-icons">search</i>
									<span>PESQUISAR</span>
								</button>
							</div>
						</div>

						<!--OPÇÕES AVANÇADAS-->
						<div class="row clearfix">
							<div class="panel-group" id="accordion_1" role="tablist" aria-multiselectable="true" style="margin-bottom: 0px;">
								<div class="panel panel-default">
									<div class="panel-heading" role="tab" id="headingOne_1">
										<h4 class="panel-title">
											<a role="button" data-toggle="collapse" data-parent="#accordion_1" href="#collapseOne_1" aria-expanded="false" aria-controls="collapseOne_1">
												<i class="material-icons">expand_more</i> Opções Avançadas
											</a>
										</h4>
									</div>
									<div id="collapseOne_1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne_1">
										<div class="panel-body">
										
											<div class="col-sm-6 col-md-4">
												<p><b>Ramais</b></p>
												<div class="col-sm-12">
													<select name="ramais[]" id="ramais" class="form-control show-tick" multiple>
													<?php
														foreach($ramais_sip as $key=>$value) {
															print "<option value=\"".$key."\" ".(in_array("".$key ,$filtroramais)?"selected=\"selected\"":"").">SIP/".$key."</option>";
														}
														foreach($ramais_iax2 as $key=>$value) {
															print "<option value=\"".$key."\" ".(in_array("".$key ,$filtroramais)?"selected=\"selected\"":"").">IAX2/".$key."</option>";
														}
													?>
													</select>
												</div>
												<p><b>Filas</b></p>
												<div class="col-sm-12">
													<select name="filas[]" id="filas" class="form-control show-tick" multiple>
													<?php
														foreach($filas as $key=>$value) {
															print "<option value=\"".$key."\" ".(in_array($key ,$filtrofilas)?"selected=\"selected\"":"").">QUE/".$key."</option>";
														}
													?>
													</select>
												</div>
												<p><b>Troncos</b></p>
												<div class="col-sm-12">
													<select name="troncos[]" id="troncos" class="form-control show-tick" multiple>
													<?php
														foreach($troncos as $value) {
															print "<option value=\"".$value."\" ".(in_array($value ,$filtrotroncos)?"selected=\"selected\"":"").">".$value."</option>";
														}
													?>
													</select>
												</div>
												<p><b>Contabil</b></p>
												<div class="col-sm-12">
													<select name="codigos[]" id="codigos" class="form-control show-tick" multiple>
													<?php
														foreach($codigos as $key=>$value) {
															print "<option value=\"".$key."\" ".(in_array("".$key ,$filtrocodigos)?"selected=\"selected\"":"").">".$key."</option>";
														}
													?>
													</select>
												</div>
											</div>

											<div class="col-sm-6 col-md-4">
												<div class="row clearfix">
													<div class="col-sm-6">
														<select name="condicaonumero" id="condicaonumero" class="form-control show-tick">
															<option value="igual" <?=(@$_REQUEST['condicaonumero'] == "igual"?'selected="selected"':"");?> >Igual</option>
															<option value="contem" <?=(@$_REQUEST['condicaonumero'] == "contem"?'selected="selected"':"");?> >Contém</option>
														</select>
													</div>
													<div class="col-sm-6">
														<div class="form-group form-float" style="margin-bottom:0px">
															<div class="form-line">
																<input name="numero" id="numero" type="text" class="form-control" <?=(@$numero?'value="'.$numero.'"':"");?> />
																<label class="form-label">Número</label>
															</div>
														</div>
													</div>
												</div>
												<div class="form-group form-float">
													<div class="form-line">
														<input name="ddr" id="ddr" type="text" class="form-control" <?=(@$ddr?'value="'.$ddr.'"':"");?> />
														<label class="form-label">DDR</label>
													</div>
												</div>
												<div class="form-group form-float">
													<div class="form-line">
														<input name="protocolo" id="protocolo" type="text" class="form-control" <?=(@$protocolo?'value="'.$protocolo.'"':"");?> />
														<label class="form-label">Protocolo</label>
													</div>
												</div>
												<div class="form-group form-float">
													<div class="form-line">
														<input name="cidade" id="cidade" type="text" class="form-control" <?=(@$cidade?'value="'.$cidade.'"':"");?> />
														<label class="form-label">Cidade</label>
													</div>
												</div>
											</div>

											<div class="col-sm-6 col-md-4">
												<p><b>Espera</b></p>
												<div class="col-sm-6">
													<select name="condicaoespera" id="condicaoespera" class="form-control show-tick">
														<option <?=(@$_REQUEST['condicaoespera'] == "Maior"?'selected="selected"':"");?> >Maior</option>
														<option <?=(@$_REQUEST['condicaoespera'] == "Menor"?'selected="selected"':"");?> >Menor</option>
														<option <?=(@$_REQUEST['condicaoespera'] == "Igual"?'selected="selected"':"");?> >Igual</option>
													</select>
												</div>
												<div class="col-sm-6">
													<div class="form-group form-float" style="margin-bottom:0px">
														<div class="form-line">
															<input name="tempoespera" id="tempoespera" type="text" class="form-control" <?=(@$espera?'value="'.$espera.'"':"");?> />
															<label class="form-label">tempo (s)</label>
														</div>
													</div>
												</div>

												<p><b>Duração</b></p>
												<div class="col-sm-6">
													<select name="condicaoduracao" id="condicaoduracao" class="form-control show-tick">
														<option <?=(@$_REQUEST['condicaoduracao'] == "Maior"?'selected="selected"':"");?> >Maior</option>
														<option <?=(@$_REQUEST['condicaoduracao'] == "Menor"?'selected="selected"':"");?> >Menor</option>
														<option <?=(@$_REQUEST['condicaoduracao'] == "Igual"?'selected="selected"':"");?> >Igual</option>
													</select>
												</div>
												<div class="col-sm-6">
													<div class="form-group form-float" style="margin-bottom:0px">
														<div class="form-line">
															<input name="tempoduracao" id="tempoduracao" type="text" class="form-control" <?=(@$duracao?'value="'.$duracao.'"':"");?> />
															<label class="form-label">tempo (s)</label>
														</div>
													</div>
												</div>
												
												<p><b>Tipo</b></p>
												<div class="col-sm-12">
													<select name="tipo[]" id="tipo" class="form-control show-tick" multiple>
													<?php
														if ($tipo_disponivel != "") {
															print $tipo_disponivel;
														}
													?>
													</select>
												</div>
												<p><b>Status</b></p>
												<div class="col-sm-12">
													<select name="status[]" id="status" class="form-control show-tick" multiple>
													<?php
														if ($status_disponivel != "") {
															print $status_disponivel;
														}
													?>
													</select>
												</div>
											</div>

										</div>
									</div>
								</div>
							</div>
						</div>
						<!--FIM OPÇÕES AVANÇADAS-->
						</form>
						<!--FIM FORMULÁRIO-->
					</div>
				</div>
			</div>
		</div>
		<!-- #END# Bloco de Pesquisa -->


		<!-- Total e Tempo -->
		<div class="row clearfix">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<div class="card">
					<div class="header">
						<h2>Resumo</h2>
					</div>
					<div class="body">
						<div class="row clearfix">
							<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
								<h4>Total</h4>
								<p>Total: <?=$resumo['total'];?> ligações</p>
								<p>Tempo em Atendimento: <?=$resumo['tempo_chamada'];?></p>
								<p>Tempo em Espera: <?=$resumo['tempo_espera'];?></p>
								<p>Tempo Total: <?=$resumo['tempo_total'];?></p>
							</div>
							<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
								<h4>Entrada</h4>
								<p>Atendidas: <?=$resumo['entrada_atendidas'];?></br>
								Não Atendidas: <?=$resumo['entrada_abandonadas'];?></p>
								<p>Tempo em Atendimento: <?=$resumo['entrada_tempo_chamada'];?></p>
								<p>Tempo em Espera: <?=$resumo['entrada_tempo_espera'];?></p>
								<p>Tempo Total: <?=$resumo['entrada_tempo_total'];?></p>
							</div>
							<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
								<h4>Saída</h4>
								<p>Completadas: <?=$resumo['saida_atendidas'];?></br>
								Não Atendidas: <?=$resumo['saida_abandonadas'];?></p>
								<p>Tempo em Atendimento: <?=$resumo['saida_tempo_chamada'];?></p>
								<p>Tempo em Espera: <?=$resumo['saida_tempo_espera'];?></p>
								<p>Tempo Total: <?=$resumo['saida_tempo_total'];?></p>
							</div>
							<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
								<h4>Interno</h4>
								<p>Completadas: <?=$resumo['interno_atendidas'];?></br>
								Não Atendidas: <?=$resumo['interno_abandonadas'];?></p>
								<p>Tempo em Atendimento: <?=$resumo['interno_tempo_chamada'];?></p>
								<p>Tempo em Espera: <?=$resumo['interno_tempo_espera'];?></p>
								<p>Tempo Total: <?=$resumo['interno_tempo_total'];?></p>
							</div>
						</div>
						<div class="row clearfix">
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<p><b>TME</b>: <?=$resumo['tme'];?> - <b>TMA</b>: <?=$resumo['tma'];?> - <b>TMC</b>: <?=$resumo['tmc'];?></p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	<!-- #END# Tempo de ligação -->


	<!--Fila Analítico - Exportable Table -->
		<div class="row clearfix">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="card">
					<div class="body">
						<div class="table-responsive">
							<table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination2">
								<thead>
									<tr>
										<th>Data</th>
										<th>DDR</th>
										<th>Origem</th>
										<th>Destino</th>
										<th>Tipo</th>
										<th>Espera</th>
										<th>Duração</th>
										<th>Status</th>
										<th>Cidade</th>
										<th>Protocolo</th>
										<th>Gravação</th>
									</tr>
								</thead>
								<tbody>
					<?php
					$lastLinkedid = "";
					$lastColor = "";
					$color = "";
					foreach ($relatorio as $value){
					?>
						<tr>
							<td><?=date('d/m/Y H:i:s',strtotime($value['calldate']));?></td>
							<td><?=$value['ddr'];?></td> 
							<td><?=$value['origem'];?></td>
							<td><?=$value['destino'];?></td>
							<td><?=$value['tipo'];?></td> 
							<td><?=$value['espera'];?></td>
							<td><?=$value['duracao'];?></td>
							<td>
							<?php
								switch ($value['status']) {
								case "Atendido":
									echo '<span class="badge bg-green">';
									break;
								case "Ocupado":
									echo '<span class="badge bg-deep-orange">';
									break;
								case "Não atendido":
									echo '<span class="badge bg-amber">';
									break;
								case "Cancelada":
									echo '<span class="badge bg-grey">';
									break;
								case "Congestionado":
									echo '<span class="badge bg-deep-orange">';
									break;
								case "Indisponivel":
									echo '<span class="badge bg-red">';
									break;
								default:
									echo '<span class="badge bg-grey">';
									break;
								}
							?>
							<?=$value['status'];?></span></td>
							<td><?=$value['cidade'];?></td>
							<?php
								if ($value['linkedid'] != $lastLinkedid) {
									$lastColor = $color;
									do {
										$color = $colors[rand(0,12)];
									} while ($lastColor == $color);
								}
								$lastLinkedid = $value['linkedid'];
							?>
							<td><span class="badge <?=$color;?>"><?=$value['linkedid'];?></span></td>
							<?php
								if ($value['audio']) {
							?>
								<td>
									<a href="javascript:;" class="play" data-url="/download.php?file=<?=$value['audio'];?>&data=<?=date('Y-m-d',strtotime($value['calldate']));?>" onclick="loadModalAudio('<?=$value['audio'];?>')" data-toggle="modal" data-target="#defaultModal" ><i class="material-icons" title="Ouvir a gravação">play_arrow</i></a>
									&nbsp;
									<a href="/download.php?file=<?=$value['audio'];?>&data=<?=date('Y-m-d',strtotime($value['calldate']));?>"><i class="material-icons" title="Clique aqui para baixar a gravação no seu computador">file_download</i></a>
								</td>
							<?php
								} else {
								echo "<td></td>";
								}
							?>
						</tr>
					<?php
					}
					?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- #END# Exportable Table -->


	<!-- Modal Dialogs ====================================================================================================================== -->
		<!-- Modal AudioPlayer -->
		<div class="modal fade" id="defaultModal" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="defaultModalLabel">Ouvindo Gravação</h4>
					</div>
					<div class="modal-body">
						<div id="audioerror"></div>
						<div id="audioplayer"></div>

						<div style="float:left;" id="audioCurrent">00:00:00</div>
						<div align="right" style="float:right;" id="audioDuration">00:00:00</div>
						<p></br></p>

						<div class="row clearfix">
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8" style="padding-right:0px;">
								<button type="button" id="audioplay" class="btn btn-default waves-effect">
									<i class="material-icons">play_arrow</i>
								</button>
								<button type="button" id="audiopause" class="btn btn-default waves-effect">
									<i class="material-icons">pause</i>
								</button>
								<i style="float:right;padding-top:6px" class="material-icons">volume_up</i>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4" style="padding-top:10px;">
								<div id="volumeControl"></div>
							</div>
						</div>
						<div class="row clearfix">
							<div class="col-xs-12" style="padding-top:10px;">
								<p id="nameAudio">Arquivo</p>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" id="closemodal" class="btn btn-link waves-effect" data-dismiss="modal">Fechar</button>
					</div>
				</div>
			</div>
		</div>


	</div>
    <!--#END of PAGE CONTENT-->

<script>

function data_click() {
    //$('#inputPeriodo').prop('disabled', 'disabled');
    $('[data-id="inputPeriodo"]').prop('disabled', 'disabled');
    $('#data_inicial').prop('disabled', false);
    $('#data_final').prop('disabled', false);
    $('#hora_inicial').prop('disabled', false);
    $('#hora_final').prop('disabled', false);
}
function periodo_click() {
    //$('#inputPeriodo').prop('disabled', false);
    $('[data-id="inputPeriodo"]').prop('disabled', false);
    $('#data_inicial').prop('disabled', 'disabled');
    $('#data_final').prop('disabled', 'disabled');
    $('#hora_inicial').prop('disabled', 'disabled');
    $('#hora_final').prop('disabled', 'disabled');
}

function loadModalAudio(audio) {
	$('#nameAudio').text("Arquivo: "+audio);
}

$(document).ready(function(){
	if ("<?=$radio_Data;?>" == "checked") {
		data_click();
	}
});

$( "#data_inicial" ).datepicker({
	dateFormat: "dd/mm/yy",
	locale: 'pt-br'
});

$( "#data_final" ).datepicker({
	dateFormat: "dd/mm/yy",
	locale: 'pt-br'
});

$(function() {
	var wavesurfer = WaveSurfer.create({
		container: '#audioplayer',
		waveColor: '#448CCC',
		progressColor: 'cyan'
	});

	$('[data-url]').on('click', function(event) {
		event.preventDefault();

		wavesurfer.load(
			$(this).data('url')
		);

		document.getElementById("audioerror").innerHTML = "";

		wavesurfer.on('ready', function () {
		wavesurfer.play();
		var duration = formatSeconds(wavesurfer.getDuration());
		document.getElementById("audioDuration").innerHTML = duration;

		setInterval(function() {
			var current = formatSeconds(wavesurfer.getCurrentTime());
			document.getElementById("audioCurrent").innerHTML = current;
		}, 1000);

		});
	});

	wavesurfer.on('error', function () {
	    document.getElementById("audioerror").innerHTML = "Ocorreu um erro na abertura do arquivo!";
	});

	$('#closemodal').click(function() {
		wavesurfer.stop();
	});
	$('#audioplay').click(function() {
		wavesurfer.play();
	});
	$('#audiopause').click(function() {
		wavesurfer.pause();
	});

	var sliderBasic = document.getElementById('volumeControl');
    	noUiSlider.create(sliderBasic, {
		start: [100],
        	connect: 'lower',
        	step: 1,
        	range: {
            		'min': [0],
            		'max': [100]
        	}
    	});
    	getNoUISliderValue(sliderBasic, true);

	function getNoUISliderValue(slider) {
		slider.noUiSlider.on('update', function () {
			var val = slider.noUiSlider.get()
			wavesurfer.setVolume(val/100);
		});
	}

});

function formatSeconds(seconds)
{
	var date = new Date(null);
	date.setSeconds(seconds);
	var days = date.toISOString().substr(8, 2) - 1;
	if (days == 0) {
		return date.toISOString().substr(11, 8);
	} else {	
		return (date.toISOString().substr(8, 2) - 1) + 'd ' + date.toISOString().substr(11, 8);
	}
}

</script>