<?php
	require_once("config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.ini.php");
	require_once(DIR_WWW."funcoes/funcoes.arquivos.php");
	require_once(DIR_WWW."funcoes/funcoes.config.ramal.php");
	require_once(DIR_WWW."funcoes/funcoes.db.php");
	require_once(DIR_WWW."funcoes/funcoes.relatorios.sintetico.php");
	
	require_once(DIR_WWW."funcoes/funcoes.ramais.config_e1.php"); //PARA OBTER TRONCOS G1, G2, etc.
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.rotas_saida.php"); //TRONCOS
	
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_sip.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_iax2.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.filas.php");

	//DATA E HORA ================================================================================
	if (isset($_REQUEST['data_inicial']) && $_REQUEST['data_inicial'] != "") {
		$data_inicial = $_REQUEST['data_inicial'];
	} else {
		$data_inicial = date("d/m/Y");
	}
	
	if (isset($_REQUEST['data_final']) && $_REQUEST['data_final'] != "") {
		$data_final = $_REQUEST['data_final'];
	} else {
		$data_final = date("d/m/Y");
	}

	if (isset($_REQUEST['hora_inicial']) && $_REQUEST['hora_inicial'] != "") {
		$hora_inicial = $_REQUEST['hora_inicial'];
	} else {
		$hora_inicial = "00:00";
	}
	
	if (isset($_REQUEST['hora_final']) && $_REQUEST['hora_final'] != "") {
		$hora_final = $_REQUEST['hora_final'];
	} else {
		$hora_final = "23:59";
	}

	if (isset($_REQUEST['input_Data']) && $_REQUEST['input_Data'] == "periodo") {
		$atalho = $_REQUEST['inputPeriodo'];
		switch ($_REQUEST['inputPeriodo']) {
			case "hoje" :
				$data_inicial = date("d/m/Y");
				$data_final = date("d/m/Y");
			break;
			
			case "ontem" :
				$timestamp = strtotime("-1 days");
				$data_inicial = date("d/m/Y", $timestamp);
				$data_final = date("d/m/Y", $timestamp);
			break;
			
			case "semana" :
				$timestamp = strtotime(sprintf("-%s days", date('w')));
				$data_inicial = date("d/m/Y", $timestamp);
				$data_final = date("d/m/Y");
			break;
			
			case "mes" :
				$data_inicial = "01/".date("m/Y");
				$data_final = date("d/m/Y");
			break;
			
			case "trimestre" :
				$timestamp = strtotime("-3 months");
				$data_inicial = date("d/m/Y", $timestamp);
				$data_final = date("d/m/Y");
			break;

			case "semestre" :
				$timestamp = strtotime("-6 months");
				$data_inicial = date("d/m/Y", $timestamp);
				$data_final = date("d/m/Y");
			break;

			case "ano" :
				$timestamp = strtotime("-12 months");
				$data_inicial = date("d/m/Y", $timestamp);
				$data_final = date("d/m/Y");
			break;
		}
	} else {
		$atalho = "";
	}

	$tmp1 = explode("/",$data_inicial);
	$data_inicial_mysql = $tmp1[2]."-".$tmp1[1]."-".$tmp1[0]." ".$hora_inicial.":00";
	$data_inicial_1 = $tmp1[2]."-".$tmp1[1]."-".$tmp1[0];
	$tmp1 = explode("/",$data_final);
	$data_final_mysql = $tmp1[2]."-".$tmp1[1]."-".$tmp1[0]." ".$hora_final.":59";
	$data_final_1 = $tmp1[2]."-".$tmp1[1]."-".$tmp1[0];

	if (isset($_REQUEST['input_Data']) && $_REQUEST['input_Data'] == "data") {
		$radio_Data = "checked";
		$radio_Periodo = "";
	} else {
		$radio_Data = "";
		$radio_Periodo = "checked";
	}
	
	$txtwhere = "";
	$sql = new conexao();
	//TRONCOS =============================================================================================================
	$troncos = get_troncos();
	
	if (isset($_REQUEST['troncos'])) {
		$filtrotroncos = $_REQUEST['troncos'];
	} else {
		$filtrotroncos = array();
		$filtrotroncos[] = "";
	}
	
	if (strlen($filtrotroncos[0]) > 1) {
		$txtwhere .= " and (";
		foreach ($filtrotroncos as $k=>$value) {
			if ($k != 0) {
				$txtwhere .= " or ";
			}
			$txtwhere .= "tronco = '".$value."'";
		}
		$txtwhere .= ")";
	}
	
	//$cidades = get_cidades();
	//$codigos_ddd = get_cod_area();
	
	//RAMAIS ==============================================================================================================
	$ramais_sip = get_ramais();
	$ramais_iax2 = get_ramais_iax();
	
	if (isset($_REQUEST['ramais'])) {
		$filtroramais = $_REQUEST['ramais'];
	} else {
		$filtroramais = array();
		$filtroramais[] = "";
	}
	
	if (strlen($filtroramais[0]) > 1) {
		$txtwhere .= " and (";
		foreach ($filtroramais as $k=>$value) {
			if ($k != 0) {
				$txtwhere .= " or ";
			}
			$txtwhere .= "origem = '".$value."' or destino = '".$value."'";
		}
		$txtwhere .= ")";
	}

	//FILAS ===============================================================================================================
	
	$filas = get_filas();

	if (isset($_REQUEST['filas'])) {
		$filtrofilas = $_REQUEST['filas'];
	} else {
		$filtrofilas = array();
		$filtrofilas[] = "";
	}
	
	if (strlen($filtrofilas[0]) > 1) {
		$lista_filas = "'".implode("', '", $filtrofilas)."'";
		$txtwhere .= " and queue in (".$lista_filas.")";
	}

	//TIPO ============================================================================================================

	$vtipo = array("IN", "OUT", "INTERNO");

	if (isset($_REQUEST['tipo'])) {
		$filtrotipo = $_REQUEST['tipo'];
	} else {
		$filtrotipo = array();
		$filtrotipo[] = "";
	}

	$tipo_disponivel = "";
	foreach($vtipo as $valor) {
		if (in_array ( $valor,$filtrotipo)) {
			$tipo_disponivel .= "<option value=\"".$valor."\" selected=\"selected\">".$valor."</option>".PHP_EOL; 
		} else {
			$tipo_disponivel .= "<option value=\"".$valor."\">".$valor."</option>".PHP_EOL;
		}
	}
	
	if (strlen($filtrotipo[0]) > 1) {
		$lista_tipo = "'".implode("', '", $filtrotipo)."'";
		$txtwhere .= " and tipo in (".$lista_tipo.")";
	}

	//STATUS =============================================================================================================

	$vstatus = array(
		'Atendido' => 'ANSWER', 
		'Ocupado' => 'BUSY', 
		'Não atendido' => 'NOANSWER', 
		'Congestionado' => 'CONGESTION', 
		'Cancelada' => 'CANCEL', 
		'Indisponível' => 'CHANUNAVAIL',
		'Falhou' => 'FAILED'
	);

	if (isset($_REQUEST['status'])) {
		$filtrostatus = $_REQUEST['status'];
	} else {
		$filtrostatus = array();
		$filtrostatus[] = "";
	}

	$status_disponivel = "";
	foreach($vstatus as $key=>$valor) {
		if ( in_array($valor, $filtrostatus) ) {
			$status_disponivel .= "<option value=\"".$valor."\" selected=\"selected\">".$key."</option>".PHP_EOL; 
		} else {
			$status_disponivel .= "<option value=\"".$valor."\">".$key."</option>".PHP_EOL;
		}
	}
	
	if (strlen($filtrostatus[0]) > 1) {
		$lista_status = "'".implode("', '", $filtrostatus)."'";
		$txtwhere .= " and status in (".$lista_status.")";
	}

	//CAMPOS NÚMERO, DDR, TRF E PROTOCOLO ================================================================================

	if (isset($_REQUEST['numero']) and $_REQUEST['numero'] != "") {
		$numero = mysqli_real_escape_string($sql->conexao, $_REQUEST['numero']);
		if ($_REQUEST['condicaonumero'] == "igual") {
			$txtwhere .= ' and (origem = "'.$numero.'" or destino = "'.$numero.'") ';
		} elseif ($_REQUEST['condicaonumero'] == "contem") {
			$txtwhere .= ' and (origem LIKE "%'.$numero.'%" or destino LIKE "%'.$numero.'%") ';
		}
	}

	if (isset($_REQUEST['ddr']) And $_REQUEST['ddr'] != "") {
		$ddr = mysqli_real_escape_string($sql->conexao, $_REQUEST['ddr']);
		$txtwhere .= ' and ddr LIKE "%'.$ddr.'%" ';
	}

	if (isset($_REQUEST['trf']) and $_REQUEST['trf'] != "") {
		$trf = mysqli_real_escape_string($sql->conexao, $_REQUEST['trf']);
		$txtwhere .= ' and trf LIKE "%'.$trf.'%" ';
	}
	
	if (isset($_REQUEST['protocolo']) and $_REQUEST['protocolo'] != "") {
		$protocolo = mysqli_real_escape_string($sql->conexao, $_REQUEST['protocolo']);
		$txtwhere .= ' and linkedid LIKE "'.$protocolo.'%" ';
	}

	//CAMPOS ESPERA E DURAÇÃO ============================================================================================

	if (isset($_REQUEST['tempoespera']) and is_numeric($_REQUEST['tempoespera'])) {
		$espera = mysqli_real_escape_string($sql->conexao, $_REQUEST['tempoespera']);
		if ($_REQUEST['condicaoespera'] == "Maior") {
			$txtwhere .= ' and `holdtime` >= '.$espera.' ';
		} elseif ($_REQUEST['condicaoespera'] == "Menor") {
			$txtwhere .= ' and `holdtime` <= '.$espera.' ';
		} elseif ($_REQUEST['condicaoespera'] == "Igual") {
			$txtwhere .= ' and `holdtime` = '.$espera.' ';
		}
	}

	if (isset($_REQUEST['tempoduracao']) and is_numeric($_REQUEST['tempoduracao'])) {
		$duracao = mysqli_real_escape_string($sql->conexao, $_REQUEST['tempoduracao']);
		if ($_REQUEST['condicaoduracao'] == "Maior") {
			$txtwhere .= ' and `callduration` >= '.$duracao.' ';
		} elseif ($_REQUEST['condicaoduracao'] == "Menor") {
			$txtwhere .= ' and `callduration` <= '.$duracao.' ';
		} elseif ($_REQUEST['condicaoduracao'] == "Igual") {
			$txtwhere .= ' and `callduration` = '.$duracao.' ';
		}
	}

	//Cidade =============================================================================================================
	
	if (isset($_REQUEST['cidade']) And $_REQUEST['cidade'] != "") {
		$cidade = mysqli_real_escape_string($sql->conexao, $_REQUEST['cidade']);
		$txtwhere .= ' and cidade LIKE "%'.$cidade.'%" ';
	}

	//FUNCOES E RESULTADOS ===============================================================================================

	$txtwhere_entrada = $txtwhere." and tipo = 'IN'";
	$txtwhere_saida = $txtwhere." and tipo = 'OUT'";
	$total_entrada = total_entrada($txtwhere,$data_inicial_mysql,$data_final_mysql);
		//Array ( [completecaller] => 393 [completeagent] => 431 [transfer] => 227 [abandon] => 138 )
	$chamadas_hora_entrada = chamadas_hora($txtwhere_entrada,$data_inicial_mysql,$data_final_mysql);
		//[entrada_atendidas] => 15 [abandonadas] => 0 [hora] => 08:00

	$total_saida = total_saida($txtwhere,$data_inicial_mysql,$data_final_mysql);
		//Array ( [completecaller] => 0 [completeagent] => 285 [transfer] => 1 [abandon] => 175 )
	$chamadas_hora_saida = chamadas_hora($txtwhere_saida,$data_inicial_mysql,$data_final_mysql);
		//[completadas] => 15 [abandonadas] => 0 [hora] => 08:00

	if ($data_inicial_1 != $data_final_1) {
		$chamadas_dia_entrada = chamadas_dia($txtwhere_entrada,$data_inicial_1,$data_final_1);
			//Array ( [entrada_atendidas] => 688 [abandonadas] => 106 [ano] => 2018 [mes] => 1 [dia] => 15 [data] => 15/01/2018 )
		$chamadas_dia_saida = chamadas_dia($txtwhere_saida,$data_inicial_1,$data_final_1);
	}
	
?>

    <script src="plugins/raphael/raphael.min.js"></script>
    <script src="plugins/morrisjs/morris.js"></script>
    <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/prettify/r224/prettify.min.js"></script>-->
    <script src="plugins/prettify/prettify.min.js"></script>

	<!--PAGE CONTENT-->
	<div class="container-fluid">

		<!-- Bloco de Pesquisa -->
		<div class="row clearfix">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<div class="card">
					<div class="row clearfix">
						<div class="col-xs-12 col-sm-6">
							<ol class="breadcrumb">
								<li>NUCLEAR PABX IP</li>
								<li><?=$pagina_nome;?></li>
								<li class="active"><?=$menu_nome;?></li>
							</ol>
						</div>
					</div>
					<div class="body">
						<!--Formulário-->
						<form id="filtro-filas" method="post">
						<?=$text_form;?>
						<div class="row clearfix">
							<div class="col-sm-6 col-md-2">
								<input name="input_Data" type="radio" onclick="periodo_click()" id="radio_Periodo" class="radio-col-blue" value="periodo" <?=$radio_Periodo;?> />
								<label for="radio_Periodo">Por Período</label>
							</div>
							<div class="col-sm-6 col-md-2">
								<select name="inputPeriodo" id="inputPeriodo" class="form-control show-tick" class="form-control show-tick">
									<option value="hoje">Hoje</option>
									<option value="ontem">Ontem</option>
									<option value="semana">Semana</option>
									<option value="mes">Mês</option>
									<option value="trimestre">Trimestre</option>
									<option value="semestre">Semestre</option>
									<option value="ano">Ano</option>
								</select>
							</div>
							<div class="col-sm-6 col-md-4">
								<input name="input_Data" type="radio" onclick="data_click()" id="radio_Data" class="radio-col-blue" value="data" <?=$radio_Data;?> />
								<label for="radio_Data">Por Data</label>
								<div class="demo-masked-input">
									<div class="col-md-6">
										<b>Data inicial</b>
										<div class="input-group">
											<span class="input-group-addon">
												<i class="material-icons">date_range</i>
											</span>
											<div class="form-line">
												<input type="text" name="data_inicial" id="data_inicial" class="form-control date" value="<?=$data_inicial;?>" disabled="disabled">
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<b>Data Final</b>
										<div class="input-group">
											<span class="input-group-addon">
												<i class="material-icons">date_range</i>
											</span>
											<div class="form-line">
												<input type="text" name="data_final" id="data_final" class="form-control date" value="<?=$data_final;?>" disabled="disabled">
											</div>
										</div>
									</div>
								</div>
								<div class="demo-masked-input">
									<div class="col-md-6">
										<b>Hora Inicial</b>
										<div class="input-group">
											<span class="input-group-addon">
												<i class="material-icons">access_time</i>
											</span>
											<div class="form-line">
												<input type="text" name="hora_inicial" id="hora_inicial" class="form-control time24" value="<?=$hora_inicial;?>" placeholder="Ex: 00:00" disabled="disabled">
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<b>Hora Final</b>
										<div class="input-group">
											<span class="input-group-addon">
												<i class="material-icons">access_time</i>
											</span>
											<div class="form-line">
												<input type="text" name="hora_final" id="hora_final" class="form-control time24" value="<?=$hora_final;?>" placeholder="Ex: 23:59" disabled="disabled">
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-6 col-md-4">
								<!--NUCLEAR FILAS-->
							</div>
							<div style="align-self: flex-end; margin-right: 15px">
								<button id="btnPesquisar" type="submit" class="btn bg-default waves-effect pull-right">
									<i class="material-icons">search</i>
									<span>PESQUISAR</span>
								</button>
							</div>
						</div>

						<!--OPÇÕES AVANÇADAS-->
						<div class="row clearfix">
							<div class="panel-group" id="accordion_1" role="tablist" aria-multiselectable="true" style="margin-bottom: 0px;">
								<div class="panel panel-default">
									<div class="panel-heading" role="tab" id="headingOne_1">
										<h4 class="panel-title">
											<a role="button" data-toggle="collapse" data-parent="#accordion_1" href="#collapseOne_1" aria-expanded="false" aria-controls="collapseOne_1">
												<i class="material-icons">expand_more</i> Opções Avançadas
											</a>
										</h4>
									</div>
									<div id="collapseOne_1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne_1">
										<div class="panel-body">
										
											<div class="col-sm-6 col-md-4">
												<p><b>Ramais</b></p>
												<div class="col-sm-12">
													<select name="ramais[]" id="ramais" class="form-control show-tick" multiple>
													<?php
														foreach($ramais_sip as $key=>$value) {
															print "<option value=\"".$key."\" ".(in_array("".$key ,$filtroramais)?"selected=\"selected\"":"").">SIP/".$key."</option>";
														}
														foreach($ramais_iax2 as $key=>$value) {
															print "<option value=\"".$key."\" ".(in_array("".$key ,$filtroramais)?"selected=\"selected\"":"").">IAX2/".$key."</option>";
														}
													?>
													</select>
												</div>
												<p><b>Filas</b></p>
												<div class="col-sm-12">
													<select name="filas[]" id="filas" class="form-control show-tick" multiple>
													<?php
														foreach($filas as $key=>$value) {
															print "<option value=\"".$key."\" ".(in_array($key ,$filtrofilas)?"selected=\"selected\"":"").">QUE/".$key."</option>";
														}
													?>
													</select>
												</div>
												<p><b>Troncos</b></p>
												<div class="col-sm-12">
													<select name="troncos[]" id="troncos" class="form-control show-tick" multiple>
													<?php
														foreach($troncos as $value) {
															print "<option value=\"".$value."\" ".(in_array($value ,$filtrotroncos)?"selected=\"selected\"":"").">".$value."</option>";
														}
													?>
													</select>
												</div>
											</div>

											<div class="col-sm-6 col-md-4">
												<div class="row clearfix">
													<div class="col-sm-6">
														<select name="condicaonumero" id="condicaonumero" class="form-control show-tick">
															<option value="igual" <?=(@$_REQUEST['condicaonumero'] == "igual"?'selected="selected"':"");?> >Igual</option>
															<option value="contem" <?=(@$_REQUEST['condicaonumero'] == "contem"?'selected="selected"':"");?> >Contém</option>
														</select>
													</div>
													<div class="col-sm-6">
														<div class="form-group form-float" style="margin-bottom:0px">
															<div class="form-line">
																<input name="numero" id="numero" type="text" class="form-control" <?=(@$numero?'value="'.$numero.'"':"");?> />
																<label class="form-label">Número</label>
															</div>
														</div>
													</div>
												</div>
												<div class="form-group form-float">
													<div class="form-line">
														<input name="ddr" id="ddr" type="text" class="form-control" <?=(@$ddr?'value="'.$ddr.'"':"");?> />
														<label class="form-label">DDR</label>
													</div>
												</div>
												<div class="form-group form-float">
													<div class="form-line">
														<input name="trf" id="trf" type="text" class="form-control" <?=(@$trf?'value="'.$trf.'"':"");?> />
														<label class="form-label">TRF</label>
													</div>
												</div>
												<div class="form-group form-float">
													<div class="form-line">
														<input name="protocolo" id="protocolo" type="text" class="form-control" <?=(@$protocolo?'value="'.$protocolo.'"':"");?> />
														<label class="form-label">Protocolo</label>
													</div>
												</div>
												<div class="form-group form-float">
													<div class="form-line">
														<input name="cidade" id="cidade" type="text" class="form-control" <?=(@$cidade?'value="'.$cidade.'"':"");?> />
														<label class="form-label">Cidade</label>
													</div>
												</div>
											</div>

											<div class="col-sm-6 col-md-4">
												<p><b>Espera</b></p>
												<div class="col-sm-6">
													<select name="condicaoespera" id="condicaoespera" class="form-control show-tick">
														<option <?=(@$_REQUEST['condicaoespera'] == "Maior"?'selected="selected"':"");?> >Maior</option>
														<option <?=(@$_REQUEST['condicaoespera'] == "Menor"?'selected="selected"':"");?> >Menor</option>
														<option <?=(@$_REQUEST['condicaoespera'] == "Igual"?'selected="selected"':"");?> >Igual</option>
													</select>
												</div>
												<div class="col-sm-6">
													<div class="form-group form-float" style="margin-bottom:0px">
														<div class="form-line">
															<input name="tempoespera" id="tempoespera" type="text" class="form-control" <?=(@$espera?'value="'.$espera.'"':"");?> />
															<label class="form-label">tempo (s)</label>
														</div>
													</div>
												</div>

												<p><b>Duração</b></p>
												<div class="col-sm-6">
													<select name="condicaoduracao" id="condicaoduracao" class="form-control show-tick">
														<option <?=(@$_REQUEST['condicaoduracao'] == "Maior"?'selected="selected"':"");?> >Maior</option>
														<option <?=(@$_REQUEST['condicaoduracao'] == "Menor"?'selected="selected"':"");?> >Menor</option>
														<option <?=(@$_REQUEST['condicaoduracao'] == "Igual"?'selected="selected"':"");?> >Igual</option>
													</select>
												</div>
												<div class="col-sm-6">
													<div class="form-group form-float" style="margin-bottom:0px">
														<div class="form-line">
															<input name="tempoduracao" id="tempoduracao" type="text" class="form-control" <?=(@$duracao?'value="'.$duracao.'"':"");?> />
															<label class="form-label">tempo (s)</label>
														</div>
													</div>
												</div>
												
												<p><b>Tipo</b></p>
												<div class="col-sm-12">
													<select name="tipo[]" id="tipo" class="form-control show-tick" multiple>
													<?php
														if ($tipo_disponivel != "") {
															print $tipo_disponivel;
														}
													?>
													</select>
												</div>
												<p><b>Status</b></p>
												<div class="col-sm-12">
													<select name="status[]" id="status" class="form-control show-tick" multiple>
													<?php
														if ($status_disponivel != "") {
															print $status_disponivel;
														}
													?>
													</select>
												</div>
											</div>

										</div>
									</div>
								</div>
							</div>
						</div>
						<!--FIM OPÇÕES AVANÇADAS-->

						</form>
						<!--FIM FORMULÁRIO-->
					</div>
				</div>
			</div>
		</div>
		<!-- #END# Bloco de Pesquisa -->


		<!-- Chamadas Total -->
		<div class="row clearfix">
			<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
				<div class="card">
					<div class="header">
						<h2 title="Total de chamadas de entrada">Total - Entrada</h2>
					</div>
					<div class="body">
						<div id="total-entrada" class="graph"></div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
				<div class="card">
					<div class="header">
						<h2 title="Total de chamadas realizadas">Total - Saída</h2>
					</div>
					<div class="body">
						<div id="total-saida" class="graph"></div>
					</div>
				</div>
			</div>
		</div>
		<!-- #END# Chamadas Total -->

		<!-- Filas Total -->
		<div class="row clearfix">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<div class="card">
					<div class="header">
						<h2 title="Valores totais e porcentagens">Estatísticas</h2>
					</div>
					<div class="body">
					<?php
					if ($total_entrada['entrada_atendidas'] >= 1) {
						$completadas_entrada = round ($total_entrada['entrada_atendidas'] / $total_entrada['total'] * 100, 2);
						$abandonadas_entrada = round ($total_entrada['entrada_abandonadas'] / $total_entrada['total'] * 100, 2);
						//$completeagent = round ($total_entrada['completeagent'] / $total_entrada['total'] * 100, 2);
						//$completecaller = round ($total_entrada['completecaller'] / $total_entrada['total'] * 100, 2);
						//$transfer = round ($total_entrada['transfer'] / $total_entrada['total'] * 100, 2);
					?>
						<h4>Total Entrada: </h4>
						<p>Total: <span class="badge bg-light-blue"><?=$total_entrada['total'];?></span></p>
						<p>Atendidas: <?=$total_entrada['entrada_atendidas'];?> <span class="badge bg-teal"><?=$completadas_entrada;?>%</span> - Abandonadas: <?=$total_entrada['entrada_abandonadas'];?> <span class="badge bg-red"><?=$abandonadas_entrada;?>%</span></p>
						<p><br/></p>
					<?php
					}
					if (isset($total_saida['saida_atendidas'])) {
						$completadas_saida = round ($total_saida['saida_atendidas'] / $total_saida['total'] * 100, 2);
						$abandonadas_saida = round ($total_saida['saida_abandonadas'] / $total_saida['total'] * 100, 2);
					?>
						<h4>Total Saída: </h4>
						<p>Total: <span class="badge bg-light-blue"><?=$total_saida['total'];?></span></p>
						<p>Completadas: <?=$total_saida['saida_atendidas'];?> <span class="badge bg-teal"><?=$completadas_saida;?>%</span> - Não atendidas: <?=$total_saida['saida_abandonadas'];?> <span class="badge bg-red"><?=$abandonadas_saida;?>%</span></p>
					<?php
					}
					?>
					</div>
				</div>
			</div>
		</div>
		<!-- #END# Filas Total -->

		<!--Resumo Estatísticas - Entrada Exportable Table -->
		<div class="row clearfix">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="card">
					<div class="header">
						<h2>Resumo - Estatísticas</h2>
					</div>
					<div class="body">
						<div class="table-responsive">
							<table class="table table-bordered table-striped table-hover dataTable js-exportable">
								<thead>
									<tr>
										<th>-</th>
										<th>Ligações</th>
										<th>Porcentagem</th>
									</tr>
								</thead>
								<tbody>
					<?php
						if ($total_entrada['total'] >= 1) {
					?>
						<tr>
							<td>Total Entrada</td>
							<td>-</td>
							<td>-</td>
						</tr>
						<tr>
							<td>Total</td>
							<td><?=$total_entrada['total'];?></td>
							<td><span class="badge bg-light-blue">100%</span></td>
						</tr>
						<tr>
							<td>Atendidas</td>
							<td><?=$total_entrada['entrada_atendidas'];?></td>
							<td><span class="badge bg-teal"><?=$completadas_entrada;?>%</span></td>
						</tr>
						<tr>
							<td>Abandonadas</td>
							<td><?=$total_entrada['entrada_abandonadas'];?></td>
							<td><span class="badge bg-red"><?=$abandonadas_entrada;?>%</span></td>
						</tr>
					<?php
						}
						if (isset($total_saida['total']) && $total_saida['total'] != 0) {
					?>
						<tr>
							<td>Total Saída</td>
							<td>-</td>
							<td>-</td>
						</tr>
						<tr>
							<td>Total</td>
							<td><?=$total_saida['total'];?></td>
							<td><span class="badge bg-light-blue">100%</span></td>
						</tr>
						<tr>
							<td>Completadas</td>
							<td><?=$total_saida['saida_atendidas'];?></td>
							<td><span class="badge bg-teal"><?=$completadas_saida;?>%</span></td>
						</tr>
						<tr>
							<td>Não atendidas</td>
							<td><?=$total_saida['saida_abandonadas'];?></td>
							<td><span class="badge bg-red"><?=$abandonadas_saida;?>%</span></td>
						</tr>
					<?php
						}
					?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
        <!-- #END# Exportable Table -->

		<!-- Tempo de ligação -->
		<div class="row clearfix">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<div class="card">
					<div class="header">
						<h2>Tempo de ligação</h2>
					</div>
					<div class="body">
						<div class="row clearfix">
						<?php
							if (isset($total_entrada['tempo_total']) && @$total_entrada['tempo_total'] != "00:00:00") {
						?>
							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<h4>Entrada: </h4>
								<p>Tempo em Chamada: <?=$total_entrada['tempo_chamada'];?></p>
								<p>Tempo em Espera: <?=$total_entrada['tempo_espera'];?></p>
								<p>Tempo Total: <?=$total_entrada['tempo_total'];?></p>
								<p><b>TME</b>: <?=$total_entrada['tme'];?> - <b>TMA</b>: <?=$total_entrada['tma'];?> - <b>TMC</b>: <?=$total_entrada['tmc'];?></p>
							</div>
						<?php
							}
							if (isset($total_saida['tempo_total']) && @$total_saida['tempo_total'] != "00:00:00") {
						?>
							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<h4>Saída: </h4>
								<p>Tempo em Chamada: <?=$total_saida['tempo_chamada'];?></p>
								<p>Tempo em Espera: <?=$total_saida['tempo_espera'];?></p>
								<p>Tempo Total: <?=$total_saida['tempo_total'];?></p>
								<p><b>TME</b>: <?=$total_saida['tme'];?> - <b>TMA</b>: <?=$total_saida['tma'];?> - <b>TMC</b>: <?=$total_saida['tmc'];?></p>
							</div>
						<?php
							}
						?>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- #END# Tempo de ligação -->


<?php
	if (isset($chamadas_hora_entrada[0]['hora'])) {
?>

		<!-- Ligacoes por hora - Entrada-->
		<div class="row clearfix">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<div class="card">
					<div class="header">
						<h2>Chamadas por Hora - Entrada</h2>
					</div>
					<div class="body">
						<div id="chamadas-hora-entrada" class="graph"></div>
					</div>
				</div>
			</div>
		</div>
		<!-- #END# Ligacoes por hora - Entrada -->


		<!--Ligacoes por Hora - Entrada Exportable Table -->
		<div class="row clearfix">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="card">
					<div class="header">
						<h2>Chamadas por Hora - Entrada</h2>
					</div>
					<div class="body">
						<div class="table-responsive">
							<table class="table table-bordered table-striped table-hover dataTable js-exportable">
								<thead>
									<tr>
										<th>Hora</th>
										<th>Atendidas</th>
										<th>%</th>
										<th>Abandonadas</th>
										<th>%</th>
									</tr>
								</thead>
								<tbody>
								<?php
								foreach ($chamadas_hora_entrada as $value){
									$completadas = round($value['completadas']/($value['completadas']+$value['abandonadas'])*100, 2);
									$abandonadas = round($value['abandonadas']/($value['completadas']+$value['abandonadas'])*100, 2);
								?>
									<tr>
										<td><?=$value['hora'];?></td>
										<td><?=$value['completadas'];?></td> 
										<td><span class="badge bg-teal"><?=$completadas;?>%</span></td>
										<td><?=$value['abandonadas'];?></td> 
										<td><span class="badge bg-red"><?=$abandonadas;?>%</span></td>
									</tr>
								<?php
								}
								?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- #END# Exportable Table -->
<?php
	}
	if (isset($chamadas_hora_saida[0]['hora'])) {
?>
		<!-- Ligacoes por hora - Saída-->
		<div class="row clearfix">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<div class="card">
					<div class="header">
						<h2>Chamadas por Hora - Saída</h2>
					</div>
					<div class="body">
						<div id="chamadas-hora-saida" class="graph"></div>
					</div>
				</div>
			</div>
		</div>
		<!-- #END# Ligacoes por hora - Saída -->

		<!--Ligacoes por Hora - Saída Exportable Table -->
		<div class="row clearfix">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="card">
					<div class="header">
						<h2>Chamadas por Hora - Saída</h2>
					</div>
					<div class="body">
						<div class="table-responsive">
							<table class="table table-bordered table-striped table-hover dataTable js-exportable">
								<thead>
									<tr>
										<th>Hora</th>
										<th>Completadas</th>
										<th>%</th>
										<th>Não Atendidas</th>
										<th>%</th>
									</tr>
								</thead>
								<tbody>
					<?php
					foreach ($chamadas_hora_saida as $value){
						$completadas = round($value['completadas']/($value['completadas']+$value['abandonadas'])*100, 2);
						$abandonadas = round($value['abandonadas']/($value['completadas']+$value['abandonadas'])*100, 2);
					?>
						<tr>
							<td><?=$value['hora'];?></td>
							<td><?=$value['completadas'];?></td>
							<td><span class="badge bg-teal"><?=$completadas;?>%</span></td>
							<td><?=$value['abandonadas'];?></td>
							<td><span class="badge bg-red"><?=$abandonadas;?>%</span></td>
						</tr>
					<?php
					}
					?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- #END# Exportable Table -->
<?php
	}
	if (isset($chamadas_dia_entrada[0]['data'])) {
?>

		<!-- Ligacoes por Dia - Entrada-->
		<div class="row clearfix">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<div class="card">
					<div class="header">
						<h2>Chamadas por Dia - Entrada</h2>
					</div>
					<div class="body">
						<div id="chamadas-dia-entrada" class="graph"></div>
					</div>
				</div>
			</div>
		</div>
		<!-- #END# Ligacoes por dia - Entrada-->


		<!--Ligacoes por Dia - Entrada Exportable Table -->
		<div class="row clearfix">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="card">
					<div class="header">
						<h2>Chamadas por dia - Entrada</h2>
					</div>
					<div class="body">
						<div class="table-responsive">
							<table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination">
								<thead>
									<tr>
										<th>Data</th>
										<th>Atendidas</th>
										<th>%</th>
										<th>Abandonadas</th>
										<th>%</th>
									</tr>
								</thead>
								<tbody>
								<?php
								foreach ($chamadas_dia_entrada as $value){
									$completadas = round($value['completadas']/($value['completadas']+$value['abandonadas'])*100, 2);
									$abandonadas = round($value['abandonadas']/($value['completadas']+$value['abandonadas'])*100, 2);
								?>
									<tr>
										<td><?=$value['data'];?></td>
										<td><?=$value['completadas'];?></td>
										<td><span class="badge bg-teal"><?=$completadas;?>%</span></td>
										<td><?=$value['abandonadas'];?></td>
										<td><span class="badge bg-red"><?=$abandonadas;?>%</span></td>
									</tr>
								<?php
								}
								?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- #END# Exportable Table -->
<?php
	}
	if (isset($chamadas_dia_saida[0]['data'])) {
?>
		<!-- Ligacoes por Dia - Saída-->
		<div class="row clearfix">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<div class="card">
					<div class="header">
						<h2>Chamadas por Dia - Saída</h2>
					</div>
					<div class="body">
						<div id="chamadas-dia-saida" class="graph"></div>
					</div>
				</div>
			</div>
		</div>
		<!-- #END# Ligacoes por dia - Saída-->


		<!--Ligacoes por Dia - Saída Exportable Table -->
		<div class="row clearfix">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="card">
					<div class="header">
						<h2>Chamadas por dia - Saída</h2>
					</div>
					<div class="body">
						<div class="table-responsive">
							<table class="table table-bordered table-striped table-hover dataTable js-exportable-pagination">
								<thead>
									<tr>
										<th>Data</th>
										<th>Completadas</th>
										<th>%</th>
										<th>Não Atendidas</th>
										<th>%</th>
									</tr>
								</thead>
								<tbody>
								<?php
								foreach ($chamadas_dia_saida as $value){
									$completadas = round($value['completadas']/($value['completadas']+$value['abandonadas'])*100, 2);
									$abandonadas = round($value['abandonadas']/($value['completadas']+$value['abandonadas'])*100, 2);
								?>
									<tr>
										<td><?=$value['data'];?></td>
										<td><?=$value['completadas'];?></td>
										<td><span class="badge bg-teal"><?=$completadas;?>%</span></td>
										<td><?=$value['abandonadas'];?></td>
										<td><span class="badge bg-red"><?=$abandonadas;?>%</span></td>
									</tr>
								<?php
								}
								?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- #END# Exportable Table -->
<?php
	}
?>


	</div>
	<!--#END of PAGE CONTENT-->

<script>

function data_click() {
    //$('#inputPeriodo').prop('disabled', 'disabled');
    $('[data-id="inputPeriodo"]').prop('disabled', 'disabled');
    $('#data_inicial').prop('disabled', false);
    $('#data_final').prop('disabled', false);
    $('#hora_inicial').prop('disabled', false);
    $('#hora_final').prop('disabled', false);
}
function periodo_click() {
    //$('#inputPeriodo').prop('disabled', false);
    $('[data-id="inputPeriodo"]').prop('disabled', false);
    $('#data_inicial').prop('disabled', 'disabled');
    $('#data_final').prop('disabled', 'disabled');
    $('#hora_inicial').prop('disabled', 'disabled');
    $('#hora_final').prop('disabled', 'disabled');
}

$(document).ready(function(){
	if ("<?=$radio_Data;?>" == "checked") {
		data_click();
	}
});

$( "#data_inicial" ).datepicker({
	dateFormat: "dd/mm/yy",
	locale: 'pt-br'
});

$( "#data_final" ).datepicker({
	dateFormat: "dd/mm/yy",
	locale: 'pt-br'
});


$("#total-entrada").css("height","320");

var data_total_entrada = [
<?php
	if (strlen($total_entrada['total']) >= 1) {
		echo "{ label: 'Atendidas', a: ".$total_entrada['entrada_atendidas']."},";
		echo "{ label: 'Abandonadas', a: ".$total_entrada['entrada_abandonadas']."},";
	} else {
		echo "{ label: 'n/a', a: 0},";
	}
?>
    ],
    config_total_entrada = {
	xkey: 'label',
	ykeys: ['a'],
	labels: ['Valor'],
	xLabelMargin: 0,
	fillOpacity: 0.6,
	hideHover: 'auto',
	behaveLikeLine: true,
	resize: true,
	pointFillColors:['#ffffff'],
	pointStrokeColors: ['black'],
	barColors: function (row, series, type) {
		console.log("--> "+row.label, series, type);
		if(row.label == "Atendidas") return "#448CCC";
		else if(row.label == "Abandonadas") return "#317589";
	}
  };
  
config_total_entrada.element = 'total-entrada';
config_total_entrada.data = data_total_entrada;
Morris.Bar(config_total_entrada);

/*
$("#total-entrada-detalhada").css("height","320");

var data_total_entrada = [
<?php
	if (strlen($total_entrada['entrada_atendidas']) >= 1) {
		echo "{ label: 'Finalizadas Agente', a: ".$total_entrada['completeagent']."},";
		echo "{ label: 'Finalizadas Chamador', a: ".$total_entrada['completecaller']."},";
		echo "{ label: 'Transferidas', a: ".$total_entrada['transfer']."},";
	} else {
		echo "{ label: 'n/a', a: 0},";
	}
?>
    ],
    config_total_entrada = {
	xkey: 'label',
	ykeys: ['a'],
	labels: ['Valor'],
	xLabelMargin: 0,
	fillOpacity: 0.6,
	hideHover: 'auto',
	behaveLikeLine: true,
	resize: true,
	pointFillColors:['#ffffff'],
	pointStrokeColors: ['black'],
	barColors: function (row, series, type) {
		console.log("--> "+row.label, series, type);
		if(row.label == "Finalizadas Agente") return "#448CCC";
		else if(row.label == "Finalizadas Chamador") return "#89C4F4";
		else if(row.label == "Transferidas") return "#317589";
	}
  };
  
config_total_entrada.element = 'total-entrada-detalhada';
config_total_entrada.data = data_total_entrada;
Morris.Bar(config_total_entrada);
*/

$("#total-saida").css("height","320");

var data_total_saida = [
<?php
	if (isset($total_saida['saida_atendidas'])) {
		echo "{ label: 'Completadas', a: ".$total_saida['saida_atendidas']."},";
		echo "{ label: 'Não Atendidas', a: ".$total_saida['saida_abandonadas']."},";
	} else {
		echo "{ label: 'n/a', a: 0},";
	}
?>
    ],
    config_total_saida = {
	xkey: 'label',
	ykeys: ['a'],
	labels: ['Valor'],
	xLabelMargin: 0,
	fillOpacity: 0.6,
	hideHover: 'auto',
	behaveLikeLine: true,
	resize: true,
	pointFillColors:['#ffffff'],
	pointStrokeColors: ['black'],
	barColors: function (row, series, type) {
		console.log("--> "+row.label, series, type);
		if(row.label == "Completadas") return "#448CCC";
		else if(row.label == "Não Atendidas") return "#317589";
		else if(row.label == "n/a") return "#317589";
	}
  };
  
config_total_saida.element = 'total-saida';
config_total_saida.data = data_total_saida;
Morris.Bar(config_total_saida);


<?php
	if (isset($chamadas_hora_entrada[0]['hora'])) {
?>
$("#chamadas-hora-entrada").css("height","320");

var data_hora_entrada = [
<?php
	foreach ($chamadas_hora_entrada as $value){
		echo "{ hora: '".$value['hora']."', a: ".$value['completadas'].", b: ".$value['abandonadas']."},";
	}
?>
    ],
    config_hora_entrada = {
	xkey: 'hora',
	ykeys: ['a', 'b'],
	labels: ['Atendidas', 'Abandonadas'],
	xLabelMargin: 0,
	fillOpacity: 0.7,
	hideHover: 'auto',
	behaveLikeLine: true,
	resize: true,
	parseTime: false,
	pointFillColors:['#ffffff'],
	pointStrokeColors: ['black'],
	lineColors:["#448CCC","#317589"]
  };
  
config_hora_entrada.element = 'chamadas-hora-entrada';
config_hora_entrada.data = data_hora_entrada;
Morris.Area(config_hora_entrada);
<?php
	}
?>


<?php
	if (isset($chamadas_hora_saida[0]['hora'])) {
?>
$("#chamadas-hora-saida").css("height","320");

var data_hora_saida = [
<?php
	foreach ($chamadas_hora_saida as $value){
		echo "{ hora: '".$value['hora']."', a: ".$value['completadas'].", b: ".$value['abandonadas']."},";
	}
?>
    ],
    config_hora_saida = {
	xkey: 'hora',
	ykeys: ['a', 'b'],
	labels: ['Completadas', 'Não Atendidas'],
	xLabelMargin: 0,
	fillOpacity: 0.7,
	hideHover: 'auto',
	behaveLikeLine: true,
	resize: true,
	parseTime: false,
	pointFillColors:['#ffffff'],
	pointStrokeColors: ['black'],
	lineColors:["#448CCC","#317589"]
  };
  
config_hora_saida.element = 'chamadas-hora-saida';
config_hora_saida.data = data_hora_saida;
Morris.Area(config_hora_saida);
<?php
	}
?>


<?php
	if (isset($chamadas_dia_entrada[0]['data'])) {
?>
$("#chamadas-dia-entrada").css("height","320");

var data_dia_entrada = [
<?php
	foreach ($chamadas_dia_entrada as $value){
		echo "{ data: '".$value['data']."', a: ".$value['completadas'].", b: ".$value['abandonadas']."},";
	}
?>
    ],
    config_dia_entrada = {
	xkey: 'data',
	ykeys: ['a', 'b'],
	labels: ['Atendidas', 'Abandonadas'],
	xLabelAngle: 35,
	xLabelMargin: 0,
	fillOpacity: 0.7,
	hideHover: 'auto',
	behaveLikeLine: true,
	resize: true,
	parseTime: false,
	pointFillColors:['#ffffff'],
	pointStrokeColors: ['black'],
	lineColors:["#448CCC","#317589"]
  };
  
config_dia_entrada.element = 'chamadas-dia-entrada';
config_dia_entrada.data = data_dia_entrada;
Morris.Area(config_dia_entrada);
<?php
	}
?>


<?php
	if (isset($chamadas_dia_saida[0]['data'])) {
?>
$("#chamadas-dia-saida").css("height","320");

var data_dia_saida = [
<?php
	foreach ($chamadas_dia_saida as $value){
		echo "{ data: '".$value['data']."', a: ".$value['completadas'].", b: ".$value['abandonadas']."},";
	}
?>
    ],
    config_dia_saida = {
	xkey: 'data',
	ykeys: ['a', 'b'],
	labels: ['Completadas', 'Não Atendidas'],
	xLabelAngle: 35,
	xLabelMargin: 0,
	fillOpacity: 0.7,
	hideHover: 'auto',
	behaveLikeLine: true,
	resize: true,
	parseTime: false,
	pointFillColors:['#ffffff'],
	pointStrokeColors: ['black'],
	lineColors:["#448CCC","#317589"]
  };
  
config_dia_saida.element = 'chamadas-dia-saida';
config_dia_saida.data = data_dia_saida;
Morris.Area(config_dia_saida);
<?php
	}
?>

</script>