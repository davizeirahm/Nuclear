<?php

	require_once("../config/inc_fileconf.php");
	require_once(DIR_WWW."funcoes/funcoes.db.php");
	require_once(DIR_WWW."funcoes/funcoes.aplicativos.agendar.php");

	$retorno = array();

	if (!empty($_POST)) {

		$numero = $_POST['numero'];
		$ramal = $_POST['ramal'];

		//$file = shell_exec('sudo /root/scripts/agenda.sh "'.$numero.'" "'.$ramal.'"');
		log_agendar($ramal,$numero);
		originateAsterisk($ramal,$numero);

		$retorno["status"] = "OK";
		print json_encode($retorno);
	} else {
		$retorno["status"] = "ERRO";
		print json_encode($retorno);
	}

?>