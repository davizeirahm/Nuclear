<?php

	require_once(DIR_WWW."funcoes/funcoes.crm.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_sip.php");
	require_once(DIR_WWW."funcoes/funcoes.pbxconfig.filas.php");
	
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_sip.php");
	require_once(DIR_WWW."funcoes/funcoes.ramais.ramais_iax2.php");
	
	//VARIAVEIS ==========================================================================================================
	
	$ramais_sip = get_ramais();
	$ramais_iax2 = get_ramais_iax();
	
	$ramaissip = get_ramais();
	$ramaisCcenter = array();
	foreach($ramaissip as $key=>$value) {
		if ($value['tipoRamal'] == 'yes') {
			$ramaisCcenter[] = $key;
		}
	}
	//print_r($ramaisCcenter);
	
	$filas = get_filas();
	$pausas = get_pausas();

	$filasCcenter = array();
	foreach($filas as $key=>$value) {
		if ($value['tipoFila'] == 'yes') {
			$filasCcenter[] = $key;
		}
	}
	//print_r($filasCcenter);
	
	//REDEFINIR SENHA ===================================================
	
	if (isset($_POST['cmd']) && $_POST['cmd'] == "redefinirSenha") {
		//print_r($_POST);
		//die();
		$erro = "";
		if ( !isset($_SESSION['idagente']) || @$_SESSION['idagente'] == "" ) {
			$erro = "Erro: Agente inválido!";
		}
		if (!isset($_SESSION["agent"]) || @$_SESSION["agent"] == "") {
			$erro = "Erro: Agente inválido!";
		}
		if (!isset($_POST['senha']) || @$_POST['senha'] == "") {
			$erro = "Erro: Senha inválida!";
		}
		if ($erro != "") {
			print "<script type='text/javascript'>
				alert('".$erro."');
				document.location.assign('?pagina=inicial');
			</script>";
			die();
		}
		
		if ( !nova_senha($_SESSION['idagente'],$_SESSION['agent'],$_POST['senha']) ) {
			print "<script>
				alert('Erro ao salvar as configurações!');
				document.location.assign('?pagina=inicial');
			</script>";
			die();
		} else {
			print "<script>
				alert('Configurações salvas com sucesso!');
				document.location.assign('?pagina=inicial');
			</script>";
			die();
		}
	}
	
?>

	<!--PAGE CONTENT-->
		<div class="container-fluid">
			<!-- Primeira linha -->
			<div class="row clearfix">
				<div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
			<?php
				if ($_SESSION['agendar'] == 1) {
			?>
				<!--<div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">-->
					<div class="card" id="agendar_chamada">
						<div class="body">
							<form class="form" id="formAgendarLigacao">
								<h4 id="titulo">Agendar Chamada</h4>
								<div class="row clearfix">
                                    <div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="agendar_numero">Número</label>
                                    </div>
                                    <div class="col-md-4 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="numero" id="agendar_numero" class="form-control numero" >
                                            </div>
                                        </div>
                                    </div>
									<div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
                                        <label for="agendar_ramal">Ramal</label>
                                    </div>
                                    <div class="col-md-4 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
										<div class="form-group form-float" style="margin-bottom: 0px;">
											<select name="ramal" id="agendar_ramal" class="form-control show-tick" data-live-search="true">
												<option value=""> - </option>
												<?php
													foreach($ramais_sip as $key=>$value) {
														print "<option value=\"".$key."\">SIP/".$key."</option>";
													}
													foreach($ramais_iax2 as $key=>$value) {
														print "<option value=\"".$key."\">IAX2/".$key."</option>";
													}
												?>
											</select>
										</div>
                                    </div>
								</div>
								
									<button type="submit" class="btn btn-primary waves-effect" id="agendarLigacao-btn">
										<i class="material-icons">send</i>
										<span>Ligar</span>
									</button>
								
							</form>
						</div>
					</div>
				<!--</div>-->
			<?php
				}
			?>
				<!-- Em branco ?CRM? -->
				<!--<div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">-->
					<div class="card">
						<div class="body">
							<div id="ligacao" class="row clearfix" hidden>
								
							</div>
						</div>
					</div>
				</div>
				<!-- Login Status Agente -->
				<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
					<div class="card">
						<div class="body">
							<div class="row clearfix">
								<div id="pause" hidden>
									<div class="info-box-4">
										<div class="icon">
											<i class="material-icons col-red">pause</i>
										</div>
										<div class="content">
											<div class="text">EM PAUSA</div>
											<div class="number" id="pauseCounter">00:00:00</div>
										</div>
									</div>
									<div class="col-xs-12">
										<button onclick="botaoUnpauseAgente();" class="btn btn-primary waves-effect">
											<i class="material-icons">play_arrow</i>
											<span>Retornar</span>
										</button>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-xs-12">
									<button data-toggle="modal" data-target="#pauseAgenteModal" class="btn btn-primary waves-effect">
										<i class="material-icons">pause</i>
										<span>Pausar</span>
									</button>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-xs-12">
									<button data-toggle="modal" data-target="#loginAgenteModal" class="btn btn-primary waves-effect">
										<i class="material-icons">edit</i>
										<span>Editar Login</span>
									</button>
								</div>
							</div>
						</div>
					</div>
					
					<div class="panel-group" id="filasRealtime" role="tablist" aria-multiselectable="true">
						
					</div>
				</div>
			</div>
			<!--#END of Primeira linha -->
		</div>
	<!--#END of PAGE CONTENT-->
		
	<!-- MODAL ================================================================================================================================== -->
		
		<!--MODAL REDEFINIR SENHA-->
		<div class="modal fade" id="redefinirSenhaModal" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h2 class="modal-title" id="redefinirSenhaLabel">Redefinir Senha</h2>
					</div>
					<div class="modal-body">
						<div class="demo-masked-input">
						<form id="formRedefinirSenha" method="post">
						<!-- <input type="hidden" name="pagina" value="pbxconfig" /> -->
						<!-- <input type="hidden" name="menu" value="agentes" /> -->
						<input type="hidden" name="cmd" value="redefinirSenha" />
						<!-- <input type="hidden" id="editarAgente" name="id" value="" /> -->

							<div class="row clearfix">
								<div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
									<label for="senha_redefinirSenha">Senha</label>
								</div>
								<div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
									<div class="form-group">
										<div class="form-line">
											<input type="password" name="senha" id="senha_redefinirSenha" class="form-control">
										</div>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-2 col-sm-3 col-xs-5 form-control-label" style="margin-bottom: 0px;">
									<label for="confSenha_redefinirSenha">Confirmar Senha</label>
								</div>
								<div class="col-md-10 col-sm-9 col-xs-7" style="margin-bottom: 0px;">
									<div class="form-group">
										<div class="form-line">
											<input type="password" name="confSenha" id="confSenha_redefinirSenha" class="form-control">
										</div>
									</div>
								</div>
							</div>
						</form>
						</div>
					</div>
					<div class="modal-footer">
						<button onclick="botaoRedefinirSenha();" class="btn btn-primary waves-effect">
							<i class="material-icons">save</i>
							<span>Salvar</span>
						</button>
						<button type="button" id="closeRedefinirSenhaModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
					</div>
						
				</div>
			</div>
		</div>
	    <!--#END of MODAL REDEFINIR SENHA-->
		
		
		<!--MODAL SOLICITAR PAUSA-->
		<div class="modal fade" id="pauseAgenteModal" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h2 class="modal-title" id="pauseAgenteLabel">Solicitar Pausa</h2>
					</div>
					<div class="modal-body">
						<div class="demo-masked-input">
						<form id="formPauseAgente" method="post">
						<!-- <input type="hidden" name="pagina" value="pbxconfig" /> -->
						<!-- <input type="hidden" name="menu" value="agentes" /> -->
						<input type="hidden" name="cmd" value="pauseAgente" />
						<!-- <input type="hidden" id="editarAgente" name="id" value="" /> -->

							<div class="row clearfix">
								<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
									<label>Motivo</label>
								</div>
								<div class="col-md-10 col-sm-6 col-xs-7">
									<div class="form-group form-float" >
										<select name="pausa" id="pausa_pauseAgente" class="form-control show-tick">
										<?php
											foreach($pausas as $key=>$value) {
												print "<option value=\"".$value."\">".$value."</option>";
											}
										?>
										</select>
									</div>
								</div>
							</div>
						</form>
						</div>
					</div>
					<div class="modal-footer">
						<button onclick="botaoPauseAgente();" class="btn btn-primary waves-effect">
							<i class="material-icons">pause</i>
							<span>Pausar</span>
						</button>
						<button type="button" id="closePauseAgenteModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
					</div>
						
				</div>
			</div>
		</div>
	    <!--#END of MODAL SOLICITAR PAUSA-->
		
		
		<!--MODAL LOGIN AGENTE-->
		<div class="modal fade" id="loginAgenteModal" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h2 class="modal-title" id="loginAgenteLabel">Login</h2>
					</div>
					<div class="modal-body">
						<div class="demo-masked-input">
						<form id="formLoginAgente" method="post">
						<!-- <input type="hidden" name="pagina" value="pbxconfig" /> -->
						<!-- <input type="hidden" name="menu" value="agentes" /> -->
						<input type="hidden" name="cmd" value="loginAgente" />
						<!-- <input type="hidden" id="editarAgente" name="id" value="" /> -->

							<div class="row clearfix">
								<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
									<label>Ramal</label>
								</div>
								<div class="col-md-10 col-sm-6 col-xs-7">
									<div class="form-group form-float" >
										<select name="ramal" id="ramal_loginAgente" class="form-control show-tick">
										<?php
											foreach($ramaisCcenter as $key=>$value) {
												print "<option value=\"".$value."\">SIP/".$value."</option>";
											}
										?>
										</select>
									</div>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-md-2 col-sm-6 col-xs-5 form-control-label">
									<label>Filas</label>
								</div>
								<div class="col-md-10 col-sm-6 col-xs-7">
									<div class="form-group form-float" >
										<select name="fila[]" id="fila_loginAgente" class="form-control show-tick" multiple>
										<?php
											foreach($filasCcenter as $key=>$value) {
												print "<option value=\"".$value."\">".$value."</option>";
											}
										?>
										</select>
									</div>
								</div>
							</div>
						</form>
						</div>
					</div>
					<div class="modal-footer">
						<button onclick="botaoLoginAgente();" class="btn btn-primary waves-effect">
							<i class="material-icons">done</i>
							<span>Login</span>
						</button>
						<button type="button" id="closeLoginAgenteModal" class="btn btn-link waves-effect" data-dismiss="modal">Cancelar</button>
					</div>
						
				</div>
			</div>
		</div>
	    <!--#END of MODAL LOGIN AGENTE-->

<script>

	var senha_padrao = '<?=$_SESSION["senha_padrao"];?>';

	function botaoRedefinirSenha() {
		if ( ($("#senha_redefinirSenha").val() == "123456") || ($("#senha_redefinirSenha").val() != $("#confSenha_redefinirSenha").val()) ) {
			alert("Senha incorreta! Confira os dados");
		} else if ( $("#senha_redefinirSenha").val().length < 6) {
			alert("Senha deve possuir 6 ou mais caracteres!");
		} else {
			$("#formRedefinirSenha").submit();
		}
	}
	
	function botaoLoginAgente() {
		//console.log('<?=$_SESSION['agent'];?>');
		//console.log($("#ramal_loginAgente").val());
		var filas = [];
		filas = $("#fila_loginAgente").val();
		//console.log(filas);
		
		if (!$("#fila_loginAgente").val()) {
			//swal("Erro!", "Nenhuma fila selecionada", "error");
			alert("TESTE");
		} else {
			socket.emit('cliente unpause', {
				agente: '<?=$_SESSION['agent'];?>'
			});
			socket.emit('cliente login', {
				agente: '<?=$_SESSION['agent'];?>',
				ramal: $("#ramal_loginAgente").val(),
				fila: filas
			});
		}
	}
	
	function botaoPauseAgente() {
		socket.emit('cliente pause', {
			agente: '<?=$_SESSION['agent'];?>',
			motivo: $("#pausa_pauseAgente").val()
		});
	}
	
	function botaoUnpauseAgente() {
		paused = false;
		socket.emit('cliente unpause', {
			agente: '<?=$_SESSION['agent'];?>'
		});
	}

	$(document).ready(function(){
		if (senha_padrao != '') {
			//Se a senha for 123456 altera força a alteração de senha
			$("#redefinirSenhaModal").modal();
		} else {
			//Verifica se o agente esta logado e faz o login
			socket.emit('check agente', {
				agente: '<?=$_SESSION['agent'];?>'
			});
			socket.on('log in', function() {
				$("#loginAgenteModal").modal();
			});
		}
	});
	
	$("#formAgendarLigacao").submit(function() {
		event.preventDefault();
		$.ajax({
			url: "/pages_crm/process.agendar.php",
			type: "post",
			data: {
				numero : $("#agendar_numero").val(),
				ramal: $("#agendar_ramal").val()
			},
			dataType: 'json', 
			success: function(msg, textStatus, jqXHR) {
				if (msg.status == 'OK') {
					$("#agendar_numero").val('');
					$("#agendar_ramal").val('');
				} else 
				if (msg.status == 'ERRO') {
					alert("Não foi possível realizar a ligação");
				}
			},
			error: function(erro) {
				alert("Error");
			}
		});
	});

</script>