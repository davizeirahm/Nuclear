<?php

	// A sessão precisa ser iniciada em cada página diferente
	if (!isset($_SESSION)) session_start();
      
	// Verifica se não há a variável da sessão que identifica o usuário
 	if (!isset($_SESSION['nome'])) {
		// Destrói a sessão por segurança
		session_destroy();
		// Redireciona o visitante de volta pro login
		header("Location: nuclearlogin.php"); 
		exit;
	}

$retorno = shell_exec("sudo /root/scripts/backup.sh");
		
$retorno = chop($retorno);
			
if ($retorno == "OK") {
	
	$filename = "/tmp/backup-pbxerix-".date('Y-m-d').".erix"; 
				
	if (!file_exists($filename)) { 
		print "<script type='text/javascript'>
			alert(\"Erro ao gerar backup.\");
			document.location.assign('index.php?pagina=sistema&menu=backup');
			</script>";
		die();
	}

	$tamanho = filesize($filename);				
	header('Content-Type: application/zip');
	header('Content-Disposition: attachment; filename='.basename($filename));
	header('Content-Length: ' . $tamanho);
	ob_clean();
	flush();
	readfile($filename);

	unlink($filename);
				
} else {
	print "<script type='text/javascript'>
			alert(\"Erro ao tentar fazer download! Não foi possível criar o backup.\");
			document.location.assign('index.php?pagina=sistema&menu=backup');
		</script>";
	die();
}

?>